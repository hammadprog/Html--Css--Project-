import {
    G as ae,
    c as se,
    r as X,
    g as Zt,
    a as Jt,
    j as R,
    F as er,
    b as tr,
    d as rr,
    e as nr,
    f as ir,
    h as or,
    m as ie,
    P as Qe,
    H as ar
} from "./index-cplxNlKn.js";

function lr(r) {
    return ae({
        tag: "svg",
        attr: {
            role: "img",
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M24 18.588a1.529 1.529 0 01-1.895-.72l-3.45-4.771-.5-.667-4.003 5.444a1.466 1.466 0 01-1.802.708l5.158-6.92-4.798-6.251a1.595 1.595 0 011.9.666l3.576 4.83 3.596-4.81a1.435 1.435 0 011.788-.668L21.708 7.9l-2.522 3.283a.666.666 0 000 .994l4.804 6.412zM.002 11.576l.42-2.075c1.154-4.103 5.858-5.81 9.094-3.27 1.895 1.489 2.368 3.597 2.275 5.973H1.116C.943 16.447 4.005 19.009 7.92 17.7a4.078 4.078 0 002.582-2.876c.207-.666.548-.78 1.174-.588a5.417 5.417 0 01-2.589 3.957 6.272 6.272 0 01-7.306-.933 6.575 6.575 0 01-1.64-3.858c0-.235-.08-.455-.134-.666A88.33 88.33 0 010 11.577zm1.127-.286h9.654c-.06-3.076-2.001-5.258-4.59-5.278-2.882-.04-4.944 2.094-5.071 5.264z"
            },
            child: []
        }]
    })(r)
}

function sr(r) {
    return ae({
        tag: "svg",
        attr: {
            role: "img",
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M18.665 21.978C16.758 23.255 14.465 24 12 24 5.377 24 0 18.623 0 12S5.377 0 12 0s12 5.377 12 12c0 3.583-1.574 6.801-4.067 9.001L9.219 7.2H7.2v9.596h1.615V9.251l9.85 12.727Zm-3.332-8.533 1.6 2.061V7.2h-1.6v6.245Z"
            },
            child: []
        }]
    })(r)
}

function ur(r) {
    return ae({
        tag: "svg",
        attr: {
            role: "img",
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M23.4337 7.344c-.5641-.7664-1.469-1.2197-2.4343-1.2197H13.999L11.9993 12h4.8377l-1.9998 5.8755H9.9995l-1.9997 5.8755h9.0001c1.2912 0 2.438-.8086 2.8466-2.0088L23.846 9.9922c.3049-.8957.1518-1.8807-.4123-2.647Zm-13.434 4.655H7.1618l1.9997-5.8756h4.8378l2.001-5.8743H7c-1.2912 0-2.438.8086-2.8466 2.0089L.154 14.0079c-.3049.8956-.1518 1.8807.4123 2.647.5641.7663 1.469 1.2196 2.4343 1.2196h7.0004l1.9998-5.8755H10.001z"
            },
            child: []
        }]
    })(r)
}

function cr(r) {
    return ae({
        tag: "svg",
        attr: {
            role: "img",
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M8.32 0c-3.922 0-5.882 0-7.1 1.219C0 2.438 0 4.399 0 8.32v7.36c0 3.922 0 5.882 1.219 7.101C2.438 24 4.399 24 8.32 24h7.36c3.922 0 5.882 0 7.101-1.219C24 21.562 24 19.601 24 15.68V8.32c0-3.922 0-5.882-1.219-7.101C21.562 0 19.601 0 15.68 0H8.32zm.41 7.28h7.83a.16.16 0 0 1 .16.16v7.83h-3.87v-3.71a.41.41 0 0 0-.313-.398l-.086-.012h-3.72V7.28zm-.5.25v3.87H4.553a.08.08 0 0 1-.057-.136L8.23 7.529zm.25 4.12h3.87v3.87H8.64a.16.16 0 0 1-.16-.16v-3.71zm4.12 4.12h3.87l-3.734 3.734a.08.08 0 0 1-.136-.057V15.77z"
            },
            child: []
        }]
    })(r)
}

function fr(r) {
    return ae({
        tag: "svg",
        attr: {
            role: "img",
            viewBox: "0 0 24 24"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M12.001,4.8c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c0.913,0.228,1.565,0.89,2.288,1.624 C13.666,10.618,15.027,12,18.001,12c3.2,0,5.2-1.6,6-4.8c-1.2,1.6-2.6,2.2-4.2,1.8c-0.913-0.228-1.565-0.89-2.288-1.624 C16.337,6.182,14.976,4.8,12.001,4.8z M6.001,12c-3.2,0-5.2,1.6-6,4.8c1.2-1.6,2.6-2.2,4.2-1.8c0.913,0.228,1.565,0.89,2.288,1.624 c1.177,1.194,2.538,2.576,5.512,2.576c3.2,0,5.2-1.6,6-4.8c-1.2,1.6-2.6,2.2-4.2,1.8c-0.913-0.228-1.565-0.89-2.288-1.624 C10.337,13.382,8.976,12,6.001,12z"
            },
            child: []
        }]
    })(r)
}
var yt = {},
    gt = {},
    Oe = {},
    mt = {};
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = void 0;
    var e = {
        animating: !1,
        autoplaying: null,
        currentDirection: 0,
        currentLeft: null,
        currentSlide: 0,
        direction: 1,
        dragging: !1,
        edgeDragged: !1,
        initialized: !1,
        lazyLoadedList: [],
        listHeight: null,
        listWidth: null,
        scrolling: !1,
        slideCount: null,
        slideHeight: null,
        slideWidth: null,
        swipeLeft: null,
        swiped: !1,
        swiping: !1,
        touchObject: {
            startX: 0,
            startY: 0,
            curX: 0,
            curY: 0
        },
        trackStyle: {},
        trackWidth: 0,
        targetSlide: 0
    };
    r.default = e
})(mt);
var dr = "Expected a function",
    Ze = NaN,
    pr = "[object Symbol]",
    vr = /^\s+|\s+$/g,
    hr = /^[-+]0x[0-9a-f]+$/i,
    yr = /^0b[01]+$/i,
    gr = /^0o[0-7]+$/i,
    mr = parseInt,
    br = typeof se == "object" && se && se.Object === Object && se,
    Sr = typeof self == "object" && self && self.Object === Object && self,
    wr = br || Sr || Function("return this")(),
    Or = Object.prototype,
    _r = Or.toString,
    Pr = Math.max,
    Tr = Math.min,
    je = function() {
        return wr.Date.now()
    };

function xr(r, e, n) {
    var i, t, a, o, l, s, u = 0,
        h = !1,
        c = !1,
        b = !0;
    if (typeof r != "function") throw new TypeError(dr);
    e = Je(e) || 0, Ie(n) && (h = !!n.leading, c = "maxWait" in n, a = c ? Pr(Je(n.maxWait) || 0, e) : a, b = "trailing" in n ? !!n.trailing : b);

    function M(x) {
        var D = i,
            W = t;
        return i = t = void 0, u = x, o = r.apply(W, D), o
    }

    function O(x) {
        return u = x, l = setTimeout(T, e), h ? M(x) : o
    }

    function y(x) {
        var D = x - s,
            W = x - u,
            p = e - D;
        return c ? Tr(p, a - W) : p
    }

    function g(x) {
        var D = x - s,
            W = x - u;
        return s === void 0 || D >= e || D < 0 || c && W >= a
    }

    function T() {
        var x = je();
        if (g(x)) return v(x);
        l = setTimeout(T, y(x))
    }

    function v(x) {
        return l = void 0, b && i ? M(x) : (i = t = void 0, o)
    }

    function S() {
        l !== void 0 && clearTimeout(l), u = 0, i = s = t = l = void 0
    }

    function k() {
        return l === void 0 ? o : v(je())
    }

    function j() {
        var x = je(),
            D = g(x);
        if (i = arguments, t = this, s = x, D) {
            if (l === void 0) return O(s);
            if (c) return l = setTimeout(T, e), M(s)
        }
        return l === void 0 && (l = setTimeout(T, e)), o
    }
    return j.cancel = S, j.flush = k, j
}

function Ie(r) {
    var e = typeof r;
    return !!r && (e == "object" || e == "function")
}

function kr(r) {
    return !!r && typeof r == "object"
}

function jr(r) {
    return typeof r == "symbol" || kr(r) && _r.call(r) == pr
}

function Je(r) {
    if (typeof r == "number") return r;
    if (jr(r)) return Ze;
    if (Ie(r)) {
        var e = typeof r.valueOf == "function" ? r.valueOf() : r;
        r = Ie(e) ? e + "" : e
    }
    if (typeof r != "string") return r === 0 ? r : +r;
    r = r.replace(vr, "");
    var n = yr.test(r);
    return n || gr.test(r) ? mr(r.slice(2), n ? 2 : 8) : hr.test(r) ? Ze : +r
}
var Er = xr,
    bt = {
        exports: {}
    };
/*!
	Copyright (c) 2018 Jed Watson.
	Licensed under the MIT License (MIT), see
	http://jedwatson.github.io/classnames
*/
(function(r) {
    (function() {
        var e = {}.hasOwnProperty;

        function n() {
            for (var a = "", o = 0; o < arguments.length; o++) {
                var l = arguments[o];
                l && (a = t(a, i(l)))
            }
            return a
        }

        function i(a) {
            if (typeof a == "string" || typeof a == "number") return a;
            if (typeof a != "object") return "";
            if (Array.isArray(a)) return n.apply(null, a);
            if (a.toString !== Object.prototype.toString && !a.toString.toString().includes("[native code]")) return a.toString();
            var o = "";
            for (var l in a) e.call(a, l) && a[l] && (o = t(o, l));
            return o
        }

        function t(a, o) {
            return o ? a ? a + " " + o : a + o : a
        }
        r.exports ? (n.default = n, r.exports = n) : window.classNames = n
    })()
})(bt);
var _e = bt.exports,
    f = {},
    Ke = {};
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = void 0;
    var e = n(X);

    function n(t) {
        return t && t.__esModule ? t : {
            default: t
        }
    }
    var i = {
        accessibility: !0,
        adaptiveHeight: !1,
        afterChange: null,
        appendDots: function(a) {
            return e.default.createElement("ul", {
                style: {
                    display: "block"
                }
            }, a)
        },
        arrows: !0,
        autoplay: !1,
        autoplaySpeed: 3e3,
        beforeChange: null,
        centerMode: !1,
        centerPadding: "50px",
        className: "",
        cssEase: "ease",
        customPaging: function(a) {
            return e.default.createElement("button", null, a + 1)
        },
        dots: !1,
        dotsClass: "slick-dots",
        draggable: !0,
        easing: "linear",
        edgeFriction: .35,
        fade: !1,
        focusOnSelect: !1,
        infinite: !0,
        initialSlide: 0,
        lazyLoad: null,
        nextArrow: null,
        onEdge: null,
        onInit: null,
        onLazyLoadError: null,
        onReInit: null,
        pauseOnDotsHover: !1,
        pauseOnFocus: !1,
        pauseOnHover: !0,
        prevArrow: null,
        responsive: null,
        rows: 1,
        rtl: !1,
        slide: "div",
        slidesPerRow: 1,
        slidesToScroll: 1,
        slidesToShow: 1,
        speed: 500,
        swipe: !0,
        swipeEvent: null,
        swipeToSlide: !1,
        touchMove: !0,
        touchThreshold: 5,
        useCSS: !0,
        useTransform: !0,
        variableWidth: !1,
        vertical: !1,
        waitForAnimate: !0,
        asNavFor: null
    };
    r.default = i
})(Ke);
Object.defineProperty(f, "__esModule", {
    value: !0
});
f.checkSpecKeys = f.checkNavigable = f.changeSlide = f.canUseDOM = f.canGoNext = void 0;
f.clamp = wt;
f.extractObject = void 0;
f.filterSettings = Br;
f.validSettings = f.swipeStart = f.swipeMove = f.swipeEnd = f.slidesOnRight = f.slidesOnLeft = f.slideHandler = f.siblingDirection = f.safePreventDefault = f.lazyStartIndex = f.lazySlidesOnRight = f.lazySlidesOnLeft = f.lazyEndIndex = f.keyHandler = f.initializedState = f.getWidth = f.getTrackLeft = f.getTrackCSS = f.getTrackAnimateCSS = f.getTotalSlides = f.getSwipeDirection = f.getSlideCount = f.getRequiredLazySlides = f.getPreClones = f.getPostClones = f.getOnDemandLazySlides = f.getNavigableIndexes = f.getHeight = void 0;
var Cr = St(X),
    Lr = St(Ke);

function St(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}

function oe(r) {
    "@babel/helpers - typeof";
    return oe = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, oe(r)
}

function et(r, e) {
    var n = Object.keys(r);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(r);
        e && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(r, t).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function z(r) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? et(Object(n), !0).forEach(function(i) {
            Mr(r, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(n)) : et(Object(n)).forEach(function(i) {
            Object.defineProperty(r, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return r
}

function Mr(r, e, n) {
    return e = Rr(e), e in r ? Object.defineProperty(r, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = n, r
}

function Rr(r) {
    var e = zr(r, "string");
    return oe(e) == "symbol" ? e : String(e)
}

function zr(r, e) {
    if (oe(r) != "object" || !r) return r;
    var n = r[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(r, e || "default");
        if (oe(i) != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(r)
}

function wt(r, e, n) {
    return Math.max(e, Math.min(r, n))
}
var V = f.safePreventDefault = function(e) {
        var n = ["onTouchStart", "onTouchMove", "onWheel"];
        n.includes(e._reactName) || e.preventDefault()
    },
    Ot = f.getOnDemandLazySlides = function(e) {
        for (var n = [], i = _t(e), t = Pt(e), a = i; a < t; a++) e.lazyLoadedList.indexOf(a) < 0 && n.push(a);
        return n
    };
f.getRequiredLazySlides = function(e) {
    for (var n = [], i = _t(e), t = Pt(e), a = i; a < t; a++) n.push(a);
    return n
};
var _t = f.lazyStartIndex = function(e) {
        return e.currentSlide - Dr(e)
    },
    Pt = f.lazyEndIndex = function(e) {
        return e.currentSlide + Hr(e)
    },
    Dr = f.lazySlidesOnLeft = function(e) {
        return e.centerMode ? Math.floor(e.slidesToShow / 2) + (parseInt(e.centerPadding) > 0 ? 1 : 0) : 0
    },
    Hr = f.lazySlidesOnRight = function(e) {
        return e.centerMode ? Math.floor((e.slidesToShow - 1) / 2) + 1 + (parseInt(e.centerPadding) > 0 ? 1 : 0) : e.slidesToShow
    },
    Ae = f.getWidth = function(e) {
        return e && e.offsetWidth || 0
    },
    Tt = f.getHeight = function(e) {
        return e && e.offsetHeight || 0
    },
    xt = f.getSwipeDirection = function(e) {
        var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
            i, t, a, o;
        return i = e.startX - e.curX, t = e.startY - e.curY, a = Math.atan2(t, i), o = Math.round(a * 180 / Math.PI), o < 0 && (o = 360 - Math.abs(o)), o <= 45 && o >= 0 || o <= 360 && o >= 315 ? "left" : o >= 135 && o <= 225 ? "right" : n === !0 ? o >= 35 && o <= 135 ? "up" : "down" : "vertical"
    },
    kt = f.canGoNext = function(e) {
        var n = !0;
        return e.infinite || (e.centerMode && e.currentSlide >= e.slideCount - 1 || e.slideCount <= e.slidesToShow || e.currentSlide >= e.slideCount - e.slidesToShow) && (n = !1), n
    };
f.extractObject = function(e, n) {
    var i = {};
    return n.forEach(function(t) {
        return i[t] = e[t]
    }), i
};
f.initializedState = function(e) {
    var n = Cr.default.Children.count(e.children),
        i = e.listRef,
        t = Math.ceil(Ae(i)),
        a = e.trackRef && e.trackRef.node,
        o = Math.ceil(Ae(a)),
        l;
    if (e.vertical) l = t;
    else {
        var s = e.centerMode && parseInt(e.centerPadding) * 2;
        typeof e.centerPadding == "string" && e.centerPadding.slice(-1) === "%" && (s *= t / 100), l = Math.ceil((t - s) / e.slidesToShow)
    }
    var u = i && Tt(i.querySelector('[data-index="0"]')),
        h = u * e.slidesToShow,
        c = e.currentSlide === void 0 ? e.initialSlide : e.currentSlide;
    e.rtl && e.currentSlide === void 0 && (c = n - 1 - e.initialSlide);
    var b = e.lazyLoadedList || [],
        M = Ot(z(z({}, e), {}, {
            currentSlide: c,
            lazyLoadedList: b
        }));
    b = b.concat(M);
    var O = {
        slideCount: n,
        slideWidth: l,
        listWidth: t,
        trackWidth: o,
        currentSlide: c,
        slideHeight: u,
        listHeight: h,
        lazyLoadedList: b
    };
    return e.autoplaying === null && e.autoplay && (O.autoplaying = "playing"), O
};
f.slideHandler = function(e) {
    var n = e.waitForAnimate,
        i = e.animating,
        t = e.fade,
        a = e.infinite,
        o = e.index,
        l = e.slideCount,
        s = e.lazyLoad,
        u = e.currentSlide,
        h = e.centerMode,
        c = e.slidesToScroll,
        b = e.slidesToShow,
        M = e.useCSS,
        O = e.lazyLoadedList;
    if (n && i) return {};
    var y = o,
        g, T, v, S = {},
        k = {},
        j = a ? o : wt(o, 0, l - 1);
    if (t) {
        if (!a && (o < 0 || o >= l)) return {};
        o < 0 ? y = o + l : o >= l && (y = o - l), s && O.indexOf(y) < 0 && (O = O.concat(y)), S = {
            animating: !0,
            currentSlide: y,
            lazyLoadedList: O,
            targetSlide: y
        }, k = {
            animating: !1,
            targetSlide: y
        }
    } else g = y, y < 0 ? (g = y + l, a ? l % c !== 0 && (g = l - l % c) : g = 0) : !kt(e) && y > u ? y = g = u : h && y >= l ? (y = a ? l : l - 1, g = a ? 0 : l - 1) : y >= l && (g = y - l, a ? l % c !== 0 && (g = 0) : g = l - b), !a && y + b >= l && (g = l - b), T = de(z(z({}, e), {}, {
        slideIndex: y
    })), v = de(z(z({}, e), {}, {
        slideIndex: g
    })), a || (T === v && (y = g), T = v), s && (O = O.concat(Ot(z(z({}, e), {}, {
        currentSlide: y
    })))), M ? (S = {
        animating: !0,
        currentSlide: g,
        trackStyle: jt(z(z({}, e), {}, {
            left: T
        })),
        lazyLoadedList: O,
        targetSlide: j
    }, k = {
        animating: !1,
        currentSlide: g,
        trackStyle: fe(z(z({}, e), {}, {
            left: v
        })),
        swipeLeft: null,
        targetSlide: j
    }) : S = {
        currentSlide: g,
        trackStyle: fe(z(z({}, e), {}, {
            left: v
        })),
        lazyLoadedList: O,
        targetSlide: j
    };
    return {
        state: S,
        nextState: k
    }
};
f.changeSlide = function(e, n) {
    var i, t, a, o, l, s = e.slidesToScroll,
        u = e.slidesToShow,
        h = e.slideCount,
        c = e.currentSlide,
        b = e.targetSlide,
        M = e.lazyLoad,
        O = e.infinite;
    if (o = h % s !== 0, i = o ? 0 : (h - c) % s, n.message === "previous") a = i === 0 ? s : u - i, l = c - a, M && !O && (t = c - a, l = t === -1 ? h - 1 : t), O || (l = b - s);
    else if (n.message === "next") a = i === 0 ? s : i, l = c + a, M && !O && (l = (c + s) % h + i), O || (l = b + s);
    else if (n.message === "dots") l = n.index * n.slidesToScroll;
    else if (n.message === "children") {
        if (l = n.index, O) {
            var y = Wr(z(z({}, e), {}, {
                targetSlide: l
            }));
            l > n.currentSlide && y === "left" ? l = l - h : l < n.currentSlide && y === "right" && (l = l + h)
        }
    } else n.message === "index" && (l = Number(n.index));
    return l
};
f.keyHandler = function(e, n, i) {
    return e.target.tagName.match("TEXTAREA|INPUT|SELECT") || !n ? "" : e.keyCode === 37 ? i ? "next" : "previous" : e.keyCode === 39 ? i ? "previous" : "next" : ""
};
f.swipeStart = function(e, n, i) {
    return e.target.tagName === "IMG" && V(e), !n || !i && e.type.indexOf("mouse") !== -1 ? "" : {
        dragging: !0,
        touchObject: {
            startX: e.touches ? e.touches[0].pageX : e.clientX,
            startY: e.touches ? e.touches[0].pageY : e.clientY,
            curX: e.touches ? e.touches[0].pageX : e.clientX,
            curY: e.touches ? e.touches[0].pageY : e.clientY
        }
    }
};
f.swipeMove = function(e, n) {
    var i = n.scrolling,
        t = n.animating,
        a = n.vertical,
        o = n.swipeToSlide,
        l = n.verticalSwiping,
        s = n.rtl,
        u = n.currentSlide,
        h = n.edgeFriction,
        c = n.edgeDragged,
        b = n.onEdge,
        M = n.swiped,
        O = n.swiping,
        y = n.slideCount,
        g = n.slidesToScroll,
        T = n.infinite,
        v = n.touchObject,
        S = n.swipeEvent,
        k = n.listHeight,
        j = n.listWidth;
    if (!i) {
        if (t) return V(e);
        a && o && l && V(e);
        var x, D = {},
            W = de(n);
        v.curX = e.touches ? e.touches[0].pageX : e.clientX, v.curY = e.touches ? e.touches[0].pageY : e.clientY, v.swipeLength = Math.round(Math.sqrt(Math.pow(v.curX - v.startX, 2)));
        var p = Math.round(Math.sqrt(Math.pow(v.curY - v.startY, 2)));
        if (!l && !O && p > 10) return {
            scrolling: !0
        };
        l && (v.swipeLength = p);
        var d = (s ? -1 : 1) * (v.curX > v.startX ? 1 : -1);
        l && (d = v.curY > v.startY ? 1 : -1);
        var E = Math.ceil(y / g),
            w = xt(n.touchObject, l),
            _ = v.swipeLength;
        return T || (u === 0 && (w === "right" || w === "down") || u + 1 >= E && (w === "left" || w === "up") || !kt(n) && (w === "left" || w === "up")) && (_ = v.swipeLength * h, c === !1 && b && (b(w), D.edgeDragged = !0)), !M && S && (S(w), D.swiped = !0), a ? x = W + _ * (k / j) * d : s ? x = W - _ * d : x = W + _ * d, l && (x = W + _ * d), D = z(z({}, D), {}, {
            touchObject: v,
            swipeLeft: x,
            trackStyle: fe(z(z({}, n), {}, {
                left: x
            }))
        }), Math.abs(v.curX - v.startX) < Math.abs(v.curY - v.startY) * .8 || v.swipeLength > 10 && (D.swiping = !0, V(e)), D
    }
};
f.swipeEnd = function(e, n) {
    var i = n.dragging,
        t = n.swipe,
        a = n.touchObject,
        o = n.listWidth,
        l = n.touchThreshold,
        s = n.verticalSwiping,
        u = n.listHeight,
        h = n.swipeToSlide,
        c = n.scrolling,
        b = n.onSwipe,
        M = n.targetSlide,
        O = n.currentSlide,
        y = n.infinite;
    if (!i) return t && V(e), {};
    var g = s ? u / l : o / l,
        T = xt(a, s),
        v = {
            dragging: !1,
            edgeDragged: !1,
            scrolling: !1,
            swiping: !1,
            swiped: !1,
            swipeLeft: null,
            touchObject: {}
        };
    if (c || !a.swipeLength) return v;
    if (a.swipeLength > g) {
        V(e), b && b(T);
        var S, k, j = y ? O : M;
        switch (T) {
            case "left":
            case "up":
                k = j + rt(n), S = h ? tt(n, k) : k, v.currentDirection = 0;
                break;
            case "right":
            case "down":
                k = j - rt(n), S = h ? tt(n, k) : k, v.currentDirection = 1;
                break;
            default:
                S = j
        }
        v.triggerSlideHandler = S
    } else {
        var x = de(n);
        v.trackStyle = jt(z(z({}, n), {}, {
            left: x
        }))
    }
    return v
};
var Nr = f.getNavigableIndexes = function(e) {
        for (var n = e.infinite ? e.slideCount * 2 : e.slideCount, i = e.infinite ? e.slidesToShow * -1 : 0, t = e.infinite ? e.slidesToShow * -1 : 0, a = []; i < n;) a.push(i), i = t + e.slidesToScroll, t += Math.min(e.slidesToScroll, e.slidesToShow);
        return a
    },
    tt = f.checkNavigable = function(e, n) {
        var i = Nr(e),
            t = 0;
        if (n > i[i.length - 1]) n = i[i.length - 1];
        else
            for (var a in i) {
                if (n < i[a]) {
                    n = t;
                    break
                }
                t = i[a]
            }
        return n
    },
    rt = f.getSlideCount = function(e) {
        var n = e.centerMode ? e.slideWidth * Math.floor(e.slidesToShow / 2) : 0;
        if (e.swipeToSlide) {
            var i, t = e.listRef,
                a = t.querySelectorAll && t.querySelectorAll(".slick-slide") || [];
            if (Array.from(a).every(function(s) {
                    if (e.vertical) {
                        if (s.offsetTop + Tt(s) / 2 > e.swipeLeft * -1) return i = s, !1
                    } else if (s.offsetLeft - n + Ae(s) / 2 > e.swipeLeft * -1) return i = s, !1;
                    return !0
                }), !i) return 0;
            var o = e.rtl === !0 ? e.slideCount - e.currentSlide : e.currentSlide,
                l = Math.abs(i.dataset.index - o) || 1;
            return l
        } else return e.slidesToScroll
    },
    Ye = f.checkSpecKeys = function(e, n) {
        return n.reduce(function(i, t) {
            return i && e.hasOwnProperty(t)
        }, !0) ? null : console.error("Keys Missing:", e)
    },
    fe = f.getTrackCSS = function(e) {
        Ye(e, ["left", "variableWidth", "slideCount", "slidesToShow", "slideWidth"]);
        var n, i, t = e.slideCount + 2 * e.slidesToShow;
        e.vertical ? i = t * e.slideHeight : n = Ar(e) * e.slideWidth;
        var a = {
            opacity: 1,
            transition: "",
            WebkitTransition: ""
        };
        if (e.useTransform) {
            var o = e.vertical ? "translate3d(0px, " + e.left + "px, 0px)" : "translate3d(" + e.left + "px, 0px, 0px)",
                l = e.vertical ? "translate3d(0px, " + e.left + "px, 0px)" : "translate3d(" + e.left + "px, 0px, 0px)",
                s = e.vertical ? "translateY(" + e.left + "px)" : "translateX(" + e.left + "px)";
            a = z(z({}, a), {}, {
                WebkitTransform: o,
                transform: l,
                msTransform: s
            })
        } else e.vertical ? a.top = e.left : a.left = e.left;
        return e.fade && (a = {
            opacity: 1
        }), n && (a.width = n), i && (a.height = i), window && !window.addEventListener && window.attachEvent && (e.vertical ? a.marginTop = e.left + "px" : a.marginLeft = e.left + "px"), a
    },
    jt = f.getTrackAnimateCSS = function(e) {
        Ye(e, ["left", "variableWidth", "slideCount", "slidesToShow", "slideWidth", "speed", "cssEase"]);
        var n = fe(e);
        return e.useTransform ? (n.WebkitTransition = "-webkit-transform " + e.speed + "ms " + e.cssEase, n.transition = "transform " + e.speed + "ms " + e.cssEase) : e.vertical ? n.transition = "top " + e.speed + "ms " + e.cssEase : n.transition = "left " + e.speed + "ms " + e.cssEase, n
    },
    de = f.getTrackLeft = function(e) {
        if (e.unslick) return 0;
        Ye(e, ["slideIndex", "trackRef", "infinite", "centerMode", "slideCount", "slidesToShow", "slidesToScroll", "slideWidth", "listWidth", "variableWidth", "slideHeight"]);
        var n = e.slideIndex,
            i = e.trackRef,
            t = e.infinite,
            a = e.centerMode,
            o = e.slideCount,
            l = e.slidesToShow,
            s = e.slidesToScroll,
            u = e.slideWidth,
            h = e.listWidth,
            c = e.variableWidth,
            b = e.slideHeight,
            M = e.fade,
            O = e.vertical,
            y = 0,
            g, T, v = 0;
        if (M || e.slideCount === 1) return 0;
        var S = 0;
        if (t ? (S = -ce(e), o % s !== 0 && n + s > o && (S = -(n > o ? l - (n - o) : o % s)), a && (S += parseInt(l / 2))) : (o % s !== 0 && n + s > o && (S = l - o % s), a && (S = parseInt(l / 2))), y = S * u, v = S * b, O ? g = n * b * -1 + v : g = n * u * -1 + y, c === !0) {
            var k, j = i && i.node;
            if (k = n + ce(e), T = j && j.childNodes[k], g = T ? T.offsetLeft * -1 : 0, a === !0) {
                k = t ? n + ce(e) : n, T = j && j.children[k], g = 0;
                for (var x = 0; x < k; x++) g -= j && j.children[x] && j.children[x].offsetWidth;
                g -= parseInt(e.centerPadding), g += T && (h - T.offsetWidth) / 2
            }
        }
        return g
    },
    ce = f.getPreClones = function(e) {
        return e.unslick || !e.infinite ? 0 : e.variableWidth ? e.slideCount : e.slidesToShow + (e.centerMode ? 1 : 0)
    },
    Ir = f.getPostClones = function(e) {
        return e.unslick || !e.infinite ? 0 : e.slideCount
    },
    Ar = f.getTotalSlides = function(e) {
        return e.slideCount === 1 ? 1 : ce(e) + e.slideCount + Ir(e)
    },
    Wr = f.siblingDirection = function(e) {
        return e.targetSlide > e.currentSlide ? e.targetSlide > e.currentSlide + $r(e) ? "left" : "right" : e.targetSlide < e.currentSlide - qr(e) ? "right" : "left"
    },
    $r = f.slidesOnRight = function(e) {
        var n = e.slidesToShow,
            i = e.centerMode,
            t = e.rtl,
            a = e.centerPadding;
        if (i) {
            var o = (n - 1) / 2 + 1;
            return parseInt(a) > 0 && (o += 1), t && n % 2 === 0 && (o += 1), o
        }
        return t ? 0 : n - 1
    },
    qr = f.slidesOnLeft = function(e) {
        var n = e.slidesToShow,
            i = e.centerMode,
            t = e.rtl,
            a = e.centerPadding;
        if (i) {
            var o = (n - 1) / 2 + 1;
            return parseInt(a) > 0 && (o += 1), !t && n % 2 === 0 && (o += 1), o
        }
        return t ? n - 1 : 0
    };
f.canUseDOM = function() {
    return !!(typeof window < "u" && window.document && window.document.createElement)
};
var Fr = f.validSettings = Object.keys(Lr.default);

function Br(r) {
    return Fr.reduce(function(e, n) {
        return r.hasOwnProperty(n) && (e[n] = r[n]), e
    }, {})
}
var Pe = {};
Object.defineProperty(Pe, "__esModule", {
    value: !0
});
Pe.Track = void 0;
var F = Et(X),
    Ee = Et(_e),
    Ce = f;

function Et(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}

function Z(r) {
    "@babel/helpers - typeof";
    return Z = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, Z(r)
}

function We() {
    return We = Object.assign ? Object.assign.bind() : function(r) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (r[i] = n[i])
        }
        return r
    }, We.apply(this, arguments)
}

function Ur(r, e) {
    if (!(r instanceof e)) throw new TypeError("Cannot call a class as a function")
}

function Gr(r, e) {
    for (var n = 0; n < e.length; n++) {
        var i = e[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(r, Lt(i.key), i)
    }
}

function Xr(r, e, n) {
    return e && Gr(r.prototype, e), Object.defineProperty(r, "prototype", {
        writable: !1
    }), r
}

function Kr(r, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Super expression must either be null or a function");
    r.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: r,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(r, "prototype", {
        writable: !1
    }), e && $e(r, e)
}

function $e(r, e) {
    return $e = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i, t) {
        return i.__proto__ = t, i
    }, $e(r, e)
}

function Yr(r) {
    var e = Ct();
    return function() {
        var i = pe(r),
            t;
        if (e) {
            var a = pe(this).constructor;
            t = Reflect.construct(i, arguments, a)
        } else t = i.apply(this, arguments);
        return Vr(this, t)
    }
}

function Vr(r, e) {
    if (e && (Z(e) === "object" || typeof e == "function")) return e;
    if (e !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
    return qe(r)
}

function qe(r) {
    if (r === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return r
}

function Ct() {
    try {
        var r = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}))
    } catch {}
    return (Ct = function() {
        return !!r
    })()
}

function pe(r) {
    return pe = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(n) {
        return n.__proto__ || Object.getPrototypeOf(n)
    }, pe(r)
}

function nt(r, e) {
    var n = Object.keys(r);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(r);
        e && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(r, t).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function A(r) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? nt(Object(n), !0).forEach(function(i) {
            Fe(r, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(n)) : nt(Object(n)).forEach(function(i) {
            Object.defineProperty(r, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return r
}

function Fe(r, e, n) {
    return e = Lt(e), e in r ? Object.defineProperty(r, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = n, r
}

function Lt(r) {
    var e = Qr(r, "string");
    return Z(e) == "symbol" ? e : String(e)
}

function Qr(r, e) {
    if (Z(r) != "object" || !r) return r;
    var n = r[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(r, e || "default");
        if (Z(i) != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(r)
}
var Le = function(e) {
        var n, i, t, a, o;
        e.rtl ? o = e.slideCount - 1 - e.index : o = e.index, t = o < 0 || o >= e.slideCount, e.centerMode ? (a = Math.floor(e.slidesToShow / 2), i = (o - e.currentSlide) % e.slideCount === 0, o > e.currentSlide - a - 1 && o <= e.currentSlide + a && (n = !0)) : n = e.currentSlide <= o && o < e.currentSlide + e.slidesToShow;
        var l;
        e.targetSlide < 0 ? l = e.targetSlide + e.slideCount : e.targetSlide >= e.slideCount ? l = e.targetSlide - e.slideCount : l = e.targetSlide;
        var s = o === l;
        return {
            "slick-slide": !0,
            "slick-active": n,
            "slick-center": i,
            "slick-cloned": t,
            "slick-current": s
        }
    },
    Zr = function(e) {
        var n = {};
        return (e.variableWidth === void 0 || e.variableWidth === !1) && (n.width = e.slideWidth), e.fade && (n.position = "relative", e.vertical ? n.top = -e.index * parseInt(e.slideHeight) : n.left = -e.index * parseInt(e.slideWidth), n.opacity = e.currentSlide === e.index ? 1 : 0, n.zIndex = e.currentSlide === e.index ? 999 : 998, e.useCSS && (n.transition = "opacity " + e.speed + "ms " + e.cssEase + ", visibility " + e.speed + "ms " + e.cssEase)), n
    },
    Me = function(e, n) {
        return e.key || n
    },
    Jr = function(e) {
        var n, i = [],
            t = [],
            a = [],
            o = F.default.Children.count(e.children),
            l = (0, Ce.lazyStartIndex)(e),
            s = (0, Ce.lazyEndIndex)(e);
        return F.default.Children.forEach(e.children, function(u, h) {
            var c, b = {
                message: "children",
                index: h,
                slidesToScroll: e.slidesToScroll,
                currentSlide: e.currentSlide
            };
            !e.lazyLoad || e.lazyLoad && e.lazyLoadedList.indexOf(h) >= 0 ? c = u : c = F.default.createElement("div", null);
            var M = Zr(A(A({}, e), {}, {
                    index: h
                })),
                O = c.props.className || "",
                y = Le(A(A({}, e), {}, {
                    index: h
                }));
            if (i.push(F.default.cloneElement(c, {
                    key: "original" + Me(c, h),
                    "data-index": h,
                    className: (0, Ee.default)(y, O),
                    tabIndex: "-1",
                    "aria-hidden": !y["slick-active"],
                    style: A(A({
                        outline: "none"
                    }, c.props.style || {}), M),
                    onClick: function(v) {
                        c.props && c.props.onClick && c.props.onClick(v), e.focusOnSelect && e.focusOnSelect(b)
                    }
                })), e.infinite && e.fade === !1) {
                var g = o - h;
                g <= (0, Ce.getPreClones)(e) && (n = -g, n >= l && (c = u), y = Le(A(A({}, e), {}, {
                    index: n
                })), t.push(F.default.cloneElement(c, {
                    key: "precloned" + Me(c, n),
                    "data-index": n,
                    tabIndex: "-1",
                    className: (0, Ee.default)(y, O),
                    "aria-hidden": !y["slick-active"],
                    style: A(A({}, c.props.style || {}), M),
                    onClick: function(v) {
                        c.props && c.props.onClick && c.props.onClick(v), e.focusOnSelect && e.focusOnSelect(b)
                    }
                }))), n = o + h, n < s && (c = u), y = Le(A(A({}, e), {}, {
                    index: n
                })), a.push(F.default.cloneElement(c, {
                    key: "postcloned" + Me(c, n),
                    "data-index": n,
                    tabIndex: "-1",
                    className: (0, Ee.default)(y, O),
                    "aria-hidden": !y["slick-active"],
                    style: A(A({}, c.props.style || {}), M),
                    onClick: function(v) {
                        c.props && c.props.onClick && c.props.onClick(v), e.focusOnSelect && e.focusOnSelect(b)
                    }
                }))
            }
        }), e.rtl ? t.concat(i, a).reverse() : t.concat(i, a)
    };
Pe.Track = function(r) {
    Kr(n, r);
    var e = Yr(n);

    function n() {
        var i;
        Ur(this, n);
        for (var t = arguments.length, a = new Array(t), o = 0; o < t; o++) a[o] = arguments[o];
        return i = e.call.apply(e, [this].concat(a)), Fe(qe(i), "node", null), Fe(qe(i), "handleRef", function(l) {
            i.node = l
        }), i
    }
    return Xr(n, [{
        key: "render",
        value: function() {
            var t = Jr(this.props),
                a = this.props,
                o = a.onMouseEnter,
                l = a.onMouseOver,
                s = a.onMouseLeave,
                u = {
                    onMouseEnter: o,
                    onMouseOver: l,
                    onMouseLeave: s
                };
            return F.default.createElement("div", We({
                ref: this.handleRef,
                className: "slick-track",
                style: this.props.trackStyle
            }, u), t)
        }
    }]), n
}(F.default.PureComponent);
var Te = {};

function J(r) {
    "@babel/helpers - typeof";
    return J = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, J(r)
}
Object.defineProperty(Te, "__esModule", {
    value: !0
});
Te.Dots = void 0;
var ue = Mt(X),
    en = Mt(_e),
    it = f;

function Mt(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}

function ot(r, e) {
    var n = Object.keys(r);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(r);
        e && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(r, t).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function tn(r) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? ot(Object(n), !0).forEach(function(i) {
            rn(r, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(n)) : ot(Object(n)).forEach(function(i) {
            Object.defineProperty(r, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return r
}

function rn(r, e, n) {
    return e = Rt(e), e in r ? Object.defineProperty(r, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = n, r
}

function nn(r, e) {
    if (!(r instanceof e)) throw new TypeError("Cannot call a class as a function")
}

function on(r, e) {
    for (var n = 0; n < e.length; n++) {
        var i = e[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(r, Rt(i.key), i)
    }
}

function an(r, e, n) {
    return e && on(r.prototype, e), Object.defineProperty(r, "prototype", {
        writable: !1
    }), r
}

function Rt(r) {
    var e = ln(r, "string");
    return J(e) == "symbol" ? e : String(e)
}

function ln(r, e) {
    if (J(r) != "object" || !r) return r;
    var n = r[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(r, e || "default");
        if (J(i) != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(r)
}

function sn(r, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Super expression must either be null or a function");
    r.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: r,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(r, "prototype", {
        writable: !1
    }), e && Be(r, e)
}

function Be(r, e) {
    return Be = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i, t) {
        return i.__proto__ = t, i
    }, Be(r, e)
}

function un(r) {
    var e = zt();
    return function() {
        var i = ve(r),
            t;
        if (e) {
            var a = ve(this).constructor;
            t = Reflect.construct(i, arguments, a)
        } else t = i.apply(this, arguments);
        return cn(this, t)
    }
}

function cn(r, e) {
    if (e && (J(e) === "object" || typeof e == "function")) return e;
    if (e !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
    return fn(r)
}

function fn(r) {
    if (r === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return r
}

function zt() {
    try {
        var r = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}))
    } catch {}
    return (zt = function() {
        return !!r
    })()
}

function ve(r) {
    return ve = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(n) {
        return n.__proto__ || Object.getPrototypeOf(n)
    }, ve(r)
}
var dn = function(e) {
    var n;
    return e.infinite ? n = Math.ceil(e.slideCount / e.slidesToScroll) : n = Math.ceil((e.slideCount - e.slidesToShow) / e.slidesToScroll) + 1, n
};
Te.Dots = function(r) {
    sn(n, r);
    var e = un(n);

    function n() {
        return nn(this, n), e.apply(this, arguments)
    }
    return an(n, [{
        key: "clickHandler",
        value: function(t, a) {
            a.preventDefault(), this.props.clickHandler(t)
        }
    }, {
        key: "render",
        value: function() {
            for (var t = this.props, a = t.onMouseEnter, o = t.onMouseOver, l = t.onMouseLeave, s = t.infinite, u = t.slidesToScroll, h = t.slidesToShow, c = t.slideCount, b = t.currentSlide, M = dn({
                    slideCount: c,
                    slidesToScroll: u,
                    slidesToShow: h,
                    infinite: s
                }), O = {
                    onMouseEnter: a,
                    onMouseOver: o,
                    onMouseLeave: l
                }, y = [], g = 0; g < M; g++) {
                var T = (g + 1) * u - 1,
                    v = s ? T : (0, it.clamp)(T, 0, c - 1),
                    S = v - (u - 1),
                    k = s ? S : (0, it.clamp)(S, 0, c - 1),
                    j = (0, en.default)({
                        "slick-active": s ? b >= k && b <= v : b === k
                    }),
                    x = {
                        message: "dots",
                        index: g,
                        slidesToScroll: u,
                        currentSlide: b
                    },
                    D = this.clickHandler.bind(this, x);
                y = y.concat(ue.default.createElement("li", {
                    key: g,
                    className: j
                }, ue.default.cloneElement(this.props.customPaging(g), {
                    onClick: D
                })))
            }
            return ue.default.cloneElement(this.props.appendDots(y), tn({
                className: this.props.dotsClass
            }, O))
        }
    }]), n
}(ue.default.PureComponent);
var ee = {};

function te(r) {
    "@babel/helpers - typeof";
    return te = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, te(r)
}
Object.defineProperty(ee, "__esModule", {
    value: !0
});
ee.PrevArrow = ee.NextArrow = void 0;
var Q = Ht(X),
    Dt = Ht(_e),
    pn = f;

function Ht(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}

function he() {
    return he = Object.assign ? Object.assign.bind() : function(r) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (r[i] = n[i])
        }
        return r
    }, he.apply(this, arguments)
}

function at(r, e) {
    var n = Object.keys(r);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(r);
        e && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(r, t).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function ye(r) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? at(Object(n), !0).forEach(function(i) {
            vn(r, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(n)) : at(Object(n)).forEach(function(i) {
            Object.defineProperty(r, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return r
}

function vn(r, e, n) {
    return e = At(e), e in r ? Object.defineProperty(r, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = n, r
}

function Nt(r, e) {
    if (!(r instanceof e)) throw new TypeError("Cannot call a class as a function")
}

function hn(r, e) {
    for (var n = 0; n < e.length; n++) {
        var i = e[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(r, At(i.key), i)
    }
}

function It(r, e, n) {
    return e && hn(r.prototype, e), Object.defineProperty(r, "prototype", {
        writable: !1
    }), r
}

function At(r) {
    var e = yn(r, "string");
    return te(e) == "symbol" ? e : String(e)
}

function yn(r, e) {
    if (te(r) != "object" || !r) return r;
    var n = r[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(r, e || "default");
        if (te(i) != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(r)
}

function Wt(r, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Super expression must either be null or a function");
    r.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: r,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(r, "prototype", {
        writable: !1
    }), e && Ue(r, e)
}

function Ue(r, e) {
    return Ue = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i, t) {
        return i.__proto__ = t, i
    }, Ue(r, e)
}

function $t(r) {
    var e = qt();
    return function() {
        var i = ge(r),
            t;
        if (e) {
            var a = ge(this).constructor;
            t = Reflect.construct(i, arguments, a)
        } else t = i.apply(this, arguments);
        return gn(this, t)
    }
}

function gn(r, e) {
    if (e && (te(e) === "object" || typeof e == "function")) return e;
    if (e !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
    return mn(r)
}

function mn(r) {
    if (r === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return r
}

function qt() {
    try {
        var r = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}))
    } catch {}
    return (qt = function() {
        return !!r
    })()
}

function ge(r) {
    return ge = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(n) {
        return n.__proto__ || Object.getPrototypeOf(n)
    }, ge(r)
}
ee.PrevArrow = function(r) {
    Wt(n, r);
    var e = $t(n);

    function n() {
        return Nt(this, n), e.apply(this, arguments)
    }
    return It(n, [{
        key: "clickHandler",
        value: function(t, a) {
            a && a.preventDefault(), this.props.clickHandler(t, a)
        }
    }, {
        key: "render",
        value: function() {
            var t = {
                    "slick-arrow": !0,
                    "slick-prev": !0
                },
                a = this.clickHandler.bind(this, {
                    message: "previous"
                });
            !this.props.infinite && (this.props.currentSlide === 0 || this.props.slideCount <= this.props.slidesToShow) && (t["slick-disabled"] = !0, a = null);
            var o = {
                    key: "0",
                    "data-role": "none",
                    className: (0, Dt.default)(t),
                    style: {
                        display: "block"
                    },
                    onClick: a
                },
                l = {
                    currentSlide: this.props.currentSlide,
                    slideCount: this.props.slideCount
                },
                s;
            return this.props.prevArrow ? s = Q.default.cloneElement(this.props.prevArrow, ye(ye({}, o), l)) : s = Q.default.createElement("button", he({
                key: "0",
                type: "button"
            }, o), " ", "Previous"), s
        }
    }]), n
}(Q.default.PureComponent);
ee.NextArrow = function(r) {
    Wt(n, r);
    var e = $t(n);

    function n() {
        return Nt(this, n), e.apply(this, arguments)
    }
    return It(n, [{
        key: "clickHandler",
        value: function(t, a) {
            a && a.preventDefault(), this.props.clickHandler(t, a)
        }
    }, {
        key: "render",
        value: function() {
            var t = {
                    "slick-arrow": !0,
                    "slick-next": !0
                },
                a = this.clickHandler.bind(this, {
                    message: "next"
                });
            (0, pn.canGoNext)(this.props) || (t["slick-disabled"] = !0, a = null);
            var o = {
                    key: "1",
                    "data-role": "none",
                    className: (0, Dt.default)(t),
                    style: {
                        display: "block"
                    },
                    onClick: a
                },
                l = {
                    currentSlide: this.props.currentSlide,
                    slideCount: this.props.slideCount
                },
                s;
            return this.props.nextArrow ? s = Q.default.cloneElement(this.props.nextArrow, ye(ye({}, o), l)) : s = Q.default.createElement("button", he({
                key: "1",
                type: "button"
            }, o), " ", "Next"), s
        }
    }]), n
}(Q.default.PureComponent);
var Ft = function() {
        if (typeof Map < "u") return Map;

        function r(e, n) {
            var i = -1;
            return e.some(function(t, a) {
                return t[0] === n ? (i = a, !0) : !1
            }), i
        }
        return function() {
            function e() {
                this.__entries__ = []
            }
            return Object.defineProperty(e.prototype, "size", {
                get: function() {
                    return this.__entries__.length
                },
                enumerable: !0,
                configurable: !0
            }), e.prototype.get = function(n) {
                var i = r(this.__entries__, n),
                    t = this.__entries__[i];
                return t && t[1]
            }, e.prototype.set = function(n, i) {
                var t = r(this.__entries__, n);
                ~t ? this.__entries__[t][1] = i : this.__entries__.push([n, i])
            }, e.prototype.delete = function(n) {
                var i = this.__entries__,
                    t = r(i, n);
                ~t && i.splice(t, 1)
            }, e.prototype.has = function(n) {
                return !!~r(this.__entries__, n)
            }, e.prototype.clear = function() {
                this.__entries__.splice(0)
            }, e.prototype.forEach = function(n, i) {
                i === void 0 && (i = null);
                for (var t = 0, a = this.__entries__; t < a.length; t++) {
                    var o = a[t];
                    n.call(i, o[1], o[0])
                }
            }, e
        }()
    }(),
    Ge = typeof window < "u" && typeof document < "u" && window.document === document,
    me = function() {
        return typeof global < "u" && global.Math === Math ? global : typeof self < "u" && self.Math === Math ? self : typeof window < "u" && window.Math === Math ? window : Function("return this")()
    }(),
    bn = function() {
        return typeof requestAnimationFrame == "function" ? requestAnimationFrame.bind(me) : function(r) {
            return setTimeout(function() {
                return r(Date.now())
            }, 1e3 / 60)
        }
    }(),
    Sn = 2;

function wn(r, e) {
    var n = !1,
        i = !1,
        t = 0;

    function a() {
        n && (n = !1, r()), i && l()
    }

    function o() {
        bn(a)
    }

    function l() {
        var s = Date.now();
        if (n) {
            if (s - t < Sn) return;
            i = !0
        } else n = !0, i = !1, setTimeout(o, e);
        t = s
    }
    return l
}
var On = 20,
    _n = ["top", "right", "bottom", "left", "width", "height", "size", "weight"],
    Pn = typeof MutationObserver < "u",
    Tn = function() {
        function r() {
            this.connected_ = !1, this.mutationEventsAdded_ = !1, this.mutationsObserver_ = null, this.observers_ = [], this.onTransitionEnd_ = this.onTransitionEnd_.bind(this), this.refresh = wn(this.refresh.bind(this), On)
        }
        return r.prototype.addObserver = function(e) {
            ~this.observers_.indexOf(e) || this.observers_.push(e), this.connected_ || this.connect_()
        }, r.prototype.removeObserver = function(e) {
            var n = this.observers_,
                i = n.indexOf(e);
            ~i && n.splice(i, 1), !n.length && this.connected_ && this.disconnect_()
        }, r.prototype.refresh = function() {
            var e = this.updateObservers_();
            e && this.refresh()
        }, r.prototype.updateObservers_ = function() {
            var e = this.observers_.filter(function(n) {
                return n.gatherActive(), n.hasActive()
            });
            return e.forEach(function(n) {
                return n.broadcastActive()
            }), e.length > 0
        }, r.prototype.connect_ = function() {
            !Ge || this.connected_ || (document.addEventListener("transitionend", this.onTransitionEnd_), window.addEventListener("resize", this.refresh), Pn ? (this.mutationsObserver_ = new MutationObserver(this.refresh), this.mutationsObserver_.observe(document, {
                attributes: !0,
                childList: !0,
                characterData: !0,
                subtree: !0
            })) : (document.addEventListener("DOMSubtreeModified", this.refresh), this.mutationEventsAdded_ = !0), this.connected_ = !0)
        }, r.prototype.disconnect_ = function() {
            !Ge || !this.connected_ || (document.removeEventListener("transitionend", this.onTransitionEnd_), window.removeEventListener("resize", this.refresh), this.mutationsObserver_ && this.mutationsObserver_.disconnect(), this.mutationEventsAdded_ && document.removeEventListener("DOMSubtreeModified", this.refresh), this.mutationsObserver_ = null, this.mutationEventsAdded_ = !1, this.connected_ = !1)
        }, r.prototype.onTransitionEnd_ = function(e) {
            var n = e.propertyName,
                i = n === void 0 ? "" : n,
                t = _n.some(function(a) {
                    return !!~i.indexOf(a)
                });
            t && this.refresh()
        }, r.getInstance = function() {
            return this.instance_ || (this.instance_ = new r), this.instance_
        }, r.instance_ = null, r
    }(),
    Bt = function(r, e) {
        for (var n = 0, i = Object.keys(e); n < i.length; n++) {
            var t = i[n];
            Object.defineProperty(r, t, {
                value: e[t],
                enumerable: !1,
                writable: !1,
                configurable: !0
            })
        }
        return r
    },
    re = function(r) {
        var e = r && r.ownerDocument && r.ownerDocument.defaultView;
        return e || me
    },
    Ut = xe(0, 0, 0, 0);

function be(r) {
    return parseFloat(r) || 0
}

function lt(r) {
    for (var e = [], n = 1; n < arguments.length; n++) e[n - 1] = arguments[n];
    return e.reduce(function(i, t) {
        var a = r["border-" + t + "-width"];
        return i + be(a)
    }, 0)
}

function xn(r) {
    for (var e = ["top", "right", "bottom", "left"], n = {}, i = 0, t = e; i < t.length; i++) {
        var a = t[i],
            o = r["padding-" + a];
        n[a] = be(o)
    }
    return n
}

function kn(r) {
    var e = r.getBBox();
    return xe(0, 0, e.width, e.height)
}

function jn(r) {
    var e = r.clientWidth,
        n = r.clientHeight;
    if (!e && !n) return Ut;
    var i = re(r).getComputedStyle(r),
        t = xn(i),
        a = t.left + t.right,
        o = t.top + t.bottom,
        l = be(i.width),
        s = be(i.height);
    if (i.boxSizing === "border-box" && (Math.round(l + a) !== e && (l -= lt(i, "left", "right") + a), Math.round(s + o) !== n && (s -= lt(i, "top", "bottom") + o)), !Cn(r)) {
        var u = Math.round(l + a) - e,
            h = Math.round(s + o) - n;
        Math.abs(u) !== 1 && (l -= u), Math.abs(h) !== 1 && (s -= h)
    }
    return xe(t.left, t.top, l, s)
}
var En = function() {
    return typeof SVGGraphicsElement < "u" ? function(r) {
        return r instanceof re(r).SVGGraphicsElement
    } : function(r) {
        return r instanceof re(r).SVGElement && typeof r.getBBox == "function"
    }
}();

function Cn(r) {
    return r === re(r).document.documentElement
}

function Ln(r) {
    return Ge ? En(r) ? kn(r) : jn(r) : Ut
}

function Mn(r) {
    var e = r.x,
        n = r.y,
        i = r.width,
        t = r.height,
        a = typeof DOMRectReadOnly < "u" ? DOMRectReadOnly : Object,
        o = Object.create(a.prototype);
    return Bt(o, {
        x: e,
        y: n,
        width: i,
        height: t,
        top: n,
        right: e + i,
        bottom: t + n,
        left: e
    }), o
}

function xe(r, e, n, i) {
    return {
        x: r,
        y: e,
        width: n,
        height: i
    }
}
var Rn = function() {
        function r(e) {
            this.broadcastWidth = 0, this.broadcastHeight = 0, this.contentRect_ = xe(0, 0, 0, 0), this.target = e
        }
        return r.prototype.isActive = function() {
            var e = Ln(this.target);
            return this.contentRect_ = e, e.width !== this.broadcastWidth || e.height !== this.broadcastHeight
        }, r.prototype.broadcastRect = function() {
            var e = this.contentRect_;
            return this.broadcastWidth = e.width, this.broadcastHeight = e.height, e
        }, r
    }(),
    zn = function() {
        function r(e, n) {
            var i = Mn(n);
            Bt(this, {
                target: e,
                contentRect: i
            })
        }
        return r
    }(),
    Dn = function() {
        function r(e, n, i) {
            if (this.activeObservations_ = [], this.observations_ = new Ft, typeof e != "function") throw new TypeError("The callback provided as parameter 1 is not a function.");
            this.callback_ = e, this.controller_ = n, this.callbackCtx_ = i
        }
        return r.prototype.observe = function(e) {
            if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
            if (!(typeof Element > "u" || !(Element instanceof Object))) {
                if (!(e instanceof re(e).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                var n = this.observations_;
                n.has(e) || (n.set(e, new Rn(e)), this.controller_.addObserver(this), this.controller_.refresh())
            }
        }, r.prototype.unobserve = function(e) {
            if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
            if (!(typeof Element > "u" || !(Element instanceof Object))) {
                if (!(e instanceof re(e).Element)) throw new TypeError('parameter 1 is not of type "Element".');
                var n = this.observations_;
                n.has(e) && (n.delete(e), n.size || this.controller_.removeObserver(this))
            }
        }, r.prototype.disconnect = function() {
            this.clearActive(), this.observations_.clear(), this.controller_.removeObserver(this)
        }, r.prototype.gatherActive = function() {
            var e = this;
            this.clearActive(), this.observations_.forEach(function(n) {
                n.isActive() && e.activeObservations_.push(n)
            })
        }, r.prototype.broadcastActive = function() {
            if (this.hasActive()) {
                var e = this.callbackCtx_,
                    n = this.activeObservations_.map(function(i) {
                        return new zn(i.target, i.broadcastRect())
                    });
                this.callback_.call(e, n, e), this.clearActive()
            }
        }, r.prototype.clearActive = function() {
            this.activeObservations_.splice(0)
        }, r.prototype.hasActive = function() {
            return this.activeObservations_.length > 0
        }, r
    }(),
    Gt = typeof WeakMap < "u" ? new WeakMap : new Ft,
    Xt = function() {
        function r(e) {
            if (!(this instanceof r)) throw new TypeError("Cannot call a class as a function.");
            if (!arguments.length) throw new TypeError("1 argument required, but only 0 present.");
            var n = Tn.getInstance(),
                i = new Dn(e, n, this);
            Gt.set(this, i)
        }
        return r
    }();
["observe", "unobserve", "disconnect"].forEach(function(r) {
    Xt.prototype[r] = function() {
        var e;
        return (e = Gt.get(this))[r].apply(e, arguments)
    }
});
var Hn = function() {
    return typeof me.ResizeObserver < "u" ? me.ResizeObserver : Xt
}();
const Nn = Object.freeze(Object.defineProperty({
        __proto__: null,
        default: Hn
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    In = Zt(Nn);
Object.defineProperty(Oe, "__esModule", {
    value: !0
});
Oe.InnerSlider = void 0;
var I = le(X),
    An = le(mt),
    Wn = le(Er),
    $n = le(_e),
    H = f,
    qn = Pe,
    Fn = Te,
    st = ee,
    Bn = le(In);

function le(r) {
    return r && r.__esModule ? r : {
        default: r
    }
}

function G(r) {
    "@babel/helpers - typeof";
    return G = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    }, G(r)
}

function Se() {
    return Se = Object.assign ? Object.assign.bind() : function(r) {
        for (var e = 1; e < arguments.length; e++) {
            var n = arguments[e];
            for (var i in n) Object.prototype.hasOwnProperty.call(n, i) && (r[i] = n[i])
        }
        return r
    }, Se.apply(this, arguments)
}

function Un(r, e) {
    if (r == null) return {};
    var n = Gn(r, e),
        i, t;
    if (Object.getOwnPropertySymbols) {
        var a = Object.getOwnPropertySymbols(r);
        for (t = 0; t < a.length; t++) i = a[t], !(e.indexOf(i) >= 0) && Object.prototype.propertyIsEnumerable.call(r, i) && (n[i] = r[i])
    }
    return n
}

function Gn(r, e) {
    if (r == null) return {};
    var n = {},
        i = Object.keys(r),
        t, a;
    for (a = 0; a < i.length; a++) t = i[a], !(e.indexOf(t) >= 0) && (n[t] = r[t]);
    return n
}

function ut(r, e) {
    var n = Object.keys(r);
    if (Object.getOwnPropertySymbols) {
        var i = Object.getOwnPropertySymbols(r);
        e && (i = i.filter(function(t) {
            return Object.getOwnPropertyDescriptor(r, t).enumerable
        })), n.push.apply(n, i)
    }
    return n
}

function m(r) {
    for (var e = 1; e < arguments.length; e++) {
        var n = arguments[e] != null ? arguments[e] : {};
        e % 2 ? ut(Object(n), !0).forEach(function(i) {
            L(r, i, n[i])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(r, Object.getOwnPropertyDescriptors(n)) : ut(Object(n)).forEach(function(i) {
            Object.defineProperty(r, i, Object.getOwnPropertyDescriptor(n, i))
        })
    }
    return r
}

function Xn(r, e) {
    if (!(r instanceof e)) throw new TypeError("Cannot call a class as a function")
}

function Kn(r, e) {
    for (var n = 0; n < e.length; n++) {
        var i = e[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(r, Yt(i.key), i)
    }
}

function Yn(r, e, n) {
    return e && Kn(r.prototype, e), Object.defineProperty(r, "prototype", {
        writable: !1
    }), r
}

function Vn(r, e) {
    if (typeof e != "function" && e !== null) throw new TypeError("Super expression must either be null or a function");
    r.prototype = Object.create(e && e.prototype, {
        constructor: {
            value: r,
            writable: !0,
            configurable: !0
        }
    }), Object.defineProperty(r, "prototype", {
        writable: !1
    }), e && Xe(r, e)
}

function Xe(r, e) {
    return Xe = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i, t) {
        return i.__proto__ = t, i
    }, Xe(r, e)
}

function Qn(r) {
    var e = Kt();
    return function() {
        var i = we(r),
            t;
        if (e) {
            var a = we(this).constructor;
            t = Reflect.construct(i, arguments, a)
        } else t = i.apply(this, arguments);
        return Zn(this, t)
    }
}

function Zn(r, e) {
    if (e && (G(e) === "object" || typeof e == "function")) return e;
    if (e !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
    return C(r)
}

function C(r) {
    if (r === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return r
}

function Kt() {
    try {
        var r = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}))
    } catch {}
    return (Kt = function() {
        return !!r
    })()
}

function we(r) {
    return we = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(n) {
        return n.__proto__ || Object.getPrototypeOf(n)
    }, we(r)
}

function L(r, e, n) {
    return e = Yt(e), e in r ? Object.defineProperty(r, e, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : r[e] = n, r
}

function Yt(r) {
    var e = Jn(r, "string");
    return G(e) == "symbol" ? e : String(e)
}

function Jn(r, e) {
    if (G(r) != "object" || !r) return r;
    var n = r[Symbol.toPrimitive];
    if (n !== void 0) {
        var i = n.call(r, e || "default");
        if (G(i) != "object") return i;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (e === "string" ? String : Number)(r)
}
Oe.InnerSlider = function(r) {
    Vn(n, r);
    var e = Qn(n);

    function n(i) {
        var t;
        Xn(this, n), t = e.call(this, i), L(C(t), "listRefHandler", function(o) {
            return t.list = o
        }), L(C(t), "trackRefHandler", function(o) {
            return t.track = o
        }), L(C(t), "adaptHeight", function() {
            if (t.props.adaptiveHeight && t.list) {
                var o = t.list.querySelector('[data-index="'.concat(t.state.currentSlide, '"]'));
                t.list.style.height = (0, H.getHeight)(o) + "px"
            }
        }), L(C(t), "componentDidMount", function() {
            if (t.props.onInit && t.props.onInit(), t.props.lazyLoad) {
                var o = (0, H.getOnDemandLazySlides)(m(m({}, t.props), t.state));
                o.length > 0 && (t.setState(function(s) {
                    return {
                        lazyLoadedList: s.lazyLoadedList.concat(o)
                    }
                }), t.props.onLazyLoad && t.props.onLazyLoad(o))
            }
            var l = m({
                listRef: t.list,
                trackRef: t.track
            }, t.props);
            t.updateState(l, !0, function() {
                t.adaptHeight(), t.props.autoplay && t.autoPlay("update")
            }), t.props.lazyLoad === "progressive" && (t.lazyLoadTimer = setInterval(t.progressiveLazyLoad, 1e3)), t.ro = new Bn.default(function() {
                t.state.animating ? (t.onWindowResized(!1), t.callbackTimers.push(setTimeout(function() {
                    return t.onWindowResized()
                }, t.props.speed))) : t.onWindowResized()
            }), t.ro.observe(t.list), document.querySelectorAll && Array.prototype.forEach.call(document.querySelectorAll(".slick-slide"), function(s) {
                s.onfocus = t.props.pauseOnFocus ? t.onSlideFocus : null, s.onblur = t.props.pauseOnFocus ? t.onSlideBlur : null
            }), window.addEventListener ? window.addEventListener("resize", t.onWindowResized) : window.attachEvent("onresize", t.onWindowResized)
        }), L(C(t), "componentWillUnmount", function() {
            t.animationEndCallback && clearTimeout(t.animationEndCallback), t.lazyLoadTimer && clearInterval(t.lazyLoadTimer), t.callbackTimers.length && (t.callbackTimers.forEach(function(o) {
                return clearTimeout(o)
            }), t.callbackTimers = []), window.addEventListener ? window.removeEventListener("resize", t.onWindowResized) : window.detachEvent("onresize", t.onWindowResized), t.autoplayTimer && clearInterval(t.autoplayTimer), t.ro.disconnect()
        }), L(C(t), "componentDidUpdate", function(o) {
            if (t.checkImagesLoad(), t.props.onReInit && t.props.onReInit(), t.props.lazyLoad) {
                var l = (0, H.getOnDemandLazySlides)(m(m({}, t.props), t.state));
                l.length > 0 && (t.setState(function(h) {
                    return {
                        lazyLoadedList: h.lazyLoadedList.concat(l)
                    }
                }), t.props.onLazyLoad && t.props.onLazyLoad(l))
            }
            t.adaptHeight();
            var s = m(m({
                    listRef: t.list,
                    trackRef: t.track
                }, t.props), t.state),
                u = t.didPropsChange(o);
            u && t.updateState(s, u, function() {
                t.state.currentSlide >= I.default.Children.count(t.props.children) && t.changeSlide({
                    message: "index",
                    index: I.default.Children.count(t.props.children) - t.props.slidesToShow,
                    currentSlide: t.state.currentSlide
                }), t.props.autoplay ? t.autoPlay("update") : t.pause("paused")
            })
        }), L(C(t), "onWindowResized", function(o) {
            t.debouncedResize && t.debouncedResize.cancel(), t.debouncedResize = (0, Wn.default)(function() {
                return t.resizeWindow(o)
            }, 50), t.debouncedResize()
        }), L(C(t), "resizeWindow", function() {
            var o = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0,
                l = !!(t.track && t.track.node);
            if (l) {
                var s = m(m({
                    listRef: t.list,
                    trackRef: t.track
                }, t.props), t.state);
                t.updateState(s, o, function() {
                    t.props.autoplay ? t.autoPlay("update") : t.pause("paused")
                }), t.setState({
                    animating: !1
                }), clearTimeout(t.animationEndCallback), delete t.animationEndCallback
            }
        }), L(C(t), "updateState", function(o, l, s) {
            var u = (0, H.initializedState)(o);
            o = m(m(m({}, o), u), {}, {
                slideIndex: u.currentSlide
            });
            var h = (0, H.getTrackLeft)(o);
            o = m(m({}, o), {}, {
                left: h
            });
            var c = (0, H.getTrackCSS)(o);
            (l || I.default.Children.count(t.props.children) !== I.default.Children.count(o.children)) && (u.trackStyle = c), t.setState(u, s)
        }), L(C(t), "ssrInit", function() {
            if (t.props.variableWidth) {
                var o = 0,
                    l = 0,
                    s = [],
                    u = (0, H.getPreClones)(m(m(m({}, t.props), t.state), {}, {
                        slideCount: t.props.children.length
                    })),
                    h = (0, H.getPostClones)(m(m(m({}, t.props), t.state), {}, {
                        slideCount: t.props.children.length
                    }));
                t.props.children.forEach(function(D) {
                    s.push(D.props.style.width), o += D.props.style.width
                });
                for (var c = 0; c < u; c++) l += s[s.length - 1 - c], o += s[s.length - 1 - c];
                for (var b = 0; b < h; b++) o += s[b];
                for (var M = 0; M < t.state.currentSlide; M++) l += s[M];
                var O = {
                    width: o + "px",
                    left: -l + "px"
                };
                if (t.props.centerMode) {
                    var y = "".concat(s[t.state.currentSlide], "px");
                    O.left = "calc(".concat(O.left, " + (100% - ").concat(y, ") / 2 ) ")
                }
                return {
                    trackStyle: O
                }
            }
            var g = I.default.Children.count(t.props.children),
                T = m(m(m({}, t.props), t.state), {}, {
                    slideCount: g
                }),
                v = (0, H.getPreClones)(T) + (0, H.getPostClones)(T) + g,
                S = 100 / t.props.slidesToShow * v,
                k = 100 / v,
                j = -k * ((0, H.getPreClones)(T) + t.state.currentSlide) * S / 100;
            t.props.centerMode && (j += (100 - k * S / 100) / 2);
            var x = {
                width: S + "%",
                left: j + "%"
            };
            return {
                slideWidth: k + "%",
                trackStyle: x
            }
        }), L(C(t), "checkImagesLoad", function() {
            var o = t.list && t.list.querySelectorAll && t.list.querySelectorAll(".slick-slide img") || [],
                l = o.length,
                s = 0;
            Array.prototype.forEach.call(o, function(u) {
                var h = function() {
                    return ++s && s >= l && t.onWindowResized()
                };
                if (!u.onclick) u.onclick = function() {
                    return u.parentNode.focus()
                };
                else {
                    var c = u.onclick;
                    u.onclick = function(b) {
                        c(b), u.parentNode.focus()
                    }
                }
                u.onload || (t.props.lazyLoad ? u.onload = function() {
                    t.adaptHeight(), t.callbackTimers.push(setTimeout(t.onWindowResized, t.props.speed))
                } : (u.onload = h, u.onerror = function() {
                    h(), t.props.onLazyLoadError && t.props.onLazyLoadError()
                }))
            })
        }), L(C(t), "progressiveLazyLoad", function() {
            for (var o = [], l = m(m({}, t.props), t.state), s = t.state.currentSlide; s < t.state.slideCount + (0, H.getPostClones)(l); s++)
                if (t.state.lazyLoadedList.indexOf(s) < 0) {
                    o.push(s);
                    break
                }
            for (var u = t.state.currentSlide - 1; u >= -(0, H.getPreClones)(l); u--)
                if (t.state.lazyLoadedList.indexOf(u) < 0) {
                    o.push(u);
                    break
                }
            o.length > 0 ? (t.setState(function(h) {
                return {
                    lazyLoadedList: h.lazyLoadedList.concat(o)
                }
            }), t.props.onLazyLoad && t.props.onLazyLoad(o)) : t.lazyLoadTimer && (clearInterval(t.lazyLoadTimer), delete t.lazyLoadTimer)
        }), L(C(t), "slideHandler", function(o) {
            var l = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
                s = t.props,
                u = s.asNavFor,
                h = s.beforeChange,
                c = s.onLazyLoad,
                b = s.speed,
                M = s.afterChange,
                O = t.state.currentSlide,
                y = (0, H.slideHandler)(m(m(m({
                    index: o
                }, t.props), t.state), {}, {
                    trackRef: t.track,
                    useCSS: t.props.useCSS && !l
                })),
                g = y.state,
                T = y.nextState;
            if (g) {
                h && h(O, g.currentSlide);
                var v = g.lazyLoadedList.filter(function(S) {
                    return t.state.lazyLoadedList.indexOf(S) < 0
                });
                c && v.length > 0 && c(v), !t.props.waitForAnimate && t.animationEndCallback && (clearTimeout(t.animationEndCallback), M && M(O), delete t.animationEndCallback), t.setState(g, function() {
                    u && t.asNavForIndex !== o && (t.asNavForIndex = o, u.innerSlider.slideHandler(o)), T && (t.animationEndCallback = setTimeout(function() {
                        var S = T.animating,
                            k = Un(T, ["animating"]);
                        t.setState(k, function() {
                            t.callbackTimers.push(setTimeout(function() {
                                return t.setState({
                                    animating: S
                                })
                            }, 10)), M && M(g.currentSlide), delete t.animationEndCallback
                        })
                    }, b))
                })
            }
        }), L(C(t), "changeSlide", function(o) {
            var l = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1,
                s = m(m({}, t.props), t.state),
                u = (0, H.changeSlide)(s, o);
            if (!(u !== 0 && !u) && (l === !0 ? t.slideHandler(u, l) : t.slideHandler(u), t.props.autoplay && t.autoPlay("update"), t.props.focusOnSelect)) {
                var h = t.list.querySelectorAll(".slick-current");
                h[0] && h[0].focus()
            }
        }), L(C(t), "clickHandler", function(o) {
            t.clickable === !1 && (o.stopPropagation(), o.preventDefault()), t.clickable = !0
        }), L(C(t), "keyHandler", function(o) {
            var l = (0, H.keyHandler)(o, t.props.accessibility, t.props.rtl);
            l !== "" && t.changeSlide({
                message: l
            })
        }), L(C(t), "selectHandler", function(o) {
            t.changeSlide(o)
        }), L(C(t), "disableBodyScroll", function() {
            var o = function(s) {
                s = s || window.event, s.preventDefault && s.preventDefault(), s.returnValue = !1
            };
            window.ontouchmove = o
        }), L(C(t), "enableBodyScroll", function() {
            window.ontouchmove = null
        }), L(C(t), "swipeStart", function(o) {
            t.props.verticalSwiping && t.disableBodyScroll();
            var l = (0, H.swipeStart)(o, t.props.swipe, t.props.draggable);
            l !== "" && t.setState(l)
        }), L(C(t), "swipeMove", function(o) {
            var l = (0, H.swipeMove)(o, m(m(m({}, t.props), t.state), {}, {
                trackRef: t.track,
                listRef: t.list,
                slideIndex: t.state.currentSlide
            }));
            l && (l.swiping && (t.clickable = !1), t.setState(l))
        }), L(C(t), "swipeEnd", function(o) {
            var l = (0, H.swipeEnd)(o, m(m(m({}, t.props), t.state), {}, {
                trackRef: t.track,
                listRef: t.list,
                slideIndex: t.state.currentSlide
            }));
            if (l) {
                var s = l.triggerSlideHandler;
                delete l.triggerSlideHandler, t.setState(l), s !== void 0 && (t.slideHandler(s), t.props.verticalSwiping && t.enableBodyScroll())
            }
        }), L(C(t), "touchEnd", function(o) {
            t.swipeEnd(o), t.clickable = !0
        }), L(C(t), "slickPrev", function() {
            t.callbackTimers.push(setTimeout(function() {
                return t.changeSlide({
                    message: "previous"
                })
            }, 0))
        }), L(C(t), "slickNext", function() {
            t.callbackTimers.push(setTimeout(function() {
                return t.changeSlide({
                    message: "next"
                })
            }, 0))
        }), L(C(t), "slickGoTo", function(o) {
            var l = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
            if (o = Number(o), isNaN(o)) return "";
            t.callbackTimers.push(setTimeout(function() {
                return t.changeSlide({
                    message: "index",
                    index: o,
                    currentSlide: t.state.currentSlide
                }, l)
            }, 0))
        }), L(C(t), "play", function() {
            var o;
            if (t.props.rtl) o = t.state.currentSlide - t.props.slidesToScroll;
            else if ((0, H.canGoNext)(m(m({}, t.props), t.state))) o = t.state.currentSlide + t.props.slidesToScroll;
            else return !1;
            t.slideHandler(o)
        }), L(C(t), "autoPlay", function(o) {
            t.autoplayTimer && clearInterval(t.autoplayTimer);
            var l = t.state.autoplaying;
            if (o === "update") {
                if (l === "hovered" || l === "focused" || l === "paused") return
            } else if (o === "leave") {
                if (l === "paused" || l === "focused") return
            } else if (o === "blur" && (l === "paused" || l === "hovered")) return;
            t.autoplayTimer = setInterval(t.play, t.props.autoplaySpeed + 50), t.setState({
                autoplaying: "playing"
            })
        }), L(C(t), "pause", function(o) {
            t.autoplayTimer && (clearInterval(t.autoplayTimer), t.autoplayTimer = null);
            var l = t.state.autoplaying;
            o === "paused" ? t.setState({
                autoplaying: "paused"
            }) : o === "focused" ? (l === "hovered" || l === "playing") && t.setState({
                autoplaying: "focused"
            }) : l === "playing" && t.setState({
                autoplaying: "hovered"
            })
        }), L(C(t), "onDotsOver", function() {
            return t.props.autoplay && t.pause("hovered")
        }), L(C(t), "onDotsLeave", function() {
            return t.props.autoplay && t.state.autoplaying === "hovered" && t.autoPlay("leave")
        }), L(C(t), "onTrackOver", function() {
            return t.props.autoplay && t.pause("hovered")
        }), L(C(t), "onTrackLeave", function() {
            return t.props.autoplay && t.state.autoplaying === "hovered" && t.autoPlay("leave")
        }), L(C(t), "onSlideFocus", function() {
            return t.props.autoplay && t.pause("focused")
        }), L(C(t), "onSlideBlur", function() {
            return t.props.autoplay && t.state.autoplaying === "focused" && t.autoPlay("blur")
        }), L(C(t), "render", function() {
            var o = (0, $n.default)("slick-slider", t.props.className, {
                    "slick-vertical": t.props.vertical,
                    "slick-initialized": !0
                }),
                l = m(m({}, t.props), t.state),
                s = (0, H.extractObject)(l, ["fade", "cssEase", "speed", "infinite", "centerMode", "focusOnSelect", "currentSlide", "lazyLoad", "lazyLoadedList", "rtl", "slideWidth", "slideHeight", "listHeight", "vertical", "slidesToShow", "slidesToScroll", "slideCount", "trackStyle", "variableWidth", "unslick", "centerPadding", "targetSlide", "useCSS"]),
                u = t.props.pauseOnHover;
            s = m(m({}, s), {}, {
                onMouseEnter: u ? t.onTrackOver : null,
                onMouseLeave: u ? t.onTrackLeave : null,
                onMouseOver: u ? t.onTrackOver : null,
                focusOnSelect: t.props.focusOnSelect && t.clickable ? t.selectHandler : null
            });
            var h;
            if (t.props.dots === !0 && t.state.slideCount >= t.props.slidesToShow) {
                var c = (0, H.extractObject)(l, ["dotsClass", "slideCount", "slidesToShow", "currentSlide", "slidesToScroll", "clickHandler", "children", "customPaging", "infinite", "appendDots"]),
                    b = t.props.pauseOnDotsHover;
                c = m(m({}, c), {}, {
                    clickHandler: t.changeSlide,
                    onMouseEnter: b ? t.onDotsLeave : null,
                    onMouseOver: b ? t.onDotsOver : null,
                    onMouseLeave: b ? t.onDotsLeave : null
                }), h = I.default.createElement(Fn.Dots, c)
            }
            var M, O, y = (0, H.extractObject)(l, ["infinite", "centerMode", "currentSlide", "slideCount", "slidesToShow", "prevArrow", "nextArrow"]);
            y.clickHandler = t.changeSlide, t.props.arrows && (M = I.default.createElement(st.PrevArrow, y), O = I.default.createElement(st.NextArrow, y));
            var g = null;
            t.props.vertical && (g = {
                height: t.state.listHeight
            });
            var T = null;
            t.props.vertical === !1 ? t.props.centerMode === !0 && (T = {
                padding: "0px " + t.props.centerPadding
            }) : t.props.centerMode === !0 && (T = {
                padding: t.props.centerPadding + " 0px"
            });
            var v = m(m({}, g), T),
                S = t.props.touchMove,
                k = {
                    className: "slick-list",
                    style: v,
                    onClick: t.clickHandler,
                    onMouseDown: S ? t.swipeStart : null,
                    onMouseMove: t.state.dragging && S ? t.swipeMove : null,
                    onMouseUp: S ? t.swipeEnd : null,
                    onMouseLeave: t.state.dragging && S ? t.swipeEnd : null,
                    onTouchStart: S ? t.swipeStart : null,
                    onTouchMove: t.state.dragging && S ? t.swipeMove : null,
                    onTouchEnd: S ? t.touchEnd : null,
                    onTouchCancel: t.state.dragging && S ? t.swipeEnd : null,
                    onKeyDown: t.props.accessibility ? t.keyHandler : null
                },
                j = {
                    className: o,
                    dir: "ltr",
                    style: t.props.style
                };
            return t.props.unslick && (k = {
                className: "slick-list"
            }, j = {
                className: o
            }), I.default.createElement("div", j, t.props.unslick ? "" : M, I.default.createElement("div", Se({
                ref: t.listRefHandler
            }, k), I.default.createElement(qn.Track, Se({
                ref: t.trackRefHandler
            }, s), t.props.children)), t.props.unslick ? "" : O, t.props.unslick ? "" : h)
        }), t.list = null, t.track = null, t.state = m(m({}, An.default), {}, {
            currentSlide: t.props.initialSlide,
            targetSlide: t.props.initialSlide ? t.props.initialSlide : 0,
            slideCount: I.default.Children.count(t.props.children)
        }), t.callbackTimers = [], t.clickable = !0, t.debouncedResize = null;
        var a = t.ssrInit();
        return t.state = m(m({}, t.state), a), t
    }
    return Yn(n, [{
        key: "didPropsChange",
        value: function(t) {
            for (var a = !1, o = 0, l = Object.keys(this.props); o < l.length; o++) {
                var s = l[o];
                if (!t.hasOwnProperty(s)) {
                    a = !0;
                    break
                }
                if (!(G(t[s]) === "object" || typeof t[s] == "function" || isNaN(t[s])) && t[s] !== this.props[s]) {
                    a = !0;
                    break
                }
            }
            return a || I.default.Children.count(this.props.children) !== I.default.Children.count(t.children)
        }
    }]), n
}(I.default.Component);
var ei = function(r) {
        return r.replace(/[A-Z]/g, function(e) {
            return "-" + e.toLowerCase()
        }).toLowerCase()
    },
    ti = ei,
    ri = ti,
    ni = function(r) {
        var e = /[height|width]$/;
        return e.test(r)
    },
    ct = function(r) {
        var e = "",
            n = Object.keys(r);
        return n.forEach(function(i, t) {
            var a = r[i];
            i = ri(i), ni(i) && typeof a == "number" && (a = a + "px"), a === !0 ? e += i : a === !1 ? e += "not " + i : e += "(" + i + ": " + a + ")", t < n.length - 1 && (e += " and ")
        }), e
    },
    ii = function(r) {
        var e = "";
        return typeof r == "string" ? r : r instanceof Array ? (r.forEach(function(n, i) {
            e += ct(n), i < r.length - 1 && (e += ", ")
        }), e) : ct(r)
    },
    oi = ii,
    Re, ft;

function ai() {
    if (ft) return Re;
    ft = 1;

    function r(e) {
        this.options = e, !e.deferSetup && this.setup()
    }
    return r.prototype = {
        constructor: r,
        setup: function() {
            this.options.setup && this.options.setup(), this.initialised = !0
        },
        on: function() {
            !this.initialised && this.setup(), this.options.match && this.options.match()
        },
        off: function() {
            this.options.unmatch && this.options.unmatch()
        },
        destroy: function() {
            this.options.destroy ? this.options.destroy() : this.off()
        },
        equals: function(e) {
            return this.options === e || this.options.match === e
        }
    }, Re = r, Re
}
var ze, dt;

function Vt() {
    if (dt) return ze;
    dt = 1;

    function r(i, t) {
        var a = 0,
            o = i.length,
            l;
        for (a; a < o && (l = t(i[a], a), l !== !1); a++);
    }

    function e(i) {
        return Object.prototype.toString.apply(i) === "[object Array]"
    }

    function n(i) {
        return typeof i == "function"
    }
    return ze = {
        isFunction: n,
        isArray: e,
        each: r
    }, ze
}
var De, pt;

function li() {
    if (pt) return De;
    pt = 1;
    var r = ai(),
        e = Vt().each;

    function n(i, t) {
        this.query = i, this.isUnconditional = t, this.handlers = [], this.mql = window.matchMedia(i);
        var a = this;
        this.listener = function(o) {
            a.mql = o.currentTarget || o, a.assess()
        }, this.mql.addListener(this.listener)
    }
    return n.prototype = {
        constuctor: n,
        addHandler: function(i) {
            var t = new r(i);
            this.handlers.push(t), this.matches() && t.on()
        },
        removeHandler: function(i) {
            var t = this.handlers;
            e(t, function(a, o) {
                if (a.equals(i)) return a.destroy(), !t.splice(o, 1)
            })
        },
        matches: function() {
            return this.mql.matches || this.isUnconditional
        },
        clear: function() {
            e(this.handlers, function(i) {
                i.destroy()
            }), this.mql.removeListener(this.listener), this.handlers.length = 0
        },
        assess: function() {
            var i = this.matches() ? "on" : "off";
            e(this.handlers, function(t) {
                t[i]()
            })
        }
    }, De = n, De
}
var He, vt;

function si() {
    if (vt) return He;
    vt = 1;
    var r = li(),
        e = Vt(),
        n = e.each,
        i = e.isFunction,
        t = e.isArray;

    function a() {
        if (!window.matchMedia) throw new Error("matchMedia not present, legacy browsers require a polyfill");
        this.queries = {}, this.browserIsIncapable = !window.matchMedia("only all").matches
    }
    return a.prototype = {
        constructor: a,
        register: function(o, l, s) {
            var u = this.queries,
                h = s && this.browserIsIncapable;
            return u[o] || (u[o] = new r(o, h)), i(l) && (l = {
                match: l
            }), t(l) || (l = [l]), n(l, function(c) {
                i(c) && (c = {
                    match: c
                }), u[o].addHandler(c)
            }), this
        },
        unregister: function(o, l) {
            var s = this.queries[o];
            return s && (l ? s.removeHandler(l) : (s.clear(), delete this.queries[o])), this
        }
    }, He = a, He
}
var Ne, ht;

function ui() {
    if (ht) return Ne;
    ht = 1;
    var r = si();
    return Ne = new r, Ne
}(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = void 0;
    var e = o(X),
        n = Oe,
        i = o(oi),
        t = o(Ke),
        a = f;

    function o(p) {
        return p && p.__esModule ? p : {
            default: p
        }
    }

    function l(p) {
        "@babel/helpers - typeof";
        return l = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(d) {
            return typeof d
        } : function(d) {
            return d && typeof Symbol == "function" && d.constructor === Symbol && d !== Symbol.prototype ? "symbol" : typeof d
        }, l(p)
    }

    function s() {
        return s = Object.assign ? Object.assign.bind() : function(p) {
            for (var d = 1; d < arguments.length; d++) {
                var E = arguments[d];
                for (var w in E) Object.prototype.hasOwnProperty.call(E, w) && (p[w] = E[w])
            }
            return p
        }, s.apply(this, arguments)
    }

    function u(p, d) {
        var E = Object.keys(p);
        if (Object.getOwnPropertySymbols) {
            var w = Object.getOwnPropertySymbols(p);
            d && (w = w.filter(function(_) {
                return Object.getOwnPropertyDescriptor(p, _).enumerable
            })), E.push.apply(E, w)
        }
        return E
    }

    function h(p) {
        for (var d = 1; d < arguments.length; d++) {
            var E = arguments[d] != null ? arguments[d] : {};
            d % 2 ? u(Object(E), !0).forEach(function(w) {
                j(p, w, E[w])
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(p, Object.getOwnPropertyDescriptors(E)) : u(Object(E)).forEach(function(w) {
                Object.defineProperty(p, w, Object.getOwnPropertyDescriptor(E, w))
            })
        }
        return p
    }

    function c(p, d) {
        if (!(p instanceof d)) throw new TypeError("Cannot call a class as a function")
    }

    function b(p, d) {
        for (var E = 0; E < d.length; E++) {
            var w = d[E];
            w.enumerable = w.enumerable || !1, w.configurable = !0, "value" in w && (w.writable = !0), Object.defineProperty(p, x(w.key), w)
        }
    }

    function M(p, d, E) {
        return d && b(p.prototype, d), Object.defineProperty(p, "prototype", {
            writable: !1
        }), p
    }

    function O(p, d) {
        if (typeof d != "function" && d !== null) throw new TypeError("Super expression must either be null or a function");
        p.prototype = Object.create(d && d.prototype, {
            constructor: {
                value: p,
                writable: !0,
                configurable: !0
            }
        }), Object.defineProperty(p, "prototype", {
            writable: !1
        }), d && y(p, d)
    }

    function y(p, d) {
        return y = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(w, _) {
            return w.__proto__ = _, w
        }, y(p, d)
    }

    function g(p) {
        var d = S();
        return function() {
            var w = k(p),
                _;
            if (d) {
                var P = k(this).constructor;
                _ = Reflect.construct(w, arguments, P)
            } else _ = w.apply(this, arguments);
            return T(this, _)
        }
    }

    function T(p, d) {
        if (d && (l(d) === "object" || typeof d == "function")) return d;
        if (d !== void 0) throw new TypeError("Derived constructors may only return object or undefined");
        return v(p)
    }

    function v(p) {
        if (p === void 0) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return p
    }

    function S() {
        try {
            var p = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {}))
        } catch {}
        return (S = function() {
            return !!p
        })()
    }

    function k(p) {
        return k = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(E) {
            return E.__proto__ || Object.getPrototypeOf(E)
        }, k(p)
    }

    function j(p, d, E) {
        return d = x(d), d in p ? Object.defineProperty(p, d, {
            value: E,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : p[d] = E, p
    }

    function x(p) {
        var d = D(p, "string");
        return l(d) == "symbol" ? d : String(d)
    }

    function D(p, d) {
        if (l(p) != "object" || !p) return p;
        var E = p[Symbol.toPrimitive];
        if (E !== void 0) {
            var w = E.call(p, d || "default");
            if (l(w) != "object") return w;
            throw new TypeError("@@toPrimitive must return a primitive value.")
        }
        return (d === "string" ? String : Number)(p)
    }
    var W = (0, a.canUseDOM)() && ui();
    r.default = function(p) {
        O(E, p);
        var d = g(E);

        function E(w) {
            var _;
            return c(this, E), _ = d.call(this, w), j(v(_), "innerSliderRefHandler", function(P) {
                return _.innerSlider = P
            }), j(v(_), "slickPrev", function() {
                return _.innerSlider.slickPrev()
            }), j(v(_), "slickNext", function() {
                return _.innerSlider.slickNext()
            }), j(v(_), "slickGoTo", function(P) {
                var B = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1;
                return _.innerSlider.slickGoTo(P, B)
            }), j(v(_), "slickPause", function() {
                return _.innerSlider.pause("paused")
            }), j(v(_), "slickPlay", function() {
                return _.innerSlider.autoPlay("play")
            }), _.state = {
                breakpoint: null
            }, _._responsiveMediaHandlers = [], _
        }
        return M(E, [{
            key: "media",
            value: function(_, P) {
                W.register(_, P), this._responsiveMediaHandlers.push({
                    query: _,
                    handler: P
                })
            }
        }, {
            key: "componentDidMount",
            value: function() {
                var _ = this;
                if (this.props.responsive) {
                    var P = this.props.responsive.map(function(N) {
                        return N.breakpoint
                    });
                    P.sort(function(N, $) {
                        return N - $
                    }), P.forEach(function(N, $) {
                        var K;
                        $ === 0 ? K = (0, i.default)({
                            minWidth: 0,
                            maxWidth: N
                        }) : K = (0, i.default)({
                            minWidth: P[$ - 1] + 1,
                            maxWidth: N
                        }), (0, a.canUseDOM)() && _.media(K, function() {
                            _.setState({
                                breakpoint: N
                            })
                        })
                    });
                    var B = (0, i.default)({
                        minWidth: P.slice(-1)[0]
                    });
                    (0, a.canUseDOM)() && this.media(B, function() {
                        _.setState({
                            breakpoint: null
                        })
                    })
                }
            }
        }, {
            key: "componentWillUnmount",
            value: function() {
                this._responsiveMediaHandlers.forEach(function(_) {
                    W.unregister(_.query, _.handler)
                })
            }
        }, {
            key: "render",
            value: function() {
                var _ = this,
                    P, B;
                this.state.breakpoint ? (B = this.props.responsive.filter(function(ne) {
                    return ne.breakpoint === _.state.breakpoint
                }), P = B[0].settings === "unslick" ? "unslick" : h(h(h({}, t.default), this.props), B[0].settings)) : P = h(h({}, t.default), this.props), P.centerMode && (P.slidesToScroll > 1, P.slidesToScroll = 1), P.fade && (P.slidesToShow > 1, P.slidesToScroll > 1, P.slidesToShow = 1, P.slidesToScroll = 1);
                var N = e.default.Children.toArray(this.props.children);
                N = N.filter(function(ne) {
                    return typeof ne == "string" ? !!ne.trim() : !!ne
                }), P.variableWidth && (P.rows > 1 || P.slidesPerRow > 1) && (console.warn("variableWidth is not supported in case of rows > 1 or slidesPerRow > 1"), P.variableWidth = !1);
                for (var $ = [], K = null, q = 0; q < N.length; q += P.rows * P.slidesPerRow) {
                    for (var ke = [], Y = q; Y < q + P.rows * P.slidesPerRow; Y += P.slidesPerRow) {
                        for (var Ve = [], U = Y; U < Y + P.slidesPerRow && (P.variableWidth && N[U].props.style && (K = N[U].props.style.width), !(U >= N.length)); U += 1) Ve.push(e.default.cloneElement(N[U], {
                            key: 100 * q + 10 * Y + U,
                            tabIndex: -1,
                            style: {
                                width: "".concat(100 / P.slidesPerRow, "%"),
                                display: "inline-block"
                            }
                        }));
                        ke.push(e.default.createElement("div", {
                            key: 10 * q + Y
                        }, Ve))
                    }
                    P.variableWidth ? $.push(e.default.createElement("div", {
                        key: q,
                        style: {
                            width: K
                        }
                    }, ke)) : $.push(e.default.createElement("div", {
                        key: q
                    }, ke))
                }
                if (P === "unslick") {
                    var Qt = "regular slider " + (this.props.className || "");
                    return e.default.createElement("div", {
                        className: Qt
                    }, N)
                } else $.length <= P.slidesToShow && !P.infinite && (P.unslick = !0);
                return e.default.createElement(n.InnerSlider, s({
                    style: this.props.style,
                    ref: this.innerSliderRefHandler
                }, (0, a.filterSettings)(P)), $)
            }
        }]), E
    }(e.default.Component)
})(gt);
(function(r) {
    Object.defineProperty(r, "__esModule", {
        value: !0
    }), r.default = void 0;
    var e = n(gt);

    function n(i) {
        return i && i.__esModule ? i : {
            default: i
        }
    }
    r.default = e.default
})(yt);
const ci = Jt(yt),
    fi = [{
        id: 1,
        name: "HTML",
        icon: R.jsx(er, {
            className: "text-orange-600"
        })
    }, {
        id: 2,
        name: "Strapi",
        icon: R.jsx(cr, {
            className: "text-purple-500 "
        })
    }, {
        id: 3,
        name: "Next.js",
        icon: R.jsx(sr, {
            className: "text-gray-800 "
        })
    }, {
        id: 4,
        name: "JavaScript",
        icon: R.jsx(tr, {
            className: "text-yellow-500 translate-x-[1.30rem]"
        })
    }, {
        id: 5,
        name: "React.js",
        icon: R.jsx(rr, {
            className: "text-blue-500 translate-x-[1rem]"
        })
    }, {
        id: 6,
        name: "Express.js",
        icon: R.jsx(lr, {
            className: "text-black translate-x-[1rem]"
        })
    }, {
        id: 7,
        name: "Tailwind CSS",
        icon: R.jsx(fr, {
            className: "text-blue-400 translate-x-[2rem]"
        })
    }, {
        id: 8,
        name: "CSS",
        icon: R.jsx(nr, {
            className: "text-blue-500"
        })
    }, {
        id: 9,
        name: "GSAP",
        icon: R.jsx(ur, {
            className: "text-green-500"
        })
    }],
    di = ({
        onClick: r
    }) => R.jsx("div", {
        className: "absolute top-1/2 right-0 transform -translate-y-1/2 cursor-pointer",
        children: R.jsx(ir, {
            className: "text-4xl text-green-500",
            onClick: r
        })
    }),
    pi = ({
        onClick: r
    }) => R.jsx("div", {
        className: "absolute top-1/2 left-0 transform -translate-y-1/2 cursor-pointer z-[1]",
        children: R.jsx(or, {
            className: "text-4xl text-green-500",
            onClick: r
        })
    }),
    vi = {
        dots: !0,
        infinite: !0,
        speed: 500,
        slidesToShow: 3,
        slidesToScroll: 1,
        nextArrow: R.jsx(di, {}),
        prevArrow: R.jsx(pi, {}),
        responsive: [{
            breakpoint: 768,
            settings: {
                slidesToShow: 1,
                slidesToScroll: 1
            }
        }]
    };

function hi() {
    return R.jsx("div", {
        className: "relative overflow-hidden",
        children: R.jsx(ci, { ...vi,
            children: fi.map(r => R.jsx("div", {
                className: "pl-8 md:pl-12 p-4",
                children: R.jsx("div", {
                    className: "w-[280px] flex items-center hover:shadow-multi-color hover:scale-105 duration-300 justify-center bg-[#f8f8f8] border rounded-lg shadow-lg py-[80px]",
                    children: R.jsxs("div", {
                        className: "text-center ",
                        children: [R.jsx("span", {
                            className: "text-6xl block mb-4",
                            children: r.icon
                        }), R.jsx("span", {
                            className: " font-semibold text-xl",
                            children: r.name
                        })]
                    })
                })
            }, r.id))
        })
    })
}
const gi = () => R.jsx(ie.div, {
    className: "pt-[40px] relative bg-gray-50",
    initial: {
        opacity: 0
    },
    whileInView: {
        opacity: 1
    },
    transition: {
        duration: .5
    },
    children: R.jsxs("div", {
        className: "layout text-center mb-[50px]",
        children: [R.jsx(ie.div, {
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: .2,
                duration: .5
            },
            children: R.jsx(Qe, {
                className: "text-[30px] my-4",
                labelText: "Noor offers a wide range of services"
            })
        }), R.jsx(ie.div, {
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: .4,
                duration: .5
            },
            children: R.jsx(Qe, {
                className: "text-[30px] mb-[50px]",
                labelText: "tailored to meet your project needs."
            })
        }), R.jsx(ie.div, {
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: .6,
                duration: .5
            },
            children: R.jsx(ar, {
                className: "text-[45px] mb-[40px]",
                labelText: "Skills"
            })
        }), R.jsx(ie.div, {
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: .8,
                duration: .5
            },
            className: "mx-auto mb-[80px]",
            children: R.jsx(hi, {})
        })]
    })
});
export {
    gi as
    default
};
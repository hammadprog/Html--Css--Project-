import {
    j as e,
    m as i,
    i as a,
    H as t,
    P as s,
    B as n
} from "./index-cplxNlKn.js";
const l = () => e.jsx(i.div, {
    className: "bg-gray-50",
    initial: {
        opacity: 0
    },
    whileInView: {
        opacity: 1
    },
    transition: {
        duration: .3,
        ease: "easeInOut"
    },
    children: e.jsx("div", {
        className: "layout ",
        children: e.jsxs("div", {
            className: "pt-[50px] flex flex-col md:flex-row items-start md:items-center space-y-6 md:space-y-0 md:space-x-8 p-6",
            children: [e.jsx(i.div, {
                className: "w-full md:w-1/2 rounded-md overflow-hidden shadow duration-300 hover:shadow-multi-color",
                initial: {
                    opacity: 0,
                    scale: .5,
                    x: -60
                },
                whileInView: {
                    opacity: 1,
                    scale: 1,
                    x: 0
                },
                transition: {
                    duration: .5
                },
                children: e.jsx("a", {
                    href: "https://www.renie.io/",
                    target: "_blank",
                    children: e.jsx("img", {
                        src: a,
                        alt: "Descriptive Alt Text",
                        className: "w-[100%] object-cover  duration-300 scale-110 hover:scale-125"
                    })
                })
            }), e.jsxs(i.div, {
                className: "w-full md:w-1/2",
                initial: {
                    opacity: 0,
                    y: 30
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 1
                },
                children: [e.jsx(t, {
                    className: "text-[45px] mb-4 leading-[45px]",
                    labelText: "  Freelance Work at Renie.io"
                }), e.jsx(s, {
                    className: "text-base text-[18px] text-gray-900 mb-4",
                    labelText: `At Renie.io, I specialized in converting intricate Figma designs into
          fully functional React components. This involved meticulous attention
          to detail and a deep understanding of both design and development
          principles.`
                }), e.jsxs(i.ul, {
                    className: "list-disc pl-5 space-y-2 text-gray-900",
                    initial: {
                        opacity: 0,
                        x: -30
                    },
                    whileInView: {
                        opacity: 1,
                        x: 0
                    },
                    transition: {
                        duration: 1
                    },
                    children: [e.jsx("li", {
                        children: "Converted Figma designs to React components"
                    }), e.jsx("li", {
                        children: "Ensured pixel-perfect implementation"
                    }), e.jsx("li", {
                        children: "Collaborated with designers for seamless integration"
                    })]
                }), e.jsx(i.a, {
                    href: "https://github.com/NoorNazar123/collaborateProject",
                    target: "_blank",
                    initial: {
                        opacity: 0,
                        x: -30
                    },
                    whileInView: {
                        opacity: 1,
                        x: 0
                    },
                    transition: {
                        duration: 1
                    },
                    children: e.jsx(n, {
                        className: "py-2 px-4 shadow-md rounded-md mt-4 border hover:shadow-lg hover:bg-[#f0f0fw] hover:box-border hover:text-gray-700",
                        label: "View Code"
                    })
                })]
            })]
        })
    })
});
export {
    l as
    default
};
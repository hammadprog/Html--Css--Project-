import {
    j as a,
    m as e,
    y as i,
    i as o,
    k as s,
    N as t,
    p as r,
    L as n,
    B as l
} from "./index-cplxNlKn.js";
const c = () => a.jsx(e.div, {
    initial: {
        opacity: 0
    },
    whileInView: {
        opacity: 1
    },
    transition: {
        duration: .5
    },
    children: a.jsxs("div", {
        className: "layout min-h-screen p-8",
        children: [a.jsxs(e.section, {
            className: "text-center my-16",
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: .2,
                duration: .5
            },
            children: [a.jsx("h2", {
                className: "text-[45px] font-bold mb-4",
                children: "Featured Projects"
            }), a.jsxs("p", {
                className: "text-lg text-gray-600",
                children: ["Explore my key projects that showcase my skills in web development, including ", a.jsx("br", {}), " YouTube clone and more."]
            })]
        }), a.jsxs("div", {
            className: "grid sm:grid-cols-12 gap-2",
            children: [a.jsx(e.div, {
                className: " bg-red-400 sm:col-span-6 sm:row-span-12 shadow-md hover:shadow-multi-color rounded-md overflow-hidden",
                initial: {
                    opacity: 0,
                    x: -30
                },
                whileInView: {
                    opacity: 1,
                    x: 0
                },
                transition: {
                    duration: .5
                },
                children: a.jsx("a", {
                    href: "https://zingy-brigadeiros-cf2f51.netlify.app/",
                    target: "_blank",
                    children: a.jsx("img", {
                        className: "w-[100%] h-[100%] scale-100 hover:scale-150 duration-500 ",
                        src: i,
                        alt: "youtube"
                    })
                })
            }), a.jsx(e.div, {
                className: " sm:col-span-3 sm:row-span-6 rounded-md shadow-md hover:shadow-multi-color duration-300 overflow-hidden",
                initial: {
                    opacity: 0,
                    y: 50
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: .5,
                    delay: .2
                },
                children: a.jsx("a", {
                    href: "https://www.renie.io/",
                    target: "_blank",
                    children: a.jsx("img", {
                        className: "w-[100%] h-[100%] scale-100 hover:scale-125 duration-500 object-cover",
                        src: o,
                        alt: "renie"
                    })
                })
            }), a.jsx(e.div, {
                className: " sm:col-span-3 sm:row-span-6 rounded-md shadow-md hover:shadow-multi-color duration-300 overflow-hidden",
                initial: {
                    opacity: 0,
                    x: -30
                },
                whileInView: {
                    opacity: 1,
                    x: 0
                },
                transition: {
                    duration: .5,
                    delay: .4
                },
                children: a.jsx("a", {
                    href: "https://symphonious-marzipan-f6b121.netlify.app/",
                    target: "_blank",
                    children: a.jsx("img", {
                        className: "w-[100%] h-[100%] scale-100 hover:scale-125 duration-500 object-cover",
                        src: s,
                        alt: "graphic web"
                    })
                })
            }), a.jsx(e.div, {
                className: " sm:col-span-3 sm:row-span-6 rounded-md shadow-md hover:shadow-multi-color duration-300 overflow-hidden",
                initial: {
                    opacity: 0,
                    y: 50
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: .5,
                    delay: .6
                },
                children: a.jsx("a", {
                    href: "https://nextjs-with-aceternity-ui-git-main-noor-nazars-projects.vercel.app/",
                    target: "_blank",
                    children: a.jsx("img", {
                        className: "w-[100%] h-[100%] scale-100 hover:scale-125 duration-500 object-cover",
                        src: t,
                        alt: "NextWeb"
                    })
                })
            }), a.jsx(e.div, {
                className: " sm:col-span-3 sm:row-span-6 rounded-md shadow-md hover:shadow-multi-color duration-300 overflow-hidden",
                initial: {
                    opacity: 0,
                    x: -20
                },
                whileInView: {
                    opacity: 1,
                    x: 0
                },
                transition: {
                    duration: .5,
                    delay: .8
                },
                children: a.jsx("a", {
                    href: "https://comforting-concha-965fde.netlify.app/",
                    target: "_blank",
                    children: a.jsx("img", {
                        className: "w-[100%] h-[100%] scale-100 hover:scale-125 duration-500 object-cover",
                        src: r,
                        alt: "portfolio"
                    })
                })
            })]
        }), a.jsx(e.div, {
            className: "text-center my-[30px]",
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                duration: .5,
                delay: .8
            },
            children: a.jsx(n, {
                to: "/api/v1/noor-e-nazar/project",
                children: a.jsx(l, {
                    className: "px-6 py-3 shadow-md hover:shadow-lg duration-300 rounded-md ",
                    label: "All Projects"
                })
            })
        })]
    })
});
export {
    c as
    default
};
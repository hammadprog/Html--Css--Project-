import {
    r as o,
    j as i,
    m as s
} from "./index-cplxNlKn.js";
const d = () => {
    const [r, a] = o.useState(!1), e = () => {
        const t = document.getElementById("google-map");
        if (t) {
            const {
                top: n
            } = t.getBoundingClientRect();
            n < window.innerHeight && n > 0 && (a(!0), window.removeEventListener("scroll", e))
        }
    };
    return o.useEffect(() => (window.addEventListener("scroll", e), () => {
        window.removeEventListener("scroll", e)
    }), []), i.jsx(s.div, {
        className: "flex justify-center items-center py-8",
        initial: {
            opacity: 0
        },
        whileInView: {
            opacity: 1
        },
        transition: {
            duration: .5
        },
        children: i.jsx(s.div, {
            id: "google-map",
            className: "rounded-lg shadow-lg md:w-[90%] lg:w-[85%] xl:w-[80%] 2xl:w-[75%]",
            initial: {
                opacity: 0,
                y: 50
            },
            whileInView: {
                opacity: 1,
                y: 0
            },
            transition: {
                delay: .2,
                duration: .5
            },
            children: r && i.jsx("iframe", {
                src: "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d7234.1065682635535!2d66.97186233904026!3d24.964301687934142!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3eb36af101e184e1%3A0xcd1339219122cbc1!2sChishti%20Nagar%20Orangi%20Town%2C%20Karachi%2C%20Karachi%20City%2C%20Sindh%2C%20Pakistan!5e0!3m2!1sen!2s!4v1728286691938!5m2!1sen!2s",
                width: "100%",
                height: "450",
                style: {
                    border: 0
                },
                allowFullScreen: "",
                loading: "lazy",
                referrerPolicy: "no-referrer-when-downgrade"
            })
        })
    })
};
export {
    d as
    default
};
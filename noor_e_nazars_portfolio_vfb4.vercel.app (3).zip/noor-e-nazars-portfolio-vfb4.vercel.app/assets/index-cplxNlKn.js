const __vite__mapDeps = (i, m = __vite__mapDeps, d = (m.f || (m.f = ["assets/OfferSection-BCcAEGhj.js", "assets/OfferSection-1O2rEOWV.css"]))) => i.map(i => d[i]);

function Ip(e, t) {
    for (var n = 0; n < t.length; n++) {
        const r = t[n];
        if (typeof r != "string" && !Array.isArray(r)) {
            for (const i in r)
                if (i !== "default" && !(i in e)) {
                    const o = Object.getOwnPropertyDescriptor(r, i);
                    o && Object.defineProperty(e, i, o.get ? o : {
                        enumerable: !0,
                        get: () => r[i]
                    })
                }
        }
    }
    return Object.freeze(Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }))
}(function() {
    const t = document.createElement("link").relList;
    if (t && t.supports && t.supports("modulepreload")) return;
    for (const i of document.querySelectorAll('link[rel="modulepreload"]')) r(i);
    new MutationObserver(i => {
        for (const o of i)
            if (o.type === "childList")
                for (const s of o.addedNodes) s.tagName === "LINK" && s.rel === "modulepreload" && r(s)
    }).observe(document, {
        childList: !0,
        subtree: !0
    });

    function n(i) {
        const o = {};
        return i.integrity && (o.integrity = i.integrity), i.referrerPolicy && (o.referrerPolicy = i.referrerPolicy), i.crossOrigin === "use-credentials" ? o.credentials = "include" : i.crossOrigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin", o
    }

    function r(i) {
        if (i.ep) return;
        i.ep = !0;
        const o = n(i);
        fetch(i.href, o)
    }
})();
var OE = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};

function pi(e) {
    return e && e.__esModule && Object.prototype.hasOwnProperty.call(e, "default") ? e.default : e
}

function VE(e) {
    if (e.__esModule) return e;
    var t = e.default;
    if (typeof t == "function") {
        var n = function r() {
            return this instanceof r ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments)
        };
        n.prototype = t.prototype
    } else n = {};
    return Object.defineProperty(n, "__esModule", {
        value: !0
    }), Object.keys(e).forEach(function(r) {
        var i = Object.getOwnPropertyDescriptor(e, r);
        Object.defineProperty(n, r, i.get ? i : {
            enumerable: !0,
            get: function() {
                return e[r]
            }
        })
    }), n
}
var zp = {
        exports: {}
    },
    va = {},
    bp = {
        exports: {}
    },
    X = {};
/**
 * @license React
 * react.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var Ro = Symbol.for("react.element"),
    yy = Symbol.for("react.portal"),
    xy = Symbol.for("react.fragment"),
    wy = Symbol.for("react.strict_mode"),
    Sy = Symbol.for("react.profiler"),
    Ty = Symbol.for("react.provider"),
    Py = Symbol.for("react.context"),
    Ey = Symbol.for("react.forward_ref"),
    Cy = Symbol.for("react.suspense"),
    ky = Symbol.for("react.memo"),
    Ry = Symbol.for("react.lazy"),
    Ud = Symbol.iterator;

function jy(e) {
    return e === null || typeof e != "object" ? null : (e = Ud && e[Ud] || e["@@iterator"], typeof e == "function" ? e : null)
}
var Bp = {
        isMounted: function() {
            return !1
        },
        enqueueForceUpdate: function() {},
        enqueueReplaceState: function() {},
        enqueueSetState: function() {}
    },
    Up = Object.assign,
    Hp = {};

function mi(e, t, n) {
    this.props = e, this.context = t, this.refs = Hp, this.updater = n || Bp
}
mi.prototype.isReactComponent = {};
mi.prototype.setState = function(e, t) {
    if (typeof e != "object" && typeof e != "function" && e != null) throw Error("setState(...): takes an object of state variables to update or a function which returns an object of state variables.");
    this.updater.enqueueSetState(this, e, t, "setState")
};
mi.prototype.forceUpdate = function(e) {
    this.updater.enqueueForceUpdate(this, e, "forceUpdate")
};

function $p() {}
$p.prototype = mi.prototype;

function Zu(e, t, n) {
    this.props = e, this.context = t, this.refs = Hp, this.updater = n || Bp
}
var Ju = Zu.prototype = new $p;
Ju.constructor = Zu;
Up(Ju, mi.prototype);
Ju.isPureReactComponent = !0;
var Hd = Array.isArray,
    Wp = Object.prototype.hasOwnProperty,
    qu = {
        current: null
    },
    Kp = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function Gp(e, t, n) {
    var r, i = {},
        o = null,
        s = null;
    if (t != null)
        for (r in t.ref !== void 0 && (s = t.ref), t.key !== void 0 && (o = "" + t.key), t) Wp.call(t, r) && !Kp.hasOwnProperty(r) && (i[r] = t[r]);
    var a = arguments.length - 2;
    if (a === 1) i.children = n;
    else if (1 < a) {
        for (var l = Array(a), u = 0; u < a; u++) l[u] = arguments[u + 2];
        i.children = l
    }
    if (e && e.defaultProps)
        for (r in a = e.defaultProps, a) i[r] === void 0 && (i[r] = a[r]);
    return {
        $$typeof: Ro,
        type: e,
        key: o,
        ref: s,
        props: i,
        _owner: qu.current
    }
}

function Ay(e, t) {
    return {
        $$typeof: Ro,
        type: e.type,
        key: t,
        ref: e.ref,
        props: e.props,
        _owner: e._owner
    }
}

function ec(e) {
    return typeof e == "object" && e !== null && e.$$typeof === Ro
}

function Ly(e) {
    var t = {
        "=": "=0",
        ":": "=2"
    };
    return "$" + e.replace(/[=:]/g, function(n) {
        return t[n]
    })
}
var $d = /\/+/g;

function Wa(e, t) {
    return typeof e == "object" && e !== null && e.key != null ? Ly("" + e.key) : t.toString(36)
}

function ms(e, t, n, r, i) {
    var o = typeof e;
    (o === "undefined" || o === "boolean") && (e = null);
    var s = !1;
    if (e === null) s = !0;
    else switch (o) {
        case "string":
        case "number":
            s = !0;
            break;
        case "object":
            switch (e.$$typeof) {
                case Ro:
                case yy:
                    s = !0
            }
    }
    if (s) return s = e, i = i(s), e = r === "" ? "." + Wa(s, 0) : r, Hd(i) ? (n = "", e != null && (n = e.replace($d, "$&/") + "/"), ms(i, t, n, "", function(u) {
        return u
    })) : i != null && (ec(i) && (i = Ay(i, n + (!i.key || s && s.key === i.key ? "" : ("" + i.key).replace($d, "$&/") + "/") + e)), t.push(i)), 1;
    if (s = 0, r = r === "" ? "." : r + ":", Hd(e))
        for (var a = 0; a < e.length; a++) {
            o = e[a];
            var l = r + Wa(o, a);
            s += ms(o, t, n, l, i)
        } else if (l = jy(e), typeof l == "function")
            for (e = l.call(e), a = 0; !(o = e.next()).done;) o = o.value, l = r + Wa(o, a++), s += ms(o, t, n, l, i);
        else if (o === "object") throw t = String(e), Error("Objects are not valid as a React child (found: " + (t === "[object Object]" ? "object with keys {" + Object.keys(e).join(", ") + "}" : t) + "). If you meant to render a collection of children, use an array instead.");
    return s
}

function Yo(e, t, n) {
    if (e == null) return e;
    var r = [],
        i = 0;
    return ms(e, r, "", "", function(o) {
        return t.call(n, o, i++)
    }), r
}

function My(e) {
    if (e._status === -1) {
        var t = e._result;
        t = t(), t.then(function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 1, e._result = n)
        }, function(n) {
            (e._status === 0 || e._status === -1) && (e._status = 2, e._result = n)
        }), e._status === -1 && (e._status = 0, e._result = t)
    }
    if (e._status === 1) return e._result.default;
    throw e._result
}
var Je = {
        current: null
    },
    gs = {
        transition: null
    },
    Ny = {
        ReactCurrentDispatcher: Je,
        ReactCurrentBatchConfig: gs,
        ReactCurrentOwner: qu
    };

function Yp() {
    throw Error("act(...) is not supported in production builds of React.")
}
X.Children = {
    map: Yo,
    forEach: function(e, t, n) {
        Yo(e, function() {
            t.apply(this, arguments)
        }, n)
    },
    count: function(e) {
        var t = 0;
        return Yo(e, function() {
            t++
        }), t
    },
    toArray: function(e) {
        return Yo(e, function(t) {
            return t
        }) || []
    },
    only: function(e) {
        if (!ec(e)) throw Error("React.Children.only expected to receive a single React element child.");
        return e
    }
};
X.Component = mi;
X.Fragment = xy;
X.Profiler = Sy;
X.PureComponent = Zu;
X.StrictMode = wy;
X.Suspense = Cy;
X.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ny;
X.act = Yp;
X.cloneElement = function(e, t, n) {
    if (e == null) throw Error("React.cloneElement(...): The argument must be a React element, but you passed " + e + ".");
    var r = Up({}, e.props),
        i = e.key,
        o = e.ref,
        s = e._owner;
    if (t != null) {
        if (t.ref !== void 0 && (o = t.ref, s = qu.current), t.key !== void 0 && (i = "" + t.key), e.type && e.type.defaultProps) var a = e.type.defaultProps;
        for (l in t) Wp.call(t, l) && !Kp.hasOwnProperty(l) && (r[l] = t[l] === void 0 && a !== void 0 ? a[l] : t[l])
    }
    var l = arguments.length - 2;
    if (l === 1) r.children = n;
    else if (1 < l) {
        a = Array(l);
        for (var u = 0; u < l; u++) a[u] = arguments[u + 2];
        r.children = a
    }
    return {
        $$typeof: Ro,
        type: e.type,
        key: i,
        ref: o,
        props: r,
        _owner: s
    }
};
X.createContext = function(e) {
    return e = {
        $$typeof: Py,
        _currentValue: e,
        _currentValue2: e,
        _threadCount: 0,
        Provider: null,
        Consumer: null,
        _defaultValue: null,
        _globalName: null
    }, e.Provider = {
        $$typeof: Ty,
        _context: e
    }, e.Consumer = e
};
X.createElement = Gp;
X.createFactory = function(e) {
    var t = Gp.bind(null, e);
    return t.type = e, t
};
X.createRef = function() {
    return {
        current: null
    }
};
X.forwardRef = function(e) {
    return {
        $$typeof: Ey,
        render: e
    }
};
X.isValidElement = ec;
X.lazy = function(e) {
    return {
        $$typeof: Ry,
        _payload: {
            _status: -1,
            _result: e
        },
        _init: My
    }
};
X.memo = function(e, t) {
    return {
        $$typeof: ky,
        type: e,
        compare: t === void 0 ? null : t
    }
};
X.startTransition = function(e) {
    var t = gs.transition;
    gs.transition = {};
    try {
        e()
    } finally {
        gs.transition = t
    }
};
X.unstable_act = Yp;
X.useCallback = function(e, t) {
    return Je.current.useCallback(e, t)
};
X.useContext = function(e) {
    return Je.current.useContext(e)
};
X.useDebugValue = function() {};
X.useDeferredValue = function(e) {
    return Je.current.useDeferredValue(e)
};
X.useEffect = function(e, t) {
    return Je.current.useEffect(e, t)
};
X.useId = function() {
    return Je.current.useId()
};
X.useImperativeHandle = function(e, t, n) {
    return Je.current.useImperativeHandle(e, t, n)
};
X.useInsertionEffect = function(e, t) {
    return Je.current.useInsertionEffect(e, t)
};
X.useLayoutEffect = function(e, t) {
    return Je.current.useLayoutEffect(e, t)
};
X.useMemo = function(e, t) {
    return Je.current.useMemo(e, t)
};
X.useReducer = function(e, t, n) {
    return Je.current.useReducer(e, t, n)
};
X.useRef = function(e) {
    return Je.current.useRef(e)
};
X.useState = function(e) {
    return Je.current.useState(e)
};
X.useSyncExternalStore = function(e, t, n) {
    return Je.current.useSyncExternalStore(e, t, n)
};
X.useTransition = function() {
    return Je.current.useTransition()
};
X.version = "18.3.1";
bp.exports = X;
var C = bp.exports;
const ht = pi(C),
    Dy = Ip({
        __proto__: null,
        default: ht
    }, [C]);
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var _y = C,
    Oy = Symbol.for("react.element"),
    Vy = Symbol.for("react.fragment"),
    Fy = Object.prototype.hasOwnProperty,
    Iy = _y.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,
    zy = {
        key: !0,
        ref: !0,
        __self: !0,
        __source: !0
    };

function Qp(e, t, n) {
    var r, i = {},
        o = null,
        s = null;
    n !== void 0 && (o = "" + n), t.key !== void 0 && (o = "" + t.key), t.ref !== void 0 && (s = t.ref);
    for (r in t) Fy.call(t, r) && !zy.hasOwnProperty(r) && (i[r] = t[r]);
    if (e && e.defaultProps)
        for (r in t = e.defaultProps, t) i[r] === void 0 && (i[r] = t[r]);
    return {
        $$typeof: Oy,
        type: e,
        key: o,
        ref: s,
        props: i,
        _owner: Iy.current
    }
}
va.Fragment = Vy;
va.jsx = Qp;
va.jsxs = Qp;
zp.exports = va;
var v = zp.exports,
    _l = {},
    Xp = {
        exports: {}
    },
    vt = {},
    Zp = {
        exports: {}
    },
    Jp = {};
/**
 * @license React
 * scheduler.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
(function(e) {
    function t(D, F) {
        var W = D.length;
        D.push(F);
        e: for (; 0 < W;) {
            var se = W - 1 >>> 1,
                ue = D[se];
            if (0 < i(ue, F)) D[se] = F, D[W] = ue, W = se;
            else break e
        }
    }

    function n(D) {
        return D.length === 0 ? null : D[0]
    }

    function r(D) {
        if (D.length === 0) return null;
        var F = D[0],
            W = D.pop();
        if (W !== F) {
            D[0] = W;
            e: for (var se = 0, ue = D.length, tt = ue >>> 1; se < tt;) {
                var nt = 2 * (se + 1) - 1,
                    Gt = D[nt],
                    Ve = nt + 1,
                    wt = D[Ve];
                if (0 > i(Gt, W)) Ve < ue && 0 > i(wt, Gt) ? (D[se] = wt, D[Ve] = W, se = Ve) : (D[se] = Gt, D[nt] = W, se = nt);
                else if (Ve < ue && 0 > i(wt, W)) D[se] = wt, D[Ve] = W, se = Ve;
                else break e
            }
        }
        return F
    }

    function i(D, F) {
        var W = D.sortIndex - F.sortIndex;
        return W !== 0 ? W : D.id - F.id
    }
    if (typeof performance == "object" && typeof performance.now == "function") {
        var o = performance;
        e.unstable_now = function() {
            return o.now()
        }
    } else {
        var s = Date,
            a = s.now();
        e.unstable_now = function() {
            return s.now() - a
        }
    }
    var l = [],
        u = [],
        c = 1,
        d = null,
        f = 3,
        m = !1,
        x = !1,
        w = !1,
        E = typeof setTimeout == "function" ? setTimeout : null,
        p = typeof clearTimeout == "function" ? clearTimeout : null,
        h = typeof setImmediate < "u" ? setImmediate : null;
    typeof navigator < "u" && navigator.scheduling !== void 0 && navigator.scheduling.isInputPending !== void 0 && navigator.scheduling.isInputPending.bind(navigator.scheduling);

    function g(D) {
        for (var F = n(u); F !== null;) {
            if (F.callback === null) r(u);
            else if (F.startTime <= D) r(u), F.sortIndex = F.expirationTime, t(l, F);
            else break;
            F = n(u)
        }
    }

    function P(D) {
        if (w = !1, g(D), !x)
            if (n(l) !== null) x = !0, xt(R);
            else {
                var F = n(u);
                F !== null && he(P, F.startTime - D)
            }
    }

    function R(D, F) {
        x = !1, w && (w = !1, p(y), y = -1), m = !0;
        var W = f;
        try {
            for (g(F), d = n(l); d !== null && (!(d.expirationTime > F) || D && !U());) {
                var se = d.callback;
                if (typeof se == "function") {
                    d.callback = null, f = d.priorityLevel;
                    var ue = se(d.expirationTime <= F);
                    F = e.unstable_now(), typeof ue == "function" ? d.callback = ue : d === n(l) && r(l), g(F)
                } else r(l);
                d = n(l)
            }
            if (d !== null) var tt = !0;
            else {
                var nt = n(u);
                nt !== null && he(P, nt.startTime - F), tt = !1
            }
            return tt
        } finally {
            d = null, f = W, m = !1
        }
    }
    var A = !1,
        N = null,
        y = -1,
        O = 5,
        M = -1;

    function U() {
        return !(e.unstable_now() - M < O)
    }

    function te() {
        if (N !== null) {
            var D = e.unstable_now();
            M = D;
            var F = !0;
            try {
                F = N(!0, D)
            } finally {
                F ? Te() : (A = !1, N = null)
            }
        } else A = !1
    }
    var Te;
    if (typeof h == "function") Te = function() {
        h(te)
    };
    else if (typeof MessageChannel < "u") {
        var le = new MessageChannel,
            At = le.port2;
        le.port1.onmessage = te, Te = function() {
            At.postMessage(null)
        }
    } else Te = function() {
        E(te, 0)
    };

    function xt(D) {
        N = D, A || (A = !0, Te())
    }

    function he(D, F) {
        y = E(function() {
            D(e.unstable_now())
        }, F)
    }
    e.unstable_IdlePriority = 5, e.unstable_ImmediatePriority = 1, e.unstable_LowPriority = 4, e.unstable_NormalPriority = 3, e.unstable_Profiling = null, e.unstable_UserBlockingPriority = 2, e.unstable_cancelCallback = function(D) {
        D.callback = null
    }, e.unstable_continueExecution = function() {
        x || m || (x = !0, xt(R))
    }, e.unstable_forceFrameRate = function(D) {
        0 > D || 125 < D ? console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported") : O = 0 < D ? Math.floor(1e3 / D) : 5
    }, e.unstable_getCurrentPriorityLevel = function() {
        return f
    }, e.unstable_getFirstCallbackNode = function() {
        return n(l)
    }, e.unstable_next = function(D) {
        switch (f) {
            case 1:
            case 2:
            case 3:
                var F = 3;
                break;
            default:
                F = f
        }
        var W = f;
        f = F;
        try {
            return D()
        } finally {
            f = W
        }
    }, e.unstable_pauseExecution = function() {}, e.unstable_requestPaint = function() {}, e.unstable_runWithPriority = function(D, F) {
        switch (D) {
            case 1:
            case 2:
            case 3:
            case 4:
            case 5:
                break;
            default:
                D = 3
        }
        var W = f;
        f = D;
        try {
            return F()
        } finally {
            f = W
        }
    }, e.unstable_scheduleCallback = function(D, F, W) {
        var se = e.unstable_now();
        switch (typeof W == "object" && W !== null ? (W = W.delay, W = typeof W == "number" && 0 < W ? se + W : se) : W = se, D) {
            case 1:
                var ue = -1;
                break;
            case 2:
                ue = 250;
                break;
            case 5:
                ue = 1073741823;
                break;
            case 4:
                ue = 1e4;
                break;
            default:
                ue = 5e3
        }
        return ue = W + ue, D = {
            id: c++,
            callback: F,
            priorityLevel: D,
            startTime: W,
            expirationTime: ue,
            sortIndex: -1
        }, W > se ? (D.sortIndex = W, t(u, D), n(l) === null && D === n(u) && (w ? (p(y), y = -1) : w = !0, he(P, W - se))) : (D.sortIndex = ue, t(l, D), x || m || (x = !0, xt(R))), D
    }, e.unstable_shouldYield = U, e.unstable_wrapCallback = function(D) {
        var F = f;
        return function() {
            var W = f;
            f = F;
            try {
                return D.apply(this, arguments)
            } finally {
                f = W
            }
        }
    }
})(Jp);
Zp.exports = Jp;
var by = Zp.exports;
/**
 * @license React
 * react-dom.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var By = C,
    mt = by;

function L(e) {
    for (var t = "https://reactjs.org/docs/error-decoder.html?invariant=" + e, n = 1; n < arguments.length; n++) t += "&args[]=" + encodeURIComponent(arguments[n]);
    return "Minified React error #" + e + "; visit " + t + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
}
var qp = new Set,
    to = {};

function Pr(e, t) {
    ni(e, t), ni(e + "Capture", t)
}

function ni(e, t) {
    for (to[e] = t, e = 0; e < t.length; e++) qp.add(t[e])
}
var fn = !(typeof window > "u" || typeof window.document > "u" || typeof window.document.createElement > "u"),
    Ol = Object.prototype.hasOwnProperty,
    Uy = /^[:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD][:A-Z_a-z\u00C0-\u00D6\u00D8-\u00F6\u00F8-\u02FF\u0370-\u037D\u037F-\u1FFF\u200C-\u200D\u2070-\u218F\u2C00-\u2FEF\u3001-\uD7FF\uF900-\uFDCF\uFDF0-\uFFFD\-.0-9\u00B7\u0300-\u036F\u203F-\u2040]*$/,
    Wd = {},
    Kd = {};

function Hy(e) {
    return Ol.call(Kd, e) ? !0 : Ol.call(Wd, e) ? !1 : Uy.test(e) ? Kd[e] = !0 : (Wd[e] = !0, !1)
}

function $y(e, t, n, r) {
    if (n !== null && n.type === 0) return !1;
    switch (typeof t) {
        case "function":
        case "symbol":
            return !0;
        case "boolean":
            return r ? !1 : n !== null ? !n.acceptsBooleans : (e = e.toLowerCase().slice(0, 5), e !== "data-" && e !== "aria-");
        default:
            return !1
    }
}

function Wy(e, t, n, r) {
    if (t === null || typeof t > "u" || $y(e, t, n, r)) return !0;
    if (r) return !1;
    if (n !== null) switch (n.type) {
        case 3:
            return !t;
        case 4:
            return t === !1;
        case 5:
            return isNaN(t);
        case 6:
            return isNaN(t) || 1 > t
    }
    return !1
}

function qe(e, t, n, r, i, o, s) {
    this.acceptsBooleans = t === 2 || t === 3 || t === 4, this.attributeName = r, this.attributeNamespace = i, this.mustUseProperty = n, this.propertyName = e, this.type = t, this.sanitizeURL = o, this.removeEmptyString = s
}
var be = {};
"children dangerouslySetInnerHTML defaultValue defaultChecked innerHTML suppressContentEditableWarning suppressHydrationWarning style".split(" ").forEach(function(e) {
    be[e] = new qe(e, 0, !1, e, null, !1, !1)
});
[
    ["acceptCharset", "accept-charset"],
    ["className", "class"],
    ["htmlFor", "for"],
    ["httpEquiv", "http-equiv"]
].forEach(function(e) {
    var t = e[0];
    be[t] = new qe(t, 1, !1, e[1], null, !1, !1)
});
["contentEditable", "draggable", "spellCheck", "value"].forEach(function(e) {
    be[e] = new qe(e, 2, !1, e.toLowerCase(), null, !1, !1)
});
["autoReverse", "externalResourcesRequired", "focusable", "preserveAlpha"].forEach(function(e) {
    be[e] = new qe(e, 2, !1, e, null, !1, !1)
});
"allowFullScreen async autoFocus autoPlay controls default defer disabled disablePictureInPicture disableRemotePlayback formNoValidate hidden loop noModule noValidate open playsInline readOnly required reversed scoped seamless itemScope".split(" ").forEach(function(e) {
    be[e] = new qe(e, 3, !1, e.toLowerCase(), null, !1, !1)
});
["checked", "multiple", "muted", "selected"].forEach(function(e) {
    be[e] = new qe(e, 3, !0, e, null, !1, !1)
});
["capture", "download"].forEach(function(e) {
    be[e] = new qe(e, 4, !1, e, null, !1, !1)
});
["cols", "rows", "size", "span"].forEach(function(e) {
    be[e] = new qe(e, 6, !1, e, null, !1, !1)
});
["rowSpan", "start"].forEach(function(e) {
    be[e] = new qe(e, 5, !1, e.toLowerCase(), null, !1, !1)
});
var tc = /[\-:]([a-z])/g;

function nc(e) {
    return e[1].toUpperCase()
}
"accent-height alignment-baseline arabic-form baseline-shift cap-height clip-path clip-rule color-interpolation color-interpolation-filters color-profile color-rendering dominant-baseline enable-background fill-opacity fill-rule flood-color flood-opacity font-family font-size font-size-adjust font-stretch font-style font-variant font-weight glyph-name glyph-orientation-horizontal glyph-orientation-vertical horiz-adv-x horiz-origin-x image-rendering letter-spacing lighting-color marker-end marker-mid marker-start overline-position overline-thickness paint-order panose-1 pointer-events rendering-intent shape-rendering stop-color stop-opacity strikethrough-position strikethrough-thickness stroke-dasharray stroke-dashoffset stroke-linecap stroke-linejoin stroke-miterlimit stroke-opacity stroke-width text-anchor text-decoration text-rendering underline-position underline-thickness unicode-bidi unicode-range units-per-em v-alphabetic v-hanging v-ideographic v-mathematical vector-effect vert-adv-y vert-origin-x vert-origin-y word-spacing writing-mode xmlns:xlink x-height".split(" ").forEach(function(e) {
    var t = e.replace(tc, nc);
    be[t] = new qe(t, 1, !1, e, null, !1, !1)
});
"xlink:actuate xlink:arcrole xlink:role xlink:show xlink:title xlink:type".split(" ").forEach(function(e) {
    var t = e.replace(tc, nc);
    be[t] = new qe(t, 1, !1, e, "http://www.w3.org/1999/xlink", !1, !1)
});
["xml:base", "xml:lang", "xml:space"].forEach(function(e) {
    var t = e.replace(tc, nc);
    be[t] = new qe(t, 1, !1, e, "http://www.w3.org/XML/1998/namespace", !1, !1)
});
["tabIndex", "crossOrigin"].forEach(function(e) {
    be[e] = new qe(e, 1, !1, e.toLowerCase(), null, !1, !1)
});
be.xlinkHref = new qe("xlinkHref", 1, !1, "xlink:href", "http://www.w3.org/1999/xlink", !0, !1);
["src", "href", "action", "formAction"].forEach(function(e) {
    be[e] = new qe(e, 1, !1, e.toLowerCase(), null, !0, !0)
});

function rc(e, t, n, r) {
    var i = be.hasOwnProperty(t) ? be[t] : null;
    (i !== null ? i.type !== 0 : r || !(2 < t.length) || t[0] !== "o" && t[0] !== "O" || t[1] !== "n" && t[1] !== "N") && (Wy(t, n, i, r) && (n = null), r || i === null ? Hy(t) && (n === null ? e.removeAttribute(t) : e.setAttribute(t, "" + n)) : i.mustUseProperty ? e[i.propertyName] = n === null ? i.type === 3 ? !1 : "" : n : (t = i.attributeName, r = i.attributeNamespace, n === null ? e.removeAttribute(t) : (i = i.type, n = i === 3 || i === 4 && n === !0 ? "" : "" + n, r ? e.setAttributeNS(r, t, n) : e.setAttribute(t, n))))
}
var vn = By.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED,
    Qo = Symbol.for("react.element"),
    Lr = Symbol.for("react.portal"),
    Mr = Symbol.for("react.fragment"),
    ic = Symbol.for("react.strict_mode"),
    Vl = Symbol.for("react.profiler"),
    em = Symbol.for("react.provider"),
    tm = Symbol.for("react.context"),
    oc = Symbol.for("react.forward_ref"),
    Fl = Symbol.for("react.suspense"),
    Il = Symbol.for("react.suspense_list"),
    sc = Symbol.for("react.memo"),
    En = Symbol.for("react.lazy"),
    nm = Symbol.for("react.offscreen"),
    Gd = Symbol.iterator;

function Ti(e) {
    return e === null || typeof e != "object" ? null : (e = Gd && e[Gd] || e["@@iterator"], typeof e == "function" ? e : null)
}
var Se = Object.assign,
    Ka;

function Vi(e) {
    if (Ka === void 0) try {
        throw Error()
    } catch (n) {
        var t = n.stack.trim().match(/\n( *(at )?)/);
        Ka = t && t[1] || ""
    }
    return `
` + Ka + e
}
var Ga = !1;

function Ya(e, t) {
    if (!e || Ga) return "";
    Ga = !0;
    var n = Error.prepareStackTrace;
    Error.prepareStackTrace = void 0;
    try {
        if (t)
            if (t = function() {
                    throw Error()
                }, Object.defineProperty(t.prototype, "props", {
                    set: function() {
                        throw Error()
                    }
                }), typeof Reflect == "object" && Reflect.construct) {
                try {
                    Reflect.construct(t, [])
                } catch (u) {
                    var r = u
                }
                Reflect.construct(e, [], t)
            } else {
                try {
                    t.call()
                } catch (u) {
                    r = u
                }
                e.call(t.prototype)
            }
        else {
            try {
                throw Error()
            } catch (u) {
                r = u
            }
            e()
        }
    } catch (u) {
        if (u && r && typeof u.stack == "string") {
            for (var i = u.stack.split(`
`), o = r.stack.split(`
`), s = i.length - 1, a = o.length - 1; 1 <= s && 0 <= a && i[s] !== o[a];) a--;
            for (; 1 <= s && 0 <= a; s--, a--)
                if (i[s] !== o[a]) {
                    if (s !== 1 || a !== 1)
                        do
                            if (s--, a--, 0 > a || i[s] !== o[a]) {
                                var l = `
` + i[s].replace(" at new ", " at ");
                                return e.displayName && l.includes("<anonymous>") && (l = l.replace("<anonymous>", e.displayName)), l
                            }
                    while (1 <= s && 0 <= a);
                    break
                }
        }
    } finally {
        Ga = !1, Error.prepareStackTrace = n
    }
    return (e = e ? e.displayName || e.name : "") ? Vi(e) : ""
}

function Ky(e) {
    switch (e.tag) {
        case 5:
            return Vi(e.type);
        case 16:
            return Vi("Lazy");
        case 13:
            return Vi("Suspense");
        case 19:
            return Vi("SuspenseList");
        case 0:
        case 2:
        case 15:
            return e = Ya(e.type, !1), e;
        case 11:
            return e = Ya(e.type.render, !1), e;
        case 1:
            return e = Ya(e.type, !0), e;
        default:
            return ""
    }
}

function zl(e) {
    if (e == null) return null;
    if (typeof e == "function") return e.displayName || e.name || null;
    if (typeof e == "string") return e;
    switch (e) {
        case Mr:
            return "Fragment";
        case Lr:
            return "Portal";
        case Vl:
            return "Profiler";
        case ic:
            return "StrictMode";
        case Fl:
            return "Suspense";
        case Il:
            return "SuspenseList"
    }
    if (typeof e == "object") switch (e.$$typeof) {
        case tm:
            return (e.displayName || "Context") + ".Consumer";
        case em:
            return (e._context.displayName || "Context") + ".Provider";
        case oc:
            var t = e.render;
            return e = e.displayName, e || (e = t.displayName || t.name || "", e = e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef"), e;
        case sc:
            return t = e.displayName || null, t !== null ? t : zl(e.type) || "Memo";
        case En:
            t = e._payload, e = e._init;
            try {
                return zl(e(t))
            } catch {}
    }
    return null
}

function Gy(e) {
    var t = e.type;
    switch (e.tag) {
        case 24:
            return "Cache";
        case 9:
            return (t.displayName || "Context") + ".Consumer";
        case 10:
            return (t._context.displayName || "Context") + ".Provider";
        case 18:
            return "DehydratedFragment";
        case 11:
            return e = t.render, e = e.displayName || e.name || "", t.displayName || (e !== "" ? "ForwardRef(" + e + ")" : "ForwardRef");
        case 7:
            return "Fragment";
        case 5:
            return t;
        case 4:
            return "Portal";
        case 3:
            return "Root";
        case 6:
            return "Text";
        case 16:
            return zl(t);
        case 8:
            return t === ic ? "StrictMode" : "Mode";
        case 22:
            return "Offscreen";
        case 12:
            return "Profiler";
        case 21:
            return "Scope";
        case 13:
            return "Suspense";
        case 19:
            return "SuspenseList";
        case 25:
            return "TracingMarker";
        case 1:
        case 0:
        case 17:
        case 2:
        case 14:
        case 15:
            if (typeof t == "function") return t.displayName || t.name || null;
            if (typeof t == "string") return t
    }
    return null
}

function zn(e) {
    switch (typeof e) {
        case "boolean":
        case "number":
        case "string":
        case "undefined":
            return e;
        case "object":
            return e;
        default:
            return ""
    }
}

function rm(e) {
    var t = e.type;
    return (e = e.nodeName) && e.toLowerCase() === "input" && (t === "checkbox" || t === "radio")
}

function Yy(e) {
    var t = rm(e) ? "checked" : "value",
        n = Object.getOwnPropertyDescriptor(e.constructor.prototype, t),
        r = "" + e[t];
    if (!e.hasOwnProperty(t) && typeof n < "u" && typeof n.get == "function" && typeof n.set == "function") {
        var i = n.get,
            o = n.set;
        return Object.defineProperty(e, t, {
            configurable: !0,
            get: function() {
                return i.call(this)
            },
            set: function(s) {
                r = "" + s, o.call(this, s)
            }
        }), Object.defineProperty(e, t, {
            enumerable: n.enumerable
        }), {
            getValue: function() {
                return r
            },
            setValue: function(s) {
                r = "" + s
            },
            stopTracking: function() {
                e._valueTracker = null, delete e[t]
            }
        }
    }
}

function Xo(e) {
    e._valueTracker || (e._valueTracker = Yy(e))
}

function im(e) {
    if (!e) return !1;
    var t = e._valueTracker;
    if (!t) return !0;
    var n = t.getValue(),
        r = "";
    return e && (r = rm(e) ? e.checked ? "true" : "false" : e.value), e = r, e !== n ? (t.setValue(e), !0) : !1
}

function Ds(e) {
    if (e = e || (typeof document < "u" ? document : void 0), typeof e > "u") return null;
    try {
        return e.activeElement || e.body
    } catch {
        return e.body
    }
}

function bl(e, t) {
    var n = t.checked;
    return Se({}, t, {
        defaultChecked: void 0,
        defaultValue: void 0,
        value: void 0,
        checked: n ? ? e._wrapperState.initialChecked
    })
}

function Yd(e, t) {
    var n = t.defaultValue == null ? "" : t.defaultValue,
        r = t.checked != null ? t.checked : t.defaultChecked;
    n = zn(t.value != null ? t.value : n), e._wrapperState = {
        initialChecked: r,
        initialValue: n,
        controlled: t.type === "checkbox" || t.type === "radio" ? t.checked != null : t.value != null
    }
}

function om(e, t) {
    t = t.checked, t != null && rc(e, "checked", t, !1)
}

function Bl(e, t) {
    om(e, t);
    var n = zn(t.value),
        r = t.type;
    if (n != null) r === "number" ? (n === 0 && e.value === "" || e.value != n) && (e.value = "" + n) : e.value !== "" + n && (e.value = "" + n);
    else if (r === "submit" || r === "reset") {
        e.removeAttribute("value");
        return
    }
    t.hasOwnProperty("value") ? Ul(e, t.type, n) : t.hasOwnProperty("defaultValue") && Ul(e, t.type, zn(t.defaultValue)), t.checked == null && t.defaultChecked != null && (e.defaultChecked = !!t.defaultChecked)
}

function Qd(e, t, n) {
    if (t.hasOwnProperty("value") || t.hasOwnProperty("defaultValue")) {
        var r = t.type;
        if (!(r !== "submit" && r !== "reset" || t.value !== void 0 && t.value !== null)) return;
        t = "" + e._wrapperState.initialValue, n || t === e.value || (e.value = t), e.defaultValue = t
    }
    n = e.name, n !== "" && (e.name = ""), e.defaultChecked = !!e._wrapperState.initialChecked, n !== "" && (e.name = n)
}

function Ul(e, t, n) {
    (t !== "number" || Ds(e.ownerDocument) !== e) && (n == null ? e.defaultValue = "" + e._wrapperState.initialValue : e.defaultValue !== "" + n && (e.defaultValue = "" + n))
}
var Fi = Array.isArray;

function Yr(e, t, n, r) {
    if (e = e.options, t) {
        t = {};
        for (var i = 0; i < n.length; i++) t["$" + n[i]] = !0;
        for (n = 0; n < e.length; n++) i = t.hasOwnProperty("$" + e[n].value), e[n].selected !== i && (e[n].selected = i), i && r && (e[n].defaultSelected = !0)
    } else {
        for (n = "" + zn(n), t = null, i = 0; i < e.length; i++) {
            if (e[i].value === n) {
                e[i].selected = !0, r && (e[i].defaultSelected = !0);
                return
            }
            t !== null || e[i].disabled || (t = e[i])
        }
        t !== null && (t.selected = !0)
    }
}

function Hl(e, t) {
    if (t.dangerouslySetInnerHTML != null) throw Error(L(91));
    return Se({}, t, {
        value: void 0,
        defaultValue: void 0,
        children: "" + e._wrapperState.initialValue
    })
}

function Xd(e, t) {
    var n = t.value;
    if (n == null) {
        if (n = t.children, t = t.defaultValue, n != null) {
            if (t != null) throw Error(L(92));
            if (Fi(n)) {
                if (1 < n.length) throw Error(L(93));
                n = n[0]
            }
            t = n
        }
        t == null && (t = ""), n = t
    }
    e._wrapperState = {
        initialValue: zn(n)
    }
}

function sm(e, t) {
    var n = zn(t.value),
        r = zn(t.defaultValue);
    n != null && (n = "" + n, n !== e.value && (e.value = n), t.defaultValue == null && e.defaultValue !== n && (e.defaultValue = n)), r != null && (e.defaultValue = "" + r)
}

function Zd(e) {
    var t = e.textContent;
    t === e._wrapperState.initialValue && t !== "" && t !== null && (e.value = t)
}

function am(e) {
    switch (e) {
        case "svg":
            return "http://www.w3.org/2000/svg";
        case "math":
            return "http://www.w3.org/1998/Math/MathML";
        default:
            return "http://www.w3.org/1999/xhtml"
    }
}

function $l(e, t) {
    return e == null || e === "http://www.w3.org/1999/xhtml" ? am(t) : e === "http://www.w3.org/2000/svg" && t === "foreignObject" ? "http://www.w3.org/1999/xhtml" : e
}
var Zo, lm = function(e) {
    return typeof MSApp < "u" && MSApp.execUnsafeLocalFunction ? function(t, n, r, i) {
        MSApp.execUnsafeLocalFunction(function() {
            return e(t, n, r, i)
        })
    } : e
}(function(e, t) {
    if (e.namespaceURI !== "http://www.w3.org/2000/svg" || "innerHTML" in e) e.innerHTML = t;
    else {
        for (Zo = Zo || document.createElement("div"), Zo.innerHTML = "<svg>" + t.valueOf().toString() + "</svg>", t = Zo.firstChild; e.firstChild;) e.removeChild(e.firstChild);
        for (; t.firstChild;) e.appendChild(t.firstChild)
    }
});

function no(e, t) {
    if (t) {
        var n = e.firstChild;
        if (n && n === e.lastChild && n.nodeType === 3) {
            n.nodeValue = t;
            return
        }
    }
    e.textContent = t
}
var Hi = {
        animationIterationCount: !0,
        aspectRatio: !0,
        borderImageOutset: !0,
        borderImageSlice: !0,
        borderImageWidth: !0,
        boxFlex: !0,
        boxFlexGroup: !0,
        boxOrdinalGroup: !0,
        columnCount: !0,
        columns: !0,
        flex: !0,
        flexGrow: !0,
        flexPositive: !0,
        flexShrink: !0,
        flexNegative: !0,
        flexOrder: !0,
        gridArea: !0,
        gridRow: !0,
        gridRowEnd: !0,
        gridRowSpan: !0,
        gridRowStart: !0,
        gridColumn: !0,
        gridColumnEnd: !0,
        gridColumnSpan: !0,
        gridColumnStart: !0,
        fontWeight: !0,
        lineClamp: !0,
        lineHeight: !0,
        opacity: !0,
        order: !0,
        orphans: !0,
        tabSize: !0,
        widows: !0,
        zIndex: !0,
        zoom: !0,
        fillOpacity: !0,
        floodOpacity: !0,
        stopOpacity: !0,
        strokeDasharray: !0,
        strokeDashoffset: !0,
        strokeMiterlimit: !0,
        strokeOpacity: !0,
        strokeWidth: !0
    },
    Qy = ["Webkit", "ms", "Moz", "O"];
Object.keys(Hi).forEach(function(e) {
    Qy.forEach(function(t) {
        t = t + e.charAt(0).toUpperCase() + e.substring(1), Hi[t] = Hi[e]
    })
});

function um(e, t, n) {
    return t == null || typeof t == "boolean" || t === "" ? "" : n || typeof t != "number" || t === 0 || Hi.hasOwnProperty(e) && Hi[e] ? ("" + t).trim() : t + "px"
}

function cm(e, t) {
    e = e.style;
    for (var n in t)
        if (t.hasOwnProperty(n)) {
            var r = n.indexOf("--") === 0,
                i = um(n, t[n], r);
            n === "float" && (n = "cssFloat"), r ? e.setProperty(n, i) : e[n] = i
        }
}
var Xy = Se({
    menuitem: !0
}, {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
});

function Wl(e, t) {
    if (t) {
        if (Xy[e] && (t.children != null || t.dangerouslySetInnerHTML != null)) throw Error(L(137, e));
        if (t.dangerouslySetInnerHTML != null) {
            if (t.children != null) throw Error(L(60));
            if (typeof t.dangerouslySetInnerHTML != "object" || !("__html" in t.dangerouslySetInnerHTML)) throw Error(L(61))
        }
        if (t.style != null && typeof t.style != "object") throw Error(L(62))
    }
}

function Kl(e, t) {
    if (e.indexOf("-") === -1) return typeof t.is == "string";
    switch (e) {
        case "annotation-xml":
        case "color-profile":
        case "font-face":
        case "font-face-src":
        case "font-face-uri":
        case "font-face-format":
        case "font-face-name":
        case "missing-glyph":
            return !1;
        default:
            return !0
    }
}
var Gl = null;

function ac(e) {
    return e = e.target || e.srcElement || window, e.correspondingUseElement && (e = e.correspondingUseElement), e.nodeType === 3 ? e.parentNode : e
}
var Yl = null,
    Qr = null,
    Xr = null;

function Jd(e) {
    if (e = Lo(e)) {
        if (typeof Yl != "function") throw Error(L(280));
        var t = e.stateNode;
        t && (t = Ta(t), Yl(e.stateNode, e.type, t))
    }
}

function dm(e) {
    Qr ? Xr ? Xr.push(e) : Xr = [e] : Qr = e
}

function fm() {
    if (Qr) {
        var e = Qr,
            t = Xr;
        if (Xr = Qr = null, Jd(e), t)
            for (e = 0; e < t.length; e++) Jd(t[e])
    }
}

function hm(e, t) {
    return e(t)
}

function pm() {}
var Qa = !1;

function mm(e, t, n) {
    if (Qa) return e(t, n);
    Qa = !0;
    try {
        return hm(e, t, n)
    } finally {
        Qa = !1, (Qr !== null || Xr !== null) && (pm(), fm())
    }
}

function ro(e, t) {
    var n = e.stateNode;
    if (n === null) return null;
    var r = Ta(n);
    if (r === null) return null;
    n = r[t];
    e: switch (t) {
        case "onClick":
        case "onClickCapture":
        case "onDoubleClick":
        case "onDoubleClickCapture":
        case "onMouseDown":
        case "onMouseDownCapture":
        case "onMouseMove":
        case "onMouseMoveCapture":
        case "onMouseUp":
        case "onMouseUpCapture":
        case "onMouseEnter":
            (r = !r.disabled) || (e = e.type, r = !(e === "button" || e === "input" || e === "select" || e === "textarea")), e = !r;
            break e;
        default:
            e = !1
    }
    if (e) return null;
    if (n && typeof n != "function") throw Error(L(231, t, typeof n));
    return n
}
var Ql = !1;
if (fn) try {
    var Pi = {};
    Object.defineProperty(Pi, "passive", {
        get: function() {
            Ql = !0
        }
    }), window.addEventListener("test", Pi, Pi), window.removeEventListener("test", Pi, Pi)
} catch {
    Ql = !1
}

function Zy(e, t, n, r, i, o, s, a, l) {
    var u = Array.prototype.slice.call(arguments, 3);
    try {
        t.apply(n, u)
    } catch (c) {
        this.onError(c)
    }
}
var $i = !1,
    _s = null,
    Os = !1,
    Xl = null,
    Jy = {
        onError: function(e) {
            $i = !0, _s = e
        }
    };

function qy(e, t, n, r, i, o, s, a, l) {
    $i = !1, _s = null, Zy.apply(Jy, arguments)
}

function e1(e, t, n, r, i, o, s, a, l) {
    if (qy.apply(this, arguments), $i) {
        if ($i) {
            var u = _s;
            $i = !1, _s = null
        } else throw Error(L(198));
        Os || (Os = !0, Xl = u)
    }
}

function Er(e) {
    var t = e,
        n = e;
    if (e.alternate)
        for (; t.return;) t = t.return;
    else {
        e = t;
        do t = e, t.flags & 4098 && (n = t.return), e = t.return; while (e)
    }
    return t.tag === 3 ? n : null
}

function gm(e) {
    if (e.tag === 13) {
        var t = e.memoizedState;
        if (t === null && (e = e.alternate, e !== null && (t = e.memoizedState)), t !== null) return t.dehydrated
    }
    return null
}

function qd(e) {
    if (Er(e) !== e) throw Error(L(188))
}

function t1(e) {
    var t = e.alternate;
    if (!t) {
        if (t = Er(e), t === null) throw Error(L(188));
        return t !== e ? null : e
    }
    for (var n = e, r = t;;) {
        var i = n.return;
        if (i === null) break;
        var o = i.alternate;
        if (o === null) {
            if (r = i.return, r !== null) {
                n = r;
                continue
            }
            break
        }
        if (i.child === o.child) {
            for (o = i.child; o;) {
                if (o === n) return qd(i), e;
                if (o === r) return qd(i), t;
                o = o.sibling
            }
            throw Error(L(188))
        }
        if (n.return !== r.return) n = i, r = o;
        else {
            for (var s = !1, a = i.child; a;) {
                if (a === n) {
                    s = !0, n = i, r = o;
                    break
                }
                if (a === r) {
                    s = !0, r = i, n = o;
                    break
                }
                a = a.sibling
            }
            if (!s) {
                for (a = o.child; a;) {
                    if (a === n) {
                        s = !0, n = o, r = i;
                        break
                    }
                    if (a === r) {
                        s = !0, r = o, n = i;
                        break
                    }
                    a = a.sibling
                }
                if (!s) throw Error(L(189))
            }
        }
        if (n.alternate !== r) throw Error(L(190))
    }
    if (n.tag !== 3) throw Error(L(188));
    return n.stateNode.current === n ? e : t
}

function vm(e) {
    return e = t1(e), e !== null ? ym(e) : null
}

function ym(e) {
    if (e.tag === 5 || e.tag === 6) return e;
    for (e = e.child; e !== null;) {
        var t = ym(e);
        if (t !== null) return t;
        e = e.sibling
    }
    return null
}
var xm = mt.unstable_scheduleCallback,
    ef = mt.unstable_cancelCallback,
    n1 = mt.unstable_shouldYield,
    r1 = mt.unstable_requestPaint,
    Re = mt.unstable_now,
    i1 = mt.unstable_getCurrentPriorityLevel,
    lc = mt.unstable_ImmediatePriority,
    wm = mt.unstable_UserBlockingPriority,
    Vs = mt.unstable_NormalPriority,
    o1 = mt.unstable_LowPriority,
    Sm = mt.unstable_IdlePriority,
    ya = null,
    Ht = null;

function s1(e) {
    if (Ht && typeof Ht.onCommitFiberRoot == "function") try {
        Ht.onCommitFiberRoot(ya, e, void 0, (e.current.flags & 128) === 128)
    } catch {}
}
var Ft = Math.clz32 ? Math.clz32 : u1,
    a1 = Math.log,
    l1 = Math.LN2;

function u1(e) {
    return e >>>= 0, e === 0 ? 32 : 31 - (a1(e) / l1 | 0) | 0
}
var Jo = 64,
    qo = 4194304;

function Ii(e) {
    switch (e & -e) {
        case 1:
            return 1;
        case 2:
            return 2;
        case 4:
            return 4;
        case 8:
            return 8;
        case 16:
            return 16;
        case 32:
            return 32;
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return e & 4194240;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return e & 130023424;
        case 134217728:
            return 134217728;
        case 268435456:
            return 268435456;
        case 536870912:
            return 536870912;
        case 1073741824:
            return 1073741824;
        default:
            return e
    }
}

function Fs(e, t) {
    var n = e.pendingLanes;
    if (n === 0) return 0;
    var r = 0,
        i = e.suspendedLanes,
        o = e.pingedLanes,
        s = n & 268435455;
    if (s !== 0) {
        var a = s & ~i;
        a !== 0 ? r = Ii(a) : (o &= s, o !== 0 && (r = Ii(o)))
    } else s = n & ~i, s !== 0 ? r = Ii(s) : o !== 0 && (r = Ii(o));
    if (r === 0) return 0;
    if (t !== 0 && t !== r && !(t & i) && (i = r & -r, o = t & -t, i >= o || i === 16 && (o & 4194240) !== 0)) return t;
    if (r & 4 && (r |= n & 16), t = e.entangledLanes, t !== 0)
        for (e = e.entanglements, t &= r; 0 < t;) n = 31 - Ft(t), i = 1 << n, r |= e[n], t &= ~i;
    return r
}

function c1(e, t) {
    switch (e) {
        case 1:
        case 2:
        case 4:
            return t + 250;
        case 8:
        case 16:
        case 32:
        case 64:
        case 128:
        case 256:
        case 512:
        case 1024:
        case 2048:
        case 4096:
        case 8192:
        case 16384:
        case 32768:
        case 65536:
        case 131072:
        case 262144:
        case 524288:
        case 1048576:
        case 2097152:
            return t + 5e3;
        case 4194304:
        case 8388608:
        case 16777216:
        case 33554432:
        case 67108864:
            return -1;
        case 134217728:
        case 268435456:
        case 536870912:
        case 1073741824:
            return -1;
        default:
            return -1
    }
}

function d1(e, t) {
    for (var n = e.suspendedLanes, r = e.pingedLanes, i = e.expirationTimes, o = e.pendingLanes; 0 < o;) {
        var s = 31 - Ft(o),
            a = 1 << s,
            l = i[s];
        l === -1 ? (!(a & n) || a & r) && (i[s] = c1(a, t)) : l <= t && (e.expiredLanes |= a), o &= ~a
    }
}

function Zl(e) {
    return e = e.pendingLanes & -1073741825, e !== 0 ? e : e & 1073741824 ? 1073741824 : 0
}

function Tm() {
    var e = Jo;
    return Jo <<= 1, !(Jo & 4194240) && (Jo = 64), e
}

function Xa(e) {
    for (var t = [], n = 0; 31 > n; n++) t.push(e);
    return t
}

function jo(e, t, n) {
    e.pendingLanes |= t, t !== 536870912 && (e.suspendedLanes = 0, e.pingedLanes = 0), e = e.eventTimes, t = 31 - Ft(t), e[t] = n
}

function f1(e, t) {
    var n = e.pendingLanes & ~t;
    e.pendingLanes = t, e.suspendedLanes = 0, e.pingedLanes = 0, e.expiredLanes &= t, e.mutableReadLanes &= t, e.entangledLanes &= t, t = e.entanglements;
    var r = e.eventTimes;
    for (e = e.expirationTimes; 0 < n;) {
        var i = 31 - Ft(n),
            o = 1 << i;
        t[i] = 0, r[i] = -1, e[i] = -1, n &= ~o
    }
}

function uc(e, t) {
    var n = e.entangledLanes |= t;
    for (e = e.entanglements; n;) {
        var r = 31 - Ft(n),
            i = 1 << r;
        i & t | e[r] & t && (e[r] |= t), n &= ~i
    }
}
var re = 0;

function Pm(e) {
    return e &= -e, 1 < e ? 4 < e ? e & 268435455 ? 16 : 536870912 : 4 : 1
}
var Em, cc, Cm, km, Rm, Jl = !1,
    es = [],
    Mn = null,
    Nn = null,
    Dn = null,
    io = new Map,
    oo = new Map,
    kn = [],
    h1 = "mousedown mouseup touchcancel touchend touchstart auxclick dblclick pointercancel pointerdown pointerup dragend dragstart drop compositionend compositionstart keydown keypress keyup input textInput copy cut paste click change contextmenu reset submit".split(" ");

function tf(e, t) {
    switch (e) {
        case "focusin":
        case "focusout":
            Mn = null;
            break;
        case "dragenter":
        case "dragleave":
            Nn = null;
            break;
        case "mouseover":
        case "mouseout":
            Dn = null;
            break;
        case "pointerover":
        case "pointerout":
            io.delete(t.pointerId);
            break;
        case "gotpointercapture":
        case "lostpointercapture":
            oo.delete(t.pointerId)
    }
}

function Ei(e, t, n, r, i, o) {
    return e === null || e.nativeEvent !== o ? (e = {
        blockedOn: t,
        domEventName: n,
        eventSystemFlags: r,
        nativeEvent: o,
        targetContainers: [i]
    }, t !== null && (t = Lo(t), t !== null && cc(t)), e) : (e.eventSystemFlags |= r, t = e.targetContainers, i !== null && t.indexOf(i) === -1 && t.push(i), e)
}

function p1(e, t, n, r, i) {
    switch (t) {
        case "focusin":
            return Mn = Ei(Mn, e, t, n, r, i), !0;
        case "dragenter":
            return Nn = Ei(Nn, e, t, n, r, i), !0;
        case "mouseover":
            return Dn = Ei(Dn, e, t, n, r, i), !0;
        case "pointerover":
            var o = i.pointerId;
            return io.set(o, Ei(io.get(o) || null, e, t, n, r, i)), !0;
        case "gotpointercapture":
            return o = i.pointerId, oo.set(o, Ei(oo.get(o) || null, e, t, n, r, i)), !0
    }
    return !1
}

function jm(e) {
    var t = lr(e.target);
    if (t !== null) {
        var n = Er(t);
        if (n !== null) {
            if (t = n.tag, t === 13) {
                if (t = gm(n), t !== null) {
                    e.blockedOn = t, Rm(e.priority, function() {
                        Cm(n)
                    });
                    return
                }
            } else if (t === 3 && n.stateNode.current.memoizedState.isDehydrated) {
                e.blockedOn = n.tag === 3 ? n.stateNode.containerInfo : null;
                return
            }
        }
    }
    e.blockedOn = null
}

function vs(e) {
    if (e.blockedOn !== null) return !1;
    for (var t = e.targetContainers; 0 < t.length;) {
        var n = ql(e.domEventName, e.eventSystemFlags, t[0], e.nativeEvent);
        if (n === null) {
            n = e.nativeEvent;
            var r = new n.constructor(n.type, n);
            Gl = r, n.target.dispatchEvent(r), Gl = null
        } else return t = Lo(n), t !== null && cc(t), e.blockedOn = n, !1;
        t.shift()
    }
    return !0
}

function nf(e, t, n) {
    vs(e) && n.delete(t)
}

function m1() {
    Jl = !1, Mn !== null && vs(Mn) && (Mn = null), Nn !== null && vs(Nn) && (Nn = null), Dn !== null && vs(Dn) && (Dn = null), io.forEach(nf), oo.forEach(nf)
}

function Ci(e, t) {
    e.blockedOn === t && (e.blockedOn = null, Jl || (Jl = !0, mt.unstable_scheduleCallback(mt.unstable_NormalPriority, m1)))
}

function so(e) {
    function t(i) {
        return Ci(i, e)
    }
    if (0 < es.length) {
        Ci(es[0], e);
        for (var n = 1; n < es.length; n++) {
            var r = es[n];
            r.blockedOn === e && (r.blockedOn = null)
        }
    }
    for (Mn !== null && Ci(Mn, e), Nn !== null && Ci(Nn, e), Dn !== null && Ci(Dn, e), io.forEach(t), oo.forEach(t), n = 0; n < kn.length; n++) r = kn[n], r.blockedOn === e && (r.blockedOn = null);
    for (; 0 < kn.length && (n = kn[0], n.blockedOn === null);) jm(n), n.blockedOn === null && kn.shift()
}
var Zr = vn.ReactCurrentBatchConfig,
    Is = !0;

function g1(e, t, n, r) {
    var i = re,
        o = Zr.transition;
    Zr.transition = null;
    try {
        re = 1, dc(e, t, n, r)
    } finally {
        re = i, Zr.transition = o
    }
}

function v1(e, t, n, r) {
    var i = re,
        o = Zr.transition;
    Zr.transition = null;
    try {
        re = 4, dc(e, t, n, r)
    } finally {
        re = i, Zr.transition = o
    }
}

function dc(e, t, n, r) {
    if (Is) {
        var i = ql(e, t, n, r);
        if (i === null) sl(e, t, r, zs, n), tf(e, r);
        else if (p1(i, e, t, n, r)) r.stopPropagation();
        else if (tf(e, r), t & 4 && -1 < h1.indexOf(e)) {
            for (; i !== null;) {
                var o = Lo(i);
                if (o !== null && Em(o), o = ql(e, t, n, r), o === null && sl(e, t, r, zs, n), o === i) break;
                i = o
            }
            i !== null && r.stopPropagation()
        } else sl(e, t, r, null, n)
    }
}
var zs = null;

function ql(e, t, n, r) {
    if (zs = null, e = ac(r), e = lr(e), e !== null)
        if (t = Er(e), t === null) e = null;
        else if (n = t.tag, n === 13) {
        if (e = gm(t), e !== null) return e;
        e = null
    } else if (n === 3) {
        if (t.stateNode.current.memoizedState.isDehydrated) return t.tag === 3 ? t.stateNode.containerInfo : null;
        e = null
    } else t !== e && (e = null);
    return zs = e, null
}

function Am(e) {
    switch (e) {
        case "cancel":
        case "click":
        case "close":
        case "contextmenu":
        case "copy":
        case "cut":
        case "auxclick":
        case "dblclick":
        case "dragend":
        case "dragstart":
        case "drop":
        case "focusin":
        case "focusout":
        case "input":
        case "invalid":
        case "keydown":
        case "keypress":
        case "keyup":
        case "mousedown":
        case "mouseup":
        case "paste":
        case "pause":
        case "play":
        case "pointercancel":
        case "pointerdown":
        case "pointerup":
        case "ratechange":
        case "reset":
        case "resize":
        case "seeked":
        case "submit":
        case "touchcancel":
        case "touchend":
        case "touchstart":
        case "volumechange":
        case "change":
        case "selectionchange":
        case "textInput":
        case "compositionstart":
        case "compositionend":
        case "compositionupdate":
        case "beforeblur":
        case "afterblur":
        case "beforeinput":
        case "blur":
        case "fullscreenchange":
        case "focus":
        case "hashchange":
        case "popstate":
        case "select":
        case "selectstart":
            return 1;
        case "drag":
        case "dragenter":
        case "dragexit":
        case "dragleave":
        case "dragover":
        case "mousemove":
        case "mouseout":
        case "mouseover":
        case "pointermove":
        case "pointerout":
        case "pointerover":
        case "scroll":
        case "toggle":
        case "touchmove":
        case "wheel":
        case "mouseenter":
        case "mouseleave":
        case "pointerenter":
        case "pointerleave":
            return 4;
        case "message":
            switch (i1()) {
                case lc:
                    return 1;
                case wm:
                    return 4;
                case Vs:
                case o1:
                    return 16;
                case Sm:
                    return 536870912;
                default:
                    return 16
            }
        default:
            return 16
    }
}
var jn = null,
    fc = null,
    ys = null;

function Lm() {
    if (ys) return ys;
    var e, t = fc,
        n = t.length,
        r, i = "value" in jn ? jn.value : jn.textContent,
        o = i.length;
    for (e = 0; e < n && t[e] === i[e]; e++);
    var s = n - e;
    for (r = 1; r <= s && t[n - r] === i[o - r]; r++);
    return ys = i.slice(e, 1 < r ? 1 - r : void 0)
}

function xs(e) {
    var t = e.keyCode;
    return "charCode" in e ? (e = e.charCode, e === 0 && t === 13 && (e = 13)) : e = t, e === 10 && (e = 13), 32 <= e || e === 13 ? e : 0
}

function ts() {
    return !0
}

function rf() {
    return !1
}

function yt(e) {
    function t(n, r, i, o, s) {
        this._reactName = n, this._targetInst = i, this.type = r, this.nativeEvent = o, this.target = s, this.currentTarget = null;
        for (var a in e) e.hasOwnProperty(a) && (n = e[a], this[a] = n ? n(o) : o[a]);
        return this.isDefaultPrevented = (o.defaultPrevented != null ? o.defaultPrevented : o.returnValue === !1) ? ts : rf, this.isPropagationStopped = rf, this
    }
    return Se(t.prototype, {
        preventDefault: function() {
            this.defaultPrevented = !0;
            var n = this.nativeEvent;
            n && (n.preventDefault ? n.preventDefault() : typeof n.returnValue != "unknown" && (n.returnValue = !1), this.isDefaultPrevented = ts)
        },
        stopPropagation: function() {
            var n = this.nativeEvent;
            n && (n.stopPropagation ? n.stopPropagation() : typeof n.cancelBubble != "unknown" && (n.cancelBubble = !0), this.isPropagationStopped = ts)
        },
        persist: function() {},
        isPersistent: ts
    }), t
}
var gi = {
        eventPhase: 0,
        bubbles: 0,
        cancelable: 0,
        timeStamp: function(e) {
            return e.timeStamp || Date.now()
        },
        defaultPrevented: 0,
        isTrusted: 0
    },
    hc = yt(gi),
    Ao = Se({}, gi, {
        view: 0,
        detail: 0
    }),
    y1 = yt(Ao),
    Za, Ja, ki, xa = Se({}, Ao, {
        screenX: 0,
        screenY: 0,
        clientX: 0,
        clientY: 0,
        pageX: 0,
        pageY: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        getModifierState: pc,
        button: 0,
        buttons: 0,
        relatedTarget: function(e) {
            return e.relatedTarget === void 0 ? e.fromElement === e.srcElement ? e.toElement : e.fromElement : e.relatedTarget
        },
        movementX: function(e) {
            return "movementX" in e ? e.movementX : (e !== ki && (ki && e.type === "mousemove" ? (Za = e.screenX - ki.screenX, Ja = e.screenY - ki.screenY) : Ja = Za = 0, ki = e), Za)
        },
        movementY: function(e) {
            return "movementY" in e ? e.movementY : Ja
        }
    }),
    of = yt(xa),
    x1 = Se({}, xa, {
        dataTransfer: 0
    }),
    w1 = yt(x1),
    S1 = Se({}, Ao, {
        relatedTarget: 0
    }),
    qa = yt(S1),
    T1 = Se({}, gi, {
        animationName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    P1 = yt(T1),
    E1 = Se({}, gi, {
        clipboardData: function(e) {
            return "clipboardData" in e ? e.clipboardData : window.clipboardData
        }
    }),
    C1 = yt(E1),
    k1 = Se({}, gi, {
        data: 0
    }),
    sf = yt(k1),
    R1 = {
        Esc: "Escape",
        Spacebar: " ",
        Left: "ArrowLeft",
        Up: "ArrowUp",
        Right: "ArrowRight",
        Down: "ArrowDown",
        Del: "Delete",
        Win: "OS",
        Menu: "ContextMenu",
        Apps: "ContextMenu",
        Scroll: "ScrollLock",
        MozPrintableKey: "Unidentified"
    },
    j1 = {
        8: "Backspace",
        9: "Tab",
        12: "Clear",
        13: "Enter",
        16: "Shift",
        17: "Control",
        18: "Alt",
        19: "Pause",
        20: "CapsLock",
        27: "Escape",
        32: " ",
        33: "PageUp",
        34: "PageDown",
        35: "End",
        36: "Home",
        37: "ArrowLeft",
        38: "ArrowUp",
        39: "ArrowRight",
        40: "ArrowDown",
        45: "Insert",
        46: "Delete",
        112: "F1",
        113: "F2",
        114: "F3",
        115: "F4",
        116: "F5",
        117: "F6",
        118: "F7",
        119: "F8",
        120: "F9",
        121: "F10",
        122: "F11",
        123: "F12",
        144: "NumLock",
        145: "ScrollLock",
        224: "Meta"
    },
    A1 = {
        Alt: "altKey",
        Control: "ctrlKey",
        Meta: "metaKey",
        Shift: "shiftKey"
    };

function L1(e) {
    var t = this.nativeEvent;
    return t.getModifierState ? t.getModifierState(e) : (e = A1[e]) ? !!t[e] : !1
}

function pc() {
    return L1
}
var M1 = Se({}, Ao, {
        key: function(e) {
            if (e.key) {
                var t = R1[e.key] || e.key;
                if (t !== "Unidentified") return t
            }
            return e.type === "keypress" ? (e = xs(e), e === 13 ? "Enter" : String.fromCharCode(e)) : e.type === "keydown" || e.type === "keyup" ? j1[e.keyCode] || "Unidentified" : ""
        },
        code: 0,
        location: 0,
        ctrlKey: 0,
        shiftKey: 0,
        altKey: 0,
        metaKey: 0,
        repeat: 0,
        locale: 0,
        getModifierState: pc,
        charCode: function(e) {
            return e.type === "keypress" ? xs(e) : 0
        },
        keyCode: function(e) {
            return e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        },
        which: function(e) {
            return e.type === "keypress" ? xs(e) : e.type === "keydown" || e.type === "keyup" ? e.keyCode : 0
        }
    }),
    N1 = yt(M1),
    D1 = Se({}, xa, {
        pointerId: 0,
        width: 0,
        height: 0,
        pressure: 0,
        tangentialPressure: 0,
        tiltX: 0,
        tiltY: 0,
        twist: 0,
        pointerType: 0,
        isPrimary: 0
    }),
    af = yt(D1),
    _1 = Se({}, Ao, {
        touches: 0,
        targetTouches: 0,
        changedTouches: 0,
        altKey: 0,
        metaKey: 0,
        ctrlKey: 0,
        shiftKey: 0,
        getModifierState: pc
    }),
    O1 = yt(_1),
    V1 = Se({}, gi, {
        propertyName: 0,
        elapsedTime: 0,
        pseudoElement: 0
    }),
    F1 = yt(V1),
    I1 = Se({}, xa, {
        deltaX: function(e) {
            return "deltaX" in e ? e.deltaX : "wheelDeltaX" in e ? -e.wheelDeltaX : 0
        },
        deltaY: function(e) {
            return "deltaY" in e ? e.deltaY : "wheelDeltaY" in e ? -e.wheelDeltaY : "wheelDelta" in e ? -e.wheelDelta : 0
        },
        deltaZ: 0,
        deltaMode: 0
    }),
    z1 = yt(I1),
    b1 = [9, 13, 27, 32],
    mc = fn && "CompositionEvent" in window,
    Wi = null;
fn && "documentMode" in document && (Wi = document.documentMode);
var B1 = fn && "TextEvent" in window && !Wi,
    Mm = fn && (!mc || Wi && 8 < Wi && 11 >= Wi),
    lf = " ",
    uf = !1;

function Nm(e, t) {
    switch (e) {
        case "keyup":
            return b1.indexOf(t.keyCode) !== -1;
        case "keydown":
            return t.keyCode !== 229;
        case "keypress":
        case "mousedown":
        case "focusout":
            return !0;
        default:
            return !1
    }
}

function Dm(e) {
    return e = e.detail, typeof e == "object" && "data" in e ? e.data : null
}
var Nr = !1;

function U1(e, t) {
    switch (e) {
        case "compositionend":
            return Dm(t);
        case "keypress":
            return t.which !== 32 ? null : (uf = !0, lf);
        case "textInput":
            return e = t.data, e === lf && uf ? null : e;
        default:
            return null
    }
}

function H1(e, t) {
    if (Nr) return e === "compositionend" || !mc && Nm(e, t) ? (e = Lm(), ys = fc = jn = null, Nr = !1, e) : null;
    switch (e) {
        case "paste":
            return null;
        case "keypress":
            if (!(t.ctrlKey || t.altKey || t.metaKey) || t.ctrlKey && t.altKey) {
                if (t.char && 1 < t.char.length) return t.char;
                if (t.which) return String.fromCharCode(t.which)
            }
            return null;
        case "compositionend":
            return Mm && t.locale !== "ko" ? null : t.data;
        default:
            return null
    }
}
var $1 = {
    color: !0,
    date: !0,
    datetime: !0,
    "datetime-local": !0,
    email: !0,
    month: !0,
    number: !0,
    password: !0,
    range: !0,
    search: !0,
    tel: !0,
    text: !0,
    time: !0,
    url: !0,
    week: !0
};

function cf(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t === "input" ? !!$1[e.type] : t === "textarea"
}

function _m(e, t, n, r) {
    dm(r), t = bs(t, "onChange"), 0 < t.length && (n = new hc("onChange", "change", null, n, r), e.push({
        event: n,
        listeners: t
    }))
}
var Ki = null,
    ao = null;

function W1(e) {
    Wm(e, 0)
}

function wa(e) {
    var t = Or(e);
    if (im(t)) return e
}

function K1(e, t) {
    if (e === "change") return t
}
var Om = !1;
if (fn) {
    var el;
    if (fn) {
        var tl = "oninput" in document;
        if (!tl) {
            var df = document.createElement("div");
            df.setAttribute("oninput", "return;"), tl = typeof df.oninput == "function"
        }
        el = tl
    } else el = !1;
    Om = el && (!document.documentMode || 9 < document.documentMode)
}

function ff() {
    Ki && (Ki.detachEvent("onpropertychange", Vm), ao = Ki = null)
}

function Vm(e) {
    if (e.propertyName === "value" && wa(ao)) {
        var t = [];
        _m(t, ao, e, ac(e)), mm(W1, t)
    }
}

function G1(e, t, n) {
    e === "focusin" ? (ff(), Ki = t, ao = n, Ki.attachEvent("onpropertychange", Vm)) : e === "focusout" && ff()
}

function Y1(e) {
    if (e === "selectionchange" || e === "keyup" || e === "keydown") return wa(ao)
}

function Q1(e, t) {
    if (e === "click") return wa(t)
}

function X1(e, t) {
    if (e === "input" || e === "change") return wa(t)
}

function Z1(e, t) {
    return e === t && (e !== 0 || 1 / e === 1 / t) || e !== e && t !== t
}
var zt = typeof Object.is == "function" ? Object.is : Z1;

function lo(e, t) {
    if (zt(e, t)) return !0;
    if (typeof e != "object" || e === null || typeof t != "object" || t === null) return !1;
    var n = Object.keys(e),
        r = Object.keys(t);
    if (n.length !== r.length) return !1;
    for (r = 0; r < n.length; r++) {
        var i = n[r];
        if (!Ol.call(t, i) || !zt(e[i], t[i])) return !1
    }
    return !0
}

function hf(e) {
    for (; e && e.firstChild;) e = e.firstChild;
    return e
}

function pf(e, t) {
    var n = hf(e);
    e = 0;
    for (var r; n;) {
        if (n.nodeType === 3) {
            if (r = e + n.textContent.length, e <= t && r >= t) return {
                node: n,
                offset: t - e
            };
            e = r
        }
        e: {
            for (; n;) {
                if (n.nextSibling) {
                    n = n.nextSibling;
                    break e
                }
                n = n.parentNode
            }
            n = void 0
        }
        n = hf(n)
    }
}

function Fm(e, t) {
    return e && t ? e === t ? !0 : e && e.nodeType === 3 ? !1 : t && t.nodeType === 3 ? Fm(e, t.parentNode) : "contains" in e ? e.contains(t) : e.compareDocumentPosition ? !!(e.compareDocumentPosition(t) & 16) : !1 : !1
}

function Im() {
    for (var e = window, t = Ds(); t instanceof e.HTMLIFrameElement;) {
        try {
            var n = typeof t.contentWindow.location.href == "string"
        } catch {
            n = !1
        }
        if (n) e = t.contentWindow;
        else break;
        t = Ds(e.document)
    }
    return t
}

function gc(e) {
    var t = e && e.nodeName && e.nodeName.toLowerCase();
    return t && (t === "input" && (e.type === "text" || e.type === "search" || e.type === "tel" || e.type === "url" || e.type === "password") || t === "textarea" || e.contentEditable === "true")
}

function J1(e) {
    var t = Im(),
        n = e.focusedElem,
        r = e.selectionRange;
    if (t !== n && n && n.ownerDocument && Fm(n.ownerDocument.documentElement, n)) {
        if (r !== null && gc(n)) {
            if (t = r.start, e = r.end, e === void 0 && (e = t), "selectionStart" in n) n.selectionStart = t, n.selectionEnd = Math.min(e, n.value.length);
            else if (e = (t = n.ownerDocument || document) && t.defaultView || window, e.getSelection) {
                e = e.getSelection();
                var i = n.textContent.length,
                    o = Math.min(r.start, i);
                r = r.end === void 0 ? o : Math.min(r.end, i), !e.extend && o > r && (i = r, r = o, o = i), i = pf(n, o);
                var s = pf(n, r);
                i && s && (e.rangeCount !== 1 || e.anchorNode !== i.node || e.anchorOffset !== i.offset || e.focusNode !== s.node || e.focusOffset !== s.offset) && (t = t.createRange(), t.setStart(i.node, i.offset), e.removeAllRanges(), o > r ? (e.addRange(t), e.extend(s.node, s.offset)) : (t.setEnd(s.node, s.offset), e.addRange(t)))
            }
        }
        for (t = [], e = n; e = e.parentNode;) e.nodeType === 1 && t.push({
            element: e,
            left: e.scrollLeft,
            top: e.scrollTop
        });
        for (typeof n.focus == "function" && n.focus(), n = 0; n < t.length; n++) e = t[n], e.element.scrollLeft = e.left, e.element.scrollTop = e.top
    }
}
var q1 = fn && "documentMode" in document && 11 >= document.documentMode,
    Dr = null,
    eu = null,
    Gi = null,
    tu = !1;

function mf(e, t, n) {
    var r = n.window === n ? n.document : n.nodeType === 9 ? n : n.ownerDocument;
    tu || Dr == null || Dr !== Ds(r) || (r = Dr, "selectionStart" in r && gc(r) ? r = {
        start: r.selectionStart,
        end: r.selectionEnd
    } : (r = (r.ownerDocument && r.ownerDocument.defaultView || window).getSelection(), r = {
        anchorNode: r.anchorNode,
        anchorOffset: r.anchorOffset,
        focusNode: r.focusNode,
        focusOffset: r.focusOffset
    }), Gi && lo(Gi, r) || (Gi = r, r = bs(eu, "onSelect"), 0 < r.length && (t = new hc("onSelect", "select", null, t, n), e.push({
        event: t,
        listeners: r
    }), t.target = Dr)))
}

function ns(e, t) {
    var n = {};
    return n[e.toLowerCase()] = t.toLowerCase(), n["Webkit" + e] = "webkit" + t, n["Moz" + e] = "moz" + t, n
}
var _r = {
        animationend: ns("Animation", "AnimationEnd"),
        animationiteration: ns("Animation", "AnimationIteration"),
        animationstart: ns("Animation", "AnimationStart"),
        transitionend: ns("Transition", "TransitionEnd")
    },
    nl = {},
    zm = {};
fn && (zm = document.createElement("div").style, "AnimationEvent" in window || (delete _r.animationend.animation, delete _r.animationiteration.animation, delete _r.animationstart.animation), "TransitionEvent" in window || delete _r.transitionend.transition);

function Sa(e) {
    if (nl[e]) return nl[e];
    if (!_r[e]) return e;
    var t = _r[e],
        n;
    for (n in t)
        if (t.hasOwnProperty(n) && n in zm) return nl[e] = t[n];
    return e
}
var bm = Sa("animationend"),
    Bm = Sa("animationiteration"),
    Um = Sa("animationstart"),
    Hm = Sa("transitionend"),
    $m = new Map,
    gf = "abort auxClick cancel canPlay canPlayThrough click close contextMenu copy cut drag dragEnd dragEnter dragExit dragLeave dragOver dragStart drop durationChange emptied encrypted ended error gotPointerCapture input invalid keyDown keyPress keyUp load loadedData loadedMetadata loadStart lostPointerCapture mouseDown mouseMove mouseOut mouseOver mouseUp paste pause play playing pointerCancel pointerDown pointerMove pointerOut pointerOver pointerUp progress rateChange reset resize seeked seeking stalled submit suspend timeUpdate touchCancel touchEnd touchStart volumeChange scroll toggle touchMove waiting wheel".split(" ");

function $n(e, t) {
    $m.set(e, t), Pr(t, [e])
}
for (var rl = 0; rl < gf.length; rl++) {
    var il = gf[rl],
        ex = il.toLowerCase(),
        tx = il[0].toUpperCase() + il.slice(1);
    $n(ex, "on" + tx)
}
$n(bm, "onAnimationEnd");
$n(Bm, "onAnimationIteration");
$n(Um, "onAnimationStart");
$n("dblclick", "onDoubleClick");
$n("focusin", "onFocus");
$n("focusout", "onBlur");
$n(Hm, "onTransitionEnd");
ni("onMouseEnter", ["mouseout", "mouseover"]);
ni("onMouseLeave", ["mouseout", "mouseover"]);
ni("onPointerEnter", ["pointerout", "pointerover"]);
ni("onPointerLeave", ["pointerout", "pointerover"]);
Pr("onChange", "change click focusin focusout input keydown keyup selectionchange".split(" "));
Pr("onSelect", "focusout contextmenu dragend focusin keydown keyup mousedown mouseup selectionchange".split(" "));
Pr("onBeforeInput", ["compositionend", "keypress", "textInput", "paste"]);
Pr("onCompositionEnd", "compositionend focusout keydown keypress keyup mousedown".split(" "));
Pr("onCompositionStart", "compositionstart focusout keydown keypress keyup mousedown".split(" "));
Pr("onCompositionUpdate", "compositionupdate focusout keydown keypress keyup mousedown".split(" "));
var zi = "abort canplay canplaythrough durationchange emptied encrypted ended error loadeddata loadedmetadata loadstart pause play playing progress ratechange resize seeked seeking stalled suspend timeupdate volumechange waiting".split(" "),
    nx = new Set("cancel close invalid load scroll toggle".split(" ").concat(zi));

function vf(e, t, n) {
    var r = e.type || "unknown-event";
    e.currentTarget = n, e1(r, t, void 0, e), e.currentTarget = null
}

function Wm(e, t) {
    t = (t & 4) !== 0;
    for (var n = 0; n < e.length; n++) {
        var r = e[n],
            i = r.event;
        r = r.listeners;
        e: {
            var o = void 0;
            if (t)
                for (var s = r.length - 1; 0 <= s; s--) {
                    var a = r[s],
                        l = a.instance,
                        u = a.currentTarget;
                    if (a = a.listener, l !== o && i.isPropagationStopped()) break e;
                    vf(i, a, u), o = l
                } else
                    for (s = 0; s < r.length; s++) {
                        if (a = r[s], l = a.instance, u = a.currentTarget, a = a.listener, l !== o && i.isPropagationStopped()) break e;
                        vf(i, a, u), o = l
                    }
        }
    }
    if (Os) throw e = Xl, Os = !1, Xl = null, e
}

function de(e, t) {
    var n = t[su];
    n === void 0 && (n = t[su] = new Set);
    var r = e + "__bubble";
    n.has(r) || (Km(t, e, 2, !1), n.add(r))
}

function ol(e, t, n) {
    var r = 0;
    t && (r |= 4), Km(n, e, r, t)
}
var rs = "_reactListening" + Math.random().toString(36).slice(2);

function uo(e) {
    if (!e[rs]) {
        e[rs] = !0, qp.forEach(function(n) {
            n !== "selectionchange" && (nx.has(n) || ol(n, !1, e), ol(n, !0, e))
        });
        var t = e.nodeType === 9 ? e : e.ownerDocument;
        t === null || t[rs] || (t[rs] = !0, ol("selectionchange", !1, t))
    }
}

function Km(e, t, n, r) {
    switch (Am(t)) {
        case 1:
            var i = g1;
            break;
        case 4:
            i = v1;
            break;
        default:
            i = dc
    }
    n = i.bind(null, t, n, e), i = void 0, !Ql || t !== "touchstart" && t !== "touchmove" && t !== "wheel" || (i = !0), r ? i !== void 0 ? e.addEventListener(t, n, {
        capture: !0,
        passive: i
    }) : e.addEventListener(t, n, !0) : i !== void 0 ? e.addEventListener(t, n, {
        passive: i
    }) : e.addEventListener(t, n, !1)
}

function sl(e, t, n, r, i) {
    var o = r;
    if (!(t & 1) && !(t & 2) && r !== null) e: for (;;) {
        if (r === null) return;
        var s = r.tag;
        if (s === 3 || s === 4) {
            var a = r.stateNode.containerInfo;
            if (a === i || a.nodeType === 8 && a.parentNode === i) break;
            if (s === 4)
                for (s = r.return; s !== null;) {
                    var l = s.tag;
                    if ((l === 3 || l === 4) && (l = s.stateNode.containerInfo, l === i || l.nodeType === 8 && l.parentNode === i)) return;
                    s = s.return
                }
            for (; a !== null;) {
                if (s = lr(a), s === null) return;
                if (l = s.tag, l === 5 || l === 6) {
                    r = o = s;
                    continue e
                }
                a = a.parentNode
            }
        }
        r = r.return
    }
    mm(function() {
        var u = o,
            c = ac(n),
            d = [];
        e: {
            var f = $m.get(e);
            if (f !== void 0) {
                var m = hc,
                    x = e;
                switch (e) {
                    case "keypress":
                        if (xs(n) === 0) break e;
                    case "keydown":
                    case "keyup":
                        m = N1;
                        break;
                    case "focusin":
                        x = "focus", m = qa;
                        break;
                    case "focusout":
                        x = "blur", m = qa;
                        break;
                    case "beforeblur":
                    case "afterblur":
                        m = qa;
                        break;
                    case "click":
                        if (n.button === 2) break e;
                    case "auxclick":
                    case "dblclick":
                    case "mousedown":
                    case "mousemove":
                    case "mouseup":
                    case "mouseout":
                    case "mouseover":
                    case "contextmenu":
                        m = of ;
                        break;
                    case "drag":
                    case "dragend":
                    case "dragenter":
                    case "dragexit":
                    case "dragleave":
                    case "dragover":
                    case "dragstart":
                    case "drop":
                        m = w1;
                        break;
                    case "touchcancel":
                    case "touchend":
                    case "touchmove":
                    case "touchstart":
                        m = O1;
                        break;
                    case bm:
                    case Bm:
                    case Um:
                        m = P1;
                        break;
                    case Hm:
                        m = F1;
                        break;
                    case "scroll":
                        m = y1;
                        break;
                    case "wheel":
                        m = z1;
                        break;
                    case "copy":
                    case "cut":
                    case "paste":
                        m = C1;
                        break;
                    case "gotpointercapture":
                    case "lostpointercapture":
                    case "pointercancel":
                    case "pointerdown":
                    case "pointermove":
                    case "pointerout":
                    case "pointerover":
                    case "pointerup":
                        m = af
                }
                var w = (t & 4) !== 0,
                    E = !w && e === "scroll",
                    p = w ? f !== null ? f + "Capture" : null : f;
                w = [];
                for (var h = u, g; h !== null;) {
                    g = h;
                    var P = g.stateNode;
                    if (g.tag === 5 && P !== null && (g = P, p !== null && (P = ro(h, p), P != null && w.push(co(h, P, g)))), E) break;
                    h = h.return
                }
                0 < w.length && (f = new m(f, x, null, n, c), d.push({
                    event: f,
                    listeners: w
                }))
            }
        }
        if (!(t & 7)) {
            e: {
                if (f = e === "mouseover" || e === "pointerover", m = e === "mouseout" || e === "pointerout", f && n !== Gl && (x = n.relatedTarget || n.fromElement) && (lr(x) || x[hn])) break e;
                if ((m || f) && (f = c.window === c ? c : (f = c.ownerDocument) ? f.defaultView || f.parentWindow : window, m ? (x = n.relatedTarget || n.toElement, m = u, x = x ? lr(x) : null, x !== null && (E = Er(x), x !== E || x.tag !== 5 && x.tag !== 6) && (x = null)) : (m = null, x = u), m !== x)) {
                    if (w = of , P = "onMouseLeave", p = "onMouseEnter", h = "mouse", (e === "pointerout" || e === "pointerover") && (w = af, P = "onPointerLeave", p = "onPointerEnter", h = "pointer"), E = m == null ? f : Or(m), g = x == null ? f : Or(x), f = new w(P, h + "leave", m, n, c), f.target = E, f.relatedTarget = g, P = null, lr(c) === u && (w = new w(p, h + "enter", x, n, c), w.target = g, w.relatedTarget = E, P = w), E = P, m && x) t: {
                        for (w = m, p = x, h = 0, g = w; g; g = Rr(g)) h++;
                        for (g = 0, P = p; P; P = Rr(P)) g++;
                        for (; 0 < h - g;) w = Rr(w),
                        h--;
                        for (; 0 < g - h;) p = Rr(p),
                        g--;
                        for (; h--;) {
                            if (w === p || p !== null && w === p.alternate) break t;
                            w = Rr(w), p = Rr(p)
                        }
                        w = null
                    }
                    else w = null;
                    m !== null && yf(d, f, m, w, !1), x !== null && E !== null && yf(d, E, x, w, !0)
                }
            }
            e: {
                if (f = u ? Or(u) : window, m = f.nodeName && f.nodeName.toLowerCase(), m === "select" || m === "input" && f.type === "file") var R = K1;
                else if (cf(f))
                    if (Om) R = X1;
                    else {
                        R = Y1;
                        var A = G1
                    }
                else(m = f.nodeName) && m.toLowerCase() === "input" && (f.type === "checkbox" || f.type === "radio") && (R = Q1);
                if (R && (R = R(e, u))) {
                    _m(d, R, n, c);
                    break e
                }
                A && A(e, f, u),
                e === "focusout" && (A = f._wrapperState) && A.controlled && f.type === "number" && Ul(f, "number", f.value)
            }
            switch (A = u ? Or(u) : window, e) {
                case "focusin":
                    (cf(A) || A.contentEditable === "true") && (Dr = A, eu = u, Gi = null);
                    break;
                case "focusout":
                    Gi = eu = Dr = null;
                    break;
                case "mousedown":
                    tu = !0;
                    break;
                case "contextmenu":
                case "mouseup":
                case "dragend":
                    tu = !1, mf(d, n, c);
                    break;
                case "selectionchange":
                    if (q1) break;
                case "keydown":
                case "keyup":
                    mf(d, n, c)
            }
            var N;
            if (mc) e: {
                switch (e) {
                    case "compositionstart":
                        var y = "onCompositionStart";
                        break e;
                    case "compositionend":
                        y = "onCompositionEnd";
                        break e;
                    case "compositionupdate":
                        y = "onCompositionUpdate";
                        break e
                }
                y = void 0
            }
            else Nr ? Nm(e, n) && (y = "onCompositionEnd") : e === "keydown" && n.keyCode === 229 && (y = "onCompositionStart");y && (Mm && n.locale !== "ko" && (Nr || y !== "onCompositionStart" ? y === "onCompositionEnd" && Nr && (N = Lm()) : (jn = c, fc = "value" in jn ? jn.value : jn.textContent, Nr = !0)), A = bs(u, y), 0 < A.length && (y = new sf(y, e, null, n, c), d.push({
                event: y,
                listeners: A
            }), N ? y.data = N : (N = Dm(n), N !== null && (y.data = N)))),
            (N = B1 ? U1(e, n) : H1(e, n)) && (u = bs(u, "onBeforeInput"), 0 < u.length && (c = new sf("onBeforeInput", "beforeinput", null, n, c), d.push({
                event: c,
                listeners: u
            }), c.data = N))
        }
        Wm(d, t)
    })
}

function co(e, t, n) {
    return {
        instance: e,
        listener: t,
        currentTarget: n
    }
}

function bs(e, t) {
    for (var n = t + "Capture", r = []; e !== null;) {
        var i = e,
            o = i.stateNode;
        i.tag === 5 && o !== null && (i = o, o = ro(e, n), o != null && r.unshift(co(e, o, i)), o = ro(e, t), o != null && r.push(co(e, o, i))), e = e.return
    }
    return r
}

function Rr(e) {
    if (e === null) return null;
    do e = e.return; while (e && e.tag !== 5);
    return e || null
}

function yf(e, t, n, r, i) {
    for (var o = t._reactName, s = []; n !== null && n !== r;) {
        var a = n,
            l = a.alternate,
            u = a.stateNode;
        if (l !== null && l === r) break;
        a.tag === 5 && u !== null && (a = u, i ? (l = ro(n, o), l != null && s.unshift(co(n, l, a))) : i || (l = ro(n, o), l != null && s.push(co(n, l, a)))), n = n.return
    }
    s.length !== 0 && e.push({
        event: t,
        listeners: s
    })
}
var rx = /\r\n?/g,
    ix = /\u0000|\uFFFD/g;

function xf(e) {
    return (typeof e == "string" ? e : "" + e).replace(rx, `
`).replace(ix, "")
}

function is(e, t, n) {
    if (t = xf(t), xf(e) !== t && n) throw Error(L(425))
}

function Bs() {}
var nu = null,
    ru = null;

function iu(e, t) {
    return e === "textarea" || e === "noscript" || typeof t.children == "string" || typeof t.children == "number" || typeof t.dangerouslySetInnerHTML == "object" && t.dangerouslySetInnerHTML !== null && t.dangerouslySetInnerHTML.__html != null
}
var ou = typeof setTimeout == "function" ? setTimeout : void 0,
    ox = typeof clearTimeout == "function" ? clearTimeout : void 0,
    wf = typeof Promise == "function" ? Promise : void 0,
    sx = typeof queueMicrotask == "function" ? queueMicrotask : typeof wf < "u" ? function(e) {
        return wf.resolve(null).then(e).catch(ax)
    } : ou;

function ax(e) {
    setTimeout(function() {
        throw e
    })
}

function al(e, t) {
    var n = t,
        r = 0;
    do {
        var i = n.nextSibling;
        if (e.removeChild(n), i && i.nodeType === 8)
            if (n = i.data, n === "/$") {
                if (r === 0) {
                    e.removeChild(i), so(t);
                    return
                }
                r--
            } else n !== "$" && n !== "$?" && n !== "$!" || r++;
        n = i
    } while (n);
    so(t)
}

function _n(e) {
    for (; e != null; e = e.nextSibling) {
        var t = e.nodeType;
        if (t === 1 || t === 3) break;
        if (t === 8) {
            if (t = e.data, t === "$" || t === "$!" || t === "$?") break;
            if (t === "/$") return null
        }
    }
    return e
}

function Sf(e) {
    e = e.previousSibling;
    for (var t = 0; e;) {
        if (e.nodeType === 8) {
            var n = e.data;
            if (n === "$" || n === "$!" || n === "$?") {
                if (t === 0) return e;
                t--
            } else n === "/$" && t++
        }
        e = e.previousSibling
    }
    return null
}
var vi = Math.random().toString(36).slice(2),
    Ut = "__reactFiber$" + vi,
    fo = "__reactProps$" + vi,
    hn = "__reactContainer$" + vi,
    su = "__reactEvents$" + vi,
    lx = "__reactListeners$" + vi,
    ux = "__reactHandles$" + vi;

function lr(e) {
    var t = e[Ut];
    if (t) return t;
    for (var n = e.parentNode; n;) {
        if (t = n[hn] || n[Ut]) {
            if (n = t.alternate, t.child !== null || n !== null && n.child !== null)
                for (e = Sf(e); e !== null;) {
                    if (n = e[Ut]) return n;
                    e = Sf(e)
                }
            return t
        }
        e = n, n = e.parentNode
    }
    return null
}

function Lo(e) {
    return e = e[Ut] || e[hn], !e || e.tag !== 5 && e.tag !== 6 && e.tag !== 13 && e.tag !== 3 ? null : e
}

function Or(e) {
    if (e.tag === 5 || e.tag === 6) return e.stateNode;
    throw Error(L(33))
}

function Ta(e) {
    return e[fo] || null
}
var au = [],
    Vr = -1;

function Wn(e) {
    return {
        current: e
    }
}

function fe(e) {
    0 > Vr || (e.current = au[Vr], au[Vr] = null, Vr--)
}

function ae(e, t) {
    Vr++, au[Vr] = e.current, e.current = t
}
var bn = {},
    Ge = Wn(bn),
    st = Wn(!1),
    vr = bn;

function ri(e, t) {
    var n = e.type.contextTypes;
    if (!n) return bn;
    var r = e.stateNode;
    if (r && r.__reactInternalMemoizedUnmaskedChildContext === t) return r.__reactInternalMemoizedMaskedChildContext;
    var i = {},
        o;
    for (o in n) i[o] = t[o];
    return r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = t, e.__reactInternalMemoizedMaskedChildContext = i), i
}

function at(e) {
    return e = e.childContextTypes, e != null
}

function Us() {
    fe(st), fe(Ge)
}

function Tf(e, t, n) {
    if (Ge.current !== bn) throw Error(L(168));
    ae(Ge, t), ae(st, n)
}

function Gm(e, t, n) {
    var r = e.stateNode;
    if (t = t.childContextTypes, typeof r.getChildContext != "function") return n;
    r = r.getChildContext();
    for (var i in r)
        if (!(i in t)) throw Error(L(108, Gy(e) || "Unknown", i));
    return Se({}, n, r)
}

function Hs(e) {
    return e = (e = e.stateNode) && e.__reactInternalMemoizedMergedChildContext || bn, vr = Ge.current, ae(Ge, e), ae(st, st.current), !0
}

function Pf(e, t, n) {
    var r = e.stateNode;
    if (!r) throw Error(L(169));
    n ? (e = Gm(e, t, vr), r.__reactInternalMemoizedMergedChildContext = e, fe(st), fe(Ge), ae(Ge, e)) : fe(st), ae(st, n)
}
var en = null,
    Pa = !1,
    ll = !1;

function Ym(e) {
    en === null ? en = [e] : en.push(e)
}

function cx(e) {
    Pa = !0, Ym(e)
}

function Kn() {
    if (!ll && en !== null) {
        ll = !0;
        var e = 0,
            t = re;
        try {
            var n = en;
            for (re = 1; e < n.length; e++) {
                var r = n[e];
                do r = r(!0); while (r !== null)
            }
            en = null, Pa = !1
        } catch (i) {
            throw en !== null && (en = en.slice(e + 1)), xm(lc, Kn), i
        } finally {
            re = t, ll = !1
        }
    }
    return null
}
var Fr = [],
    Ir = 0,
    $s = null,
    Ws = 0,
    Pt = [],
    Et = 0,
    yr = null,
    tn = 1,
    nn = "";

function nr(e, t) {
    Fr[Ir++] = Ws, Fr[Ir++] = $s, $s = e, Ws = t
}

function Qm(e, t, n) {
    Pt[Et++] = tn, Pt[Et++] = nn, Pt[Et++] = yr, yr = e;
    var r = tn;
    e = nn;
    var i = 32 - Ft(r) - 1;
    r &= ~(1 << i), n += 1;
    var o = 32 - Ft(t) + i;
    if (30 < o) {
        var s = i - i % 5;
        o = (r & (1 << s) - 1).toString(32), r >>= s, i -= s, tn = 1 << 32 - Ft(t) + i | n << i | r, nn = o + e
    } else tn = 1 << o | n << i | r, nn = e
}

function vc(e) {
    e.return !== null && (nr(e, 1), Qm(e, 1, 0))
}

function yc(e) {
    for (; e === $s;) $s = Fr[--Ir], Fr[Ir] = null, Ws = Fr[--Ir], Fr[Ir] = null;
    for (; e === yr;) yr = Pt[--Et], Pt[Et] = null, nn = Pt[--Et], Pt[Et] = null, tn = Pt[--Et], Pt[Et] = null
}
var pt = null,
    ft = null,
    ge = !1,
    _t = null;

function Xm(e, t) {
    var n = Ct(5, null, null, 0);
    n.elementType = "DELETED", n.stateNode = t, n.return = e, t = e.deletions, t === null ? (e.deletions = [n], e.flags |= 16) : t.push(n)
}

function Ef(e, t) {
    switch (e.tag) {
        case 5:
            var n = e.type;
            return t = t.nodeType !== 1 || n.toLowerCase() !== t.nodeName.toLowerCase() ? null : t, t !== null ? (e.stateNode = t, pt = e, ft = _n(t.firstChild), !0) : !1;
        case 6:
            return t = e.pendingProps === "" || t.nodeType !== 3 ? null : t, t !== null ? (e.stateNode = t, pt = e, ft = null, !0) : !1;
        case 13:
            return t = t.nodeType !== 8 ? null : t, t !== null ? (n = yr !== null ? {
                id: tn,
                overflow: nn
            } : null, e.memoizedState = {
                dehydrated: t,
                treeContext: n,
                retryLane: 1073741824
            }, n = Ct(18, null, null, 0), n.stateNode = t, n.return = e, e.child = n, pt = e, ft = null, !0) : !1;
        default:
            return !1
    }
}

function lu(e) {
    return (e.mode & 1) !== 0 && (e.flags & 128) === 0
}

function uu(e) {
    if (ge) {
        var t = ft;
        if (t) {
            var n = t;
            if (!Ef(e, t)) {
                if (lu(e)) throw Error(L(418));
                t = _n(n.nextSibling);
                var r = pt;
                t && Ef(e, t) ? Xm(r, n) : (e.flags = e.flags & -4097 | 2, ge = !1, pt = e)
            }
        } else {
            if (lu(e)) throw Error(L(418));
            e.flags = e.flags & -4097 | 2, ge = !1, pt = e
        }
    }
}

function Cf(e) {
    for (e = e.return; e !== null && e.tag !== 5 && e.tag !== 3 && e.tag !== 13;) e = e.return;
    pt = e
}

function os(e) {
    if (e !== pt) return !1;
    if (!ge) return Cf(e), ge = !0, !1;
    var t;
    if ((t = e.tag !== 3) && !(t = e.tag !== 5) && (t = e.type, t = t !== "head" && t !== "body" && !iu(e.type, e.memoizedProps)), t && (t = ft)) {
        if (lu(e)) throw Zm(), Error(L(418));
        for (; t;) Xm(e, t), t = _n(t.nextSibling)
    }
    if (Cf(e), e.tag === 13) {
        if (e = e.memoizedState, e = e !== null ? e.dehydrated : null, !e) throw Error(L(317));
        e: {
            for (e = e.nextSibling, t = 0; e;) {
                if (e.nodeType === 8) {
                    var n = e.data;
                    if (n === "/$") {
                        if (t === 0) {
                            ft = _n(e.nextSibling);
                            break e
                        }
                        t--
                    } else n !== "$" && n !== "$!" && n !== "$?" || t++
                }
                e = e.nextSibling
            }
            ft = null
        }
    } else ft = pt ? _n(e.stateNode.nextSibling) : null;
    return !0
}

function Zm() {
    for (var e = ft; e;) e = _n(e.nextSibling)
}

function ii() {
    ft = pt = null, ge = !1
}

function xc(e) {
    _t === null ? _t = [e] : _t.push(e)
}
var dx = vn.ReactCurrentBatchConfig;

function Ri(e, t, n) {
    if (e = n.ref, e !== null && typeof e != "function" && typeof e != "object") {
        if (n._owner) {
            if (n = n._owner, n) {
                if (n.tag !== 1) throw Error(L(309));
                var r = n.stateNode
            }
            if (!r) throw Error(L(147, e));
            var i = r,
                o = "" + e;
            return t !== null && t.ref !== null && typeof t.ref == "function" && t.ref._stringRef === o ? t.ref : (t = function(s) {
                var a = i.refs;
                s === null ? delete a[o] : a[o] = s
            }, t._stringRef = o, t)
        }
        if (typeof e != "string") throw Error(L(284));
        if (!n._owner) throw Error(L(290, e))
    }
    return e
}

function ss(e, t) {
    throw e = Object.prototype.toString.call(t), Error(L(31, e === "[object Object]" ? "object with keys {" + Object.keys(t).join(", ") + "}" : e))
}

function kf(e) {
    var t = e._init;
    return t(e._payload)
}

function Jm(e) {
    function t(p, h) {
        if (e) {
            var g = p.deletions;
            g === null ? (p.deletions = [h], p.flags |= 16) : g.push(h)
        }
    }

    function n(p, h) {
        if (!e) return null;
        for (; h !== null;) t(p, h), h = h.sibling;
        return null
    }

    function r(p, h) {
        for (p = new Map; h !== null;) h.key !== null ? p.set(h.key, h) : p.set(h.index, h), h = h.sibling;
        return p
    }

    function i(p, h) {
        return p = In(p, h), p.index = 0, p.sibling = null, p
    }

    function o(p, h, g) {
        return p.index = g, e ? (g = p.alternate, g !== null ? (g = g.index, g < h ? (p.flags |= 2, h) : g) : (p.flags |= 2, h)) : (p.flags |= 1048576, h)
    }

    function s(p) {
        return e && p.alternate === null && (p.flags |= 2), p
    }

    function a(p, h, g, P) {
        return h === null || h.tag !== 6 ? (h = ml(g, p.mode, P), h.return = p, h) : (h = i(h, g), h.return = p, h)
    }

    function l(p, h, g, P) {
        var R = g.type;
        return R === Mr ? c(p, h, g.props.children, P, g.key) : h !== null && (h.elementType === R || typeof R == "object" && R !== null && R.$$typeof === En && kf(R) === h.type) ? (P = i(h, g.props), P.ref = Ri(p, h, g), P.return = p, P) : (P = ks(g.type, g.key, g.props, null, p.mode, P), P.ref = Ri(p, h, g), P.return = p, P)
    }

    function u(p, h, g, P) {
        return h === null || h.tag !== 4 || h.stateNode.containerInfo !== g.containerInfo || h.stateNode.implementation !== g.implementation ? (h = gl(g, p.mode, P), h.return = p, h) : (h = i(h, g.children || []), h.return = p, h)
    }

    function c(p, h, g, P, R) {
        return h === null || h.tag !== 7 ? (h = pr(g, p.mode, P, R), h.return = p, h) : (h = i(h, g), h.return = p, h)
    }

    function d(p, h, g) {
        if (typeof h == "string" && h !== "" || typeof h == "number") return h = ml("" + h, p.mode, g), h.return = p, h;
        if (typeof h == "object" && h !== null) {
            switch (h.$$typeof) {
                case Qo:
                    return g = ks(h.type, h.key, h.props, null, p.mode, g), g.ref = Ri(p, null, h), g.return = p, g;
                case Lr:
                    return h = gl(h, p.mode, g), h.return = p, h;
                case En:
                    var P = h._init;
                    return d(p, P(h._payload), g)
            }
            if (Fi(h) || Ti(h)) return h = pr(h, p.mode, g, null), h.return = p, h;
            ss(p, h)
        }
        return null
    }

    function f(p, h, g, P) {
        var R = h !== null ? h.key : null;
        if (typeof g == "string" && g !== "" || typeof g == "number") return R !== null ? null : a(p, h, "" + g, P);
        if (typeof g == "object" && g !== null) {
            switch (g.$$typeof) {
                case Qo:
                    return g.key === R ? l(p, h, g, P) : null;
                case Lr:
                    return g.key === R ? u(p, h, g, P) : null;
                case En:
                    return R = g._init, f(p, h, R(g._payload), P)
            }
            if (Fi(g) || Ti(g)) return R !== null ? null : c(p, h, g, P, null);
            ss(p, g)
        }
        return null
    }

    function m(p, h, g, P, R) {
        if (typeof P == "string" && P !== "" || typeof P == "number") return p = p.get(g) || null, a(h, p, "" + P, R);
        if (typeof P == "object" && P !== null) {
            switch (P.$$typeof) {
                case Qo:
                    return p = p.get(P.key === null ? g : P.key) || null, l(h, p, P, R);
                case Lr:
                    return p = p.get(P.key === null ? g : P.key) || null, u(h, p, P, R);
                case En:
                    var A = P._init;
                    return m(p, h, g, A(P._payload), R)
            }
            if (Fi(P) || Ti(P)) return p = p.get(g) || null, c(h, p, P, R, null);
            ss(h, P)
        }
        return null
    }

    function x(p, h, g, P) {
        for (var R = null, A = null, N = h, y = h = 0, O = null; N !== null && y < g.length; y++) {
            N.index > y ? (O = N, N = null) : O = N.sibling;
            var M = f(p, N, g[y], P);
            if (M === null) {
                N === null && (N = O);
                break
            }
            e && N && M.alternate === null && t(p, N), h = o(M, h, y), A === null ? R = M : A.sibling = M, A = M, N = O
        }
        if (y === g.length) return n(p, N), ge && nr(p, y), R;
        if (N === null) {
            for (; y < g.length; y++) N = d(p, g[y], P), N !== null && (h = o(N, h, y), A === null ? R = N : A.sibling = N, A = N);
            return ge && nr(p, y), R
        }
        for (N = r(p, N); y < g.length; y++) O = m(N, p, y, g[y], P), O !== null && (e && O.alternate !== null && N.delete(O.key === null ? y : O.key), h = o(O, h, y), A === null ? R = O : A.sibling = O, A = O);
        return e && N.forEach(function(U) {
            return t(p, U)
        }), ge && nr(p, y), R
    }

    function w(p, h, g, P) {
        var R = Ti(g);
        if (typeof R != "function") throw Error(L(150));
        if (g = R.call(g), g == null) throw Error(L(151));
        for (var A = R = null, N = h, y = h = 0, O = null, M = g.next(); N !== null && !M.done; y++, M = g.next()) {
            N.index > y ? (O = N, N = null) : O = N.sibling;
            var U = f(p, N, M.value, P);
            if (U === null) {
                N === null && (N = O);
                break
            }
            e && N && U.alternate === null && t(p, N), h = o(U, h, y), A === null ? R = U : A.sibling = U, A = U, N = O
        }
        if (M.done) return n(p, N), ge && nr(p, y), R;
        if (N === null) {
            for (; !M.done; y++, M = g.next()) M = d(p, M.value, P), M !== null && (h = o(M, h, y), A === null ? R = M : A.sibling = M, A = M);
            return ge && nr(p, y), R
        }
        for (N = r(p, N); !M.done; y++, M = g.next()) M = m(N, p, y, M.value, P), M !== null && (e && M.alternate !== null && N.delete(M.key === null ? y : M.key), h = o(M, h, y), A === null ? R = M : A.sibling = M, A = M);
        return e && N.forEach(function(te) {
            return t(p, te)
        }), ge && nr(p, y), R
    }

    function E(p, h, g, P) {
        if (typeof g == "object" && g !== null && g.type === Mr && g.key === null && (g = g.props.children), typeof g == "object" && g !== null) {
            switch (g.$$typeof) {
                case Qo:
                    e: {
                        for (var R = g.key, A = h; A !== null;) {
                            if (A.key === R) {
                                if (R = g.type, R === Mr) {
                                    if (A.tag === 7) {
                                        n(p, A.sibling), h = i(A, g.props.children), h.return = p, p = h;
                                        break e
                                    }
                                } else if (A.elementType === R || typeof R == "object" && R !== null && R.$$typeof === En && kf(R) === A.type) {
                                    n(p, A.sibling), h = i(A, g.props), h.ref = Ri(p, A, g), h.return = p, p = h;
                                    break e
                                }
                                n(p, A);
                                break
                            } else t(p, A);
                            A = A.sibling
                        }
                        g.type === Mr ? (h = pr(g.props.children, p.mode, P, g.key), h.return = p, p = h) : (P = ks(g.type, g.key, g.props, null, p.mode, P), P.ref = Ri(p, h, g), P.return = p, p = P)
                    }
                    return s(p);
                case Lr:
                    e: {
                        for (A = g.key; h !== null;) {
                            if (h.key === A)
                                if (h.tag === 4 && h.stateNode.containerInfo === g.containerInfo && h.stateNode.implementation === g.implementation) {
                                    n(p, h.sibling), h = i(h, g.children || []), h.return = p, p = h;
                                    break e
                                } else {
                                    n(p, h);
                                    break
                                }
                            else t(p, h);
                            h = h.sibling
                        }
                        h = gl(g, p.mode, P),
                        h.return = p,
                        p = h
                    }
                    return s(p);
                case En:
                    return A = g._init, E(p, h, A(g._payload), P)
            }
            if (Fi(g)) return x(p, h, g, P);
            if (Ti(g)) return w(p, h, g, P);
            ss(p, g)
        }
        return typeof g == "string" && g !== "" || typeof g == "number" ? (g = "" + g, h !== null && h.tag === 6 ? (n(p, h.sibling), h = i(h, g), h.return = p, p = h) : (n(p, h), h = ml(g, p.mode, P), h.return = p, p = h), s(p)) : n(p, h)
    }
    return E
}
var oi = Jm(!0),
    qm = Jm(!1),
    Ks = Wn(null),
    Gs = null,
    zr = null,
    wc = null;

function Sc() {
    wc = zr = Gs = null
}

function Tc(e) {
    var t = Ks.current;
    fe(Ks), e._currentValue = t
}

function cu(e, t, n) {
    for (; e !== null;) {
        var r = e.alternate;
        if ((e.childLanes & t) !== t ? (e.childLanes |= t, r !== null && (r.childLanes |= t)) : r !== null && (r.childLanes & t) !== t && (r.childLanes |= t), e === n) break;
        e = e.return
    }
}

function Jr(e, t) {
    Gs = e, wc = zr = null, e = e.dependencies, e !== null && e.firstContext !== null && (e.lanes & t && (ot = !0), e.firstContext = null)
}

function Rt(e) {
    var t = e._currentValue;
    if (wc !== e)
        if (e = {
                context: e,
                memoizedValue: t,
                next: null
            }, zr === null) {
            if (Gs === null) throw Error(L(308));
            zr = e, Gs.dependencies = {
                lanes: 0,
                firstContext: e
            }
        } else zr = zr.next = e;
    return t
}
var ur = null;

function Pc(e) {
    ur === null ? ur = [e] : ur.push(e)
}

function eg(e, t, n, r) {
    var i = t.interleaved;
    return i === null ? (n.next = n, Pc(t)) : (n.next = i.next, i.next = n), t.interleaved = n, pn(e, r)
}

function pn(e, t) {
    e.lanes |= t;
    var n = e.alternate;
    for (n !== null && (n.lanes |= t), n = e, e = e.return; e !== null;) e.childLanes |= t, n = e.alternate, n !== null && (n.childLanes |= t), n = e, e = e.return;
    return n.tag === 3 ? n.stateNode : null
}
var Cn = !1;

function Ec(e) {
    e.updateQueue = {
        baseState: e.memoizedState,
        firstBaseUpdate: null,
        lastBaseUpdate: null,
        shared: {
            pending: null,
            interleaved: null,
            lanes: 0
        },
        effects: null
    }
}

function tg(e, t) {
    e = e.updateQueue, t.updateQueue === e && (t.updateQueue = {
        baseState: e.baseState,
        firstBaseUpdate: e.firstBaseUpdate,
        lastBaseUpdate: e.lastBaseUpdate,
        shared: e.shared,
        effects: e.effects
    })
}

function sn(e, t) {
    return {
        eventTime: e,
        lane: t,
        tag: 0,
        payload: null,
        callback: null,
        next: null
    }
}

function On(e, t, n) {
    var r = e.updateQueue;
    if (r === null) return null;
    if (r = r.shared, q & 2) {
        var i = r.pending;
        return i === null ? t.next = t : (t.next = i.next, i.next = t), r.pending = t, pn(e, n)
    }
    return i = r.interleaved, i === null ? (t.next = t, Pc(r)) : (t.next = i.next, i.next = t), r.interleaved = t, pn(e, n)
}

function ws(e, t, n) {
    if (t = t.updateQueue, t !== null && (t = t.shared, (n & 4194240) !== 0)) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, uc(e, n)
    }
}

function Rf(e, t) {
    var n = e.updateQueue,
        r = e.alternate;
    if (r !== null && (r = r.updateQueue, n === r)) {
        var i = null,
            o = null;
        if (n = n.firstBaseUpdate, n !== null) {
            do {
                var s = {
                    eventTime: n.eventTime,
                    lane: n.lane,
                    tag: n.tag,
                    payload: n.payload,
                    callback: n.callback,
                    next: null
                };
                o === null ? i = o = s : o = o.next = s, n = n.next
            } while (n !== null);
            o === null ? i = o = t : o = o.next = t
        } else i = o = t;
        n = {
            baseState: r.baseState,
            firstBaseUpdate: i,
            lastBaseUpdate: o,
            shared: r.shared,
            effects: r.effects
        }, e.updateQueue = n;
        return
    }
    e = n.lastBaseUpdate, e === null ? n.firstBaseUpdate = t : e.next = t, n.lastBaseUpdate = t
}

function Ys(e, t, n, r) {
    var i = e.updateQueue;
    Cn = !1;
    var o = i.firstBaseUpdate,
        s = i.lastBaseUpdate,
        a = i.shared.pending;
    if (a !== null) {
        i.shared.pending = null;
        var l = a,
            u = l.next;
        l.next = null, s === null ? o = u : s.next = u, s = l;
        var c = e.alternate;
        c !== null && (c = c.updateQueue, a = c.lastBaseUpdate, a !== s && (a === null ? c.firstBaseUpdate = u : a.next = u, c.lastBaseUpdate = l))
    }
    if (o !== null) {
        var d = i.baseState;
        s = 0, c = u = l = null, a = o;
        do {
            var f = a.lane,
                m = a.eventTime;
            if ((r & f) === f) {
                c !== null && (c = c.next = {
                    eventTime: m,
                    lane: 0,
                    tag: a.tag,
                    payload: a.payload,
                    callback: a.callback,
                    next: null
                });
                e: {
                    var x = e,
                        w = a;
                    switch (f = t, m = n, w.tag) {
                        case 1:
                            if (x = w.payload, typeof x == "function") {
                                d = x.call(m, d, f);
                                break e
                            }
                            d = x;
                            break e;
                        case 3:
                            x.flags = x.flags & -65537 | 128;
                        case 0:
                            if (x = w.payload, f = typeof x == "function" ? x.call(m, d, f) : x, f == null) break e;
                            d = Se({}, d, f);
                            break e;
                        case 2:
                            Cn = !0
                    }
                }
                a.callback !== null && a.lane !== 0 && (e.flags |= 64, f = i.effects, f === null ? i.effects = [a] : f.push(a))
            } else m = {
                eventTime: m,
                lane: f,
                tag: a.tag,
                payload: a.payload,
                callback: a.callback,
                next: null
            }, c === null ? (u = c = m, l = d) : c = c.next = m, s |= f;
            if (a = a.next, a === null) {
                if (a = i.shared.pending, a === null) break;
                f = a, a = f.next, f.next = null, i.lastBaseUpdate = f, i.shared.pending = null
            }
        } while (!0);
        if (c === null && (l = d), i.baseState = l, i.firstBaseUpdate = u, i.lastBaseUpdate = c, t = i.shared.interleaved, t !== null) {
            i = t;
            do s |= i.lane, i = i.next; while (i !== t)
        } else o === null && (i.shared.lanes = 0);
        wr |= s, e.lanes = s, e.memoizedState = d
    }
}

function jf(e, t, n) {
    if (e = t.effects, t.effects = null, e !== null)
        for (t = 0; t < e.length; t++) {
            var r = e[t],
                i = r.callback;
            if (i !== null) {
                if (r.callback = null, r = n, typeof i != "function") throw Error(L(191, i));
                i.call(r)
            }
        }
}
var Mo = {},
    $t = Wn(Mo),
    ho = Wn(Mo),
    po = Wn(Mo);

function cr(e) {
    if (e === Mo) throw Error(L(174));
    return e
}

function Cc(e, t) {
    switch (ae(po, t), ae(ho, e), ae($t, Mo), e = t.nodeType, e) {
        case 9:
        case 11:
            t = (t = t.documentElement) ? t.namespaceURI : $l(null, "");
            break;
        default:
            e = e === 8 ? t.parentNode : t, t = e.namespaceURI || null, e = e.tagName, t = $l(t, e)
    }
    fe($t), ae($t, t)
}

function si() {
    fe($t), fe(ho), fe(po)
}

function ng(e) {
    cr(po.current);
    var t = cr($t.current),
        n = $l(t, e.type);
    t !== n && (ae(ho, e), ae($t, n))
}

function kc(e) {
    ho.current === e && (fe($t), fe(ho))
}
var ye = Wn(0);

function Qs(e) {
    for (var t = e; t !== null;) {
        if (t.tag === 13) {
            var n = t.memoizedState;
            if (n !== null && (n = n.dehydrated, n === null || n.data === "$?" || n.data === "$!")) return t
        } else if (t.tag === 19 && t.memoizedProps.revealOrder !== void 0) {
            if (t.flags & 128) return t
        } else if (t.child !== null) {
            t.child.return = t, t = t.child;
            continue
        }
        if (t === e) break;
        for (; t.sibling === null;) {
            if (t.return === null || t.return === e) return null;
            t = t.return
        }
        t.sibling.return = t.return, t = t.sibling
    }
    return null
}
var ul = [];

function Rc() {
    for (var e = 0; e < ul.length; e++) ul[e]._workInProgressVersionPrimary = null;
    ul.length = 0
}
var Ss = vn.ReactCurrentDispatcher,
    cl = vn.ReactCurrentBatchConfig,
    xr = 0,
    we = null,
    Me = null,
    _e = null,
    Xs = !1,
    Yi = !1,
    mo = 0,
    fx = 0;

function Be() {
    throw Error(L(321))
}

function jc(e, t) {
    if (t === null) return !1;
    for (var n = 0; n < t.length && n < e.length; n++)
        if (!zt(e[n], t[n])) return !1;
    return !0
}

function Ac(e, t, n, r, i, o) {
    if (xr = o, we = t, t.memoizedState = null, t.updateQueue = null, t.lanes = 0, Ss.current = e === null || e.memoizedState === null ? gx : vx, e = n(r, i), Yi) {
        o = 0;
        do {
            if (Yi = !1, mo = 0, 25 <= o) throw Error(L(301));
            o += 1, _e = Me = null, t.updateQueue = null, Ss.current = yx, e = n(r, i)
        } while (Yi)
    }
    if (Ss.current = Zs, t = Me !== null && Me.next !== null, xr = 0, _e = Me = we = null, Xs = !1, t) throw Error(L(300));
    return e
}

function Lc() {
    var e = mo !== 0;
    return mo = 0, e
}

function Bt() {
    var e = {
        memoizedState: null,
        baseState: null,
        baseQueue: null,
        queue: null,
        next: null
    };
    return _e === null ? we.memoizedState = _e = e : _e = _e.next = e, _e
}

function jt() {
    if (Me === null) {
        var e = we.alternate;
        e = e !== null ? e.memoizedState : null
    } else e = Me.next;
    var t = _e === null ? we.memoizedState : _e.next;
    if (t !== null) _e = t, Me = e;
    else {
        if (e === null) throw Error(L(310));
        Me = e, e = {
            memoizedState: Me.memoizedState,
            baseState: Me.baseState,
            baseQueue: Me.baseQueue,
            queue: Me.queue,
            next: null
        }, _e === null ? we.memoizedState = _e = e : _e = _e.next = e
    }
    return _e
}

function go(e, t) {
    return typeof t == "function" ? t(e) : t
}

function dl(e) {
    var t = jt(),
        n = t.queue;
    if (n === null) throw Error(L(311));
    n.lastRenderedReducer = e;
    var r = Me,
        i = r.baseQueue,
        o = n.pending;
    if (o !== null) {
        if (i !== null) {
            var s = i.next;
            i.next = o.next, o.next = s
        }
        r.baseQueue = i = o, n.pending = null
    }
    if (i !== null) {
        o = i.next, r = r.baseState;
        var a = s = null,
            l = null,
            u = o;
        do {
            var c = u.lane;
            if ((xr & c) === c) l !== null && (l = l.next = {
                lane: 0,
                action: u.action,
                hasEagerState: u.hasEagerState,
                eagerState: u.eagerState,
                next: null
            }), r = u.hasEagerState ? u.eagerState : e(r, u.action);
            else {
                var d = {
                    lane: c,
                    action: u.action,
                    hasEagerState: u.hasEagerState,
                    eagerState: u.eagerState,
                    next: null
                };
                l === null ? (a = l = d, s = r) : l = l.next = d, we.lanes |= c, wr |= c
            }
            u = u.next
        } while (u !== null && u !== o);
        l === null ? s = r : l.next = a, zt(r, t.memoizedState) || (ot = !0), t.memoizedState = r, t.baseState = s, t.baseQueue = l, n.lastRenderedState = r
    }
    if (e = n.interleaved, e !== null) {
        i = e;
        do o = i.lane, we.lanes |= o, wr |= o, i = i.next; while (i !== e)
    } else i === null && (n.lanes = 0);
    return [t.memoizedState, n.dispatch]
}

function fl(e) {
    var t = jt(),
        n = t.queue;
    if (n === null) throw Error(L(311));
    n.lastRenderedReducer = e;
    var r = n.dispatch,
        i = n.pending,
        o = t.memoizedState;
    if (i !== null) {
        n.pending = null;
        var s = i = i.next;
        do o = e(o, s.action), s = s.next; while (s !== i);
        zt(o, t.memoizedState) || (ot = !0), t.memoizedState = o, t.baseQueue === null && (t.baseState = o), n.lastRenderedState = o
    }
    return [o, r]
}

function rg() {}

function ig(e, t) {
    var n = we,
        r = jt(),
        i = t(),
        o = !zt(r.memoizedState, i);
    if (o && (r.memoizedState = i, ot = !0), r = r.queue, Mc(ag.bind(null, n, r, e), [e]), r.getSnapshot !== t || o || _e !== null && _e.memoizedState.tag & 1) {
        if (n.flags |= 2048, vo(9, sg.bind(null, n, r, i, t), void 0, null), Oe === null) throw Error(L(349));
        xr & 30 || og(n, t, i)
    }
    return i
}

function og(e, t, n) {
    e.flags |= 16384, e = {
        getSnapshot: t,
        value: n
    }, t = we.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, we.updateQueue = t, t.stores = [e]) : (n = t.stores, n === null ? t.stores = [e] : n.push(e))
}

function sg(e, t, n, r) {
    t.value = n, t.getSnapshot = r, lg(t) && ug(e)
}

function ag(e, t, n) {
    return n(function() {
        lg(t) && ug(e)
    })
}

function lg(e) {
    var t = e.getSnapshot;
    e = e.value;
    try {
        var n = t();
        return !zt(e, n)
    } catch {
        return !0
    }
}

function ug(e) {
    var t = pn(e, 1);
    t !== null && It(t, e, 1, -1)
}

function Af(e) {
    var t = Bt();
    return typeof e == "function" && (e = e()), t.memoizedState = t.baseState = e, e = {
        pending: null,
        interleaved: null,
        lanes: 0,
        dispatch: null,
        lastRenderedReducer: go,
        lastRenderedState: e
    }, t.queue = e, e = e.dispatch = mx.bind(null, we, e), [t.memoizedState, e]
}

function vo(e, t, n, r) {
    return e = {
        tag: e,
        create: t,
        destroy: n,
        deps: r,
        next: null
    }, t = we.updateQueue, t === null ? (t = {
        lastEffect: null,
        stores: null
    }, we.updateQueue = t, t.lastEffect = e.next = e) : (n = t.lastEffect, n === null ? t.lastEffect = e.next = e : (r = n.next, n.next = e, e.next = r, t.lastEffect = e)), e
}

function cg() {
    return jt().memoizedState
}

function Ts(e, t, n, r) {
    var i = Bt();
    we.flags |= e, i.memoizedState = vo(1 | t, n, void 0, r === void 0 ? null : r)
}

function Ea(e, t, n, r) {
    var i = jt();
    r = r === void 0 ? null : r;
    var o = void 0;
    if (Me !== null) {
        var s = Me.memoizedState;
        if (o = s.destroy, r !== null && jc(r, s.deps)) {
            i.memoizedState = vo(t, n, o, r);
            return
        }
    }
    we.flags |= e, i.memoizedState = vo(1 | t, n, o, r)
}

function Lf(e, t) {
    return Ts(8390656, 8, e, t)
}

function Mc(e, t) {
    return Ea(2048, 8, e, t)
}

function dg(e, t) {
    return Ea(4, 2, e, t)
}

function fg(e, t) {
    return Ea(4, 4, e, t)
}

function hg(e, t) {
    if (typeof t == "function") return e = e(), t(e),
        function() {
            t(null)
        };
    if (t != null) return e = e(), t.current = e,
        function() {
            t.current = null
        }
}

function pg(e, t, n) {
    return n = n != null ? n.concat([e]) : null, Ea(4, 4, hg.bind(null, t, e), n)
}

function Nc() {}

function mg(e, t) {
    var n = jt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && jc(t, r[1]) ? r[0] : (n.memoizedState = [e, t], e)
}

function gg(e, t) {
    var n = jt();
    t = t === void 0 ? null : t;
    var r = n.memoizedState;
    return r !== null && t !== null && jc(t, r[1]) ? r[0] : (e = e(), n.memoizedState = [e, t], e)
}

function vg(e, t, n) {
    return xr & 21 ? (zt(n, t) || (n = Tm(), we.lanes |= n, wr |= n, e.baseState = !0), t) : (e.baseState && (e.baseState = !1, ot = !0), e.memoizedState = n)
}

function hx(e, t) {
    var n = re;
    re = n !== 0 && 4 > n ? n : 4, e(!0);
    var r = cl.transition;
    cl.transition = {};
    try {
        e(!1), t()
    } finally {
        re = n, cl.transition = r
    }
}

function yg() {
    return jt().memoizedState
}

function px(e, t, n) {
    var r = Fn(e);
    if (n = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        }, xg(e)) wg(t, n);
    else if (n = eg(e, t, n, r), n !== null) {
        var i = Ze();
        It(n, e, r, i), Sg(n, t, r)
    }
}

function mx(e, t, n) {
    var r = Fn(e),
        i = {
            lane: r,
            action: n,
            hasEagerState: !1,
            eagerState: null,
            next: null
        };
    if (xg(e)) wg(t, i);
    else {
        var o = e.alternate;
        if (e.lanes === 0 && (o === null || o.lanes === 0) && (o = t.lastRenderedReducer, o !== null)) try {
            var s = t.lastRenderedState,
                a = o(s, n);
            if (i.hasEagerState = !0, i.eagerState = a, zt(a, s)) {
                var l = t.interleaved;
                l === null ? (i.next = i, Pc(t)) : (i.next = l.next, l.next = i), t.interleaved = i;
                return
            }
        } catch {} finally {}
        n = eg(e, t, i, r), n !== null && (i = Ze(), It(n, e, r, i), Sg(n, t, r))
    }
}

function xg(e) {
    var t = e.alternate;
    return e === we || t !== null && t === we
}

function wg(e, t) {
    Yi = Xs = !0;
    var n = e.pending;
    n === null ? t.next = t : (t.next = n.next, n.next = t), e.pending = t
}

function Sg(e, t, n) {
    if (n & 4194240) {
        var r = t.lanes;
        r &= e.pendingLanes, n |= r, t.lanes = n, uc(e, n)
    }
}
var Zs = {
        readContext: Rt,
        useCallback: Be,
        useContext: Be,
        useEffect: Be,
        useImperativeHandle: Be,
        useInsertionEffect: Be,
        useLayoutEffect: Be,
        useMemo: Be,
        useReducer: Be,
        useRef: Be,
        useState: Be,
        useDebugValue: Be,
        useDeferredValue: Be,
        useTransition: Be,
        useMutableSource: Be,
        useSyncExternalStore: Be,
        useId: Be,
        unstable_isNewReconciler: !1
    },
    gx = {
        readContext: Rt,
        useCallback: function(e, t) {
            return Bt().memoizedState = [e, t === void 0 ? null : t], e
        },
        useContext: Rt,
        useEffect: Lf,
        useImperativeHandle: function(e, t, n) {
            return n = n != null ? n.concat([e]) : null, Ts(4194308, 4, hg.bind(null, t, e), n)
        },
        useLayoutEffect: function(e, t) {
            return Ts(4194308, 4, e, t)
        },
        useInsertionEffect: function(e, t) {
            return Ts(4, 2, e, t)
        },
        useMemo: function(e, t) {
            var n = Bt();
            return t = t === void 0 ? null : t, e = e(), n.memoizedState = [e, t], e
        },
        useReducer: function(e, t, n) {
            var r = Bt();
            return t = n !== void 0 ? n(t) : t, r.memoizedState = r.baseState = t, e = {
                pending: null,
                interleaved: null,
                lanes: 0,
                dispatch: null,
                lastRenderedReducer: e,
                lastRenderedState: t
            }, r.queue = e, e = e.dispatch = px.bind(null, we, e), [r.memoizedState, e]
        },
        useRef: function(e) {
            var t = Bt();
            return e = {
                current: e
            }, t.memoizedState = e
        },
        useState: Af,
        useDebugValue: Nc,
        useDeferredValue: function(e) {
            return Bt().memoizedState = e
        },
        useTransition: function() {
            var e = Af(!1),
                t = e[0];
            return e = hx.bind(null, e[1]), Bt().memoizedState = e, [t, e]
        },
        useMutableSource: function() {},
        useSyncExternalStore: function(e, t, n) {
            var r = we,
                i = Bt();
            if (ge) {
                if (n === void 0) throw Error(L(407));
                n = n()
            } else {
                if (n = t(), Oe === null) throw Error(L(349));
                xr & 30 || og(r, t, n)
            }
            i.memoizedState = n;
            var o = {
                value: n,
                getSnapshot: t
            };
            return i.queue = o, Lf(ag.bind(null, r, o, e), [e]), r.flags |= 2048, vo(9, sg.bind(null, r, o, n, t), void 0, null), n
        },
        useId: function() {
            var e = Bt(),
                t = Oe.identifierPrefix;
            if (ge) {
                var n = nn,
                    r = tn;
                n = (r & ~(1 << 32 - Ft(r) - 1)).toString(32) + n, t = ":" + t + "R" + n, n = mo++, 0 < n && (t += "H" + n.toString(32)), t += ":"
            } else n = fx++, t = ":" + t + "r" + n.toString(32) + ":";
            return e.memoizedState = t
        },
        unstable_isNewReconciler: !1
    },
    vx = {
        readContext: Rt,
        useCallback: mg,
        useContext: Rt,
        useEffect: Mc,
        useImperativeHandle: pg,
        useInsertionEffect: dg,
        useLayoutEffect: fg,
        useMemo: gg,
        useReducer: dl,
        useRef: cg,
        useState: function() {
            return dl(go)
        },
        useDebugValue: Nc,
        useDeferredValue: function(e) {
            var t = jt();
            return vg(t, Me.memoizedState, e)
        },
        useTransition: function() {
            var e = dl(go)[0],
                t = jt().memoizedState;
            return [e, t]
        },
        useMutableSource: rg,
        useSyncExternalStore: ig,
        useId: yg,
        unstable_isNewReconciler: !1
    },
    yx = {
        readContext: Rt,
        useCallback: mg,
        useContext: Rt,
        useEffect: Mc,
        useImperativeHandle: pg,
        useInsertionEffect: dg,
        useLayoutEffect: fg,
        useMemo: gg,
        useReducer: fl,
        useRef: cg,
        useState: function() {
            return fl(go)
        },
        useDebugValue: Nc,
        useDeferredValue: function(e) {
            var t = jt();
            return Me === null ? t.memoizedState = e : vg(t, Me.memoizedState, e)
        },
        useTransition: function() {
            var e = fl(go)[0],
                t = jt().memoizedState;
            return [e, t]
        },
        useMutableSource: rg,
        useSyncExternalStore: ig,
        useId: yg,
        unstable_isNewReconciler: !1
    };

function Mt(e, t) {
    if (e && e.defaultProps) {
        t = Se({}, t), e = e.defaultProps;
        for (var n in e) t[n] === void 0 && (t[n] = e[n]);
        return t
    }
    return t
}

function du(e, t, n, r) {
    t = e.memoizedState, n = n(r, t), n = n == null ? t : Se({}, t, n), e.memoizedState = n, e.lanes === 0 && (e.updateQueue.baseState = n)
}
var Ca = {
    isMounted: function(e) {
        return (e = e._reactInternals) ? Er(e) === e : !1
    },
    enqueueSetState: function(e, t, n) {
        e = e._reactInternals;
        var r = Ze(),
            i = Fn(e),
            o = sn(r, i);
        o.payload = t, n != null && (o.callback = n), t = On(e, o, i), t !== null && (It(t, e, i, r), ws(t, e, i))
    },
    enqueueReplaceState: function(e, t, n) {
        e = e._reactInternals;
        var r = Ze(),
            i = Fn(e),
            o = sn(r, i);
        o.tag = 1, o.payload = t, n != null && (o.callback = n), t = On(e, o, i), t !== null && (It(t, e, i, r), ws(t, e, i))
    },
    enqueueForceUpdate: function(e, t) {
        e = e._reactInternals;
        var n = Ze(),
            r = Fn(e),
            i = sn(n, r);
        i.tag = 2, t != null && (i.callback = t), t = On(e, i, r), t !== null && (It(t, e, r, n), ws(t, e, r))
    }
};

function Mf(e, t, n, r, i, o, s) {
    return e = e.stateNode, typeof e.shouldComponentUpdate == "function" ? e.shouldComponentUpdate(r, o, s) : t.prototype && t.prototype.isPureReactComponent ? !lo(n, r) || !lo(i, o) : !0
}

function Tg(e, t, n) {
    var r = !1,
        i = bn,
        o = t.contextType;
    return typeof o == "object" && o !== null ? o = Rt(o) : (i = at(t) ? vr : Ge.current, r = t.contextTypes, o = (r = r != null) ? ri(e, i) : bn), t = new t(n, o), e.memoizedState = t.state !== null && t.state !== void 0 ? t.state : null, t.updater = Ca, e.stateNode = t, t._reactInternals = e, r && (e = e.stateNode, e.__reactInternalMemoizedUnmaskedChildContext = i, e.__reactInternalMemoizedMaskedChildContext = o), t
}

function Nf(e, t, n, r) {
    e = t.state, typeof t.componentWillReceiveProps == "function" && t.componentWillReceiveProps(n, r), typeof t.UNSAFE_componentWillReceiveProps == "function" && t.UNSAFE_componentWillReceiveProps(n, r), t.state !== e && Ca.enqueueReplaceState(t, t.state, null)
}

function fu(e, t, n, r) {
    var i = e.stateNode;
    i.props = n, i.state = e.memoizedState, i.refs = {}, Ec(e);
    var o = t.contextType;
    typeof o == "object" && o !== null ? i.context = Rt(o) : (o = at(t) ? vr : Ge.current, i.context = ri(e, o)), i.state = e.memoizedState, o = t.getDerivedStateFromProps, typeof o == "function" && (du(e, t, o, n), i.state = e.memoizedState), typeof t.getDerivedStateFromProps == "function" || typeof i.getSnapshotBeforeUpdate == "function" || typeof i.UNSAFE_componentWillMount != "function" && typeof i.componentWillMount != "function" || (t = i.state, typeof i.componentWillMount == "function" && i.componentWillMount(), typeof i.UNSAFE_componentWillMount == "function" && i.UNSAFE_componentWillMount(), t !== i.state && Ca.enqueueReplaceState(i, i.state, null), Ys(e, n, i, r), i.state = e.memoizedState), typeof i.componentDidMount == "function" && (e.flags |= 4194308)
}

function ai(e, t) {
    try {
        var n = "",
            r = t;
        do n += Ky(r), r = r.return; while (r);
        var i = n
    } catch (o) {
        i = `
Error generating stack: ` + o.message + `
` + o.stack
    }
    return {
        value: e,
        source: t,
        stack: i,
        digest: null
    }
}

function hl(e, t, n) {
    return {
        value: e,
        source: null,
        stack: n ? ? null,
        digest: t ? ? null
    }
}

function hu(e, t) {
    try {
        console.error(t.value)
    } catch (n) {
        setTimeout(function() {
            throw n
        })
    }
}
var xx = typeof WeakMap == "function" ? WeakMap : Map;

function Pg(e, t, n) {
    n = sn(-1, n), n.tag = 3, n.payload = {
        element: null
    };
    var r = t.value;
    return n.callback = function() {
        qs || (qs = !0, Pu = r), hu(e, t)
    }, n
}

function Eg(e, t, n) {
    n = sn(-1, n), n.tag = 3;
    var r = e.type.getDerivedStateFromError;
    if (typeof r == "function") {
        var i = t.value;
        n.payload = function() {
            return r(i)
        }, n.callback = function() {
            hu(e, t)
        }
    }
    var o = e.stateNode;
    return o !== null && typeof o.componentDidCatch == "function" && (n.callback = function() {
        hu(e, t), typeof r != "function" && (Vn === null ? Vn = new Set([this]) : Vn.add(this));
        var s = t.stack;
        this.componentDidCatch(t.value, {
            componentStack: s !== null ? s : ""
        })
    }), n
}

function Df(e, t, n) {
    var r = e.pingCache;
    if (r === null) {
        r = e.pingCache = new xx;
        var i = new Set;
        r.set(t, i)
    } else i = r.get(t), i === void 0 && (i = new Set, r.set(t, i));
    i.has(n) || (i.add(n), e = Dx.bind(null, e, t, n), t.then(e, e))
}

function _f(e) {
    do {
        var t;
        if ((t = e.tag === 13) && (t = e.memoizedState, t = t !== null ? t.dehydrated !== null : !0), t) return e;
        e = e.return
    } while (e !== null);
    return null
}

function Of(e, t, n, r, i) {
    return e.mode & 1 ? (e.flags |= 65536, e.lanes = i, e) : (e === t ? e.flags |= 65536 : (e.flags |= 128, n.flags |= 131072, n.flags &= -52805, n.tag === 1 && (n.alternate === null ? n.tag = 17 : (t = sn(-1, 1), t.tag = 2, On(n, t, 1))), n.lanes |= 1), e)
}
var wx = vn.ReactCurrentOwner,
    ot = !1;

function Xe(e, t, n, r) {
    t.child = e === null ? qm(t, null, n, r) : oi(t, e.child, n, r)
}

function Vf(e, t, n, r, i) {
    n = n.render;
    var o = t.ref;
    return Jr(t, i), r = Ac(e, t, n, r, o, i), n = Lc(), e !== null && !ot ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, mn(e, t, i)) : (ge && n && vc(t), t.flags |= 1, Xe(e, t, r, i), t.child)
}

function Ff(e, t, n, r, i) {
    if (e === null) {
        var o = n.type;
        return typeof o == "function" && !bc(o) && o.defaultProps === void 0 && n.compare === null && n.defaultProps === void 0 ? (t.tag = 15, t.type = o, Cg(e, t, o, r, i)) : (e = ks(n.type, null, r, t, t.mode, i), e.ref = t.ref, e.return = t, t.child = e)
    }
    if (o = e.child, !(e.lanes & i)) {
        var s = o.memoizedProps;
        if (n = n.compare, n = n !== null ? n : lo, n(s, r) && e.ref === t.ref) return mn(e, t, i)
    }
    return t.flags |= 1, e = In(o, r), e.ref = t.ref, e.return = t, t.child = e
}

function Cg(e, t, n, r, i) {
    if (e !== null) {
        var o = e.memoizedProps;
        if (lo(o, r) && e.ref === t.ref)
            if (ot = !1, t.pendingProps = r = o, (e.lanes & i) !== 0) e.flags & 131072 && (ot = !0);
            else return t.lanes = e.lanes, mn(e, t, i)
    }
    return pu(e, t, n, r, i)
}

function kg(e, t, n) {
    var r = t.pendingProps,
        i = r.children,
        o = e !== null ? e.memoizedState : null;
    if (r.mode === "hidden")
        if (!(t.mode & 1)) t.memoizedState = {
            baseLanes: 0,
            cachePool: null,
            transitions: null
        }, ae(Br, ct), ct |= n;
        else {
            if (!(n & 1073741824)) return e = o !== null ? o.baseLanes | n : n, t.lanes = t.childLanes = 1073741824, t.memoizedState = {
                baseLanes: e,
                cachePool: null,
                transitions: null
            }, t.updateQueue = null, ae(Br, ct), ct |= e, null;
            t.memoizedState = {
                baseLanes: 0,
                cachePool: null,
                transitions: null
            }, r = o !== null ? o.baseLanes : n, ae(Br, ct), ct |= r
        }
    else o !== null ? (r = o.baseLanes | n, t.memoizedState = null) : r = n, ae(Br, ct), ct |= r;
    return Xe(e, t, i, n), t.child
}

function Rg(e, t) {
    var n = t.ref;
    (e === null && n !== null || e !== null && e.ref !== n) && (t.flags |= 512, t.flags |= 2097152)
}

function pu(e, t, n, r, i) {
    var o = at(n) ? vr : Ge.current;
    return o = ri(t, o), Jr(t, i), n = Ac(e, t, n, r, o, i), r = Lc(), e !== null && !ot ? (t.updateQueue = e.updateQueue, t.flags &= -2053, e.lanes &= ~i, mn(e, t, i)) : (ge && r && vc(t), t.flags |= 1, Xe(e, t, n, i), t.child)
}

function If(e, t, n, r, i) {
    if (at(n)) {
        var o = !0;
        Hs(t)
    } else o = !1;
    if (Jr(t, i), t.stateNode === null) Ps(e, t), Tg(t, n, r), fu(t, n, r, i), r = !0;
    else if (e === null) {
        var s = t.stateNode,
            a = t.memoizedProps;
        s.props = a;
        var l = s.context,
            u = n.contextType;
        typeof u == "object" && u !== null ? u = Rt(u) : (u = at(n) ? vr : Ge.current, u = ri(t, u));
        var c = n.getDerivedStateFromProps,
            d = typeof c == "function" || typeof s.getSnapshotBeforeUpdate == "function";
        d || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (a !== r || l !== u) && Nf(t, s, r, u), Cn = !1;
        var f = t.memoizedState;
        s.state = f, Ys(t, r, s, i), l = t.memoizedState, a !== r || f !== l || st.current || Cn ? (typeof c == "function" && (du(t, n, c, r), l = t.memoizedState), (a = Cn || Mf(t, n, a, r, f, l, u)) ? (d || typeof s.UNSAFE_componentWillMount != "function" && typeof s.componentWillMount != "function" || (typeof s.componentWillMount == "function" && s.componentWillMount(), typeof s.UNSAFE_componentWillMount == "function" && s.UNSAFE_componentWillMount()), typeof s.componentDidMount == "function" && (t.flags |= 4194308)) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), t.memoizedProps = r, t.memoizedState = l), s.props = r, s.state = l, s.context = u, r = a) : (typeof s.componentDidMount == "function" && (t.flags |= 4194308), r = !1)
    } else {
        s = t.stateNode, tg(e, t), a = t.memoizedProps, u = t.type === t.elementType ? a : Mt(t.type, a), s.props = u, d = t.pendingProps, f = s.context, l = n.contextType, typeof l == "object" && l !== null ? l = Rt(l) : (l = at(n) ? vr : Ge.current, l = ri(t, l));
        var m = n.getDerivedStateFromProps;
        (c = typeof m == "function" || typeof s.getSnapshotBeforeUpdate == "function") || typeof s.UNSAFE_componentWillReceiveProps != "function" && typeof s.componentWillReceiveProps != "function" || (a !== d || f !== l) && Nf(t, s, r, l), Cn = !1, f = t.memoizedState, s.state = f, Ys(t, r, s, i);
        var x = t.memoizedState;
        a !== d || f !== x || st.current || Cn ? (typeof m == "function" && (du(t, n, m, r), x = t.memoizedState), (u = Cn || Mf(t, n, u, r, f, x, l) || !1) ? (c || typeof s.UNSAFE_componentWillUpdate != "function" && typeof s.componentWillUpdate != "function" || (typeof s.componentWillUpdate == "function" && s.componentWillUpdate(r, x, l), typeof s.UNSAFE_componentWillUpdate == "function" && s.UNSAFE_componentWillUpdate(r, x, l)), typeof s.componentDidUpdate == "function" && (t.flags |= 4), typeof s.getSnapshotBeforeUpdate == "function" && (t.flags |= 1024)) : (typeof s.componentDidUpdate != "function" || a === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || a === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), t.memoizedProps = r, t.memoizedState = x), s.props = r, s.state = x, s.context = l, r = u) : (typeof s.componentDidUpdate != "function" || a === e.memoizedProps && f === e.memoizedState || (t.flags |= 4), typeof s.getSnapshotBeforeUpdate != "function" || a === e.memoizedProps && f === e.memoizedState || (t.flags |= 1024), r = !1)
    }
    return mu(e, t, n, r, o, i)
}

function mu(e, t, n, r, i, o) {
    Rg(e, t);
    var s = (t.flags & 128) !== 0;
    if (!r && !s) return i && Pf(t, n, !1), mn(e, t, o);
    r = t.stateNode, wx.current = t;
    var a = s && typeof n.getDerivedStateFromError != "function" ? null : r.render();
    return t.flags |= 1, e !== null && s ? (t.child = oi(t, e.child, null, o), t.child = oi(t, null, a, o)) : Xe(e, t, a, o), t.memoizedState = r.state, i && Pf(t, n, !0), t.child
}

function jg(e) {
    var t = e.stateNode;
    t.pendingContext ? Tf(e, t.pendingContext, t.pendingContext !== t.context) : t.context && Tf(e, t.context, !1), Cc(e, t.containerInfo)
}

function zf(e, t, n, r, i) {
    return ii(), xc(i), t.flags |= 256, Xe(e, t, n, r), t.child
}
var gu = {
    dehydrated: null,
    treeContext: null,
    retryLane: 0
};

function vu(e) {
    return {
        baseLanes: e,
        cachePool: null,
        transitions: null
    }
}

function Ag(e, t, n) {
    var r = t.pendingProps,
        i = ye.current,
        o = !1,
        s = (t.flags & 128) !== 0,
        a;
    if ((a = s) || (a = e !== null && e.memoizedState === null ? !1 : (i & 2) !== 0), a ? (o = !0, t.flags &= -129) : (e === null || e.memoizedState !== null) && (i |= 1), ae(ye, i & 1), e === null) return uu(t), e = t.memoizedState, e !== null && (e = e.dehydrated, e !== null) ? (t.mode & 1 ? e.data === "$!" ? t.lanes = 8 : t.lanes = 1073741824 : t.lanes = 1, null) : (s = r.children, e = r.fallback, o ? (r = t.mode, o = t.child, s = {
        mode: "hidden",
        children: s
    }, !(r & 1) && o !== null ? (o.childLanes = 0, o.pendingProps = s) : o = ja(s, r, 0, null), e = pr(e, r, n, null), o.return = t, e.return = t, o.sibling = e, t.child = o, t.child.memoizedState = vu(n), t.memoizedState = gu, e) : Dc(t, s));
    if (i = e.memoizedState, i !== null && (a = i.dehydrated, a !== null)) return Sx(e, t, s, r, a, i, n);
    if (o) {
        o = r.fallback, s = t.mode, i = e.child, a = i.sibling;
        var l = {
            mode: "hidden",
            children: r.children
        };
        return !(s & 1) && t.child !== i ? (r = t.child, r.childLanes = 0, r.pendingProps = l, t.deletions = null) : (r = In(i, l), r.subtreeFlags = i.subtreeFlags & 14680064), a !== null ? o = In(a, o) : (o = pr(o, s, n, null), o.flags |= 2), o.return = t, r.return = t, r.sibling = o, t.child = r, r = o, o = t.child, s = e.child.memoizedState, s = s === null ? vu(n) : {
            baseLanes: s.baseLanes | n,
            cachePool: null,
            transitions: s.transitions
        }, o.memoizedState = s, o.childLanes = e.childLanes & ~n, t.memoizedState = gu, r
    }
    return o = e.child, e = o.sibling, r = In(o, {
        mode: "visible",
        children: r.children
    }), !(t.mode & 1) && (r.lanes = n), r.return = t, r.sibling = null, e !== null && (n = t.deletions, n === null ? (t.deletions = [e], t.flags |= 16) : n.push(e)), t.child = r, t.memoizedState = null, r
}

function Dc(e, t) {
    return t = ja({
        mode: "visible",
        children: t
    }, e.mode, 0, null), t.return = e, e.child = t
}

function as(e, t, n, r) {
    return r !== null && xc(r), oi(t, e.child, null, n), e = Dc(t, t.pendingProps.children), e.flags |= 2, t.memoizedState = null, e
}

function Sx(e, t, n, r, i, o, s) {
    if (n) return t.flags & 256 ? (t.flags &= -257, r = hl(Error(L(422))), as(e, t, s, r)) : t.memoizedState !== null ? (t.child = e.child, t.flags |= 128, null) : (o = r.fallback, i = t.mode, r = ja({
        mode: "visible",
        children: r.children
    }, i, 0, null), o = pr(o, i, s, null), o.flags |= 2, r.return = t, o.return = t, r.sibling = o, t.child = r, t.mode & 1 && oi(t, e.child, null, s), t.child.memoizedState = vu(s), t.memoizedState = gu, o);
    if (!(t.mode & 1)) return as(e, t, s, null);
    if (i.data === "$!") {
        if (r = i.nextSibling && i.nextSibling.dataset, r) var a = r.dgst;
        return r = a, o = Error(L(419)), r = hl(o, r, void 0), as(e, t, s, r)
    }
    if (a = (s & e.childLanes) !== 0, ot || a) {
        if (r = Oe, r !== null) {
            switch (s & -s) {
                case 4:
                    i = 2;
                    break;
                case 16:
                    i = 8;
                    break;
                case 64:
                case 128:
                case 256:
                case 512:
                case 1024:
                case 2048:
                case 4096:
                case 8192:
                case 16384:
                case 32768:
                case 65536:
                case 131072:
                case 262144:
                case 524288:
                case 1048576:
                case 2097152:
                case 4194304:
                case 8388608:
                case 16777216:
                case 33554432:
                case 67108864:
                    i = 32;
                    break;
                case 536870912:
                    i = 268435456;
                    break;
                default:
                    i = 0
            }
            i = i & (r.suspendedLanes | s) ? 0 : i, i !== 0 && i !== o.retryLane && (o.retryLane = i, pn(e, i), It(r, e, i, -1))
        }
        return zc(), r = hl(Error(L(421))), as(e, t, s, r)
    }
    return i.data === "$?" ? (t.flags |= 128, t.child = e.child, t = _x.bind(null, e), i._reactRetry = t, null) : (e = o.treeContext, ft = _n(i.nextSibling), pt = t, ge = !0, _t = null, e !== null && (Pt[Et++] = tn, Pt[Et++] = nn, Pt[Et++] = yr, tn = e.id, nn = e.overflow, yr = t), t = Dc(t, r.children), t.flags |= 4096, t)
}

function bf(e, t, n) {
    e.lanes |= t;
    var r = e.alternate;
    r !== null && (r.lanes |= t), cu(e.return, t, n)
}

function pl(e, t, n, r, i) {
    var o = e.memoizedState;
    o === null ? e.memoizedState = {
        isBackwards: t,
        rendering: null,
        renderingStartTime: 0,
        last: r,
        tail: n,
        tailMode: i
    } : (o.isBackwards = t, o.rendering = null, o.renderingStartTime = 0, o.last = r, o.tail = n, o.tailMode = i)
}

function Lg(e, t, n) {
    var r = t.pendingProps,
        i = r.revealOrder,
        o = r.tail;
    if (Xe(e, t, r.children, n), r = ye.current, r & 2) r = r & 1 | 2, t.flags |= 128;
    else {
        if (e !== null && e.flags & 128) e: for (e = t.child; e !== null;) {
            if (e.tag === 13) e.memoizedState !== null && bf(e, n, t);
            else if (e.tag === 19) bf(e, n, t);
            else if (e.child !== null) {
                e.child.return = e, e = e.child;
                continue
            }
            if (e === t) break e;
            for (; e.sibling === null;) {
                if (e.return === null || e.return === t) break e;
                e = e.return
            }
            e.sibling.return = e.return, e = e.sibling
        }
        r &= 1
    }
    if (ae(ye, r), !(t.mode & 1)) t.memoizedState = null;
    else switch (i) {
        case "forwards":
            for (n = t.child, i = null; n !== null;) e = n.alternate, e !== null && Qs(e) === null && (i = n), n = n.sibling;
            n = i, n === null ? (i = t.child, t.child = null) : (i = n.sibling, n.sibling = null), pl(t, !1, i, n, o);
            break;
        case "backwards":
            for (n = null, i = t.child, t.child = null; i !== null;) {
                if (e = i.alternate, e !== null && Qs(e) === null) {
                    t.child = i;
                    break
                }
                e = i.sibling, i.sibling = n, n = i, i = e
            }
            pl(t, !0, n, null, o);
            break;
        case "together":
            pl(t, !1, null, null, void 0);
            break;
        default:
            t.memoizedState = null
    }
    return t.child
}

function Ps(e, t) {
    !(t.mode & 1) && e !== null && (e.alternate = null, t.alternate = null, t.flags |= 2)
}

function mn(e, t, n) {
    if (e !== null && (t.dependencies = e.dependencies), wr |= t.lanes, !(n & t.childLanes)) return null;
    if (e !== null && t.child !== e.child) throw Error(L(153));
    if (t.child !== null) {
        for (e = t.child, n = In(e, e.pendingProps), t.child = n, n.return = t; e.sibling !== null;) e = e.sibling, n = n.sibling = In(e, e.pendingProps), n.return = t;
        n.sibling = null
    }
    return t.child
}

function Tx(e, t, n) {
    switch (t.tag) {
        case 3:
            jg(t), ii();
            break;
        case 5:
            ng(t);
            break;
        case 1:
            at(t.type) && Hs(t);
            break;
        case 4:
            Cc(t, t.stateNode.containerInfo);
            break;
        case 10:
            var r = t.type._context,
                i = t.memoizedProps.value;
            ae(Ks, r._currentValue), r._currentValue = i;
            break;
        case 13:
            if (r = t.memoizedState, r !== null) return r.dehydrated !== null ? (ae(ye, ye.current & 1), t.flags |= 128, null) : n & t.child.childLanes ? Ag(e, t, n) : (ae(ye, ye.current & 1), e = mn(e, t, n), e !== null ? e.sibling : null);
            ae(ye, ye.current & 1);
            break;
        case 19:
            if (r = (n & t.childLanes) !== 0, e.flags & 128) {
                if (r) return Lg(e, t, n);
                t.flags |= 128
            }
            if (i = t.memoizedState, i !== null && (i.rendering = null, i.tail = null, i.lastEffect = null), ae(ye, ye.current), r) break;
            return null;
        case 22:
        case 23:
            return t.lanes = 0, kg(e, t, n)
    }
    return mn(e, t, n)
}
var Mg, yu, Ng, Dg;
Mg = function(e, t) {
    for (var n = t.child; n !== null;) {
        if (n.tag === 5 || n.tag === 6) e.appendChild(n.stateNode);
        else if (n.tag !== 4 && n.child !== null) {
            n.child.return = n, n = n.child;
            continue
        }
        if (n === t) break;
        for (; n.sibling === null;) {
            if (n.return === null || n.return === t) return;
            n = n.return
        }
        n.sibling.return = n.return, n = n.sibling
    }
};
yu = function() {};
Ng = function(e, t, n, r) {
    var i = e.memoizedProps;
    if (i !== r) {
        e = t.stateNode, cr($t.current);
        var o = null;
        switch (n) {
            case "input":
                i = bl(e, i), r = bl(e, r), o = [];
                break;
            case "select":
                i = Se({}, i, {
                    value: void 0
                }), r = Se({}, r, {
                    value: void 0
                }), o = [];
                break;
            case "textarea":
                i = Hl(e, i), r = Hl(e, r), o = [];
                break;
            default:
                typeof i.onClick != "function" && typeof r.onClick == "function" && (e.onclick = Bs)
        }
        Wl(n, r);
        var s;
        n = null;
        for (u in i)
            if (!r.hasOwnProperty(u) && i.hasOwnProperty(u) && i[u] != null)
                if (u === "style") {
                    var a = i[u];
                    for (s in a) a.hasOwnProperty(s) && (n || (n = {}), n[s] = "")
                } else u !== "dangerouslySetInnerHTML" && u !== "children" && u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && u !== "autoFocus" && (to.hasOwnProperty(u) ? o || (o = []) : (o = o || []).push(u, null));
        for (u in r) {
            var l = r[u];
            if (a = i != null ? i[u] : void 0, r.hasOwnProperty(u) && l !== a && (l != null || a != null))
                if (u === "style")
                    if (a) {
                        for (s in a) !a.hasOwnProperty(s) || l && l.hasOwnProperty(s) || (n || (n = {}), n[s] = "");
                        for (s in l) l.hasOwnProperty(s) && a[s] !== l[s] && (n || (n = {}), n[s] = l[s])
                    } else n || (o || (o = []), o.push(u, n)), n = l;
            else u === "dangerouslySetInnerHTML" ? (l = l ? l.__html : void 0, a = a ? a.__html : void 0, l != null && a !== l && (o = o || []).push(u, l)) : u === "children" ? typeof l != "string" && typeof l != "number" || (o = o || []).push(u, "" + l) : u !== "suppressContentEditableWarning" && u !== "suppressHydrationWarning" && (to.hasOwnProperty(u) ? (l != null && u === "onScroll" && de("scroll", e), o || a === l || (o = [])) : (o = o || []).push(u, l))
        }
        n && (o = o || []).push("style", n);
        var u = o;
        (t.updateQueue = u) && (t.flags |= 4)
    }
};
Dg = function(e, t, n, r) {
    n !== r && (t.flags |= 4)
};

function ji(e, t) {
    if (!ge) switch (e.tailMode) {
        case "hidden":
            t = e.tail;
            for (var n = null; t !== null;) t.alternate !== null && (n = t), t = t.sibling;
            n === null ? e.tail = null : n.sibling = null;
            break;
        case "collapsed":
            n = e.tail;
            for (var r = null; n !== null;) n.alternate !== null && (r = n), n = n.sibling;
            r === null ? t || e.tail === null ? e.tail = null : e.tail.sibling = null : r.sibling = null
    }
}

function Ue(e) {
    var t = e.alternate !== null && e.alternate.child === e.child,
        n = 0,
        r = 0;
    if (t)
        for (var i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags & 14680064, r |= i.flags & 14680064, i.return = e, i = i.sibling;
    else
        for (i = e.child; i !== null;) n |= i.lanes | i.childLanes, r |= i.subtreeFlags, r |= i.flags, i.return = e, i = i.sibling;
    return e.subtreeFlags |= r, e.childLanes = n, t
}

function Px(e, t, n) {
    var r = t.pendingProps;
    switch (yc(t), t.tag) {
        case 2:
        case 16:
        case 15:
        case 0:
        case 11:
        case 7:
        case 8:
        case 12:
        case 9:
        case 14:
            return Ue(t), null;
        case 1:
            return at(t.type) && Us(), Ue(t), null;
        case 3:
            return r = t.stateNode, si(), fe(st), fe(Ge), Rc(), r.pendingContext && (r.context = r.pendingContext, r.pendingContext = null), (e === null || e.child === null) && (os(t) ? t.flags |= 4 : e === null || e.memoizedState.isDehydrated && !(t.flags & 256) || (t.flags |= 1024, _t !== null && (ku(_t), _t = null))), yu(e, t), Ue(t), null;
        case 5:
            kc(t);
            var i = cr(po.current);
            if (n = t.type, e !== null && t.stateNode != null) Ng(e, t, n, r, i), e.ref !== t.ref && (t.flags |= 512, t.flags |= 2097152);
            else {
                if (!r) {
                    if (t.stateNode === null) throw Error(L(166));
                    return Ue(t), null
                }
                if (e = cr($t.current), os(t)) {
                    r = t.stateNode, n = t.type;
                    var o = t.memoizedProps;
                    switch (r[Ut] = t, r[fo] = o, e = (t.mode & 1) !== 0, n) {
                        case "dialog":
                            de("cancel", r), de("close", r);
                            break;
                        case "iframe":
                        case "object":
                        case "embed":
                            de("load", r);
                            break;
                        case "video":
                        case "audio":
                            for (i = 0; i < zi.length; i++) de(zi[i], r);
                            break;
                        case "source":
                            de("error", r);
                            break;
                        case "img":
                        case "image":
                        case "link":
                            de("error", r), de("load", r);
                            break;
                        case "details":
                            de("toggle", r);
                            break;
                        case "input":
                            Yd(r, o), de("invalid", r);
                            break;
                        case "select":
                            r._wrapperState = {
                                wasMultiple: !!o.multiple
                            }, de("invalid", r);
                            break;
                        case "textarea":
                            Xd(r, o), de("invalid", r)
                    }
                    Wl(n, o), i = null;
                    for (var s in o)
                        if (o.hasOwnProperty(s)) {
                            var a = o[s];
                            s === "children" ? typeof a == "string" ? r.textContent !== a && (o.suppressHydrationWarning !== !0 && is(r.textContent, a, e), i = ["children", a]) : typeof a == "number" && r.textContent !== "" + a && (o.suppressHydrationWarning !== !0 && is(r.textContent, a, e), i = ["children", "" + a]) : to.hasOwnProperty(s) && a != null && s === "onScroll" && de("scroll", r)
                        }
                    switch (n) {
                        case "input":
                            Xo(r), Qd(r, o, !0);
                            break;
                        case "textarea":
                            Xo(r), Zd(r);
                            break;
                        case "select":
                        case "option":
                            break;
                        default:
                            typeof o.onClick == "function" && (r.onclick = Bs)
                    }
                    r = i, t.updateQueue = r, r !== null && (t.flags |= 4)
                } else {
                    s = i.nodeType === 9 ? i : i.ownerDocument, e === "http://www.w3.org/1999/xhtml" && (e = am(n)), e === "http://www.w3.org/1999/xhtml" ? n === "script" ? (e = s.createElement("div"), e.innerHTML = "<script><\/script>", e = e.removeChild(e.firstChild)) : typeof r.is == "string" ? e = s.createElement(n, {
                        is: r.is
                    }) : (e = s.createElement(n), n === "select" && (s = e, r.multiple ? s.multiple = !0 : r.size && (s.size = r.size))) : e = s.createElementNS(e, n), e[Ut] = t, e[fo] = r, Mg(e, t, !1, !1), t.stateNode = e;
                    e: {
                        switch (s = Kl(n, r), n) {
                            case "dialog":
                                de("cancel", e), de("close", e), i = r;
                                break;
                            case "iframe":
                            case "object":
                            case "embed":
                                de("load", e), i = r;
                                break;
                            case "video":
                            case "audio":
                                for (i = 0; i < zi.length; i++) de(zi[i], e);
                                i = r;
                                break;
                            case "source":
                                de("error", e), i = r;
                                break;
                            case "img":
                            case "image":
                            case "link":
                                de("error", e), de("load", e), i = r;
                                break;
                            case "details":
                                de("toggle", e), i = r;
                                break;
                            case "input":
                                Yd(e, r), i = bl(e, r), de("invalid", e);
                                break;
                            case "option":
                                i = r;
                                break;
                            case "select":
                                e._wrapperState = {
                                    wasMultiple: !!r.multiple
                                }, i = Se({}, r, {
                                    value: void 0
                                }), de("invalid", e);
                                break;
                            case "textarea":
                                Xd(e, r), i = Hl(e, r), de("invalid", e);
                                break;
                            default:
                                i = r
                        }
                        Wl(n, i),
                        a = i;
                        for (o in a)
                            if (a.hasOwnProperty(o)) {
                                var l = a[o];
                                o === "style" ? cm(e, l) : o === "dangerouslySetInnerHTML" ? (l = l ? l.__html : void 0, l != null && lm(e, l)) : o === "children" ? typeof l == "string" ? (n !== "textarea" || l !== "") && no(e, l) : typeof l == "number" && no(e, "" + l) : o !== "suppressContentEditableWarning" && o !== "suppressHydrationWarning" && o !== "autoFocus" && (to.hasOwnProperty(o) ? l != null && o === "onScroll" && de("scroll", e) : l != null && rc(e, o, l, s))
                            }
                        switch (n) {
                            case "input":
                                Xo(e), Qd(e, r, !1);
                                break;
                            case "textarea":
                                Xo(e), Zd(e);
                                break;
                            case "option":
                                r.value != null && e.setAttribute("value", "" + zn(r.value));
                                break;
                            case "select":
                                e.multiple = !!r.multiple, o = r.value, o != null ? Yr(e, !!r.multiple, o, !1) : r.defaultValue != null && Yr(e, !!r.multiple, r.defaultValue, !0);
                                break;
                            default:
                                typeof i.onClick == "function" && (e.onclick = Bs)
                        }
                        switch (n) {
                            case "button":
                            case "input":
                            case "select":
                            case "textarea":
                                r = !!r.autoFocus;
                                break e;
                            case "img":
                                r = !0;
                                break e;
                            default:
                                r = !1
                        }
                    }
                    r && (t.flags |= 4)
                }
                t.ref !== null && (t.flags |= 512, t.flags |= 2097152)
            }
            return Ue(t), null;
        case 6:
            if (e && t.stateNode != null) Dg(e, t, e.memoizedProps, r);
            else {
                if (typeof r != "string" && t.stateNode === null) throw Error(L(166));
                if (n = cr(po.current), cr($t.current), os(t)) {
                    if (r = t.stateNode, n = t.memoizedProps, r[Ut] = t, (o = r.nodeValue !== n) && (e = pt, e !== null)) switch (e.tag) {
                        case 3:
                            is(r.nodeValue, n, (e.mode & 1) !== 0);
                            break;
                        case 5:
                            e.memoizedProps.suppressHydrationWarning !== !0 && is(r.nodeValue, n, (e.mode & 1) !== 0)
                    }
                    o && (t.flags |= 4)
                } else r = (n.nodeType === 9 ? n : n.ownerDocument).createTextNode(r), r[Ut] = t, t.stateNode = r
            }
            return Ue(t), null;
        case 13:
            if (fe(ye), r = t.memoizedState, e === null || e.memoizedState !== null && e.memoizedState.dehydrated !== null) {
                if (ge && ft !== null && t.mode & 1 && !(t.flags & 128)) Zm(), ii(), t.flags |= 98560, o = !1;
                else if (o = os(t), r !== null && r.dehydrated !== null) {
                    if (e === null) {
                        if (!o) throw Error(L(318));
                        if (o = t.memoizedState, o = o !== null ? o.dehydrated : null, !o) throw Error(L(317));
                        o[Ut] = t
                    } else ii(), !(t.flags & 128) && (t.memoizedState = null), t.flags |= 4;
                    Ue(t), o = !1
                } else _t !== null && (ku(_t), _t = null), o = !0;
                if (!o) return t.flags & 65536 ? t : null
            }
            return t.flags & 128 ? (t.lanes = n, t) : (r = r !== null, r !== (e !== null && e.memoizedState !== null) && r && (t.child.flags |= 8192, t.mode & 1 && (e === null || ye.current & 1 ? Ne === 0 && (Ne = 3) : zc())), t.updateQueue !== null && (t.flags |= 4), Ue(t), null);
        case 4:
            return si(), yu(e, t), e === null && uo(t.stateNode.containerInfo), Ue(t), null;
        case 10:
            return Tc(t.type._context), Ue(t), null;
        case 17:
            return at(t.type) && Us(), Ue(t), null;
        case 19:
            if (fe(ye), o = t.memoizedState, o === null) return Ue(t), null;
            if (r = (t.flags & 128) !== 0, s = o.rendering, s === null)
                if (r) ji(o, !1);
                else {
                    if (Ne !== 0 || e !== null && e.flags & 128)
                        for (e = t.child; e !== null;) {
                            if (s = Qs(e), s !== null) {
                                for (t.flags |= 128, ji(o, !1), r = s.updateQueue, r !== null && (t.updateQueue = r, t.flags |= 4), t.subtreeFlags = 0, r = n, n = t.child; n !== null;) o = n, e = r, o.flags &= 14680066, s = o.alternate, s === null ? (o.childLanes = 0, o.lanes = e, o.child = null, o.subtreeFlags = 0, o.memoizedProps = null, o.memoizedState = null, o.updateQueue = null, o.dependencies = null, o.stateNode = null) : (o.childLanes = s.childLanes, o.lanes = s.lanes, o.child = s.child, o.subtreeFlags = 0, o.deletions = null, o.memoizedProps = s.memoizedProps, o.memoizedState = s.memoizedState, o.updateQueue = s.updateQueue, o.type = s.type, e = s.dependencies, o.dependencies = e === null ? null : {
                                    lanes: e.lanes,
                                    firstContext: e.firstContext
                                }), n = n.sibling;
                                return ae(ye, ye.current & 1 | 2), t.child
                            }
                            e = e.sibling
                        }
                    o.tail !== null && Re() > li && (t.flags |= 128, r = !0, ji(o, !1), t.lanes = 4194304)
                }
            else {
                if (!r)
                    if (e = Qs(s), e !== null) {
                        if (t.flags |= 128, r = !0, n = e.updateQueue, n !== null && (t.updateQueue = n, t.flags |= 4), ji(o, !0), o.tail === null && o.tailMode === "hidden" && !s.alternate && !ge) return Ue(t), null
                    } else 2 * Re() - o.renderingStartTime > li && n !== 1073741824 && (t.flags |= 128, r = !0, ji(o, !1), t.lanes = 4194304);
                o.isBackwards ? (s.sibling = t.child, t.child = s) : (n = o.last, n !== null ? n.sibling = s : t.child = s, o.last = s)
            }
            return o.tail !== null ? (t = o.tail, o.rendering = t, o.tail = t.sibling, o.renderingStartTime = Re(), t.sibling = null, n = ye.current, ae(ye, r ? n & 1 | 2 : n & 1), t) : (Ue(t), null);
        case 22:
        case 23:
            return Ic(), r = t.memoizedState !== null, e !== null && e.memoizedState !== null !== r && (t.flags |= 8192), r && t.mode & 1 ? ct & 1073741824 && (Ue(t), t.subtreeFlags & 6 && (t.flags |= 8192)) : Ue(t), null;
        case 24:
            return null;
        case 25:
            return null
    }
    throw Error(L(156, t.tag))
}

function Ex(e, t) {
    switch (yc(t), t.tag) {
        case 1:
            return at(t.type) && Us(), e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 3:
            return si(), fe(st), fe(Ge), Rc(), e = t.flags, e & 65536 && !(e & 128) ? (t.flags = e & -65537 | 128, t) : null;
        case 5:
            return kc(t), null;
        case 13:
            if (fe(ye), e = t.memoizedState, e !== null && e.dehydrated !== null) {
                if (t.alternate === null) throw Error(L(340));
                ii()
            }
            return e = t.flags, e & 65536 ? (t.flags = e & -65537 | 128, t) : null;
        case 19:
            return fe(ye), null;
        case 4:
            return si(), null;
        case 10:
            return Tc(t.type._context), null;
        case 22:
        case 23:
            return Ic(), null;
        case 24:
            return null;
        default:
            return null
    }
}
var ls = !1,
    $e = !1,
    Cx = typeof WeakSet == "function" ? WeakSet : Set,
    I = null;

function br(e, t) {
    var n = e.ref;
    if (n !== null)
        if (typeof n == "function") try {
            n(null)
        } catch (r) {
            Ce(e, t, r)
        } else n.current = null
}

function xu(e, t, n) {
    try {
        n()
    } catch (r) {
        Ce(e, t, r)
    }
}
var Bf = !1;

function kx(e, t) {
    if (nu = Is, e = Im(), gc(e)) {
        if ("selectionStart" in e) var n = {
            start: e.selectionStart,
            end: e.selectionEnd
        };
        else e: {
            n = (n = e.ownerDocument) && n.defaultView || window;
            var r = n.getSelection && n.getSelection();
            if (r && r.rangeCount !== 0) {
                n = r.anchorNode;
                var i = r.anchorOffset,
                    o = r.focusNode;
                r = r.focusOffset;
                try {
                    n.nodeType, o.nodeType
                } catch {
                    n = null;
                    break e
                }
                var s = 0,
                    a = -1,
                    l = -1,
                    u = 0,
                    c = 0,
                    d = e,
                    f = null;
                t: for (;;) {
                    for (var m; d !== n || i !== 0 && d.nodeType !== 3 || (a = s + i), d !== o || r !== 0 && d.nodeType !== 3 || (l = s + r), d.nodeType === 3 && (s += d.nodeValue.length), (m = d.firstChild) !== null;) f = d, d = m;
                    for (;;) {
                        if (d === e) break t;
                        if (f === n && ++u === i && (a = s), f === o && ++c === r && (l = s), (m = d.nextSibling) !== null) break;
                        d = f, f = d.parentNode
                    }
                    d = m
                }
                n = a === -1 || l === -1 ? null : {
                    start: a,
                    end: l
                }
            } else n = null
        }
        n = n || {
            start: 0,
            end: 0
        }
    } else n = null;
    for (ru = {
            focusedElem: e,
            selectionRange: n
        }, Is = !1, I = t; I !== null;)
        if (t = I, e = t.child, (t.subtreeFlags & 1028) !== 0 && e !== null) e.return = t, I = e;
        else
            for (; I !== null;) {
                t = I;
                try {
                    var x = t.alternate;
                    if (t.flags & 1024) switch (t.tag) {
                        case 0:
                        case 11:
                        case 15:
                            break;
                        case 1:
                            if (x !== null) {
                                var w = x.memoizedProps,
                                    E = x.memoizedState,
                                    p = t.stateNode,
                                    h = p.getSnapshotBeforeUpdate(t.elementType === t.type ? w : Mt(t.type, w), E);
                                p.__reactInternalSnapshotBeforeUpdate = h
                            }
                            break;
                        case 3:
                            var g = t.stateNode.containerInfo;
                            g.nodeType === 1 ? g.textContent = "" : g.nodeType === 9 && g.documentElement && g.removeChild(g.documentElement);
                            break;
                        case 5:
                        case 6:
                        case 4:
                        case 17:
                            break;
                        default:
                            throw Error(L(163))
                    }
                } catch (P) {
                    Ce(t, t.return, P)
                }
                if (e = t.sibling, e !== null) {
                    e.return = t.return, I = e;
                    break
                }
                I = t.return
            }
    return x = Bf, Bf = !1, x
}

function Qi(e, t, n) {
    var r = t.updateQueue;
    if (r = r !== null ? r.lastEffect : null, r !== null) {
        var i = r = r.next;
        do {
            if ((i.tag & e) === e) {
                var o = i.destroy;
                i.destroy = void 0, o !== void 0 && xu(t, n, o)
            }
            i = i.next
        } while (i !== r)
    }
}

function ka(e, t) {
    if (t = t.updateQueue, t = t !== null ? t.lastEffect : null, t !== null) {
        var n = t = t.next;
        do {
            if ((n.tag & e) === e) {
                var r = n.create;
                n.destroy = r()
            }
            n = n.next
        } while (n !== t)
    }
}

function wu(e) {
    var t = e.ref;
    if (t !== null) {
        var n = e.stateNode;
        switch (e.tag) {
            case 5:
                e = n;
                break;
            default:
                e = n
        }
        typeof t == "function" ? t(e) : t.current = e
    }
}

function _g(e) {
    var t = e.alternate;
    t !== null && (e.alternate = null, _g(t)), e.child = null, e.deletions = null, e.sibling = null, e.tag === 5 && (t = e.stateNode, t !== null && (delete t[Ut], delete t[fo], delete t[su], delete t[lx], delete t[ux])), e.stateNode = null, e.return = null, e.dependencies = null, e.memoizedProps = null, e.memoizedState = null, e.pendingProps = null, e.stateNode = null, e.updateQueue = null
}

function Og(e) {
    return e.tag === 5 || e.tag === 3 || e.tag === 4
}

function Uf(e) {
    e: for (;;) {
        for (; e.sibling === null;) {
            if (e.return === null || Og(e.return)) return null;
            e = e.return
        }
        for (e.sibling.return = e.return, e = e.sibling; e.tag !== 5 && e.tag !== 6 && e.tag !== 18;) {
            if (e.flags & 2 || e.child === null || e.tag === 4) continue e;
            e.child.return = e, e = e.child
        }
        if (!(e.flags & 2)) return e.stateNode
    }
}

function Su(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.nodeType === 8 ? n.parentNode.insertBefore(e, t) : n.insertBefore(e, t) : (n.nodeType === 8 ? (t = n.parentNode, t.insertBefore(e, n)) : (t = n, t.appendChild(e)), n = n._reactRootContainer, n != null || t.onclick !== null || (t.onclick = Bs));
    else if (r !== 4 && (e = e.child, e !== null))
        for (Su(e, t, n), e = e.sibling; e !== null;) Su(e, t, n), e = e.sibling
}

function Tu(e, t, n) {
    var r = e.tag;
    if (r === 5 || r === 6) e = e.stateNode, t ? n.insertBefore(e, t) : n.appendChild(e);
    else if (r !== 4 && (e = e.child, e !== null))
        for (Tu(e, t, n), e = e.sibling; e !== null;) Tu(e, t, n), e = e.sibling
}
var Fe = null,
    Nt = !1;

function Sn(e, t, n) {
    for (n = n.child; n !== null;) Vg(e, t, n), n = n.sibling
}

function Vg(e, t, n) {
    if (Ht && typeof Ht.onCommitFiberUnmount == "function") try {
        Ht.onCommitFiberUnmount(ya, n)
    } catch {}
    switch (n.tag) {
        case 5:
            $e || br(n, t);
        case 6:
            var r = Fe,
                i = Nt;
            Fe = null, Sn(e, t, n), Fe = r, Nt = i, Fe !== null && (Nt ? (e = Fe, n = n.stateNode, e.nodeType === 8 ? e.parentNode.removeChild(n) : e.removeChild(n)) : Fe.removeChild(n.stateNode));
            break;
        case 18:
            Fe !== null && (Nt ? (e = Fe, n = n.stateNode, e.nodeType === 8 ? al(e.parentNode, n) : e.nodeType === 1 && al(e, n), so(e)) : al(Fe, n.stateNode));
            break;
        case 4:
            r = Fe, i = Nt, Fe = n.stateNode.containerInfo, Nt = !0, Sn(e, t, n), Fe = r, Nt = i;
            break;
        case 0:
        case 11:
        case 14:
        case 15:
            if (!$e && (r = n.updateQueue, r !== null && (r = r.lastEffect, r !== null))) {
                i = r = r.next;
                do {
                    var o = i,
                        s = o.destroy;
                    o = o.tag, s !== void 0 && (o & 2 || o & 4) && xu(n, t, s), i = i.next
                } while (i !== r)
            }
            Sn(e, t, n);
            break;
        case 1:
            if (!$e && (br(n, t), r = n.stateNode, typeof r.componentWillUnmount == "function")) try {
                r.props = n.memoizedProps, r.state = n.memoizedState, r.componentWillUnmount()
            } catch (a) {
                Ce(n, t, a)
            }
            Sn(e, t, n);
            break;
        case 21:
            Sn(e, t, n);
            break;
        case 22:
            n.mode & 1 ? ($e = (r = $e) || n.memoizedState !== null, Sn(e, t, n), $e = r) : Sn(e, t, n);
            break;
        default:
            Sn(e, t, n)
    }
}

function Hf(e) {
    var t = e.updateQueue;
    if (t !== null) {
        e.updateQueue = null;
        var n = e.stateNode;
        n === null && (n = e.stateNode = new Cx), t.forEach(function(r) {
            var i = Ox.bind(null, e, r);
            n.has(r) || (n.add(r), r.then(i, i))
        })
    }
}

function Lt(e, t) {
    var n = t.deletions;
    if (n !== null)
        for (var r = 0; r < n.length; r++) {
            var i = n[r];
            try {
                var o = e,
                    s = t,
                    a = s;
                e: for (; a !== null;) {
                    switch (a.tag) {
                        case 5:
                            Fe = a.stateNode, Nt = !1;
                            break e;
                        case 3:
                            Fe = a.stateNode.containerInfo, Nt = !0;
                            break e;
                        case 4:
                            Fe = a.stateNode.containerInfo, Nt = !0;
                            break e
                    }
                    a = a.return
                }
                if (Fe === null) throw Error(L(160));
                Vg(o, s, i), Fe = null, Nt = !1;
                var l = i.alternate;
                l !== null && (l.return = null), i.return = null
            } catch (u) {
                Ce(i, t, u)
            }
        }
    if (t.subtreeFlags & 12854)
        for (t = t.child; t !== null;) Fg(t, e), t = t.sibling
}

function Fg(e, t) {
    var n = e.alternate,
        r = e.flags;
    switch (e.tag) {
        case 0:
        case 11:
        case 14:
        case 15:
            if (Lt(t, e), bt(e), r & 4) {
                try {
                    Qi(3, e, e.return), ka(3, e)
                } catch (w) {
                    Ce(e, e.return, w)
                }
                try {
                    Qi(5, e, e.return)
                } catch (w) {
                    Ce(e, e.return, w)
                }
            }
            break;
        case 1:
            Lt(t, e), bt(e), r & 512 && n !== null && br(n, n.return);
            break;
        case 5:
            if (Lt(t, e), bt(e), r & 512 && n !== null && br(n, n.return), e.flags & 32) {
                var i = e.stateNode;
                try {
                    no(i, "")
                } catch (w) {
                    Ce(e, e.return, w)
                }
            }
            if (r & 4 && (i = e.stateNode, i != null)) {
                var o = e.memoizedProps,
                    s = n !== null ? n.memoizedProps : o,
                    a = e.type,
                    l = e.updateQueue;
                if (e.updateQueue = null, l !== null) try {
                    a === "input" && o.type === "radio" && o.name != null && om(i, o), Kl(a, s);
                    var u = Kl(a, o);
                    for (s = 0; s < l.length; s += 2) {
                        var c = l[s],
                            d = l[s + 1];
                        c === "style" ? cm(i, d) : c === "dangerouslySetInnerHTML" ? lm(i, d) : c === "children" ? no(i, d) : rc(i, c, d, u)
                    }
                    switch (a) {
                        case "input":
                            Bl(i, o);
                            break;
                        case "textarea":
                            sm(i, o);
                            break;
                        case "select":
                            var f = i._wrapperState.wasMultiple;
                            i._wrapperState.wasMultiple = !!o.multiple;
                            var m = o.value;
                            m != null ? Yr(i, !!o.multiple, m, !1) : f !== !!o.multiple && (o.defaultValue != null ? Yr(i, !!o.multiple, o.defaultValue, !0) : Yr(i, !!o.multiple, o.multiple ? [] : "", !1))
                    }
                    i[fo] = o
                } catch (w) {
                    Ce(e, e.return, w)
                }
            }
            break;
        case 6:
            if (Lt(t, e), bt(e), r & 4) {
                if (e.stateNode === null) throw Error(L(162));
                i = e.stateNode, o = e.memoizedProps;
                try {
                    i.nodeValue = o
                } catch (w) {
                    Ce(e, e.return, w)
                }
            }
            break;
        case 3:
            if (Lt(t, e), bt(e), r & 4 && n !== null && n.memoizedState.isDehydrated) try {
                so(t.containerInfo)
            } catch (w) {
                Ce(e, e.return, w)
            }
            break;
        case 4:
            Lt(t, e), bt(e);
            break;
        case 13:
            Lt(t, e), bt(e), i = e.child, i.flags & 8192 && (o = i.memoizedState !== null, i.stateNode.isHidden = o, !o || i.alternate !== null && i.alternate.memoizedState !== null || (Vc = Re())), r & 4 && Hf(e);
            break;
        case 22:
            if (c = n !== null && n.memoizedState !== null, e.mode & 1 ? ($e = (u = $e) || c, Lt(t, e), $e = u) : Lt(t, e), bt(e), r & 8192) {
                if (u = e.memoizedState !== null, (e.stateNode.isHidden = u) && !c && e.mode & 1)
                    for (I = e, c = e.child; c !== null;) {
                        for (d = I = c; I !== null;) {
                            switch (f = I, m = f.child, f.tag) {
                                case 0:
                                case 11:
                                case 14:
                                case 15:
                                    Qi(4, f, f.return);
                                    break;
                                case 1:
                                    br(f, f.return);
                                    var x = f.stateNode;
                                    if (typeof x.componentWillUnmount == "function") {
                                        r = f, n = f.return;
                                        try {
                                            t = r, x.props = t.memoizedProps, x.state = t.memoizedState, x.componentWillUnmount()
                                        } catch (w) {
                                            Ce(r, n, w)
                                        }
                                    }
                                    break;
                                case 5:
                                    br(f, f.return);
                                    break;
                                case 22:
                                    if (f.memoizedState !== null) {
                                        Wf(d);
                                        continue
                                    }
                            }
                            m !== null ? (m.return = f, I = m) : Wf(d)
                        }
                        c = c.sibling
                    }
                e: for (c = null, d = e;;) {
                    if (d.tag === 5) {
                        if (c === null) {
                            c = d;
                            try {
                                i = d.stateNode, u ? (o = i.style, typeof o.setProperty == "function" ? o.setProperty("display", "none", "important") : o.display = "none") : (a = d.stateNode, l = d.memoizedProps.style, s = l != null && l.hasOwnProperty("display") ? l.display : null, a.style.display = um("display", s))
                            } catch (w) {
                                Ce(e, e.return, w)
                            }
                        }
                    } else if (d.tag === 6) {
                        if (c === null) try {
                            d.stateNode.nodeValue = u ? "" : d.memoizedProps
                        } catch (w) {
                            Ce(e, e.return, w)
                        }
                    } else if ((d.tag !== 22 && d.tag !== 23 || d.memoizedState === null || d === e) && d.child !== null) {
                        d.child.return = d, d = d.child;
                        continue
                    }
                    if (d === e) break e;
                    for (; d.sibling === null;) {
                        if (d.return === null || d.return === e) break e;
                        c === d && (c = null), d = d.return
                    }
                    c === d && (c = null), d.sibling.return = d.return, d = d.sibling
                }
            }
            break;
        case 19:
            Lt(t, e), bt(e), r & 4 && Hf(e);
            break;
        case 21:
            break;
        default:
            Lt(t, e), bt(e)
    }
}

function bt(e) {
    var t = e.flags;
    if (t & 2) {
        try {
            e: {
                for (var n = e.return; n !== null;) {
                    if (Og(n)) {
                        var r = n;
                        break e
                    }
                    n = n.return
                }
                throw Error(L(160))
            }
            switch (r.tag) {
                case 5:
                    var i = r.stateNode;
                    r.flags & 32 && (no(i, ""), r.flags &= -33);
                    var o = Uf(e);
                    Tu(e, o, i);
                    break;
                case 3:
                case 4:
                    var s = r.stateNode.containerInfo,
                        a = Uf(e);
                    Su(e, a, s);
                    break;
                default:
                    throw Error(L(161))
            }
        }
        catch (l) {
            Ce(e, e.return, l)
        }
        e.flags &= -3
    }
    t & 4096 && (e.flags &= -4097)
}

function Rx(e, t, n) {
    I = e, Ig(e)
}

function Ig(e, t, n) {
    for (var r = (e.mode & 1) !== 0; I !== null;) {
        var i = I,
            o = i.child;
        if (i.tag === 22 && r) {
            var s = i.memoizedState !== null || ls;
            if (!s) {
                var a = i.alternate,
                    l = a !== null && a.memoizedState !== null || $e;
                a = ls;
                var u = $e;
                if (ls = s, ($e = l) && !u)
                    for (I = i; I !== null;) s = I, l = s.child, s.tag === 22 && s.memoizedState !== null ? Kf(i) : l !== null ? (l.return = s, I = l) : Kf(i);
                for (; o !== null;) I = o, Ig(o), o = o.sibling;
                I = i, ls = a, $e = u
            }
            $f(e)
        } else i.subtreeFlags & 8772 && o !== null ? (o.return = i, I = o) : $f(e)
    }
}

function $f(e) {
    for (; I !== null;) {
        var t = I;
        if (t.flags & 8772) {
            var n = t.alternate;
            try {
                if (t.flags & 8772) switch (t.tag) {
                    case 0:
                    case 11:
                    case 15:
                        $e || ka(5, t);
                        break;
                    case 1:
                        var r = t.stateNode;
                        if (t.flags & 4 && !$e)
                            if (n === null) r.componentDidMount();
                            else {
                                var i = t.elementType === t.type ? n.memoizedProps : Mt(t.type, n.memoizedProps);
                                r.componentDidUpdate(i, n.memoizedState, r.__reactInternalSnapshotBeforeUpdate)
                            }
                        var o = t.updateQueue;
                        o !== null && jf(t, o, r);
                        break;
                    case 3:
                        var s = t.updateQueue;
                        if (s !== null) {
                            if (n = null, t.child !== null) switch (t.child.tag) {
                                case 5:
                                    n = t.child.stateNode;
                                    break;
                                case 1:
                                    n = t.child.stateNode
                            }
                            jf(t, s, n)
                        }
                        break;
                    case 5:
                        var a = t.stateNode;
                        if (n === null && t.flags & 4) {
                            n = a;
                            var l = t.memoizedProps;
                            switch (t.type) {
                                case "button":
                                case "input":
                                case "select":
                                case "textarea":
                                    l.autoFocus && n.focus();
                                    break;
                                case "img":
                                    l.src && (n.src = l.src)
                            }
                        }
                        break;
                    case 6:
                        break;
                    case 4:
                        break;
                    case 12:
                        break;
                    case 13:
                        if (t.memoizedState === null) {
                            var u = t.alternate;
                            if (u !== null) {
                                var c = u.memoizedState;
                                if (c !== null) {
                                    var d = c.dehydrated;
                                    d !== null && so(d)
                                }
                            }
                        }
                        break;
                    case 19:
                    case 17:
                    case 21:
                    case 22:
                    case 23:
                    case 25:
                        break;
                    default:
                        throw Error(L(163))
                }
                $e || t.flags & 512 && wu(t)
            } catch (f) {
                Ce(t, t.return, f)
            }
        }
        if (t === e) {
            I = null;
            break
        }
        if (n = t.sibling, n !== null) {
            n.return = t.return, I = n;
            break
        }
        I = t.return
    }
}

function Wf(e) {
    for (; I !== null;) {
        var t = I;
        if (t === e) {
            I = null;
            break
        }
        var n = t.sibling;
        if (n !== null) {
            n.return = t.return, I = n;
            break
        }
        I = t.return
    }
}

function Kf(e) {
    for (; I !== null;) {
        var t = I;
        try {
            switch (t.tag) {
                case 0:
                case 11:
                case 15:
                    var n = t.return;
                    try {
                        ka(4, t)
                    } catch (l) {
                        Ce(t, n, l)
                    }
                    break;
                case 1:
                    var r = t.stateNode;
                    if (typeof r.componentDidMount == "function") {
                        var i = t.return;
                        try {
                            r.componentDidMount()
                        } catch (l) {
                            Ce(t, i, l)
                        }
                    }
                    var o = t.return;
                    try {
                        wu(t)
                    } catch (l) {
                        Ce(t, o, l)
                    }
                    break;
                case 5:
                    var s = t.return;
                    try {
                        wu(t)
                    } catch (l) {
                        Ce(t, s, l)
                    }
            }
        } catch (l) {
            Ce(t, t.return, l)
        }
        if (t === e) {
            I = null;
            break
        }
        var a = t.sibling;
        if (a !== null) {
            a.return = t.return, I = a;
            break
        }
        I = t.return
    }
}
var jx = Math.ceil,
    Js = vn.ReactCurrentDispatcher,
    _c = vn.ReactCurrentOwner,
    kt = vn.ReactCurrentBatchConfig,
    q = 0,
    Oe = null,
    Le = null,
    ze = 0,
    ct = 0,
    Br = Wn(0),
    Ne = 0,
    yo = null,
    wr = 0,
    Ra = 0,
    Oc = 0,
    Xi = null,
    it = null,
    Vc = 0,
    li = 1 / 0,
    qt = null,
    qs = !1,
    Pu = null,
    Vn = null,
    us = !1,
    An = null,
    ea = 0,
    Zi = 0,
    Eu = null,
    Es = -1,
    Cs = 0;

function Ze() {
    return q & 6 ? Re() : Es !== -1 ? Es : Es = Re()
}

function Fn(e) {
    return e.mode & 1 ? q & 2 && ze !== 0 ? ze & -ze : dx.transition !== null ? (Cs === 0 && (Cs = Tm()), Cs) : (e = re, e !== 0 || (e = window.event, e = e === void 0 ? 16 : Am(e.type)), e) : 1
}

function It(e, t, n, r) {
    if (50 < Zi) throw Zi = 0, Eu = null, Error(L(185));
    jo(e, n, r), (!(q & 2) || e !== Oe) && (e === Oe && (!(q & 2) && (Ra |= n), Ne === 4 && Rn(e, ze)), lt(e, r), n === 1 && q === 0 && !(t.mode & 1) && (li = Re() + 500, Pa && Kn()))
}

function lt(e, t) {
    var n = e.callbackNode;
    d1(e, t);
    var r = Fs(e, e === Oe ? ze : 0);
    if (r === 0) n !== null && ef(n), e.callbackNode = null, e.callbackPriority = 0;
    else if (t = r & -r, e.callbackPriority !== t) {
        if (n != null && ef(n), t === 1) e.tag === 0 ? cx(Gf.bind(null, e)) : Ym(Gf.bind(null, e)), sx(function() {
            !(q & 6) && Kn()
        }), n = null;
        else {
            switch (Pm(r)) {
                case 1:
                    n = lc;
                    break;
                case 4:
                    n = wm;
                    break;
                case 16:
                    n = Vs;
                    break;
                case 536870912:
                    n = Sm;
                    break;
                default:
                    n = Vs
            }
            n = Kg(n, zg.bind(null, e))
        }
        e.callbackPriority = t, e.callbackNode = n
    }
}

function zg(e, t) {
    if (Es = -1, Cs = 0, q & 6) throw Error(L(327));
    var n = e.callbackNode;
    if (qr() && e.callbackNode !== n) return null;
    var r = Fs(e, e === Oe ? ze : 0);
    if (r === 0) return null;
    if (r & 30 || r & e.expiredLanes || t) t = ta(e, r);
    else {
        t = r;
        var i = q;
        q |= 2;
        var o = Bg();
        (Oe !== e || ze !== t) && (qt = null, li = Re() + 500, hr(e, t));
        do try {
            Mx();
            break
        } catch (a) {
            bg(e, a)
        }
        while (!0);
        Sc(), Js.current = o, q = i, Le !== null ? t = 0 : (Oe = null, ze = 0, t = Ne)
    }
    if (t !== 0) {
        if (t === 2 && (i = Zl(e), i !== 0 && (r = i, t = Cu(e, i))), t === 1) throw n = yo, hr(e, 0), Rn(e, r), lt(e, Re()), n;
        if (t === 6) Rn(e, r);
        else {
            if (i = e.current.alternate, !(r & 30) && !Ax(i) && (t = ta(e, r), t === 2 && (o = Zl(e), o !== 0 && (r = o, t = Cu(e, o))), t === 1)) throw n = yo, hr(e, 0), Rn(e, r), lt(e, Re()), n;
            switch (e.finishedWork = i, e.finishedLanes = r, t) {
                case 0:
                case 1:
                    throw Error(L(345));
                case 2:
                    rr(e, it, qt);
                    break;
                case 3:
                    if (Rn(e, r), (r & 130023424) === r && (t = Vc + 500 - Re(), 10 < t)) {
                        if (Fs(e, 0) !== 0) break;
                        if (i = e.suspendedLanes, (i & r) !== r) {
                            Ze(), e.pingedLanes |= e.suspendedLanes & i;
                            break
                        }
                        e.timeoutHandle = ou(rr.bind(null, e, it, qt), t);
                        break
                    }
                    rr(e, it, qt);
                    break;
                case 4:
                    if (Rn(e, r), (r & 4194240) === r) break;
                    for (t = e.eventTimes, i = -1; 0 < r;) {
                        var s = 31 - Ft(r);
                        o = 1 << s, s = t[s], s > i && (i = s), r &= ~o
                    }
                    if (r = i, r = Re() - r, r = (120 > r ? 120 : 480 > r ? 480 : 1080 > r ? 1080 : 1920 > r ? 1920 : 3e3 > r ? 3e3 : 4320 > r ? 4320 : 1960 * jx(r / 1960)) - r, 10 < r) {
                        e.timeoutHandle = ou(rr.bind(null, e, it, qt), r);
                        break
                    }
                    rr(e, it, qt);
                    break;
                case 5:
                    rr(e, it, qt);
                    break;
                default:
                    throw Error(L(329))
            }
        }
    }
    return lt(e, Re()), e.callbackNode === n ? zg.bind(null, e) : null
}

function Cu(e, t) {
    var n = Xi;
    return e.current.memoizedState.isDehydrated && (hr(e, t).flags |= 256), e = ta(e, t), e !== 2 && (t = it, it = n, t !== null && ku(t)), e
}

function ku(e) {
    it === null ? it = e : it.push.apply(it, e)
}

function Ax(e) {
    for (var t = e;;) {
        if (t.flags & 16384) {
            var n = t.updateQueue;
            if (n !== null && (n = n.stores, n !== null))
                for (var r = 0; r < n.length; r++) {
                    var i = n[r],
                        o = i.getSnapshot;
                    i = i.value;
                    try {
                        if (!zt(o(), i)) return !1
                    } catch {
                        return !1
                    }
                }
        }
        if (n = t.child, t.subtreeFlags & 16384 && n !== null) n.return = t, t = n;
        else {
            if (t === e) break;
            for (; t.sibling === null;) {
                if (t.return === null || t.return === e) return !0;
                t = t.return
            }
            t.sibling.return = t.return, t = t.sibling
        }
    }
    return !0
}

function Rn(e, t) {
    for (t &= ~Oc, t &= ~Ra, e.suspendedLanes |= t, e.pingedLanes &= ~t, e = e.expirationTimes; 0 < t;) {
        var n = 31 - Ft(t),
            r = 1 << n;
        e[n] = -1, t &= ~r
    }
}

function Gf(e) {
    if (q & 6) throw Error(L(327));
    qr();
    var t = Fs(e, 0);
    if (!(t & 1)) return lt(e, Re()), null;
    var n = ta(e, t);
    if (e.tag !== 0 && n === 2) {
        var r = Zl(e);
        r !== 0 && (t = r, n = Cu(e, r))
    }
    if (n === 1) throw n = yo, hr(e, 0), Rn(e, t), lt(e, Re()), n;
    if (n === 6) throw Error(L(345));
    return e.finishedWork = e.current.alternate, e.finishedLanes = t, rr(e, it, qt), lt(e, Re()), null
}

function Fc(e, t) {
    var n = q;
    q |= 1;
    try {
        return e(t)
    } finally {
        q = n, q === 0 && (li = Re() + 500, Pa && Kn())
    }
}

function Sr(e) {
    An !== null && An.tag === 0 && !(q & 6) && qr();
    var t = q;
    q |= 1;
    var n = kt.transition,
        r = re;
    try {
        if (kt.transition = null, re = 1, e) return e()
    } finally {
        re = r, kt.transition = n, q = t, !(q & 6) && Kn()
    }
}

function Ic() {
    ct = Br.current, fe(Br)
}

function hr(e, t) {
    e.finishedWork = null, e.finishedLanes = 0;
    var n = e.timeoutHandle;
    if (n !== -1 && (e.timeoutHandle = -1, ox(n)), Le !== null)
        for (n = Le.return; n !== null;) {
            var r = n;
            switch (yc(r), r.tag) {
                case 1:
                    r = r.type.childContextTypes, r != null && Us();
                    break;
                case 3:
                    si(), fe(st), fe(Ge), Rc();
                    break;
                case 5:
                    kc(r);
                    break;
                case 4:
                    si();
                    break;
                case 13:
                    fe(ye);
                    break;
                case 19:
                    fe(ye);
                    break;
                case 10:
                    Tc(r.type._context);
                    break;
                case 22:
                case 23:
                    Ic()
            }
            n = n.return
        }
    if (Oe = e, Le = e = In(e.current, null), ze = ct = t, Ne = 0, yo = null, Oc = Ra = wr = 0, it = Xi = null, ur !== null) {
        for (t = 0; t < ur.length; t++)
            if (n = ur[t], r = n.interleaved, r !== null) {
                n.interleaved = null;
                var i = r.next,
                    o = n.pending;
                if (o !== null) {
                    var s = o.next;
                    o.next = i, r.next = s
                }
                n.pending = r
            }
        ur = null
    }
    return e
}

function bg(e, t) {
    do {
        var n = Le;
        try {
            if (Sc(), Ss.current = Zs, Xs) {
                for (var r = we.memoizedState; r !== null;) {
                    var i = r.queue;
                    i !== null && (i.pending = null), r = r.next
                }
                Xs = !1
            }
            if (xr = 0, _e = Me = we = null, Yi = !1, mo = 0, _c.current = null, n === null || n.return === null) {
                Ne = 1, yo = t, Le = null;
                break
            }
            e: {
                var o = e,
                    s = n.return,
                    a = n,
                    l = t;
                if (t = ze, a.flags |= 32768, l !== null && typeof l == "object" && typeof l.then == "function") {
                    var u = l,
                        c = a,
                        d = c.tag;
                    if (!(c.mode & 1) && (d === 0 || d === 11 || d === 15)) {
                        var f = c.alternate;
                        f ? (c.updateQueue = f.updateQueue, c.memoizedState = f.memoizedState, c.lanes = f.lanes) : (c.updateQueue = null, c.memoizedState = null)
                    }
                    var m = _f(s);
                    if (m !== null) {
                        m.flags &= -257, Of(m, s, a, o, t), m.mode & 1 && Df(o, u, t), t = m, l = u;
                        var x = t.updateQueue;
                        if (x === null) {
                            var w = new Set;
                            w.add(l), t.updateQueue = w
                        } else x.add(l);
                        break e
                    } else {
                        if (!(t & 1)) {
                            Df(o, u, t), zc();
                            break e
                        }
                        l = Error(L(426))
                    }
                } else if (ge && a.mode & 1) {
                    var E = _f(s);
                    if (E !== null) {
                        !(E.flags & 65536) && (E.flags |= 256), Of(E, s, a, o, t), xc(ai(l, a));
                        break e
                    }
                }
                o = l = ai(l, a),
                Ne !== 4 && (Ne = 2),
                Xi === null ? Xi = [o] : Xi.push(o),
                o = s;do {
                    switch (o.tag) {
                        case 3:
                            o.flags |= 65536, t &= -t, o.lanes |= t;
                            var p = Pg(o, l, t);
                            Rf(o, p);
                            break e;
                        case 1:
                            a = l;
                            var h = o.type,
                                g = o.stateNode;
                            if (!(o.flags & 128) && (typeof h.getDerivedStateFromError == "function" || g !== null && typeof g.componentDidCatch == "function" && (Vn === null || !Vn.has(g)))) {
                                o.flags |= 65536, t &= -t, o.lanes |= t;
                                var P = Eg(o, a, t);
                                Rf(o, P);
                                break e
                            }
                    }
                    o = o.return
                } while (o !== null)
            }
            Hg(n)
        } catch (R) {
            t = R, Le === n && n !== null && (Le = n = n.return);
            continue
        }
        break
    } while (!0)
}

function Bg() {
    var e = Js.current;
    return Js.current = Zs, e === null ? Zs : e
}

function zc() {
    (Ne === 0 || Ne === 3 || Ne === 2) && (Ne = 4), Oe === null || !(wr & 268435455) && !(Ra & 268435455) || Rn(Oe, ze)
}

function ta(e, t) {
    var n = q;
    q |= 2;
    var r = Bg();
    (Oe !== e || ze !== t) && (qt = null, hr(e, t));
    do try {
        Lx();
        break
    } catch (i) {
        bg(e, i)
    }
    while (!0);
    if (Sc(), q = n, Js.current = r, Le !== null) throw Error(L(261));
    return Oe = null, ze = 0, Ne
}

function Lx() {
    for (; Le !== null;) Ug(Le)
}

function Mx() {
    for (; Le !== null && !n1();) Ug(Le)
}

function Ug(e) {
    var t = Wg(e.alternate, e, ct);
    e.memoizedProps = e.pendingProps, t === null ? Hg(e) : Le = t, _c.current = null
}

function Hg(e) {
    var t = e;
    do {
        var n = t.alternate;
        if (e = t.return, t.flags & 32768) {
            if (n = Ex(n, t), n !== null) {
                n.flags &= 32767, Le = n;
                return
            }
            if (e !== null) e.flags |= 32768, e.subtreeFlags = 0, e.deletions = null;
            else {
                Ne = 6, Le = null;
                return
            }
        } else if (n = Px(n, t, ct), n !== null) {
            Le = n;
            return
        }
        if (t = t.sibling, t !== null) {
            Le = t;
            return
        }
        Le = t = e
    } while (t !== null);
    Ne === 0 && (Ne = 5)
}

function rr(e, t, n) {
    var r = re,
        i = kt.transition;
    try {
        kt.transition = null, re = 1, Nx(e, t, n, r)
    } finally {
        kt.transition = i, re = r
    }
    return null
}

function Nx(e, t, n, r) {
    do qr(); while (An !== null);
    if (q & 6) throw Error(L(327));
    n = e.finishedWork;
    var i = e.finishedLanes;
    if (n === null) return null;
    if (e.finishedWork = null, e.finishedLanes = 0, n === e.current) throw Error(L(177));
    e.callbackNode = null, e.callbackPriority = 0;
    var o = n.lanes | n.childLanes;
    if (f1(e, o), e === Oe && (Le = Oe = null, ze = 0), !(n.subtreeFlags & 2064) && !(n.flags & 2064) || us || (us = !0, Kg(Vs, function() {
            return qr(), null
        })), o = (n.flags & 15990) !== 0, n.subtreeFlags & 15990 || o) {
        o = kt.transition, kt.transition = null;
        var s = re;
        re = 1;
        var a = q;
        q |= 4, _c.current = null, kx(e, n), Fg(n, e), J1(ru), Is = !!nu, ru = nu = null, e.current = n, Rx(n), r1(), q = a, re = s, kt.transition = o
    } else e.current = n;
    if (us && (us = !1, An = e, ea = i), o = e.pendingLanes, o === 0 && (Vn = null), s1(n.stateNode), lt(e, Re()), t !== null)
        for (r = e.onRecoverableError, n = 0; n < t.length; n++) i = t[n], r(i.value, {
            componentStack: i.stack,
            digest: i.digest
        });
    if (qs) throw qs = !1, e = Pu, Pu = null, e;
    return ea & 1 && e.tag !== 0 && qr(), o = e.pendingLanes, o & 1 ? e === Eu ? Zi++ : (Zi = 0, Eu = e) : Zi = 0, Kn(), null
}

function qr() {
    if (An !== null) {
        var e = Pm(ea),
            t = kt.transition,
            n = re;
        try {
            if (kt.transition = null, re = 16 > e ? 16 : e, An === null) var r = !1;
            else {
                if (e = An, An = null, ea = 0, q & 6) throw Error(L(331));
                var i = q;
                for (q |= 4, I = e.current; I !== null;) {
                    var o = I,
                        s = o.child;
                    if (I.flags & 16) {
                        var a = o.deletions;
                        if (a !== null) {
                            for (var l = 0; l < a.length; l++) {
                                var u = a[l];
                                for (I = u; I !== null;) {
                                    var c = I;
                                    switch (c.tag) {
                                        case 0:
                                        case 11:
                                        case 15:
                                            Qi(8, c, o)
                                    }
                                    var d = c.child;
                                    if (d !== null) d.return = c, I = d;
                                    else
                                        for (; I !== null;) {
                                            c = I;
                                            var f = c.sibling,
                                                m = c.return;
                                            if (_g(c), c === u) {
                                                I = null;
                                                break
                                            }
                                            if (f !== null) {
                                                f.return = m, I = f;
                                                break
                                            }
                                            I = m
                                        }
                                }
                            }
                            var x = o.alternate;
                            if (x !== null) {
                                var w = x.child;
                                if (w !== null) {
                                    x.child = null;
                                    do {
                                        var E = w.sibling;
                                        w.sibling = null, w = E
                                    } while (w !== null)
                                }
                            }
                            I = o
                        }
                    }
                    if (o.subtreeFlags & 2064 && s !== null) s.return = o, I = s;
                    else e: for (; I !== null;) {
                        if (o = I, o.flags & 2048) switch (o.tag) {
                            case 0:
                            case 11:
                            case 15:
                                Qi(9, o, o.return)
                        }
                        var p = o.sibling;
                        if (p !== null) {
                            p.return = o.return, I = p;
                            break e
                        }
                        I = o.return
                    }
                }
                var h = e.current;
                for (I = h; I !== null;) {
                    s = I;
                    var g = s.child;
                    if (s.subtreeFlags & 2064 && g !== null) g.return = s, I = g;
                    else e: for (s = h; I !== null;) {
                        if (a = I, a.flags & 2048) try {
                            switch (a.tag) {
                                case 0:
                                case 11:
                                case 15:
                                    ka(9, a)
                            }
                        } catch (R) {
                            Ce(a, a.return, R)
                        }
                        if (a === s) {
                            I = null;
                            break e
                        }
                        var P = a.sibling;
                        if (P !== null) {
                            P.return = a.return, I = P;
                            break e
                        }
                        I = a.return
                    }
                }
                if (q = i, Kn(), Ht && typeof Ht.onPostCommitFiberRoot == "function") try {
                    Ht.onPostCommitFiberRoot(ya, e)
                } catch {}
                r = !0
            }
            return r
        } finally {
            re = n, kt.transition = t
        }
    }
    return !1
}

function Yf(e, t, n) {
    t = ai(n, t), t = Pg(e, t, 1), e = On(e, t, 1), t = Ze(), e !== null && (jo(e, 1, t), lt(e, t))
}

function Ce(e, t, n) {
    if (e.tag === 3) Yf(e, e, n);
    else
        for (; t !== null;) {
            if (t.tag === 3) {
                Yf(t, e, n);
                break
            } else if (t.tag === 1) {
                var r = t.stateNode;
                if (typeof t.type.getDerivedStateFromError == "function" || typeof r.componentDidCatch == "function" && (Vn === null || !Vn.has(r))) {
                    e = ai(n, e), e = Eg(t, e, 1), t = On(t, e, 1), e = Ze(), t !== null && (jo(t, 1, e), lt(t, e));
                    break
                }
            }
            t = t.return
        }
}

function Dx(e, t, n) {
    var r = e.pingCache;
    r !== null && r.delete(t), t = Ze(), e.pingedLanes |= e.suspendedLanes & n, Oe === e && (ze & n) === n && (Ne === 4 || Ne === 3 && (ze & 130023424) === ze && 500 > Re() - Vc ? hr(e, 0) : Oc |= n), lt(e, t)
}

function $g(e, t) {
    t === 0 && (e.mode & 1 ? (t = qo, qo <<= 1, !(qo & 130023424) && (qo = 4194304)) : t = 1);
    var n = Ze();
    e = pn(e, t), e !== null && (jo(e, t, n), lt(e, n))
}

function _x(e) {
    var t = e.memoizedState,
        n = 0;
    t !== null && (n = t.retryLane), $g(e, n)
}

function Ox(e, t) {
    var n = 0;
    switch (e.tag) {
        case 13:
            var r = e.stateNode,
                i = e.memoizedState;
            i !== null && (n = i.retryLane);
            break;
        case 19:
            r = e.stateNode;
            break;
        default:
            throw Error(L(314))
    }
    r !== null && r.delete(t), $g(e, n)
}
var Wg;
Wg = function(e, t, n) {
    if (e !== null)
        if (e.memoizedProps !== t.pendingProps || st.current) ot = !0;
        else {
            if (!(e.lanes & n) && !(t.flags & 128)) return ot = !1, Tx(e, t, n);
            ot = !!(e.flags & 131072)
        }
    else ot = !1, ge && t.flags & 1048576 && Qm(t, Ws, t.index);
    switch (t.lanes = 0, t.tag) {
        case 2:
            var r = t.type;
            Ps(e, t), e = t.pendingProps;
            var i = ri(t, Ge.current);
            Jr(t, n), i = Ac(null, t, r, e, i, n);
            var o = Lc();
            return t.flags |= 1, typeof i == "object" && i !== null && typeof i.render == "function" && i.$$typeof === void 0 ? (t.tag = 1, t.memoizedState = null, t.updateQueue = null, at(r) ? (o = !0, Hs(t)) : o = !1, t.memoizedState = i.state !== null && i.state !== void 0 ? i.state : null, Ec(t), i.updater = Ca, t.stateNode = i, i._reactInternals = t, fu(t, r, e, n), t = mu(null, t, r, !0, o, n)) : (t.tag = 0, ge && o && vc(t), Xe(null, t, i, n), t = t.child), t;
        case 16:
            r = t.elementType;
            e: {
                switch (Ps(e, t), e = t.pendingProps, i = r._init, r = i(r._payload), t.type = r, i = t.tag = Fx(r), e = Mt(r, e), i) {
                    case 0:
                        t = pu(null, t, r, e, n);
                        break e;
                    case 1:
                        t = If(null, t, r, e, n);
                        break e;
                    case 11:
                        t = Vf(null, t, r, e, n);
                        break e;
                    case 14:
                        t = Ff(null, t, r, Mt(r.type, e), n);
                        break e
                }
                throw Error(L(306, r, ""))
            }
            return t;
        case 0:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Mt(r, i), pu(e, t, r, i, n);
        case 1:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Mt(r, i), If(e, t, r, i, n);
        case 3:
            e: {
                if (jg(t), e === null) throw Error(L(387));r = t.pendingProps,
                o = t.memoizedState,
                i = o.element,
                tg(e, t),
                Ys(t, r, null, n);
                var s = t.memoizedState;
                if (r = s.element, o.isDehydrated)
                    if (o = {
                            element: r,
                            isDehydrated: !1,
                            cache: s.cache,
                            pendingSuspenseBoundaries: s.pendingSuspenseBoundaries,
                            transitions: s.transitions
                        }, t.updateQueue.baseState = o, t.memoizedState = o, t.flags & 256) {
                        i = ai(Error(L(423)), t), t = zf(e, t, r, n, i);
                        break e
                    } else if (r !== i) {
                    i = ai(Error(L(424)), t), t = zf(e, t, r, n, i);
                    break e
                } else
                    for (ft = _n(t.stateNode.containerInfo.firstChild), pt = t, ge = !0, _t = null, n = qm(t, null, r, n), t.child = n; n;) n.flags = n.flags & -3 | 4096, n = n.sibling;
                else {
                    if (ii(), r === i) {
                        t = mn(e, t, n);
                        break e
                    }
                    Xe(e, t, r, n)
                }
                t = t.child
            }
            return t;
        case 5:
            return ng(t), e === null && uu(t), r = t.type, i = t.pendingProps, o = e !== null ? e.memoizedProps : null, s = i.children, iu(r, i) ? s = null : o !== null && iu(r, o) && (t.flags |= 32), Rg(e, t), Xe(e, t, s, n), t.child;
        case 6:
            return e === null && uu(t), null;
        case 13:
            return Ag(e, t, n);
        case 4:
            return Cc(t, t.stateNode.containerInfo), r = t.pendingProps, e === null ? t.child = oi(t, null, r, n) : Xe(e, t, r, n), t.child;
        case 11:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Mt(r, i), Vf(e, t, r, i, n);
        case 7:
            return Xe(e, t, t.pendingProps, n), t.child;
        case 8:
            return Xe(e, t, t.pendingProps.children, n), t.child;
        case 12:
            return Xe(e, t, t.pendingProps.children, n), t.child;
        case 10:
            e: {
                if (r = t.type._context, i = t.pendingProps, o = t.memoizedProps, s = i.value, ae(Ks, r._currentValue), r._currentValue = s, o !== null)
                    if (zt(o.value, s)) {
                        if (o.children === i.children && !st.current) {
                            t = mn(e, t, n);
                            break e
                        }
                    } else
                        for (o = t.child, o !== null && (o.return = t); o !== null;) {
                            var a = o.dependencies;
                            if (a !== null) {
                                s = o.child;
                                for (var l = a.firstContext; l !== null;) {
                                    if (l.context === r) {
                                        if (o.tag === 1) {
                                            l = sn(-1, n & -n), l.tag = 2;
                                            var u = o.updateQueue;
                                            if (u !== null) {
                                                u = u.shared;
                                                var c = u.pending;
                                                c === null ? l.next = l : (l.next = c.next, c.next = l), u.pending = l
                                            }
                                        }
                                        o.lanes |= n, l = o.alternate, l !== null && (l.lanes |= n), cu(o.return, n, t), a.lanes |= n;
                                        break
                                    }
                                    l = l.next
                                }
                            } else if (o.tag === 10) s = o.type === t.type ? null : o.child;
                            else if (o.tag === 18) {
                                if (s = o.return, s === null) throw Error(L(341));
                                s.lanes |= n, a = s.alternate, a !== null && (a.lanes |= n), cu(s, n, t), s = o.sibling
                            } else s = o.child;
                            if (s !== null) s.return = o;
                            else
                                for (s = o; s !== null;) {
                                    if (s === t) {
                                        s = null;
                                        break
                                    }
                                    if (o = s.sibling, o !== null) {
                                        o.return = s.return, s = o;
                                        break
                                    }
                                    s = s.return
                                }
                            o = s
                        }
                Xe(e, t, i.children, n),
                t = t.child
            }
            return t;
        case 9:
            return i = t.type, r = t.pendingProps.children, Jr(t, n), i = Rt(i), r = r(i), t.flags |= 1, Xe(e, t, r, n), t.child;
        case 14:
            return r = t.type, i = Mt(r, t.pendingProps), i = Mt(r.type, i), Ff(e, t, r, i, n);
        case 15:
            return Cg(e, t, t.type, t.pendingProps, n);
        case 17:
            return r = t.type, i = t.pendingProps, i = t.elementType === r ? i : Mt(r, i), Ps(e, t), t.tag = 1, at(r) ? (e = !0, Hs(t)) : e = !1, Jr(t, n), Tg(t, r, i), fu(t, r, i, n), mu(null, t, r, !0, e, n);
        case 19:
            return Lg(e, t, n);
        case 22:
            return kg(e, t, n)
    }
    throw Error(L(156, t.tag))
};

function Kg(e, t) {
    return xm(e, t)
}

function Vx(e, t, n, r) {
    this.tag = e, this.key = n, this.sibling = this.child = this.return = this.stateNode = this.type = this.elementType = null, this.index = 0, this.ref = null, this.pendingProps = t, this.dependencies = this.memoizedState = this.updateQueue = this.memoizedProps = null, this.mode = r, this.subtreeFlags = this.flags = 0, this.deletions = null, this.childLanes = this.lanes = 0, this.alternate = null
}

function Ct(e, t, n, r) {
    return new Vx(e, t, n, r)
}

function bc(e) {
    return e = e.prototype, !(!e || !e.isReactComponent)
}

function Fx(e) {
    if (typeof e == "function") return bc(e) ? 1 : 0;
    if (e != null) {
        if (e = e.$$typeof, e === oc) return 11;
        if (e === sc) return 14
    }
    return 2
}

function In(e, t) {
    var n = e.alternate;
    return n === null ? (n = Ct(e.tag, t, e.key, e.mode), n.elementType = e.elementType, n.type = e.type, n.stateNode = e.stateNode, n.alternate = e, e.alternate = n) : (n.pendingProps = t, n.type = e.type, n.flags = 0, n.subtreeFlags = 0, n.deletions = null), n.flags = e.flags & 14680064, n.childLanes = e.childLanes, n.lanes = e.lanes, n.child = e.child, n.memoizedProps = e.memoizedProps, n.memoizedState = e.memoizedState, n.updateQueue = e.updateQueue, t = e.dependencies, n.dependencies = t === null ? null : {
        lanes: t.lanes,
        firstContext: t.firstContext
    }, n.sibling = e.sibling, n.index = e.index, n.ref = e.ref, n
}

function ks(e, t, n, r, i, o) {
    var s = 2;
    if (r = e, typeof e == "function") bc(e) && (s = 1);
    else if (typeof e == "string") s = 5;
    else e: switch (e) {
        case Mr:
            return pr(n.children, i, o, t);
        case ic:
            s = 8, i |= 8;
            break;
        case Vl:
            return e = Ct(12, n, t, i | 2), e.elementType = Vl, e.lanes = o, e;
        case Fl:
            return e = Ct(13, n, t, i), e.elementType = Fl, e.lanes = o, e;
        case Il:
            return e = Ct(19, n, t, i), e.elementType = Il, e.lanes = o, e;
        case nm:
            return ja(n, i, o, t);
        default:
            if (typeof e == "object" && e !== null) switch (e.$$typeof) {
                case em:
                    s = 10;
                    break e;
                case tm:
                    s = 9;
                    break e;
                case oc:
                    s = 11;
                    break e;
                case sc:
                    s = 14;
                    break e;
                case En:
                    s = 16, r = null;
                    break e
            }
            throw Error(L(130, e == null ? e : typeof e, ""))
    }
    return t = Ct(s, n, t, i), t.elementType = e, t.type = r, t.lanes = o, t
}

function pr(e, t, n, r) {
    return e = Ct(7, e, r, t), e.lanes = n, e
}

function ja(e, t, n, r) {
    return e = Ct(22, e, r, t), e.elementType = nm, e.lanes = n, e.stateNode = {
        isHidden: !1
    }, e
}

function ml(e, t, n) {
    return e = Ct(6, e, null, t), e.lanes = n, e
}

function gl(e, t, n) {
    return t = Ct(4, e.children !== null ? e.children : [], e.key, t), t.lanes = n, t.stateNode = {
        containerInfo: e.containerInfo,
        pendingChildren: null,
        implementation: e.implementation
    }, t
}

function Ix(e, t, n, r, i) {
    this.tag = t, this.containerInfo = e, this.finishedWork = this.pingCache = this.current = this.pendingChildren = null, this.timeoutHandle = -1, this.callbackNode = this.pendingContext = this.context = null, this.callbackPriority = 0, this.eventTimes = Xa(0), this.expirationTimes = Xa(-1), this.entangledLanes = this.finishedLanes = this.mutableReadLanes = this.expiredLanes = this.pingedLanes = this.suspendedLanes = this.pendingLanes = 0, this.entanglements = Xa(0), this.identifierPrefix = r, this.onRecoverableError = i, this.mutableSourceEagerHydrationData = null
}

function Bc(e, t, n, r, i, o, s, a, l) {
    return e = new Ix(e, t, n, a, l), t === 1 ? (t = 1, o === !0 && (t |= 8)) : t = 0, o = Ct(3, null, null, t), e.current = o, o.stateNode = e, o.memoizedState = {
        element: r,
        isDehydrated: n,
        cache: null,
        transitions: null,
        pendingSuspenseBoundaries: null
    }, Ec(o), e
}

function zx(e, t, n) {
    var r = 3 < arguments.length && arguments[3] !== void 0 ? arguments[3] : null;
    return {
        $$typeof: Lr,
        key: r == null ? null : "" + r,
        children: e,
        containerInfo: t,
        implementation: n
    }
}

function Gg(e) {
    if (!e) return bn;
    e = e._reactInternals;
    e: {
        if (Er(e) !== e || e.tag !== 1) throw Error(L(170));
        var t = e;do {
            switch (t.tag) {
                case 3:
                    t = t.stateNode.context;
                    break e;
                case 1:
                    if (at(t.type)) {
                        t = t.stateNode.__reactInternalMemoizedMergedChildContext;
                        break e
                    }
            }
            t = t.return
        } while (t !== null);
        throw Error(L(171))
    }
    if (e.tag === 1) {
        var n = e.type;
        if (at(n)) return Gm(e, n, t)
    }
    return t
}

function Yg(e, t, n, r, i, o, s, a, l) {
    return e = Bc(n, r, !0, e, i, o, s, a, l), e.context = Gg(null), n = e.current, r = Ze(), i = Fn(n), o = sn(r, i), o.callback = t ? ? null, On(n, o, i), e.current.lanes = i, jo(e, i, r), lt(e, r), e
}

function Aa(e, t, n, r) {
    var i = t.current,
        o = Ze(),
        s = Fn(i);
    return n = Gg(n), t.context === null ? t.context = n : t.pendingContext = n, t = sn(o, s), t.payload = {
        element: e
    }, r = r === void 0 ? null : r, r !== null && (t.callback = r), e = On(i, t, s), e !== null && (It(e, i, s, o), ws(e, i, s)), s
}

function na(e) {
    if (e = e.current, !e.child) return null;
    switch (e.child.tag) {
        case 5:
            return e.child.stateNode;
        default:
            return e.child.stateNode
    }
}

function Qf(e, t) {
    if (e = e.memoizedState, e !== null && e.dehydrated !== null) {
        var n = e.retryLane;
        e.retryLane = n !== 0 && n < t ? n : t
    }
}

function Uc(e, t) {
    Qf(e, t), (e = e.alternate) && Qf(e, t)
}

function bx() {
    return null
}
var Qg = typeof reportError == "function" ? reportError : function(e) {
    console.error(e)
};

function Hc(e) {
    this._internalRoot = e
}
La.prototype.render = Hc.prototype.render = function(e) {
    var t = this._internalRoot;
    if (t === null) throw Error(L(409));
    Aa(e, t, null, null)
};
La.prototype.unmount = Hc.prototype.unmount = function() {
    var e = this._internalRoot;
    if (e !== null) {
        this._internalRoot = null;
        var t = e.containerInfo;
        Sr(function() {
            Aa(null, e, null, null)
        }), t[hn] = null
    }
};

function La(e) {
    this._internalRoot = e
}
La.prototype.unstable_scheduleHydration = function(e) {
    if (e) {
        var t = km();
        e = {
            blockedOn: null,
            target: e,
            priority: t
        };
        for (var n = 0; n < kn.length && t !== 0 && t < kn[n].priority; n++);
        kn.splice(n, 0, e), n === 0 && jm(e)
    }
};

function $c(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11)
}

function Ma(e) {
    return !(!e || e.nodeType !== 1 && e.nodeType !== 9 && e.nodeType !== 11 && (e.nodeType !== 8 || e.nodeValue !== " react-mount-point-unstable "))
}

function Xf() {}

function Bx(e, t, n, r, i) {
    if (i) {
        if (typeof r == "function") {
            var o = r;
            r = function() {
                var u = na(s);
                o.call(u)
            }
        }
        var s = Yg(t, r, e, 0, null, !1, !1, "", Xf);
        return e._reactRootContainer = s, e[hn] = s.current, uo(e.nodeType === 8 ? e.parentNode : e), Sr(), s
    }
    for (; i = e.lastChild;) e.removeChild(i);
    if (typeof r == "function") {
        var a = r;
        r = function() {
            var u = na(l);
            a.call(u)
        }
    }
    var l = Bc(e, 0, !1, null, null, !1, !1, "", Xf);
    return e._reactRootContainer = l, e[hn] = l.current, uo(e.nodeType === 8 ? e.parentNode : e), Sr(function() {
        Aa(t, l, n, r)
    }), l
}

function Na(e, t, n, r, i) {
    var o = n._reactRootContainer;
    if (o) {
        var s = o;
        if (typeof i == "function") {
            var a = i;
            i = function() {
                var l = na(s);
                a.call(l)
            }
        }
        Aa(t, s, e, i)
    } else s = Bx(n, t, e, i, r);
    return na(s)
}
Em = function(e) {
    switch (e.tag) {
        case 3:
            var t = e.stateNode;
            if (t.current.memoizedState.isDehydrated) {
                var n = Ii(t.pendingLanes);
                n !== 0 && (uc(t, n | 1), lt(t, Re()), !(q & 6) && (li = Re() + 500, Kn()))
            }
            break;
        case 13:
            Sr(function() {
                var r = pn(e, 1);
                if (r !== null) {
                    var i = Ze();
                    It(r, e, 1, i)
                }
            }), Uc(e, 1)
    }
};
cc = function(e) {
    if (e.tag === 13) {
        var t = pn(e, 134217728);
        if (t !== null) {
            var n = Ze();
            It(t, e, 134217728, n)
        }
        Uc(e, 134217728)
    }
};
Cm = function(e) {
    if (e.tag === 13) {
        var t = Fn(e),
            n = pn(e, t);
        if (n !== null) {
            var r = Ze();
            It(n, e, t, r)
        }
        Uc(e, t)
    }
};
km = function() {
    return re
};
Rm = function(e, t) {
    var n = re;
    try {
        return re = e, t()
    } finally {
        re = n
    }
};
Yl = function(e, t, n) {
    switch (t) {
        case "input":
            if (Bl(e, n), t = n.name, n.type === "radio" && t != null) {
                for (n = e; n.parentNode;) n = n.parentNode;
                for (n = n.querySelectorAll("input[name=" + JSON.stringify("" + t) + '][type="radio"]'), t = 0; t < n.length; t++) {
                    var r = n[t];
                    if (r !== e && r.form === e.form) {
                        var i = Ta(r);
                        if (!i) throw Error(L(90));
                        im(r), Bl(r, i)
                    }
                }
            }
            break;
        case "textarea":
            sm(e, n);
            break;
        case "select":
            t = n.value, t != null && Yr(e, !!n.multiple, t, !1)
    }
};
hm = Fc;
pm = Sr;
var Ux = {
        usingClientEntryPoint: !1,
        Events: [Lo, Or, Ta, dm, fm, Fc]
    },
    Ai = {
        findFiberByHostInstance: lr,
        bundleType: 0,
        version: "18.3.1",
        rendererPackageName: "react-dom"
    },
    Hx = {
        bundleType: Ai.bundleType,
        version: Ai.version,
        rendererPackageName: Ai.rendererPackageName,
        rendererConfig: Ai.rendererConfig,
        overrideHookState: null,
        overrideHookStateDeletePath: null,
        overrideHookStateRenamePath: null,
        overrideProps: null,
        overridePropsDeletePath: null,
        overridePropsRenamePath: null,
        setErrorHandler: null,
        setSuspenseHandler: null,
        scheduleUpdate: null,
        currentDispatcherRef: vn.ReactCurrentDispatcher,
        findHostInstanceByFiber: function(e) {
            return e = vm(e), e === null ? null : e.stateNode
        },
        findFiberByHostInstance: Ai.findFiberByHostInstance || bx,
        findHostInstancesForRefresh: null,
        scheduleRefresh: null,
        scheduleRoot: null,
        setRefreshHandler: null,
        getCurrentFiber: null,
        reconcilerVersion: "18.3.1-next-f1338f8080-20240426"
    };
if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ < "u") {
    var cs = __REACT_DEVTOOLS_GLOBAL_HOOK__;
    if (!cs.isDisabled && cs.supportsFiber) try {
        ya = cs.inject(Hx), Ht = cs
    } catch {}
}
vt.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED = Ux;
vt.createPortal = function(e, t) {
    var n = 2 < arguments.length && arguments[2] !== void 0 ? arguments[2] : null;
    if (!$c(t)) throw Error(L(200));
    return zx(e, t, null, n)
};
vt.createRoot = function(e, t) {
    if (!$c(e)) throw Error(L(299));
    var n = !1,
        r = "",
        i = Qg;
    return t != null && (t.unstable_strictMode === !0 && (n = !0), t.identifierPrefix !== void 0 && (r = t.identifierPrefix), t.onRecoverableError !== void 0 && (i = t.onRecoverableError)), t = Bc(e, 1, !1, null, null, n, !1, r, i), e[hn] = t.current, uo(e.nodeType === 8 ? e.parentNode : e), new Hc(t)
};
vt.findDOMNode = function(e) {
    if (e == null) return null;
    if (e.nodeType === 1) return e;
    var t = e._reactInternals;
    if (t === void 0) throw typeof e.render == "function" ? Error(L(188)) : (e = Object.keys(e).join(","), Error(L(268, e)));
    return e = vm(t), e = e === null ? null : e.stateNode, e
};
vt.flushSync = function(e) {
    return Sr(e)
};
vt.hydrate = function(e, t, n) {
    if (!Ma(t)) throw Error(L(200));
    return Na(null, e, t, !0, n)
};
vt.hydrateRoot = function(e, t, n) {
    if (!$c(e)) throw Error(L(405));
    var r = n != null && n.hydratedSources || null,
        i = !1,
        o = "",
        s = Qg;
    if (n != null && (n.unstable_strictMode === !0 && (i = !0), n.identifierPrefix !== void 0 && (o = n.identifierPrefix), n.onRecoverableError !== void 0 && (s = n.onRecoverableError)), t = Yg(t, null, e, 1, n ? ? null, i, !1, o, s), e[hn] = t.current, uo(e), r)
        for (e = 0; e < r.length; e++) n = r[e], i = n._getVersion, i = i(n._source), t.mutableSourceEagerHydrationData == null ? t.mutableSourceEagerHydrationData = [n, i] : t.mutableSourceEagerHydrationData.push(n, i);
    return new La(t)
};
vt.render = function(e, t, n) {
    if (!Ma(t)) throw Error(L(200));
    return Na(null, e, t, !1, n)
};
vt.unmountComponentAtNode = function(e) {
    if (!Ma(e)) throw Error(L(40));
    return e._reactRootContainer ? (Sr(function() {
        Na(null, null, e, !1, function() {
            e._reactRootContainer = null, e[hn] = null
        })
    }), !0) : !1
};
vt.unstable_batchedUpdates = Fc;
vt.unstable_renderSubtreeIntoContainer = function(e, t, n, r) {
    if (!Ma(n)) throw Error(L(200));
    if (e == null || e._reactInternals === void 0) throw Error(L(38));
    return Na(e, t, n, !1, r)
};
vt.version = "18.3.1-next-f1338f8080-20240426";

function Xg() {
    if (!(typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ > "u" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE != "function")) try {
        __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(Xg)
    } catch (e) {
        console.error(e)
    }
}
Xg(), Xp.exports = vt;
var Wc = Xp.exports;
const $x = pi(Wc),
    Wx = Ip({
        __proto__: null,
        default: $x
    }, [Wc]);
var Zf = Wc;
_l.createRoot = Zf.createRoot, _l.hydrateRoot = Zf.hydrateRoot;
/**
 * @remix-run/router v1.19.2
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function ve() {
    return ve = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, ve.apply(this, arguments)
}
var Ae;
(function(e) {
    e.Pop = "POP", e.Push = "PUSH", e.Replace = "REPLACE"
})(Ae || (Ae = {}));
const Jf = "popstate";

function Kx(e) {
    e === void 0 && (e = {});

    function t(r, i) {
        let {
            pathname: o,
            search: s,
            hash: a
        } = r.location;
        return xo("", {
            pathname: o,
            search: s,
            hash: a
        }, i.state && i.state.usr || null, i.state && i.state.key || "default")
    }

    function n(r, i) {
        return typeof i == "string" ? i : Tr(i)
    }
    return Yx(t, n, null, e)
}

function Y(e, t) {
    if (e === !1 || e === null || typeof e > "u") throw new Error(t)
}

function ui(e, t) {
    if (!e) {
        typeof console < "u" && console.warn(t);
        try {
            throw new Error(t)
        } catch {}
    }
}

function Gx() {
    return Math.random().toString(36).substr(2, 8)
}

function qf(e, t) {
    return {
        usr: e.state,
        key: e.key,
        idx: t
    }
}

function xo(e, t, n, r) {
    return n === void 0 && (n = null), ve({
        pathname: typeof e == "string" ? e : e.pathname,
        search: "",
        hash: ""
    }, typeof t == "string" ? Gn(t) : t, {
        state: n,
        key: t && t.key || r || Gx()
    })
}

function Tr(e) {
    let {
        pathname: t = "/",
        search: n = "",
        hash: r = ""
    } = e;
    return n && n !== "?" && (t += n.charAt(0) === "?" ? n : "?" + n), r && r !== "#" && (t += r.charAt(0) === "#" ? r : "#" + r), t
}

function Gn(e) {
    let t = {};
    if (e) {
        let n = e.indexOf("#");
        n >= 0 && (t.hash = e.substr(n), e = e.substr(0, n));
        let r = e.indexOf("?");
        r >= 0 && (t.search = e.substr(r), e = e.substr(0, r)), e && (t.pathname = e)
    }
    return t
}

function Yx(e, t, n, r) {
    r === void 0 && (r = {});
    let {
        window: i = document.defaultView,
        v5Compat: o = !1
    } = r, s = i.history, a = Ae.Pop, l = null, u = c();
    u == null && (u = 0, s.replaceState(ve({}, s.state, {
        idx: u
    }), ""));

    function c() {
        return (s.state || {
            idx: null
        }).idx
    }

    function d() {
        a = Ae.Pop;
        let E = c(),
            p = E == null ? null : E - u;
        u = E, l && l({
            action: a,
            location: w.location,
            delta: p
        })
    }

    function f(E, p) {
        a = Ae.Push;
        let h = xo(w.location, E, p);
        u = c() + 1;
        let g = qf(h, u),
            P = w.createHref(h);
        try {
            s.pushState(g, "", P)
        } catch (R) {
            if (R instanceof DOMException && R.name === "DataCloneError") throw R;
            i.location.assign(P)
        }
        o && l && l({
            action: a,
            location: w.location,
            delta: 1
        })
    }

    function m(E, p) {
        a = Ae.Replace;
        let h = xo(w.location, E, p);
        u = c();
        let g = qf(h, u),
            P = w.createHref(h);
        s.replaceState(g, "", P), o && l && l({
            action: a,
            location: w.location,
            delta: 0
        })
    }

    function x(E) {
        let p = i.location.origin !== "null" ? i.location.origin : i.location.href,
            h = typeof E == "string" ? E : Tr(E);
        return h = h.replace(/ $/, "%20"), Y(p, "No window.location.(origin|href) available to create URL for href: " + h), new URL(h, p)
    }
    let w = {
        get action() {
            return a
        },
        get location() {
            return e(i, s)
        },
        listen(E) {
            if (l) throw new Error("A history only accepts one active listener");
            return i.addEventListener(Jf, d), l = E, () => {
                i.removeEventListener(Jf, d), l = null
            }
        },
        createHref(E) {
            return t(i, E)
        },
        createURL: x,
        encodeLocation(E) {
            let p = x(E);
            return {
                pathname: p.pathname,
                search: p.search,
                hash: p.hash
            }
        },
        push: f,
        replace: m,
        go(E) {
            return s.go(E)
        }
    };
    return w
}
var ie;
(function(e) {
    e.data = "data", e.deferred = "deferred", e.redirect = "redirect", e.error = "error"
})(ie || (ie = {}));
const Qx = new Set(["lazy", "caseSensitive", "path", "id", "index", "children"]);

function Xx(e) {
    return e.index === !0
}

function wo(e, t, n, r) {
    return n === void 0 && (n = []), r === void 0 && (r = {}), e.map((i, o) => {
        let s = [...n, String(o)],
            a = typeof i.id == "string" ? i.id : s.join("-");
        if (Y(i.index !== !0 || !i.children, "Cannot specify children on an index route"), Y(!r[a], 'Found a route id collision on id "' + a + `".  Route id's must be globally unique within Data Router usages`), Xx(i)) {
            let l = ve({}, i, t(i), {
                id: a
            });
            return r[a] = l, l
        } else {
            let l = ve({}, i, t(i), {
                id: a,
                children: void 0
            });
            return r[a] = l, i.children && (l.children = wo(i.children, t, s, r)), l
        }
    })
}

function ar(e, t, n) {
    return n === void 0 && (n = "/"), Rs(e, t, n, !1)
}

function Rs(e, t, n, r) {
    let i = typeof t == "string" ? Gn(t) : t,
        o = gn(i.pathname || "/", n);
    if (o == null) return null;
    let s = Zg(e);
    Jx(s);
    let a = null;
    for (let l = 0; a == null && l < s.length; ++l) {
        let u = uw(o);
        a = aw(s[l], u, r)
    }
    return a
}

function Zx(e, t) {
    let {
        route: n,
        pathname: r,
        params: i
    } = e;
    return {
        id: n.id,
        pathname: r,
        params: i,
        data: t[n.id],
        handle: n.handle
    }
}

function Zg(e, t, n, r) {
    t === void 0 && (t = []), n === void 0 && (n = []), r === void 0 && (r = "");
    let i = (o, s, a) => {
        let l = {
            relativePath: a === void 0 ? o.path || "" : a,
            caseSensitive: o.caseSensitive === !0,
            childrenIndex: s,
            route: o
        };
        l.relativePath.startsWith("/") && (Y(l.relativePath.startsWith(r), 'Absolute route path "' + l.relativePath + '" nested under path ' + ('"' + r + '" is not valid. An absolute child route path ') + "must start with the combined path of all its parent routes."), l.relativePath = l.relativePath.slice(r.length));
        let u = an([r, l.relativePath]),
            c = n.concat(l);
        o.children && o.children.length > 0 && (Y(o.index !== !0, "Index routes must not have child routes. Please remove " + ('all child routes from route path "' + u + '".')), Zg(o.children, t, c, u)), !(o.path == null && !o.index) && t.push({
            path: u,
            score: ow(u, o.index),
            routesMeta: c
        })
    };
    return e.forEach((o, s) => {
        var a;
        if (o.path === "" || !((a = o.path) != null && a.includes("?"))) i(o, s);
        else
            for (let l of Jg(o.path)) i(o, s, l)
    }), t
}

function Jg(e) {
    let t = e.split("/");
    if (t.length === 0) return [];
    let [n, ...r] = t, i = n.endsWith("?"), o = n.replace(/\?$/, "");
    if (r.length === 0) return i ? [o, ""] : [o];
    let s = Jg(r.join("/")),
        a = [];
    return a.push(...s.map(l => l === "" ? o : [o, l].join("/"))), i && a.push(...s), a.map(l => e.startsWith("/") && l === "" ? "/" : l)
}

function Jx(e) {
    e.sort((t, n) => t.score !== n.score ? n.score - t.score : sw(t.routesMeta.map(r => r.childrenIndex), n.routesMeta.map(r => r.childrenIndex)))
}
const qx = /^:[\w-]+$/,
    ew = 3,
    tw = 2,
    nw = 1,
    rw = 10,
    iw = -2,
    eh = e => e === "*";

function ow(e, t) {
    let n = e.split("/"),
        r = n.length;
    return n.some(eh) && (r += iw), t && (r += tw), n.filter(i => !eh(i)).reduce((i, o) => i + (qx.test(o) ? ew : o === "" ? nw : rw), r)
}

function sw(e, t) {
    return e.length === t.length && e.slice(0, -1).every((r, i) => r === t[i]) ? e[e.length - 1] - t[t.length - 1] : 0
}

function aw(e, t, n) {
    n === void 0 && (n = !1);
    let {
        routesMeta: r
    } = e, i = {}, o = "/", s = [];
    for (let a = 0; a < r.length; ++a) {
        let l = r[a],
            u = a === r.length - 1,
            c = o === "/" ? t : t.slice(o.length) || "/",
            d = ra({
                path: l.relativePath,
                caseSensitive: l.caseSensitive,
                end: u
            }, c),
            f = l.route;
        if (!d && u && n && !r[r.length - 1].route.index && (d = ra({
                path: l.relativePath,
                caseSensitive: l.caseSensitive,
                end: !1
            }, c)), !d) return null;
        Object.assign(i, d.params), s.push({
            params: i,
            pathname: an([o, d.pathname]),
            pathnameBase: fw(an([o, d.pathnameBase])),
            route: f
        }), d.pathnameBase !== "/" && (o = an([o, d.pathnameBase]))
    }
    return s
}

function ra(e, t) {
    typeof e == "string" && (e = {
        path: e,
        caseSensitive: !1,
        end: !0
    });
    let [n, r] = lw(e.path, e.caseSensitive, e.end), i = t.match(n);
    if (!i) return null;
    let o = i[0],
        s = o.replace(/(.)\/+$/, "$1"),
        a = i.slice(1);
    return {
        params: r.reduce((u, c, d) => {
            let {
                paramName: f,
                isOptional: m
            } = c;
            if (f === "*") {
                let w = a[d] || "";
                s = o.slice(0, o.length - w.length).replace(/(.)\/+$/, "$1")
            }
            const x = a[d];
            return m && !x ? u[f] = void 0 : u[f] = (x || "").replace(/%2F/g, "/"), u
        }, {}),
        pathname: o,
        pathnameBase: s,
        pattern: e
    }
}

function lw(e, t, n) {
    t === void 0 && (t = !1), n === void 0 && (n = !0), ui(e === "*" || !e.endsWith("*") || e.endsWith("/*"), 'Route path "' + e + '" will be treated as if it were ' + ('"' + e.replace(/\*$/, "/*") + '" because the `*` character must ') + "always follow a `/` in the pattern. To get rid of this warning, " + ('please change the route path to "' + e.replace(/\*$/, "/*") + '".'));
    let r = [],
        i = "^" + e.replace(/\/*\*?$/, "").replace(/^\/*/, "/").replace(/[\\.*+^${}|()[\]]/g, "\\$&").replace(/\/:([\w-]+)(\?)?/g, (s, a, l) => (r.push({
            paramName: a,
            isOptional: l != null
        }), l ? "/?([^\\/]+)?" : "/([^\\/]+)"));
    return e.endsWith("*") ? (r.push({
        paramName: "*"
    }), i += e === "*" || e === "/*" ? "(.*)$" : "(?:\\/(.+)|\\/*)$") : n ? i += "\\/*$" : e !== "" && e !== "/" && (i += "(?:(?=\\/|$))"), [new RegExp(i, t ? void 0 : "i"), r]
}

function uw(e) {
    try {
        return e.split("/").map(t => decodeURIComponent(t).replace(/\//g, "%2F")).join("/")
    } catch (t) {
        return ui(!1, 'The URL path "' + e + '" could not be decoded because it is is a malformed URL segment. This is probably due to a bad percent ' + ("encoding (" + t + ").")), e
    }
}

function gn(e, t) {
    if (t === "/") return e;
    if (!e.toLowerCase().startsWith(t.toLowerCase())) return null;
    let n = t.endsWith("/") ? t.length - 1 : t.length,
        r = e.charAt(n);
    return r && r !== "/" ? null : e.slice(n) || "/"
}

function cw(e, t) {
    t === void 0 && (t = "/");
    let {
        pathname: n,
        search: r = "",
        hash: i = ""
    } = typeof e == "string" ? Gn(e) : e;
    return {
        pathname: n ? n.startsWith("/") ? n : dw(n, t) : t,
        search: hw(r),
        hash: pw(i)
    }
}

function dw(e, t) {
    let n = t.replace(/\/+$/, "").split("/");
    return e.split("/").forEach(i => {
        i === ".." ? n.length > 1 && n.pop() : i !== "." && n.push(i)
    }), n.length > 1 ? n.join("/") : "/"
}

function vl(e, t, n, r) {
    return "Cannot include a '" + e + "' character in a manually specified " + ("`to." + t + "` field [" + JSON.stringify(r) + "].  Please separate it out to the ") + ("`to." + n + "` field. Alternatively you may provide the full path as ") + 'a string in <Link to="..."> and the router will parse it for you.'
}

function qg(e) {
    return e.filter((t, n) => n === 0 || t.route.path && t.route.path.length > 0)
}

function Kc(e, t) {
    let n = qg(e);
    return t ? n.map((r, i) => i === n.length - 1 ? r.pathname : r.pathnameBase) : n.map(r => r.pathnameBase)
}

function Gc(e, t, n, r) {
    r === void 0 && (r = !1);
    let i;
    typeof e == "string" ? i = Gn(e) : (i = ve({}, e), Y(!i.pathname || !i.pathname.includes("?"), vl("?", "pathname", "search", i)), Y(!i.pathname || !i.pathname.includes("#"), vl("#", "pathname", "hash", i)), Y(!i.search || !i.search.includes("#"), vl("#", "search", "hash", i)));
    let o = e === "" || i.pathname === "",
        s = o ? "/" : i.pathname,
        a;
    if (s == null) a = n;
    else {
        let d = t.length - 1;
        if (!r && s.startsWith("..")) {
            let f = s.split("/");
            for (; f[0] === "..";) f.shift(), d -= 1;
            i.pathname = f.join("/")
        }
        a = d >= 0 ? t[d] : "/"
    }
    let l = cw(i, a),
        u = s && s !== "/" && s.endsWith("/"),
        c = (o || s === ".") && n.endsWith("/");
    return !l.pathname.endsWith("/") && (u || c) && (l.pathname += "/"), l
}
const an = e => e.join("/").replace(/\/\/+/g, "/"),
    fw = e => e.replace(/\/+$/, "").replace(/^\/*/, "/"),
    hw = e => !e || e === "?" ? "" : e.startsWith("?") ? e : "?" + e,
    pw = e => !e || e === "#" ? "" : e.startsWith("#") ? e : "#" + e;
class ia {
    constructor(t, n, r, i) {
        i === void 0 && (i = !1), this.status = t, this.statusText = n || "", this.internal = i, r instanceof Error ? (this.data = r.toString(), this.error = r) : this.data = r
    }
}

function Da(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.internal == "boolean" && "data" in e
}
const e0 = ["post", "put", "patch", "delete"],
    mw = new Set(e0),
    gw = ["get", ...e0],
    vw = new Set(gw),
    yw = new Set([301, 302, 303, 307, 308]),
    xw = new Set([307, 308]),
    yl = {
        state: "idle",
        location: void 0,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    },
    ww = {
        state: "idle",
        data: void 0,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    },
    Li = {
        state: "unblocked",
        proceed: void 0,
        reset: void 0,
        location: void 0
    },
    Yc = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    Sw = e => ({
        hasErrorBoundary: !!e.hasErrorBoundary
    }),
    t0 = "remix-router-transitions";

function Tw(e) {
    const t = e.window ? e.window : typeof window < "u" ? window : void 0,
        n = typeof t < "u" && typeof t.document < "u" && typeof t.document.createElement < "u",
        r = !n;
    Y(e.routes.length > 0, "You must provide a non-empty routes array to createRouter");
    let i;
    if (e.mapRouteProperties) i = e.mapRouteProperties;
    else if (e.detectErrorBoundary) {
        let S = e.detectErrorBoundary;
        i = T => ({
            hasErrorBoundary: S(T)
        })
    } else i = Sw;
    let o = {},
        s = wo(e.routes, i, void 0, o),
        a, l = e.basename || "/",
        u = e.unstable_dataStrategy || jw,
        c = e.unstable_patchRoutesOnNavigation,
        d = ve({
            v7_fetcherPersist: !1,
            v7_normalizeFormMethod: !1,
            v7_partialHydration: !1,
            v7_prependBasename: !1,
            v7_relativeSplatPath: !1,
            v7_skipActionErrorRevalidation: !1
        }, e.future),
        f = null,
        m = new Set,
        x = 1e3,
        w = new Set,
        E = null,
        p = null,
        h = null,
        g = e.hydrationData != null,
        P = ar(s, e.history.location, l),
        R = null;
    if (P == null && !c) {
        let S = Qe(404, {
                pathname: e.history.location.pathname
            }),
            {
                matches: T,
                route: k
            } = uh(s);
        P = T, R = {
            [k.id]: S
        }
    }
    P && !e.hydrationData && Uo(P, s, e.history.location.pathname).active && (P = null);
    let A;
    if (P)
        if (P.some(S => S.route.lazy)) A = !1;
        else if (!P.some(S => S.route.loader)) A = !0;
    else if (d.v7_partialHydration) {
        let S = e.hydrationData ? e.hydrationData.loaderData : null,
            T = e.hydrationData ? e.hydrationData.errors : null,
            k = j => j.route.loader ? typeof j.route.loader == "function" && j.route.loader.hydrate === !0 ? !1 : S && S[j.route.id] !== void 0 || T && T[j.route.id] !== void 0 : !0;
        if (T) {
            let j = P.findIndex(V => T[V.route.id] !== void 0);
            A = P.slice(0, j + 1).every(k)
        } else A = P.every(k)
    } else A = e.hydrationData != null;
    else if (A = !1, P = [], d.v7_partialHydration) {
        let S = Uo(null, s, e.history.location.pathname);
        S.active && S.matches && (P = S.matches)
    }
    let N, y = {
            historyAction: e.history.action,
            location: e.history.location,
            matches: P,
            initialized: A,
            navigation: yl,
            restoreScrollPosition: e.hydrationData != null ? !1 : null,
            preventScrollReset: !1,
            revalidation: "idle",
            loaderData: e.hydrationData && e.hydrationData.loaderData || {},
            actionData: e.hydrationData && e.hydrationData.actionData || null,
            errors: e.hydrationData && e.hydrationData.errors || R,
            fetchers: new Map,
            blockers: new Map
        },
        O = Ae.Pop,
        M = !1,
        U, te = !1,
        Te = new Map,
        le = null,
        At = !1,
        xt = !1,
        he = [],
        D = new Set,
        F = new Map,
        W = 0,
        se = -1,
        ue = new Map,
        tt = new Set,
        nt = new Map,
        Gt = new Map,
        Ve = new Set,
        wt = new Map,
        Jn = new Map,
        ey = new Map,
        Io;

    function ty() {
        if (f = e.history.listen(S => {
                let {
                    action: T,
                    location: k,
                    delta: j
                } = S;
                if (Io) {
                    Io(), Io = void 0;
                    return
                }
                ui(Jn.size === 0 || j != null, "You are trying to use a blocker on a POP navigation to a location that was not created by @remix-run/router. This will fail silently in production. This can happen if you are navigating outside the router via `window.history.pushState`/`window.location.hash` instead of using router navigation APIs.  This can also happen if you are using createHashRouter and the user manually changes the URL.");
                let V = Fd({
                    currentLocation: y.location,
                    nextLocation: k,
                    historyAction: T
                });
                if (V && j != null) {
                    let B = new Promise(K => {
                        Io = K
                    });
                    e.history.go(j * -1), bo(V, {
                        state: "blocked",
                        location: k,
                        proceed() {
                            bo(V, {
                                state: "proceeding",
                                proceed: void 0,
                                reset: void 0,
                                location: k
                            }), B.then(() => e.history.go(j))
                        },
                        reset() {
                            let K = new Map(y.blockers);
                            K.set(V, Li), Ye({
                                blockers: K
                            })
                        }
                    });
                    return
                }
                return qn(T, k)
            }), n) {
            Hw(t, Te);
            let S = () => $w(t, Te);
            t.addEventListener("pagehide", S), le = () => t.removeEventListener("pagehide", S)
        }
        return y.initialized || qn(Ae.Pop, y.location, {
            initialHydration: !0
        }), N
    }

    function ny() {
        f && f(), le && le(), m.clear(), U && U.abort(), y.fetchers.forEach((S, T) => zo(T)), y.blockers.forEach((S, T) => Vd(T))
    }

    function ry(S) {
        return m.add(S), () => m.delete(S)
    }

    function Ye(S, T) {
        T === void 0 && (T = {}), y = ve({}, y, S);
        let k = [],
            j = [];
        d.v7_fetcherPersist && y.fetchers.forEach((V, B) => {
            V.state === "idle" && (Ve.has(B) ? j.push(B) : k.push(B))
        }), [...m].forEach(V => V(y, {
            deletedFetchers: j,
            unstable_viewTransitionOpts: T.viewTransitionOpts,
            unstable_flushSync: T.flushSync === !0
        })), d.v7_fetcherPersist && (k.forEach(V => y.fetchers.delete(V)), j.forEach(V => zo(V)))
    }

    function Cr(S, T, k) {
        var j, V;
        let {
            flushSync: B
        } = k === void 0 ? {} : k, K = y.actionData != null && y.navigation.formMethod != null && Dt(y.navigation.formMethod) && y.navigation.state === "loading" && ((j = S.state) == null ? void 0 : j._isRedirect) !== !0, _;
        T.actionData ? Object.keys(T.actionData).length > 0 ? _ = T.actionData : _ = null : K ? _ = y.actionData : _ = null;
        let H = T.loaderData ? ah(y.loaderData, T.loaderData, T.matches || [], T.errors) : y.loaderData,
            z = y.blockers;
        z.size > 0 && (z = new Map(z), z.forEach((ne, ce) => z.set(ce, Li)));
        let b = M === !0 || y.navigation.formMethod != null && Dt(y.navigation.formMethod) && ((V = S.state) == null ? void 0 : V._isRedirect) !== !0;
        a && (s = a, a = void 0), At || O === Ae.Pop || (O === Ae.Push ? e.history.push(S, S.state) : O === Ae.Replace && e.history.replace(S, S.state));
        let ee;
        if (O === Ae.Pop) {
            let ne = Te.get(y.location.pathname);
            ne && ne.has(S.pathname) ? ee = {
                currentLocation: y.location,
                nextLocation: S
            } : Te.has(S.pathname) && (ee = {
                currentLocation: S,
                nextLocation: y.location
            })
        } else if (te) {
            let ne = Te.get(y.location.pathname);
            ne ? ne.add(S.pathname) : (ne = new Set([S.pathname]), Te.set(y.location.pathname, ne)), ee = {
                currentLocation: y.location,
                nextLocation: S
            }
        }
        Ye(ve({}, T, {
            actionData: _,
            loaderData: H,
            historyAction: O,
            location: S,
            initialized: !0,
            navigation: yl,
            revalidation: "idle",
            restoreScrollPosition: zd(S, T.matches || y.matches),
            preventScrollReset: b,
            blockers: z
        }), {
            viewTransitionOpts: ee,
            flushSync: B === !0
        }), O = Ae.Pop, M = !1, te = !1, At = !1, xt = !1, he = []
    }
    async function Ad(S, T) {
        if (typeof S == "number") {
            e.history.go(S);
            return
        }
        let k = Ru(y.location, y.matches, l, d.v7_prependBasename, S, d.v7_relativeSplatPath, T == null ? void 0 : T.fromRouteId, T == null ? void 0 : T.relative),
            {
                path: j,
                submission: V,
                error: B
            } = th(d.v7_normalizeFormMethod, !1, k, T),
            K = y.location,
            _ = xo(y.location, j, T && T.state);
        _ = ve({}, _, e.history.encodeLocation(_));
        let H = T && T.replace != null ? T.replace : void 0,
            z = Ae.Push;
        H === !0 ? z = Ae.Replace : H === !1 || V != null && Dt(V.formMethod) && V.formAction === y.location.pathname + y.location.search && (z = Ae.Replace);
        let b = T && "preventScrollReset" in T ? T.preventScrollReset === !0 : void 0,
            ee = (T && T.unstable_flushSync) === !0,
            ne = Fd({
                currentLocation: K,
                nextLocation: _,
                historyAction: z
            });
        if (ne) {
            bo(ne, {
                state: "blocked",
                location: _,
                proceed() {
                    bo(ne, {
                        state: "proceeding",
                        proceed: void 0,
                        reset: void 0,
                        location: _
                    }), Ad(S, T)
                },
                reset() {
                    let ce = new Map(y.blockers);
                    ce.set(ne, Li), Ye({
                        blockers: ce
                    })
                }
            });
            return
        }
        return await qn(z, _, {
            submission: V,
            pendingError: B,
            preventScrollReset: b,
            replace: T && T.replace,
            enableViewTransition: T && T.unstable_viewTransition,
            flushSync: ee
        })
    }

    function iy() {
        if (Ua(), Ye({
                revalidation: "loading"
            }), y.navigation.state !== "submitting") {
            if (y.navigation.state === "idle") {
                qn(y.historyAction, y.location, {
                    startUninterruptedRevalidation: !0
                });
                return
            }
            qn(O || y.historyAction, y.navigation.location, {
                overrideNavigation: y.navigation,
                enableViewTransition: te === !0
            })
        }
    }
    async function qn(S, T, k) {
        U && U.abort(), U = null, O = S, At = (k && k.startUninterruptedRevalidation) === !0, py(y.location, y.matches), M = (k && k.preventScrollReset) === !0, te = (k && k.enableViewTransition) === !0;
        let j = a || s,
            V = k && k.overrideNavigation,
            B = ar(j, T, l),
            K = (k && k.flushSync) === !0,
            _ = Uo(B, j, T.pathname);
        if (_.active && _.matches && (B = _.matches), !B) {
            let {
                error: Z,
                notFoundMatches: De,
                route: je
            } = Ha(T.pathname);
            Cr(T, {
                matches: De,
                loaderData: {},
                errors: {
                    [je.id]: Z
                }
            }, {
                flushSync: K
            });
            return
        }
        if (y.initialized && !xt && _w(y.location, T) && !(k && k.submission && Dt(k.submission.formMethod))) {
            Cr(T, {
                matches: B
            }, {
                flushSync: K
            });
            return
        }
        U = new AbortController;
        let H = jr(e.history, T, U.signal, k && k.submission),
            z;
        if (k && k.pendingError) z = [Ur(B).route.id, {
            type: ie.error,
            error: k.pendingError
        }];
        else if (k && k.submission && Dt(k.submission.formMethod)) {
            let Z = await oy(H, T, k.submission, B, _.active, {
                replace: k.replace,
                flushSync: K
            });
            if (Z.shortCircuited) return;
            if (Z.pendingActionResult) {
                let [De, je] = Z.pendingActionResult;
                if (dt(je) && Da(je.error) && je.error.status === 404) {
                    U = null, Cr(T, {
                        matches: Z.matches,
                        loaderData: {},
                        errors: {
                            [De]: je.error
                        }
                    });
                    return
                }
            }
            B = Z.matches || B, z = Z.pendingActionResult, V = xl(T, k.submission), K = !1, _.active = !1, H = jr(e.history, H.url, H.signal)
        }
        let {
            shortCircuited: b,
            matches: ee,
            loaderData: ne,
            errors: ce
        } = await sy(H, T, B, _.active, V, k && k.submission, k && k.fetcherSubmission, k && k.replace, k && k.initialHydration === !0, K, z);
        b || (U = null, Cr(T, ve({
            matches: ee || B
        }, lh(z), {
            loaderData: ne,
            errors: ce
        })))
    }
    async function oy(S, T, k, j, V, B) {
        B === void 0 && (B = {}), Ua();
        let K = Bw(T, k);
        if (Ye({
                navigation: K
            }, {
                flushSync: B.flushSync === !0
            }), V) {
            let z = await Ho(j, T.pathname, S.signal);
            if (z.type === "aborted") return {
                shortCircuited: !0
            };
            if (z.type === "error") {
                let {
                    boundaryId: b,
                    error: ee
                } = Bo(T.pathname, z);
                return {
                    matches: z.partialMatches,
                    pendingActionResult: [b, {
                        type: ie.error,
                        error: ee
                    }]
                }
            } else if (z.matches) j = z.matches;
            else {
                let {
                    notFoundMatches: b,
                    error: ee,
                    route: ne
                } = Ha(T.pathname);
                return {
                    matches: b,
                    pendingActionResult: [ne.id, {
                        type: ie.error,
                        error: ee
                    }]
                }
            }
        }
        let _, H = bi(j, T);
        if (!H.route.action && !H.route.lazy) _ = {
            type: ie.error,
            error: Qe(405, {
                method: S.method,
                pathname: T.pathname,
                routeId: H.route.id
            })
        };
        else if (_ = (await wi("action", y, S, [H], j, null))[H.route.id], S.signal.aborted) return {
            shortCircuited: !0
        };
        if (dr(_)) {
            let z;
            return B && B.replace != null ? z = B.replace : z = ih(_.response.headers.get("Location"), new URL(S.url), l) === y.location.pathname + y.location.search, await er(S, _, !0, {
                submission: k,
                replace: z
            }), {
                shortCircuited: !0
            }
        }
        if (Ln(_)) throw Qe(400, {
            type: "defer-action"
        });
        if (dt(_)) {
            let z = Ur(j, H.route.id);
            return (B && B.replace) !== !0 && (O = Ae.Push), {
                matches: j,
                pendingActionResult: [z.route.id, _]
            }
        }
        return {
            matches: j,
            pendingActionResult: [H.route.id, _]
        }
    }
    async function sy(S, T, k, j, V, B, K, _, H, z, b) {
        let ee = V || xl(T, B),
            ne = B || K || dh(ee),
            ce = !At && (!d.v7_partialHydration || !H);
        if (j) {
            if (ce) {
                let Pe = Ld(b);
                Ye(ve({
                    navigation: ee
                }, Pe !== void 0 ? {
                    actionData: Pe
                } : {}), {
                    flushSync: z
                })
            }
            let Q = await Ho(k, T.pathname, S.signal);
            if (Q.type === "aborted") return {
                shortCircuited: !0
            };
            if (Q.type === "error") {
                let {
                    boundaryId: Pe,
                    error: ut
                } = Bo(T.pathname, Q);
                return {
                    matches: Q.partialMatches,
                    loaderData: {},
                    errors: {
                        [Pe]: ut
                    }
                }
            } else if (Q.matches) k = Q.matches;
            else {
                let {
                    error: Pe,
                    notFoundMatches: ut,
                    route: Ee
                } = Ha(T.pathname);
                return {
                    matches: ut,
                    loaderData: {},
                    errors: {
                        [Ee.id]: Pe
                    }
                }
            }
        }
        let Z = a || s,
            [De, je] = nh(e.history, y, k, ne, T, d.v7_partialHydration && H === !0, d.v7_skipActionErrorRevalidation, xt, he, D, Ve, nt, tt, Z, l, b);
        if ($a(Q => !(k && k.some(Pe => Pe.route.id === Q)) || De && De.some(Pe => Pe.route.id === Q)), se = ++W, De.length === 0 && je.length === 0) {
            let Q = _d();
            return Cr(T, ve({
                matches: k,
                loaderData: {},
                errors: b && dt(b[1]) ? {
                    [b[0]]: b[1].error
                } : null
            }, lh(b), Q ? {
                fetchers: new Map(y.fetchers)
            } : {}), {
                flushSync: z
            }), {
                shortCircuited: !0
            }
        }
        if (ce) {
            let Q = {};
            if (!j) {
                Q.navigation = ee;
                let Pe = Ld(b);
                Pe !== void 0 && (Q.actionData = Pe)
            }
            je.length > 0 && (Q.fetchers = ay(je)), Ye(Q, {
                flushSync: z
            })
        }
        je.forEach(Q => {
            F.has(Q.key) && xn(Q.key), Q.controller && F.set(Q.key, Q.controller)
        });
        let Si = () => je.forEach(Q => xn(Q.key));
        U && U.signal.addEventListener("abort", Si);
        let {
            loaderResults: Qt,
            fetcherResults: kr
        } = await Md(y, k, De, je, S);
        if (S.signal.aborted) return {
            shortCircuited: !0
        };
        U && U.signal.removeEventListener("abort", Si), je.forEach(Q => F.delete(Q.key));
        let wn = ds(Qt);
        if (wn) return await er(S, wn.result, !0, {
            replace: _
        }), {
            shortCircuited: !0
        };
        if (wn = ds(kr), wn) return tt.add(wn.key), await er(S, wn.result, !0, {
            replace: _
        }), {
            shortCircuited: !0
        };
        let {
            loaderData: $o,
            errors: Xt
        } = sh(y, k, De, Qt, b, je, kr, wt);
        wt.forEach((Q, Pe) => {
            Q.subscribe(ut => {
                (ut || Q.done) && wt.delete(Pe)
            })
        }), d.v7_partialHydration && H && y.errors && Object.entries(y.errors).filter(Q => {
            let [Pe] = Q;
            return !De.some(ut => ut.route.id === Pe)
        }).forEach(Q => {
            let [Pe, ut] = Q;
            Xt = Object.assign(Xt || {}, {
                [Pe]: ut
            })
        });
        let Wo = _d(),
            Ko = Od(se),
            Go = Wo || Ko || je.length > 0;
        return ve({
            matches: k,
            loaderData: $o,
            errors: Xt
        }, Go ? {
            fetchers: new Map(y.fetchers)
        } : {})
    }

    function Ld(S) {
        if (S && !dt(S[1])) return {
            [S[0]]: S[1].data
        };
        if (y.actionData) return Object.keys(y.actionData).length === 0 ? null : y.actionData
    }

    function ay(S) {
        return S.forEach(T => {
            let k = y.fetchers.get(T.key),
                j = Mi(void 0, k ? k.data : void 0);
            y.fetchers.set(T.key, j)
        }), new Map(y.fetchers)
    }

    function ly(S, T, k, j) {
        if (r) throw new Error("router.fetch() was called during the server render, but it shouldn't be. You are likely calling a useFetcher() method in the body of your component. Try moving it to a useEffect or a callback.");
        F.has(S) && xn(S);
        let V = (j && j.unstable_flushSync) === !0,
            B = a || s,
            K = Ru(y.location, y.matches, l, d.v7_prependBasename, k, d.v7_relativeSplatPath, T, j == null ? void 0 : j.relative),
            _ = ar(B, K, l),
            H = Uo(_, B, K);
        if (H.active && H.matches && (_ = H.matches), !_) {
            Yt(S, T, Qe(404, {
                pathname: K
            }), {
                flushSync: V
            });
            return
        }
        let {
            path: z,
            submission: b,
            error: ee
        } = th(d.v7_normalizeFormMethod, !0, K, j);
        if (ee) {
            Yt(S, T, ee, {
                flushSync: V
            });
            return
        }
        let ne = bi(_, z);
        if (M = (j && j.preventScrollReset) === !0, b && Dt(b.formMethod)) {
            uy(S, T, z, ne, _, H.active, V, b);
            return
        }
        nt.set(S, {
            routeId: T,
            path: z
        }), cy(S, T, z, ne, _, H.active, V, b)
    }
    async function uy(S, T, k, j, V, B, K, _) {
        Ua(), nt.delete(S);

        function H(Ee) {
            if (!Ee.route.action && !Ee.route.lazy) {
                let Zt = Qe(405, {
                    method: _.formMethod,
                    pathname: k,
                    routeId: T
                });
                return Yt(S, T, Zt, {
                    flushSync: K
                }), !0
            }
            return !1
        }
        if (!B && H(j)) return;
        let z = y.fetchers.get(S);
        yn(S, Uw(_, z), {
            flushSync: K
        });
        let b = new AbortController,
            ee = jr(e.history, k, b.signal, _);
        if (B) {
            let Ee = await Ho(V, k, ee.signal);
            if (Ee.type === "aborted") return;
            if (Ee.type === "error") {
                let {
                    error: Zt
                } = Bo(k, Ee);
                Yt(S, T, Zt, {
                    flushSync: K
                });
                return
            } else if (Ee.matches) {
                if (V = Ee.matches, j = bi(V, k), H(j)) return
            } else {
                Yt(S, T, Qe(404, {
                    pathname: k
                }), {
                    flushSync: K
                });
                return
            }
        }
        F.set(S, b);
        let ne = W,
            Z = (await wi("action", y, ee, [j], V, S))[j.route.id];
        if (ee.signal.aborted) {
            F.get(S) === b && F.delete(S);
            return
        }
        if (d.v7_fetcherPersist && Ve.has(S)) {
            if (dr(Z) || dt(Z)) {
                yn(S, Tn(void 0));
                return
            }
        } else {
            if (dr(Z))
                if (F.delete(S), se > ne) {
                    yn(S, Tn(void 0));
                    return
                } else return tt.add(S), yn(S, Mi(_)), er(ee, Z, !1, {
                    fetcherSubmission: _
                });
            if (dt(Z)) {
                Yt(S, T, Z.error);
                return
            }
        }
        if (Ln(Z)) throw Qe(400, {
            type: "defer-action"
        });
        let De = y.navigation.location || y.location,
            je = jr(e.history, De, b.signal),
            Si = a || s,
            Qt = y.navigation.state !== "idle" ? ar(Si, y.navigation.location, l) : y.matches;
        Y(Qt, "Didn't find any matches after fetcher action");
        let kr = ++W;
        ue.set(S, kr);
        let wn = Mi(_, Z.data);
        y.fetchers.set(S, wn);
        let [$o, Xt] = nh(e.history, y, Qt, _, De, !1, d.v7_skipActionErrorRevalidation, xt, he, D, Ve, nt, tt, Si, l, [j.route.id, Z]);
        Xt.filter(Ee => Ee.key !== S).forEach(Ee => {
            let Zt = Ee.key,
                Bd = y.fetchers.get(Zt),
                vy = Mi(void 0, Bd ? Bd.data : void 0);
            y.fetchers.set(Zt, vy), F.has(Zt) && xn(Zt), Ee.controller && F.set(Zt, Ee.controller)
        }), Ye({
            fetchers: new Map(y.fetchers)
        });
        let Wo = () => Xt.forEach(Ee => xn(Ee.key));
        b.signal.addEventListener("abort", Wo);
        let {
            loaderResults: Ko,
            fetcherResults: Go
        } = await Md(y, Qt, $o, Xt, je);
        if (b.signal.aborted) return;
        b.signal.removeEventListener("abort", Wo), ue.delete(S), F.delete(S), Xt.forEach(Ee => F.delete(Ee.key));
        let Q = ds(Ko);
        if (Q) return er(je, Q.result, !1);
        if (Q = ds(Go), Q) return tt.add(Q.key), er(je, Q.result, !1);
        let {
            loaderData: Pe,
            errors: ut
        } = sh(y, Qt, $o, Ko, void 0, Xt, Go, wt);
        if (y.fetchers.has(S)) {
            let Ee = Tn(Z.data);
            y.fetchers.set(S, Ee)
        }
        Od(kr), y.navigation.state === "loading" && kr > se ? (Y(O, "Expected pending action"), U && U.abort(), Cr(y.navigation.location, {
            matches: Qt,
            loaderData: Pe,
            errors: ut,
            fetchers: new Map(y.fetchers)
        })) : (Ye({
            errors: ut,
            loaderData: ah(y.loaderData, Pe, Qt, ut),
            fetchers: new Map(y.fetchers)
        }), xt = !1)
    }
    async function cy(S, T, k, j, V, B, K, _) {
        let H = y.fetchers.get(S);
        yn(S, Mi(_, H ? H.data : void 0), {
            flushSync: K
        });
        let z = new AbortController,
            b = jr(e.history, k, z.signal);
        if (B) {
            let Z = await Ho(V, k, b.signal);
            if (Z.type === "aborted") return;
            if (Z.type === "error") {
                let {
                    error: De
                } = Bo(k, Z);
                Yt(S, T, De, {
                    flushSync: K
                });
                return
            } else if (Z.matches) V = Z.matches, j = bi(V, k);
            else {
                Yt(S, T, Qe(404, {
                    pathname: k
                }), {
                    flushSync: K
                });
                return
            }
        }
        F.set(S, z);
        let ee = W,
            ce = (await wi("loader", y, b, [j], V, S))[j.route.id];
        if (Ln(ce) && (ce = await Qc(ce, b.signal, !0) || ce), F.get(S) === z && F.delete(S), !b.signal.aborted) {
            if (Ve.has(S)) {
                yn(S, Tn(void 0));
                return
            }
            if (dr(ce))
                if (se > ee) {
                    yn(S, Tn(void 0));
                    return
                } else {
                    tt.add(S), await er(b, ce, !1);
                    return
                }
            if (dt(ce)) {
                Yt(S, T, ce.error);
                return
            }
            Y(!Ln(ce), "Unhandled fetcher deferred data"), yn(S, Tn(ce.data))
        }
    }
    async function er(S, T, k, j) {
        let {
            submission: V,
            fetcherSubmission: B,
            replace: K
        } = j === void 0 ? {} : j;
        T.response.headers.has("X-Remix-Revalidate") && (xt = !0);
        let _ = T.response.headers.get("Location");
        Y(_, "Expected a Location header on the redirect Response"), _ = ih(_, new URL(S.url), l);
        let H = xo(y.location, _, {
            _isRedirect: !0
        });
        if (n) {
            let Z = !1;
            if (T.response.headers.has("X-Remix-Reload-Document")) Z = !0;
            else if (Yc.test(_)) {
                const De = e.history.createURL(_);
                Z = De.origin !== t.location.origin || gn(De.pathname, l) == null
            }
            if (Z) {
                K ? t.location.replace(_) : t.location.assign(_);
                return
            }
        }
        U = null;
        let z = K === !0 || T.response.headers.has("X-Remix-Replace") ? Ae.Replace : Ae.Push,
            {
                formMethod: b,
                formAction: ee,
                formEncType: ne
            } = y.navigation;
        !V && !B && b && ee && ne && (V = dh(y.navigation));
        let ce = V || B;
        if (xw.has(T.response.status) && ce && Dt(ce.formMethod)) await qn(z, H, {
            submission: ve({}, ce, {
                formAction: _
            }),
            preventScrollReset: M,
            enableViewTransition: k ? te : void 0
        });
        else {
            let Z = xl(H, V);
            await qn(z, H, {
                overrideNavigation: Z,
                fetcherSubmission: B,
                preventScrollReset: M,
                enableViewTransition: k ? te : void 0
            })
        }
    }
    async function wi(S, T, k, j, V, B) {
        let K, _ = {};
        try {
            K = await Aw(u, S, T, k, j, V, B, o, i)
        } catch (H) {
            return j.forEach(z => {
                _[z.route.id] = {
                    type: ie.error,
                    error: H
                }
            }), _
        }
        for (let [H, z] of Object.entries(K))
            if (Vw(z)) {
                let b = z.result;
                _[H] = {
                    type: ie.redirect,
                    response: Nw(b, k, H, V, l, d.v7_relativeSplatPath)
                }
            } else _[H] = await Mw(z);
        return _
    }
    async function Md(S, T, k, j, V) {
        let B = S.matches,
            K = wi("loader", S, V, k, T, null),
            _ = Promise.all(j.map(async b => {
                if (b.matches && b.match && b.controller) {
                    let ne = (await wi("loader", S, jr(e.history, b.path, b.controller.signal), [b.match], b.matches, b.key))[b.match.route.id];
                    return {
                        [b.key]: ne
                    }
                } else return Promise.resolve({
                    [b.key]: {
                        type: ie.error,
                        error: Qe(404, {
                            pathname: b.path
                        })
                    }
                })
            })),
            H = await K,
            z = (await _).reduce((b, ee) => Object.assign(b, ee), {});
        return await Promise.all([zw(T, H, V.signal, B, S.loaderData), bw(T, z, j)]), {
            loaderResults: H,
            fetcherResults: z
        }
    }

    function Ua() {
        xt = !0, he.push(...$a()), nt.forEach((S, T) => {
            F.has(T) && (D.add(T), xn(T))
        })
    }

    function yn(S, T, k) {
        k === void 0 && (k = {}), y.fetchers.set(S, T), Ye({
            fetchers: new Map(y.fetchers)
        }, {
            flushSync: (k && k.flushSync) === !0
        })
    }

    function Yt(S, T, k, j) {
        j === void 0 && (j = {});
        let V = Ur(y.matches, T);
        zo(S), Ye({
            errors: {
                [V.route.id]: k
            },
            fetchers: new Map(y.fetchers)
        }, {
            flushSync: (j && j.flushSync) === !0
        })
    }

    function Nd(S) {
        return d.v7_fetcherPersist && (Gt.set(S, (Gt.get(S) || 0) + 1), Ve.has(S) && Ve.delete(S)), y.fetchers.get(S) || ww
    }

    function zo(S) {
        let T = y.fetchers.get(S);
        F.has(S) && !(T && T.state === "loading" && ue.has(S)) && xn(S), nt.delete(S), ue.delete(S), tt.delete(S), Ve.delete(S), D.delete(S), y.fetchers.delete(S)
    }

    function dy(S) {
        if (d.v7_fetcherPersist) {
            let T = (Gt.get(S) || 0) - 1;
            T <= 0 ? (Gt.delete(S), Ve.add(S)) : Gt.set(S, T)
        } else zo(S);
        Ye({
            fetchers: new Map(y.fetchers)
        })
    }

    function xn(S) {
        let T = F.get(S);
        Y(T, "Expected fetch controller: " + S), T.abort(), F.delete(S)
    }

    function Dd(S) {
        for (let T of S) {
            let k = Nd(T),
                j = Tn(k.data);
            y.fetchers.set(T, j)
        }
    }

    function _d() {
        let S = [],
            T = !1;
        for (let k of tt) {
            let j = y.fetchers.get(k);
            Y(j, "Expected fetcher: " + k), j.state === "loading" && (tt.delete(k), S.push(k), T = !0)
        }
        return Dd(S), T
    }

    function Od(S) {
        let T = [];
        for (let [k, j] of ue)
            if (j < S) {
                let V = y.fetchers.get(k);
                Y(V, "Expected fetcher: " + k), V.state === "loading" && (xn(k), ue.delete(k), T.push(k))
            }
        return Dd(T), T.length > 0
    }

    function fy(S, T) {
        let k = y.blockers.get(S) || Li;
        return Jn.get(S) !== T && Jn.set(S, T), k
    }

    function Vd(S) {
        y.blockers.delete(S), Jn.delete(S)
    }

    function bo(S, T) {
        let k = y.blockers.get(S) || Li;
        Y(k.state === "unblocked" && T.state === "blocked" || k.state === "blocked" && T.state === "blocked" || k.state === "blocked" && T.state === "proceeding" || k.state === "blocked" && T.state === "unblocked" || k.state === "proceeding" && T.state === "unblocked", "Invalid blocker state transition: " + k.state + " -> " + T.state);
        let j = new Map(y.blockers);
        j.set(S, T), Ye({
            blockers: j
        })
    }

    function Fd(S) {
        let {
            currentLocation: T,
            nextLocation: k,
            historyAction: j
        } = S;
        if (Jn.size === 0) return;
        Jn.size > 1 && ui(!1, "A router only supports one blocker at a time");
        let V = Array.from(Jn.entries()),
            [B, K] = V[V.length - 1],
            _ = y.blockers.get(B);
        if (!(_ && _.state === "proceeding") && K({
                currentLocation: T,
                nextLocation: k,
                historyAction: j
            })) return B
    }

    function Ha(S) {
        let T = Qe(404, {
                pathname: S
            }),
            k = a || s,
            {
                matches: j,
                route: V
            } = uh(k);
        return $a(), {
            notFoundMatches: j,
            route: V,
            error: T
        }
    }

    function Bo(S, T) {
        return {
            boundaryId: Ur(T.partialMatches).route.id,
            error: Qe(400, {
                type: "route-discovery",
                pathname: S,
                message: T.error != null && "message" in T.error ? T.error : String(T.error)
            })
        }
    }

    function $a(S) {
        let T = [];
        return wt.forEach((k, j) => {
            (!S || S(j)) && (k.cancel(), T.push(j), wt.delete(j))
        }), T
    }

    function hy(S, T, k) {
        if (E = S, h = T, p = k || null, !g && y.navigation === yl) {
            g = !0;
            let j = zd(y.location, y.matches);
            j != null && Ye({
                restoreScrollPosition: j
            })
        }
        return () => {
            E = null, h = null, p = null
        }
    }

    function Id(S, T) {
        return p && p(S, T.map(j => Zx(j, y.loaderData))) || S.key
    }

    function py(S, T) {
        if (E && h) {
            let k = Id(S, T);
            E[k] = h()
        }
    }

    function zd(S, T) {
        if (E) {
            let k = Id(S, T),
                j = E[k];
            if (typeof j == "number") return j
        }
        return null
    }

    function Uo(S, T, k) {
        if (c) {
            if (w.has(k)) return {
                active: !1,
                matches: S
            };
            if (S) {
                if (Object.keys(S[0].params).length > 0) return {
                    active: !0,
                    matches: Rs(T, k, l, !0)
                }
            } else return {
                active: !0,
                matches: Rs(T, k, l, !0) || []
            }
        }
        return {
            active: !1,
            matches: null
        }
    }
    async function Ho(S, T, k) {
        let j = S;
        for (;;) {
            let V = a == null,
                B = a || s;
            try {
                await kw(c, T, j, B, o, i, ey, k)
            } catch (H) {
                return {
                    type: "error",
                    error: H,
                    partialMatches: j
                }
            } finally {
                V && (s = [...s])
            }
            if (k.aborted) return {
                type: "aborted"
            };
            let K = ar(B, T, l);
            if (K) return bd(T, w), {
                type: "success",
                matches: K
            };
            let _ = Rs(B, T, l, !0);
            if (!_ || j.length === _.length && j.every((H, z) => H.route.id === _[z].route.id)) return bd(T, w), {
                type: "success",
                matches: null
            };
            j = _
        }
    }

    function bd(S, T) {
        if (T.size >= x) {
            let k = T.values().next().value;
            T.delete(k)
        }
        T.add(S)
    }

    function my(S) {
        o = {}, a = wo(S, i, void 0, o)
    }

    function gy(S, T) {
        let k = a == null;
        r0(S, T, a || s, o, i), k && (s = [...s], Ye({}))
    }
    return N = {
        get basename() {
            return l
        },
        get future() {
            return d
        },
        get state() {
            return y
        },
        get routes() {
            return s
        },
        get window() {
            return t
        },
        initialize: ty,
        subscribe: ry,
        enableScrollRestoration: hy,
        navigate: Ad,
        fetch: ly,
        revalidate: iy,
        createHref: S => e.history.createHref(S),
        encodeLocation: S => e.history.encodeLocation(S),
        getFetcher: Nd,
        deleteFetcher: dy,
        dispose: ny,
        getBlocker: fy,
        deleteBlocker: Vd,
        patchRoutes: gy,
        _internalFetchControllers: F,
        _internalActiveDeferreds: wt,
        _internalSetRoutes: my
    }, N
}

function Pw(e) {
    return e != null && ("formData" in e && e.formData != null || "body" in e && e.body !== void 0)
}

function Ru(e, t, n, r, i, o, s, a) {
    let l, u;
    if (s) {
        l = [];
        for (let d of t)
            if (l.push(d), d.route.id === s) {
                u = d;
                break
            }
    } else l = t, u = t[t.length - 1];
    let c = Gc(i || ".", Kc(l, o), gn(e.pathname, n) || e.pathname, a === "path");
    return i == null && (c.search = e.search, c.hash = e.hash), (i == null || i === "" || i === ".") && u && u.route.index && !Xc(c.search) && (c.search = c.search ? c.search.replace(/^\?/, "?index&") : "?index"), r && n !== "/" && (c.pathname = c.pathname === "/" ? n : an([n, c.pathname])), Tr(c)
}

function th(e, t, n, r) {
    if (!r || !Pw(r)) return {
        path: n
    };
    if (r.formMethod && !Iw(r.formMethod)) return {
        path: n,
        error: Qe(405, {
            method: r.formMethod
        })
    };
    let i = () => ({
            path: n,
            error: Qe(400, {
                type: "invalid-body"
            })
        }),
        o = r.formMethod || "get",
        s = e ? o.toUpperCase() : o.toLowerCase(),
        a = i0(n);
    if (r.body !== void 0) {
        if (r.formEncType === "text/plain") {
            if (!Dt(s)) return i();
            let f = typeof r.body == "string" ? r.body : r.body instanceof FormData || r.body instanceof URLSearchParams ? Array.from(r.body.entries()).reduce((m, x) => {
                let [w, E] = x;
                return "" + m + w + "=" + E + `
`
            }, "") : String(r.body);
            return {
                path: n,
                submission: {
                    formMethod: s,
                    formAction: a,
                    formEncType: r.formEncType,
                    formData: void 0,
                    json: void 0,
                    text: f
                }
            }
        } else if (r.formEncType === "application/json") {
            if (!Dt(s)) return i();
            try {
                let f = typeof r.body == "string" ? JSON.parse(r.body) : r.body;
                return {
                    path: n,
                    submission: {
                        formMethod: s,
                        formAction: a,
                        formEncType: r.formEncType,
                        formData: void 0,
                        json: f,
                        text: void 0
                    }
                }
            } catch {
                return i()
            }
        }
    }
    Y(typeof FormData == "function", "FormData is not available in this environment");
    let l, u;
    if (r.formData) l = ju(r.formData), u = r.formData;
    else if (r.body instanceof FormData) l = ju(r.body), u = r.body;
    else if (r.body instanceof URLSearchParams) l = r.body, u = oh(l);
    else if (r.body == null) l = new URLSearchParams, u = new FormData;
    else try {
        l = new URLSearchParams(r.body), u = oh(l)
    } catch {
        return i()
    }
    let c = {
        formMethod: s,
        formAction: a,
        formEncType: r && r.formEncType || "application/x-www-form-urlencoded",
        formData: u,
        json: void 0,
        text: void 0
    };
    if (Dt(c.formMethod)) return {
        path: n,
        submission: c
    };
    let d = Gn(n);
    return t && d.search && Xc(d.search) && l.append("index", ""), d.search = "?" + l, {
        path: Tr(d),
        submission: c
    }
}

function Ew(e, t) {
    let n = e;
    if (t) {
        let r = e.findIndex(i => i.route.id === t);
        r >= 0 && (n = e.slice(0, r))
    }
    return n
}

function nh(e, t, n, r, i, o, s, a, l, u, c, d, f, m, x, w) {
    let E = w ? dt(w[1]) ? w[1].error : w[1].data : void 0,
        p = e.createURL(t.location),
        h = e.createURL(i),
        g = w && dt(w[1]) ? w[0] : void 0,
        P = g ? Ew(n, g) : n,
        R = w ? w[1].statusCode : void 0,
        A = s && R && R >= 400,
        N = P.filter((O, M) => {
            let {
                route: U
            } = O;
            if (U.lazy) return !0;
            if (U.loader == null) return !1;
            if (o) return typeof U.loader != "function" || U.loader.hydrate ? !0 : t.loaderData[U.id] === void 0 && (!t.errors || t.errors[U.id] === void 0);
            if (Cw(t.loaderData, t.matches[M], O) || l.some(le => le === O.route.id)) return !0;
            let te = t.matches[M],
                Te = O;
            return rh(O, ve({
                currentUrl: p,
                currentParams: te.params,
                nextUrl: h,
                nextParams: Te.params
            }, r, {
                actionResult: E,
                actionStatus: R,
                defaultShouldRevalidate: A ? !1 : a || p.pathname + p.search === h.pathname + h.search || p.search !== h.search || n0(te, Te)
            }))
        }),
        y = [];
    return d.forEach((O, M) => {
        if (o || !n.some(At => At.route.id === O.routeId) || c.has(M)) return;
        let U = ar(m, O.path, x);
        if (!U) {
            y.push({
                key: M,
                routeId: O.routeId,
                path: O.path,
                matches: null,
                match: null,
                controller: null
            });
            return
        }
        let te = t.fetchers.get(M),
            Te = bi(U, O.path),
            le = !1;
        f.has(M) ? le = !1 : u.has(M) ? (u.delete(M), le = !0) : te && te.state !== "idle" && te.data === void 0 ? le = a : le = rh(Te, ve({
            currentUrl: p,
            currentParams: t.matches[t.matches.length - 1].params,
            nextUrl: h,
            nextParams: n[n.length - 1].params
        }, r, {
            actionResult: E,
            actionStatus: R,
            defaultShouldRevalidate: A ? !1 : a
        })), le && y.push({
            key: M,
            routeId: O.routeId,
            path: O.path,
            matches: U,
            match: Te,
            controller: new AbortController
        })
    }), [N, y]
}

function Cw(e, t, n) {
    let r = !t || n.route.id !== t.route.id,
        i = e[n.route.id] === void 0;
    return r || i
}

function n0(e, t) {
    let n = e.route.path;
    return e.pathname !== t.pathname || n != null && n.endsWith("*") && e.params["*"] !== t.params["*"]
}

function rh(e, t) {
    if (e.route.shouldRevalidate) {
        let n = e.route.shouldRevalidate(t);
        if (typeof n == "boolean") return n
    }
    return t.defaultShouldRevalidate
}
async function kw(e, t, n, r, i, o, s, a) {
    let l = [t, ...n.map(u => u.route.id)].join("-");
    try {
        let u = s.get(l);
        u || (u = e({
            path: t,
            matches: n,
            patch: (c, d) => {
                a.aborted || r0(c, d, r, i, o)
            }
        }), s.set(l, u)), u && Ow(u) && await u
    } finally {
        s.delete(l)
    }
}

function r0(e, t, n, r, i) {
    if (e) {
        var o;
        let s = r[e];
        Y(s, "No route found to patch children into: routeId = " + e);
        let a = wo(t, i, [e, "patch", String(((o = s.children) == null ? void 0 : o.length) || "0")], r);
        s.children ? s.children.push(...a) : s.children = a
    } else {
        let s = wo(t, i, ["patch", String(n.length || "0")], r);
        n.push(...s)
    }
}
async function Rw(e, t, n) {
    if (!e.lazy) return;
    let r = await e.lazy();
    if (!e.lazy) return;
    let i = n[e.id];
    Y(i, "No route found in manifest");
    let o = {};
    for (let s in r) {
        let l = i[s] !== void 0 && s !== "hasErrorBoundary";
        ui(!l, 'Route "' + i.id + '" has a static property "' + s + '" defined but its lazy function is also returning a value for this property. ' + ('The lazy route property "' + s + '" will be ignored.')), !l && !Qx.has(s) && (o[s] = r[s])
    }
    Object.assign(i, o), Object.assign(i, ve({}, t(i), {
        lazy: void 0
    }))
}
async function jw(e) {
    let {
        matches: t
    } = e, n = t.filter(i => i.shouldLoad);
    return (await Promise.all(n.map(i => i.resolve()))).reduce((i, o, s) => Object.assign(i, {
        [n[s].route.id]: o
    }), {})
}
async function Aw(e, t, n, r, i, o, s, a, l, u) {
    let c = o.map(m => m.route.lazy ? Rw(m.route, l, a) : void 0),
        d = o.map((m, x) => {
            let w = c[x],
                E = i.some(h => h.route.id === m.route.id);
            return ve({}, m, {
                shouldLoad: E,
                resolve: async h => (h && r.method === "GET" && (m.route.lazy || m.route.loader) && (E = !0), E ? Lw(t, r, m, w, h, u) : Promise.resolve({
                    type: ie.data,
                    result: void 0
                }))
            })
        }),
        f = await e({
            matches: d,
            request: r,
            params: o[0].params,
            fetcherKey: s,
            context: u
        });
    try {
        await Promise.all(c)
    } catch {}
    return f
}
async function Lw(e, t, n, r, i, o) {
    let s, a, l = u => {
        let c, d = new Promise((x, w) => c = w);
        a = () => c(), t.signal.addEventListener("abort", a);
        let f = x => typeof u != "function" ? Promise.reject(new Error("You cannot call the handler for a route which defines a boolean " + ('"' + e + '" [routeId: ' + n.route.id + "]"))) : u({
                request: t,
                params: n.params,
                context: o
            }, ...x !== void 0 ? [x] : []),
            m = (async () => {
                try {
                    return {
                        type: "data",
                        result: await (i ? i(w => f(w)) : f())
                    }
                } catch (x) {
                    return {
                        type: "error",
                        result: x
                    }
                }
            })();
        return Promise.race([m, d])
    };
    try {
        let u = n.route[e];
        if (r)
            if (u) {
                let c, [d] = await Promise.all([l(u).catch(f => {
                    c = f
                }), r]);
                if (c !== void 0) throw c;
                s = d
            } else if (await r, u = n.route[e], u) s = await l(u);
        else if (e === "action") {
            let c = new URL(t.url),
                d = c.pathname + c.search;
            throw Qe(405, {
                method: t.method,
                pathname: d,
                routeId: n.route.id
            })
        } else return {
            type: ie.data,
            result: void 0
        };
        else if (u) s = await l(u);
        else {
            let c = new URL(t.url),
                d = c.pathname + c.search;
            throw Qe(404, {
                pathname: d
            })
        }
        Y(s.result !== void 0, "You defined " + (e === "action" ? "an action" : "a loader") + " for route " + ('"' + n.route.id + "\" but didn't return anything from your `" + e + "` ") + "function. Please return a value or `null`.")
    } catch (u) {
        return {
            type: ie.error,
            result: u
        }
    } finally {
        a && t.signal.removeEventListener("abort", a)
    }
    return s
}
async function Mw(e) {
    let {
        result: t,
        type: n
    } = e;
    if (o0(t)) {
        let u;
        try {
            let c = t.headers.get("Content-Type");
            c && /\bapplication\/json\b/.test(c) ? t.body == null ? u = null : u = await t.json() : u = await t.text()
        } catch (c) {
            return {
                type: ie.error,
                error: c
            }
        }
        return n === ie.error ? {
            type: ie.error,
            error: new ia(t.status, t.statusText, u),
            statusCode: t.status,
            headers: t.headers
        } : {
            type: ie.data,
            data: u,
            statusCode: t.status,
            headers: t.headers
        }
    }
    if (n === ie.error) {
        if (ch(t)) {
            var r;
            if (t.data instanceof Error) {
                var i;
                return {
                    type: ie.error,
                    error: t.data,
                    statusCode: (i = t.init) == null ? void 0 : i.status
                }
            }
            t = new ia(((r = t.init) == null ? void 0 : r.status) || 500, void 0, t.data)
        }
        return {
            type: ie.error,
            error: t,
            statusCode: Da(t) ? t.status : void 0
        }
    }
    if (Fw(t)) {
        var o, s;
        return {
            type: ie.deferred,
            deferredData: t,
            statusCode: (o = t.init) == null ? void 0 : o.status,
            headers: ((s = t.init) == null ? void 0 : s.headers) && new Headers(t.init.headers)
        }
    }
    if (ch(t)) {
        var a, l;
        return {
            type: ie.data,
            data: t.data,
            statusCode: (a = t.init) == null ? void 0 : a.status,
            headers: (l = t.init) != null && l.headers ? new Headers(t.init.headers) : void 0
        }
    }
    return {
        type: ie.data,
        data: t
    }
}

function Nw(e, t, n, r, i, o) {
    let s = e.headers.get("Location");
    if (Y(s, "Redirects returned/thrown from loaders/actions must have a Location header"), !Yc.test(s)) {
        let a = r.slice(0, r.findIndex(l => l.route.id === n) + 1);
        s = Ru(new URL(t.url), a, i, !0, s, o), e.headers.set("Location", s)
    }
    return e
}

function ih(e, t, n) {
    if (Yc.test(e)) {
        let r = e,
            i = r.startsWith("//") ? new URL(t.protocol + r) : new URL(r),
            o = gn(i.pathname, n) != null;
        if (i.origin === t.origin && o) return i.pathname + i.search + i.hash
    }
    return e
}

function jr(e, t, n, r) {
    let i = e.createURL(i0(t)).toString(),
        o = {
            signal: n
        };
    if (r && Dt(r.formMethod)) {
        let {
            formMethod: s,
            formEncType: a
        } = r;
        o.method = s.toUpperCase(), a === "application/json" ? (o.headers = new Headers({
            "Content-Type": a
        }), o.body = JSON.stringify(r.json)) : a === "text/plain" ? o.body = r.text : a === "application/x-www-form-urlencoded" && r.formData ? o.body = ju(r.formData) : o.body = r.formData
    }
    return new Request(i, o)
}

function ju(e) {
    let t = new URLSearchParams;
    for (let [n, r] of e.entries()) t.append(n, typeof r == "string" ? r : r.name);
    return t
}

function oh(e) {
    let t = new FormData;
    for (let [n, r] of e.entries()) t.append(n, r);
    return t
}

function Dw(e, t, n, r, i) {
    let o = {},
        s = null,
        a, l = !1,
        u = {},
        c = n && dt(n[1]) ? n[1].error : void 0;
    return e.forEach(d => {
        if (!(d.route.id in t)) return;
        let f = d.route.id,
            m = t[f];
        if (Y(!dr(m), "Cannot handle redirect results in processLoaderData"), dt(m)) {
            let x = m.error;
            c !== void 0 && (x = c, c = void 0), s = s || {}; {
                let w = Ur(e, f);
                s[w.route.id] == null && (s[w.route.id] = x)
            }
            o[f] = void 0, l || (l = !0, a = Da(m.error) ? m.error.status : 500), m.headers && (u[f] = m.headers)
        } else Ln(m) ? (r.set(f, m.deferredData), o[f] = m.deferredData.data, m.statusCode != null && m.statusCode !== 200 && !l && (a = m.statusCode), m.headers && (u[f] = m.headers)) : (o[f] = m.data, m.statusCode && m.statusCode !== 200 && !l && (a = m.statusCode), m.headers && (u[f] = m.headers))
    }), c !== void 0 && n && (s = {
        [n[0]]: c
    }, o[n[0]] = void 0), {
        loaderData: o,
        errors: s,
        statusCode: a || 200,
        loaderHeaders: u
    }
}

function sh(e, t, n, r, i, o, s, a) {
    let {
        loaderData: l,
        errors: u
    } = Dw(t, r, i, a);
    return o.forEach(c => {
        let {
            key: d,
            match: f,
            controller: m
        } = c, x = s[d];
        if (Y(x, "Did not find corresponding fetcher result"), !(m && m.signal.aborted))
            if (dt(x)) {
                let w = Ur(e.matches, f == null ? void 0 : f.route.id);
                u && u[w.route.id] || (u = ve({}, u, {
                    [w.route.id]: x.error
                })), e.fetchers.delete(d)
            } else if (dr(x)) Y(!1, "Unhandled fetcher revalidation redirect");
        else if (Ln(x)) Y(!1, "Unhandled fetcher deferred data");
        else {
            let w = Tn(x.data);
            e.fetchers.set(d, w)
        }
    }), {
        loaderData: l,
        errors: u
    }
}

function ah(e, t, n, r) {
    let i = ve({}, t);
    for (let o of n) {
        let s = o.route.id;
        if (t.hasOwnProperty(s) ? t[s] !== void 0 && (i[s] = t[s]) : e[s] !== void 0 && o.route.loader && (i[s] = e[s]), r && r.hasOwnProperty(s)) break
    }
    return i
}

function lh(e) {
    return e ? dt(e[1]) ? {
        actionData: {}
    } : {
        actionData: {
            [e[0]]: e[1].data
        }
    } : {}
}

function Ur(e, t) {
    return (t ? e.slice(0, e.findIndex(r => r.route.id === t) + 1) : [...e]).reverse().find(r => r.route.hasErrorBoundary === !0) || e[0]
}

function uh(e) {
    let t = e.length === 1 ? e[0] : e.find(n => n.index || !n.path || n.path === "/") || {
        id: "__shim-error-route__"
    };
    return {
        matches: [{
            params: {},
            pathname: "",
            pathnameBase: "",
            route: t
        }],
        route: t
    }
}

function Qe(e, t) {
    let {
        pathname: n,
        routeId: r,
        method: i,
        type: o,
        message: s
    } = t === void 0 ? {} : t, a = "Unknown Server Error", l = "Unknown @remix-run/router error";
    return e === 400 ? (a = "Bad Request", o === "route-discovery" ? l = 'Unable to match URL "' + n + '" - the `unstable_patchRoutesOnNavigation()` ' + (`function threw the following error:
` + s) : i && n && r ? l = "You made a " + i + ' request to "' + n + '" but ' + ('did not provide a `loader` for route "' + r + '", ') + "so there is no way to handle the request." : o === "defer-action" ? l = "defer() is not supported in actions" : o === "invalid-body" && (l = "Unable to encode submission body")) : e === 403 ? (a = "Forbidden", l = 'Route "' + r + '" does not match URL "' + n + '"') : e === 404 ? (a = "Not Found", l = 'No route matches URL "' + n + '"') : e === 405 && (a = "Method Not Allowed", i && n && r ? l = "You made a " + i.toUpperCase() + ' request to "' + n + '" but ' + ('did not provide an `action` for route "' + r + '", ') + "so there is no way to handle the request." : i && (l = 'Invalid request method "' + i.toUpperCase() + '"')), new ia(e || 500, a, new Error(l), !0)
}

function ds(e) {
    let t = Object.entries(e);
    for (let n = t.length - 1; n >= 0; n--) {
        let [r, i] = t[n];
        if (dr(i)) return {
            key: r,
            result: i
        }
    }
}

function i0(e) {
    let t = typeof e == "string" ? Gn(e) : e;
    return Tr(ve({}, t, {
        hash: ""
    }))
}

function _w(e, t) {
    return e.pathname !== t.pathname || e.search !== t.search ? !1 : e.hash === "" ? t.hash !== "" : e.hash === t.hash ? !0 : t.hash !== ""
}

function Ow(e) {
    return typeof e == "object" && e != null && "then" in e
}

function Vw(e) {
    return o0(e.result) && yw.has(e.result.status)
}

function Ln(e) {
    return e.type === ie.deferred
}

function dt(e) {
    return e.type === ie.error
}

function dr(e) {
    return (e && e.type) === ie.redirect
}

function ch(e) {
    return typeof e == "object" && e != null && "type" in e && "data" in e && "init" in e && e.type === "DataWithResponseInit"
}

function Fw(e) {
    let t = e;
    return t && typeof t == "object" && typeof t.data == "object" && typeof t.subscribe == "function" && typeof t.cancel == "function" && typeof t.resolveData == "function"
}

function o0(e) {
    return e != null && typeof e.status == "number" && typeof e.statusText == "string" && typeof e.headers == "object" && typeof e.body < "u"
}

function Iw(e) {
    return vw.has(e.toLowerCase())
}

function Dt(e) {
    return mw.has(e.toLowerCase())
}
async function zw(e, t, n, r, i) {
    let o = Object.entries(t);
    for (let s = 0; s < o.length; s++) {
        let [a, l] = o[s], u = e.find(f => (f == null ? void 0 : f.route.id) === a);
        if (!u) continue;
        let c = r.find(f => f.route.id === u.route.id),
            d = c != null && !n0(c, u) && (i && i[u.route.id]) !== void 0;
        Ln(l) && d && await Qc(l, n, !1).then(f => {
            f && (t[a] = f)
        })
    }
}
async function bw(e, t, n) {
    for (let r = 0; r < n.length; r++) {
        let {
            key: i,
            routeId: o,
            controller: s
        } = n[r], a = t[i];
        e.find(u => (u == null ? void 0 : u.route.id) === o) && Ln(a) && (Y(s, "Expected an AbortController for revalidating fetcher deferred result"), await Qc(a, s.signal, !0).then(u => {
            u && (t[i] = u)
        }))
    }
}
async function Qc(e, t, n) {
    if (n === void 0 && (n = !1), !await e.deferredData.resolveData(t)) {
        if (n) try {
            return {
                type: ie.data,
                data: e.deferredData.unwrappedData
            }
        } catch (i) {
            return {
                type: ie.error,
                error: i
            }
        }
        return {
            type: ie.data,
            data: e.deferredData.data
        }
    }
}

function Xc(e) {
    return new URLSearchParams(e).getAll("index").some(t => t === "")
}

function bi(e, t) {
    let n = typeof t == "string" ? Gn(t).search : t.search;
    if (e[e.length - 1].route.index && Xc(n || "")) return e[e.length - 1];
    let r = qg(e);
    return r[r.length - 1]
}

function dh(e) {
    let {
        formMethod: t,
        formAction: n,
        formEncType: r,
        text: i,
        formData: o,
        json: s
    } = e;
    if (!(!t || !n || !r)) {
        if (i != null) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: void 0,
            json: void 0,
            text: i
        };
        if (o != null) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: o,
            json: void 0,
            text: void 0
        };
        if (s !== void 0) return {
            formMethod: t,
            formAction: n,
            formEncType: r,
            formData: void 0,
            json: s,
            text: void 0
        }
    }
}

function xl(e, t) {
    return t ? {
        state: "loading",
        location: e,
        formMethod: t.formMethod,
        formAction: t.formAction,
        formEncType: t.formEncType,
        formData: t.formData,
        json: t.json,
        text: t.text
    } : {
        state: "loading",
        location: e,
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0
    }
}

function Bw(e, t) {
    return {
        state: "submitting",
        location: e,
        formMethod: t.formMethod,
        formAction: t.formAction,
        formEncType: t.formEncType,
        formData: t.formData,
        json: t.json,
        text: t.text
    }
}

function Mi(e, t) {
    return e ? {
        state: "loading",
        formMethod: e.formMethod,
        formAction: e.formAction,
        formEncType: e.formEncType,
        formData: e.formData,
        json: e.json,
        text: e.text,
        data: t
    } : {
        state: "loading",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: t
    }
}

function Uw(e, t) {
    return {
        state: "submitting",
        formMethod: e.formMethod,
        formAction: e.formAction,
        formEncType: e.formEncType,
        formData: e.formData,
        json: e.json,
        text: e.text,
        data: t ? t.data : void 0
    }
}

function Tn(e) {
    return {
        state: "idle",
        formMethod: void 0,
        formAction: void 0,
        formEncType: void 0,
        formData: void 0,
        json: void 0,
        text: void 0,
        data: e
    }
}

function Hw(e, t) {
    try {
        let n = e.sessionStorage.getItem(t0);
        if (n) {
            let r = JSON.parse(n);
            for (let [i, o] of Object.entries(r || {})) o && Array.isArray(o) && t.set(i, new Set(o || []))
        }
    } catch {}
}

function $w(e, t) {
    if (t.size > 0) {
        let n = {};
        for (let [r, i] of t) n[r] = [...i];
        try {
            e.sessionStorage.setItem(t0, JSON.stringify(n))
        } catch (r) {
            ui(!1, "Failed to save applied view transitions in sessionStorage (" + r + ").")
        }
    }
}
/**
 * React Router v6.26.2
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function oa() {
    return oa = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, oa.apply(this, arguments)
}
const No = C.createContext(null),
    Zc = C.createContext(null),
    Yn = C.createContext(null),
    Jc = C.createContext(null),
    Qn = C.createContext({
        outlet: null,
        matches: [],
        isDataRoute: !1
    }),
    s0 = C.createContext(null);

function Ww(e, t) {
    let {
        relative: n
    } = t === void 0 ? {} : t;
    Do() || Y(!1);
    let {
        basename: r,
        navigator: i
    } = C.useContext(Yn), {
        hash: o,
        pathname: s,
        search: a
    } = _a(e, {
        relative: n
    }), l = s;
    return r !== "/" && (l = s === "/" ? r : an([r, s])), i.createHref({
        pathname: l,
        search: a,
        hash: o
    })
}

function Do() {
    return C.useContext(Jc) != null
}

function yi() {
    return Do() || Y(!1), C.useContext(Jc).location
}

function a0(e) {
    C.useContext(Yn).static || C.useLayoutEffect(e)
}

function Kw() {
    let {
        isDataRoute: e
    } = C.useContext(Qn);
    return e ? s2() : Gw()
}

function Gw() {
    Do() || Y(!1);
    let e = C.useContext(No),
        {
            basename: t,
            future: n,
            navigator: r
        } = C.useContext(Yn),
        {
            matches: i
        } = C.useContext(Qn),
        {
            pathname: o
        } = yi(),
        s = JSON.stringify(Kc(i, n.v7_relativeSplatPath)),
        a = C.useRef(!1);
    return a0(() => {
        a.current = !0
    }), C.useCallback(function(u, c) {
        if (c === void 0 && (c = {}), !a.current) return;
        if (typeof u == "number") {
            r.go(u);
            return
        }
        let d = Gc(u, JSON.parse(s), o, c.relative === "path");
        e == null && t !== "/" && (d.pathname = d.pathname === "/" ? t : an([t, d.pathname])), (c.replace ? r.replace : r.push)(d, c.state, c)
    }, [t, r, s, o, e])
}
const Yw = C.createContext(null);

function Qw(e) {
    let t = C.useContext(Qn).outlet;
    return t && C.createElement(Yw.Provider, {
        value: e
    }, t)
}

function _a(e, t) {
    let {
        relative: n
    } = t === void 0 ? {} : t, {
        future: r
    } = C.useContext(Yn), {
        matches: i
    } = C.useContext(Qn), {
        pathname: o
    } = yi(), s = JSON.stringify(Kc(i, r.v7_relativeSplatPath));
    return C.useMemo(() => Gc(e, JSON.parse(s), o, n === "path"), [e, s, o, n])
}

function Xw(e, t, n, r) {
    Do() || Y(!1);
    let {
        navigator: i
    } = C.useContext(Yn), {
        matches: o
    } = C.useContext(Qn), s = o[o.length - 1], a = s ? s.params : {};
    s && s.pathname;
    let l = s ? s.pathnameBase : "/";
    s && s.route;
    let u = yi(),
        c;
    c = u;
    let d = c.pathname || "/",
        f = d;
    if (l !== "/") {
        let w = l.replace(/^\//, "").split("/");
        f = "/" + d.replace(/^\//, "").split("/").slice(w.length).join("/")
    }
    let m = ar(e, {
        pathname: f
    });
    return t2(m && m.map(w => Object.assign({}, w, {
        params: Object.assign({}, a, w.params),
        pathname: an([l, i.encodeLocation ? i.encodeLocation(w.pathname).pathname : w.pathname]),
        pathnameBase: w.pathnameBase === "/" ? l : an([l, i.encodeLocation ? i.encodeLocation(w.pathnameBase).pathname : w.pathnameBase])
    })), o, n, r)
}

function Zw() {
    let e = o2(),
        t = Da(e) ? e.status + " " + e.statusText : e instanceof Error ? e.message : JSON.stringify(e),
        n = e instanceof Error ? e.stack : null,
        i = {
            padding: "0.5rem",
            backgroundColor: "rgba(200,200,200, 0.5)"
        };
    return C.createElement(C.Fragment, null, C.createElement("h2", null, "Unexpected Application Error!"), C.createElement("h3", {
        style: {
            fontStyle: "italic"
        }
    }, t), n ? C.createElement("pre", {
        style: i
    }, n) : null, null)
}
const Jw = C.createElement(Zw, null);
class qw extends C.Component {
    constructor(t) {
        super(t), this.state = {
            location: t.location,
            revalidation: t.revalidation,
            error: t.error
        }
    }
    static getDerivedStateFromError(t) {
        return {
            error: t
        }
    }
    static getDerivedStateFromProps(t, n) {
        return n.location !== t.location || n.revalidation !== "idle" && t.revalidation === "idle" ? {
            error: t.error,
            location: t.location,
            revalidation: t.revalidation
        } : {
            error: t.error !== void 0 ? t.error : n.error,
            location: n.location,
            revalidation: t.revalidation || n.revalidation
        }
    }
    componentDidCatch(t, n) {
        console.error("React Router caught the following error during render", t, n)
    }
    render() {
        return this.state.error !== void 0 ? C.createElement(Qn.Provider, {
            value: this.props.routeContext
        }, C.createElement(s0.Provider, {
            value: this.state.error,
            children: this.props.component
        })) : this.props.children
    }
}

function e2(e) {
    let {
        routeContext: t,
        match: n,
        children: r
    } = e, i = C.useContext(No);
    return i && i.static && i.staticContext && (n.route.errorElement || n.route.ErrorBoundary) && (i.staticContext._deepestRenderedBoundaryId = n.route.id), C.createElement(Qn.Provider, {
        value: t
    }, r)
}

function t2(e, t, n, r) {
    var i;
    if (t === void 0 && (t = []), n === void 0 && (n = null), r === void 0 && (r = null), e == null) {
        var o;
        if (!n) return null;
        if (n.errors) e = n.matches;
        else if ((o = r) != null && o.v7_partialHydration && t.length === 0 && !n.initialized && n.matches.length > 0) e = n.matches;
        else return null
    }
    let s = e,
        a = (i = n) == null ? void 0 : i.errors;
    if (a != null) {
        let c = s.findIndex(d => d.route.id && (a == null ? void 0 : a[d.route.id]) !== void 0);
        c >= 0 || Y(!1), s = s.slice(0, Math.min(s.length, c + 1))
    }
    let l = !1,
        u = -1;
    if (n && r && r.v7_partialHydration)
        for (let c = 0; c < s.length; c++) {
            let d = s[c];
            if ((d.route.HydrateFallback || d.route.hydrateFallbackElement) && (u = c), d.route.id) {
                let {
                    loaderData: f,
                    errors: m
                } = n, x = d.route.loader && f[d.route.id] === void 0 && (!m || m[d.route.id] === void 0);
                if (d.route.lazy || x) {
                    l = !0, u >= 0 ? s = s.slice(0, u + 1) : s = [s[0]];
                    break
                }
            }
        }
    return s.reduceRight((c, d, f) => {
        let m, x = !1,
            w = null,
            E = null;
        n && (m = a && d.route.id ? a[d.route.id] : void 0, w = d.route.errorElement || Jw, l && (u < 0 && f === 0 ? (x = !0, E = null) : u === f && (x = !0, E = d.route.hydrateFallbackElement || null)));
        let p = t.concat(s.slice(0, f + 1)),
            h = () => {
                let g;
                return m ? g = w : x ? g = E : d.route.Component ? g = C.createElement(d.route.Component, null) : d.route.element ? g = d.route.element : g = c, C.createElement(e2, {
                    match: d,
                    routeContext: {
                        outlet: c,
                        matches: p,
                        isDataRoute: n != null
                    },
                    children: g
                })
            };
        return n && (d.route.ErrorBoundary || d.route.errorElement || f === 0) ? C.createElement(qw, {
            location: n.location,
            revalidation: n.revalidation,
            component: w,
            error: m,
            children: h(),
            routeContext: {
                outlet: null,
                matches: p,
                isDataRoute: !0
            }
        }) : h()
    }, null)
}
var l0 = function(e) {
        return e.UseBlocker = "useBlocker", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e
    }(l0 || {}),
    sa = function(e) {
        return e.UseBlocker = "useBlocker", e.UseLoaderData = "useLoaderData", e.UseActionData = "useActionData", e.UseRouteError = "useRouteError", e.UseNavigation = "useNavigation", e.UseRouteLoaderData = "useRouteLoaderData", e.UseMatches = "useMatches", e.UseRevalidator = "useRevalidator", e.UseNavigateStable = "useNavigate", e.UseRouteId = "useRouteId", e
    }(sa || {});

function n2(e) {
    let t = C.useContext(No);
    return t || Y(!1), t
}

function r2(e) {
    let t = C.useContext(Zc);
    return t || Y(!1), t
}

function i2(e) {
    let t = C.useContext(Qn);
    return t || Y(!1), t
}

function u0(e) {
    let t = i2(),
        n = t.matches[t.matches.length - 1];
    return n.route.id || Y(!1), n.route.id
}

function o2() {
    var e;
    let t = C.useContext(s0),
        n = r2(sa.UseRouteError),
        r = u0(sa.UseRouteError);
    return t !== void 0 ? t : (e = n.errors) == null ? void 0 : e[r]
}

function s2() {
    let {
        router: e
    } = n2(l0.UseNavigateStable), t = u0(sa.UseNavigateStable), n = C.useRef(!1);
    return a0(() => {
        n.current = !0
    }), C.useCallback(function(i, o) {
        o === void 0 && (o = {}), n.current && (typeof i == "number" ? e.navigate(i) : e.navigate(i, oa({
            fromRouteId: t
        }, o)))
    }, [e, t])
}

function a2(e) {
    return Qw(e.context)
}

function ir(e) {
    Y(!1)
}

function l2(e) {
    let {
        basename: t = "/",
        children: n = null,
        location: r,
        navigationType: i = Ae.Pop,
        navigator: o,
        static: s = !1,
        future: a
    } = e;
    Do() && Y(!1);
    let l = t.replace(/^\/*/, "/"),
        u = C.useMemo(() => ({
            basename: l,
            navigator: o,
            static: s,
            future: oa({
                v7_relativeSplatPath: !1
            }, a)
        }), [l, a, o, s]);
    typeof r == "string" && (r = Gn(r));
    let {
        pathname: c = "/",
        search: d = "",
        hash: f = "",
        state: m = null,
        key: x = "default"
    } = r, w = C.useMemo(() => {
        let E = gn(c, l);
        return E == null ? null : {
            location: {
                pathname: E,
                search: d,
                hash: f,
                state: m,
                key: x
            },
            navigationType: i
        }
    }, [l, c, d, f, m, x, i]);
    return w == null ? null : C.createElement(Yn.Provider, {
        value: u
    }, C.createElement(Jc.Provider, {
        children: n,
        value: w
    }))
}
new Promise(() => {});

function Au(e, t) {
    t === void 0 && (t = []);
    let n = [];
    return C.Children.forEach(e, (r, i) => {
        if (!C.isValidElement(r)) return;
        let o = [...t, i];
        if (r.type === C.Fragment) {
            n.push.apply(n, Au(r.props.children, o));
            return
        }
        r.type !== ir && Y(!1), !r.props.index || !r.props.children || Y(!1);
        let s = {
            id: r.props.id || o.join("-"),
            caseSensitive: r.props.caseSensitive,
            element: r.props.element,
            Component: r.props.Component,
            index: r.props.index,
            path: r.props.path,
            loader: r.props.loader,
            action: r.props.action,
            errorElement: r.props.errorElement,
            ErrorBoundary: r.props.ErrorBoundary,
            hasErrorBoundary: r.props.ErrorBoundary != null || r.props.errorElement != null,
            shouldRevalidate: r.props.shouldRevalidate,
            handle: r.props.handle,
            lazy: r.props.lazy
        };
        r.props.children && (s.children = Au(r.props.children, o)), n.push(s)
    }), n
}

function u2(e) {
    let t = {
        hasErrorBoundary: e.ErrorBoundary != null || e.errorElement != null
    };
    return e.Component && Object.assign(t, {
        element: C.createElement(e.Component),
        Component: void 0
    }), e.HydrateFallback && Object.assign(t, {
        hydrateFallbackElement: C.createElement(e.HydrateFallback),
        HydrateFallback: void 0
    }), e.ErrorBoundary && Object.assign(t, {
        errorElement: C.createElement(e.ErrorBoundary),
        ErrorBoundary: void 0
    }), t
}
/**
 * React Router DOM v6.26.2
 *
 * Copyright (c) Remix Software Inc.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE.md file in the root directory of this source tree.
 *
 * @license MIT
 */
function ci() {
    return ci = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, ci.apply(this, arguments)
}

function c0(e, t) {
    if (e == null) return {};
    var n = {},
        r = Object.keys(e),
        i, o;
    for (o = 0; o < r.length; o++) i = r[o], !(t.indexOf(i) >= 0) && (n[i] = e[i]);
    return n
}

function c2(e) {
    return !!(e.metaKey || e.altKey || e.ctrlKey || e.shiftKey)
}

function d2(e, t) {
    return e.button === 0 && (!t || t === "_self") && !c2(e)
}
const f2 = ["onClick", "relative", "reloadDocument", "replace", "state", "target", "to", "preventScrollReset", "unstable_viewTransition"],
    h2 = ["aria-current", "caseSensitive", "className", "end", "style", "to", "unstable_viewTransition", "children"],
    p2 = "6";
try {
    window.__reactRouterVersion = p2
} catch {}

function m2(e, t) {
    return Tw({
        basename: void 0,
        future: ci({}, void 0, {
            v7_prependBasename: !0
        }),
        history: Kx({
            window: void 0
        }),
        hydrationData: g2(),
        routes: e,
        mapRouteProperties: u2,
        unstable_dataStrategy: void 0,
        unstable_patchRoutesOnNavigation: void 0,
        window: void 0
    }).initialize()
}

function g2() {
    var e;
    let t = (e = window) == null ? void 0 : e.__staticRouterHydrationData;
    return t && t.errors && (t = ci({}, t, {
        errors: v2(t.errors)
    })), t
}

function v2(e) {
    if (!e) return null;
    let t = Object.entries(e),
        n = {};
    for (let [r, i] of t)
        if (i && i.__type === "RouteErrorResponse") n[r] = new ia(i.status, i.statusText, i.data, i.internal === !0);
        else if (i && i.__type === "Error") {
        if (i.__subType) {
            let o = window[i.__subType];
            if (typeof o == "function") try {
                let s = new o(i.message);
                s.stack = "", n[r] = s
            } catch {}
        }
        if (n[r] == null) {
            let o = new Error(i.message);
            o.stack = "", n[r] = o
        }
    } else n[r] = i;
    return n
}
const d0 = C.createContext({
        isTransitioning: !1
    }),
    y2 = C.createContext(new Map),
    x2 = "startTransition",
    fh = Dy[x2],
    w2 = "flushSync",
    hh = Wx[w2];

function S2(e) {
    fh ? fh(e) : e()
}

function Ni(e) {
    hh ? hh(e) : e()
}
class T2 {
    constructor() {
        this.status = "pending", this.promise = new Promise((t, n) => {
            this.resolve = r => {
                this.status === "pending" && (this.status = "resolved", t(r))
            }, this.reject = r => {
                this.status === "pending" && (this.status = "rejected", n(r))
            }
        })
    }
}

function P2(e) {
    let {
        fallbackElement: t,
        router: n,
        future: r
    } = e, [i, o] = C.useState(n.state), [s, a] = C.useState(), [l, u] = C.useState({
        isTransitioning: !1
    }), [c, d] = C.useState(), [f, m] = C.useState(), [x, w] = C.useState(), E = C.useRef(new Map), {
        v7_startTransition: p
    } = r || {}, h = C.useCallback(y => {
        p ? S2(y) : y()
    }, [p]), g = C.useCallback((y, O) => {
        let {
            deletedFetchers: M,
            unstable_flushSync: U,
            unstable_viewTransitionOpts: te
        } = O;
        M.forEach(le => E.current.delete(le)), y.fetchers.forEach((le, At) => {
            le.data !== void 0 && E.current.set(At, le.data)
        });
        let Te = n.window == null || n.window.document == null || typeof n.window.document.startViewTransition != "function";
        if (!te || Te) {
            U ? Ni(() => o(y)) : h(() => o(y));
            return
        }
        if (U) {
            Ni(() => {
                f && (c && c.resolve(), f.skipTransition()), u({
                    isTransitioning: !0,
                    flushSync: !0,
                    currentLocation: te.currentLocation,
                    nextLocation: te.nextLocation
                })
            });
            let le = n.window.document.startViewTransition(() => {
                Ni(() => o(y))
            });
            le.finished.finally(() => {
                Ni(() => {
                    d(void 0), m(void 0), a(void 0), u({
                        isTransitioning: !1
                    })
                })
            }), Ni(() => m(le));
            return
        }
        f ? (c && c.resolve(), f.skipTransition(), w({
            state: y,
            currentLocation: te.currentLocation,
            nextLocation: te.nextLocation
        })) : (a(y), u({
            isTransitioning: !0,
            flushSync: !1,
            currentLocation: te.currentLocation,
            nextLocation: te.nextLocation
        }))
    }, [n.window, f, c, E, h]);
    C.useLayoutEffect(() => n.subscribe(g), [n, g]), C.useEffect(() => {
        l.isTransitioning && !l.flushSync && d(new T2)
    }, [l]), C.useEffect(() => {
        if (c && s && n.window) {
            let y = s,
                O = c.promise,
                M = n.window.document.startViewTransition(async () => {
                    h(() => o(y)), await O
                });
            M.finished.finally(() => {
                d(void 0), m(void 0), a(void 0), u({
                    isTransitioning: !1
                })
            }), m(M)
        }
    }, [h, s, c, n.window]), C.useEffect(() => {
        c && s && i.location.key === s.location.key && c.resolve()
    }, [c, f, i.location, s]), C.useEffect(() => {
        !l.isTransitioning && x && (a(x.state), u({
            isTransitioning: !0,
            flushSync: !1,
            currentLocation: x.currentLocation,
            nextLocation: x.nextLocation
        }), w(void 0))
    }, [l.isTransitioning, x]), C.useEffect(() => {}, []);
    let P = C.useMemo(() => ({
            createHref: n.createHref,
            encodeLocation: n.encodeLocation,
            go: y => n.navigate(y),
            push: (y, O, M) => n.navigate(y, {
                state: O,
                preventScrollReset: M == null ? void 0 : M.preventScrollReset
            }),
            replace: (y, O, M) => n.navigate(y, {
                replace: !0,
                state: O,
                preventScrollReset: M == null ? void 0 : M.preventScrollReset
            })
        }), [n]),
        R = n.basename || "/",
        A = C.useMemo(() => ({
            router: n,
            navigator: P,
            static: !1,
            basename: R
        }), [n, P, R]),
        N = C.useMemo(() => ({
            v7_relativeSplatPath: n.future.v7_relativeSplatPath
        }), [n.future.v7_relativeSplatPath]);
    return C.createElement(C.Fragment, null, C.createElement(No.Provider, {
        value: A
    }, C.createElement(Zc.Provider, {
        value: i
    }, C.createElement(y2.Provider, {
        value: E.current
    }, C.createElement(d0.Provider, {
        value: l
    }, C.createElement(l2, {
        basename: R,
        location: i.location,
        navigationType: i.historyAction,
        navigator: P,
        future: N
    }, i.initialized || n.future.v7_partialHydration ? C.createElement(E2, {
        routes: n.routes,
        future: n.future,
        state: i
    }) : t))))), null)
}
const E2 = C.memo(C2);

function C2(e) {
    let {
        routes: t,
        future: n,
        state: r
    } = e;
    return Xw(t, void 0, r, n)
}
const k2 = typeof window < "u" && typeof window.document < "u" && typeof window.document.createElement < "u",
    R2 = /^(?:[a-z][a-z0-9+.-]*:|\/\/)/i,
    rn = C.forwardRef(function(t, n) {
        let {
            onClick: r,
            relative: i,
            reloadDocument: o,
            replace: s,
            state: a,
            target: l,
            to: u,
            preventScrollReset: c,
            unstable_viewTransition: d
        } = t, f = c0(t, f2), {
            basename: m
        } = C.useContext(Yn), x, w = !1;
        if (typeof u == "string" && R2.test(u) && (x = u, k2)) try {
            let g = new URL(window.location.href),
                P = u.startsWith("//") ? new URL(g.protocol + u) : new URL(u),
                R = gn(P.pathname, m);
            P.origin === g.origin && R != null ? u = R + P.search + P.hash : w = !0
        } catch {}
        let E = Ww(u, {
                relative: i
            }),
            p = L2(u, {
                replace: s,
                state: a,
                target: l,
                preventScrollReset: c,
                relative: i,
                unstable_viewTransition: d
            });

        function h(g) {
            r && r(g), g.defaultPrevented || p(g)
        }
        return C.createElement("a", ci({}, f, {
            href: x || E,
            onClick: w || o ? r : h,
            ref: n,
            target: l
        }))
    }),
    j2 = C.forwardRef(function(t, n) {
        let {
            "aria-current": r = "page",
            caseSensitive: i = !1,
            className: o = "",
            end: s = !1,
            style: a,
            to: l,
            unstable_viewTransition: u,
            children: c
        } = t, d = c0(t, h2), f = _a(l, {
            relative: d.relative
        }), m = yi(), x = C.useContext(Zc), {
            navigator: w,
            basename: E
        } = C.useContext(Yn), p = x != null && M2(f) && u === !0, h = w.encodeLocation ? w.encodeLocation(f).pathname : f.pathname, g = m.pathname, P = x && x.navigation && x.navigation.location ? x.navigation.location.pathname : null;
        i || (g = g.toLowerCase(), P = P ? P.toLowerCase() : null, h = h.toLowerCase()), P && E && (P = gn(P, E) || P);
        const R = h !== "/" && h.endsWith("/") ? h.length - 1 : h.length;
        let A = g === h || !s && g.startsWith(h) && g.charAt(R) === "/",
            N = P != null && (P === h || !s && P.startsWith(h) && P.charAt(h.length) === "/"),
            y = {
                isActive: A,
                isPending: N,
                isTransitioning: p
            },
            O = A ? r : void 0,
            M;
        typeof o == "function" ? M = o(y) : M = [o, A ? "active" : null, N ? "pending" : null, p ? "transitioning" : null].filter(Boolean).join(" ");
        let U = typeof a == "function" ? a(y) : a;
        return C.createElement(rn, ci({}, d, {
            "aria-current": O,
            className: M,
            ref: n,
            style: U,
            to: l,
            unstable_viewTransition: u
        }), typeof c == "function" ? c(y) : c)
    });
var Lu;
(function(e) {
    e.UseScrollRestoration = "useScrollRestoration", e.UseSubmit = "useSubmit", e.UseSubmitFetcher = "useSubmitFetcher", e.UseFetcher = "useFetcher", e.useViewTransitionState = "useViewTransitionState"
})(Lu || (Lu = {}));
var ph;
(function(e) {
    e.UseFetcher = "useFetcher", e.UseFetchers = "useFetchers", e.UseScrollRestoration = "useScrollRestoration"
})(ph || (ph = {}));

function A2(e) {
    let t = C.useContext(No);
    return t || Y(!1), t
}

function L2(e, t) {
    let {
        target: n,
        replace: r,
        state: i,
        preventScrollReset: o,
        relative: s,
        unstable_viewTransition: a
    } = t === void 0 ? {} : t, l = Kw(), u = yi(), c = _a(e, {
        relative: s
    });
    return C.useCallback(d => {
        if (d2(d, n)) {
            d.preventDefault();
            let f = r !== void 0 ? r : Tr(u) === Tr(c);
            l(e, {
                replace: f,
                state: i,
                preventScrollReset: o,
                relative: s,
                unstable_viewTransition: a
            })
        }
    }, [u, l, c, r, i, n, e, o, s, a])
}

function M2(e, t) {
    t === void 0 && (t = {});
    let n = C.useContext(d0);
    n == null && Y(!1);
    let {
        basename: r
    } = A2(Lu.useViewTransitionState), i = _a(e, {
        relative: t.relative
    });
    if (!n.isTransitioning) return !1;
    let o = gn(n.currentLocation.pathname, r) || n.currentLocation.pathname,
        s = gn(n.nextLocation.pathname, r) || n.nextLocation.pathname;
    return ra(i.pathname, s) != null || ra(i.pathname, o) != null
}
const N2 = ({
        path: e,
        label: t
    }) => v.jsx(j2, {
        to: e,
        className: ({
            isActive: n
        }) => n ? "text-[#000] font-semibold " : "text-[#000]",
        children: t
    }),
    D2 = ({
        isOpen: e,
        setIsOpen: t
    }) => {
        const n = [{
                id: 1,
                path: "/api/v1/noor-e-nazar/about",
                label: "About Me"
            }, {
                id: 2,
                path: "/api/v1/noor-e-nazar/Project",
                label: "Projects "
            }, {
                id: 3,
                path: "/api/v1/noor-e-nazar/contact",
                label: "Contact Me"
            }],
            r = () => {
                t(!1)
            };
        return v.jsx(v.Fragment, {
            children: v.jsx("nav", {
                className: `absolute right-2  top-[110%]  rounded-lg w-[96%] md:w-[20%] bg-white md:h-[60vh] justify-center py-[40px] z-[-1] duration-1000 ${e?"opacity-100 translate-x-0":"opacity-0 -translate-x-full md:-translate-y-full  "} md:flex items-center gap-8 ]`,
                children: v.jsx("ul", {
                    className: "flex flex-col  gap-8 items-center",
                    children: n.map(i => v.jsx("li", {
                        className: "nav-link",
                        onClick: r,
                        children: v.jsx(N2, {
                            path: i.path,
                            label: i.label
                        })
                    }, i.id))
                })
            })
        })
    };
var f0 = {
        color: void 0,
        size: void 0,
        className: void 0,
        style: void 0,
        attr: void 0
    },
    mh = ht.createContext && ht.createContext(f0),
    _2 = ["attr", "size", "title"];

function O2(e, t) {
    if (e == null) return {};
    var n = V2(e, t),
        r, i;
    if (Object.getOwnPropertySymbols) {
        var o = Object.getOwnPropertySymbols(e);
        for (i = 0; i < o.length; i++) r = o[i], !(t.indexOf(r) >= 0) && Object.prototype.propertyIsEnumerable.call(e, r) && (n[r] = e[r])
    }
    return n
}

function V2(e, t) {
    if (e == null) return {};
    var n = {};
    for (var r in e)
        if (Object.prototype.hasOwnProperty.call(e, r)) {
            if (t.indexOf(r) >= 0) continue;
            n[r] = e[r]
        }
    return n
}

function aa() {
    return aa = Object.assign ? Object.assign.bind() : function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    }, aa.apply(this, arguments)
}

function gh(e, t) {
    var n = Object.keys(e);
    if (Object.getOwnPropertySymbols) {
        var r = Object.getOwnPropertySymbols(e);
        t && (r = r.filter(function(i) {
            return Object.getOwnPropertyDescriptor(e, i).enumerable
        })), n.push.apply(n, r)
    }
    return n
}

function la(e) {
    for (var t = 1; t < arguments.length; t++) {
        var n = arguments[t] != null ? arguments[t] : {};
        t % 2 ? gh(Object(n), !0).forEach(function(r) {
            F2(e, r, n[r])
        }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(n)) : gh(Object(n)).forEach(function(r) {
            Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(n, r))
        })
    }
    return e
}

function F2(e, t, n) {
    return t = I2(t), t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function I2(e) {
    var t = z2(e, "string");
    return typeof t == "symbol" ? t : t + ""
}

function z2(e, t) {
    if (typeof e != "object" || !e) return e;
    var n = e[Symbol.toPrimitive];
    if (n !== void 0) {
        var r = n.call(e, t || "default");
        if (typeof r != "object") return r;
        throw new TypeError("@@toPrimitive must return a primitive value.")
    }
    return (t === "string" ? String : Number)(e)
}

function h0(e) {
    return e && e.map((t, n) => ht.createElement(t.tag, la({
        key: n
    }, t.attr), h0(t.child)))
}

function et(e) {
    return t => ht.createElement(b2, aa({
        attr: la({}, e.attr)
    }, t), h0(e.child))
}

function b2(e) {
    var t = n => {
        var {
            attr: r,
            size: i,
            title: o
        } = e, s = O2(e, _2), a = i || n.size || "1em", l;
        return n.className && (l = n.className), e.className && (l = (l ? l + " " : "") + e.className), ht.createElement("svg", aa({
            stroke: "currentColor",
            fill: "currentColor",
            strokeWidth: "0"
        }, n.attr, r, s, {
            className: l,
            style: la(la({
                color: e.color || n.color
            }, n.style), e.style),
            height: a,
            width: a,
            xmlns: "http://www.w3.org/2000/svg"
        }), o && ht.createElement("title", null, o), e.children)
    };
    return mh !== void 0 ? ht.createElement(mh.Consumer, null, n => t(n)) : t(f0)
}

function B2(e) {
    return et({
        tag: "svg",
        attr: {
            fill: "currentColor",
            viewBox: "0 0 16 16"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27s1.36.09 2 .27c1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.01 8.01 0 0 0 16 8c0-4.42-3.58-8-8-8"
            },
            child: []
        }]
    })(e)
}

function U2(e) {
    return et({
        tag: "svg",
        attr: {
            fill: "currentColor",
            viewBox: "0 0 16 16"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M0 1.146C0 .513.526 0 1.175 0h13.65C15.474 0 16 .513 16 1.146v13.708c0 .633-.526 1.146-1.175 1.146H1.175C.526 16 0 15.487 0 14.854zm4.943 12.248V6.169H2.542v7.225zm-1.2-8.212c.837 0 1.358-.554 1.358-1.248-.015-.709-.52-1.248-1.342-1.248S2.4 3.226 2.4 3.934c0 .694.521 1.248 1.327 1.248zm4.908 8.212V9.359c0-.216.016-.432.08-.586.173-.431.568-.878 1.232-.878.869 0 1.216.662 1.216 1.634v3.865h2.401V9.25c0-2.22-1.184-3.252-2.764-3.252-1.274 0-1.845.7-2.165 1.193v.025h-.016l.016-.025V6.169h-2.4c.03.678 0 7.225 0 7.225z"
            },
            child: []
        }]
    })(e)
}
const H2 = ({
    href: e,
    icon: t
}) => v.jsx("a", {
    href: e,
    target: "_blank",
    rel: "noopener noreferrer",
    className: "text-[30px] hover:scale-110 duration-500",
    children: v.jsx(t, {})
});

function $2(e) {
    if (typeof Proxy > "u") return e;
    const t = new Map,
        n = (...r) => e(...r);
    return new Proxy(n, {
        get: (r, i) => i === "create" ? e : (t.has(i) || t.set(i, e(i)), t.get(i))
    })
}

function So(e) {
    return e !== null && typeof e == "object" && typeof e.start == "function"
}
const Mu = e => Array.isArray(e);

function p0(e, t) {
    if (!Array.isArray(t)) return !1;
    const n = t.length;
    if (n !== e.length) return !1;
    for (let r = 0; r < n; r++)
        if (t[r] !== e[r]) return !1;
    return !0
}

function To(e) {
    return typeof e == "string" || Array.isArray(e)
}

function vh(e) {
    const t = [{}, {}];
    return e == null || e.values.forEach((n, r) => {
        t[0][r] = n.get(), t[1][r] = n.getVelocity()
    }), t
}

function qc(e, t, n, r) {
    if (typeof t == "function") {
        const [i, o] = vh(r);
        t = t(n !== void 0 ? n : e.custom, i, o)
    }
    if (typeof t == "string" && (t = e.variants && e.variants[t]), typeof t == "function") {
        const [i, o] = vh(r);
        t = t(n !== void 0 ? n : e.custom, i, o)
    }
    return t
}

function Oa(e, t, n) {
    const r = e.getProps();
    return qc(r, t, n !== void 0 ? n : r.custom, e)
}
const ed = ["animate", "whileInView", "whileFocus", "whileHover", "whileTap", "whileDrag", "exit"],
    td = ["initial", ...ed],
    _o = ["transformPerspective", "x", "y", "z", "translateX", "translateY", "translateZ", "scale", "scaleX", "scaleY", "rotate", "rotateX", "rotateY", "rotateZ", "skew", "skewX", "skewY"],
    Xn = new Set(_o),
    ln = e => e * 1e3,
    un = e => e / 1e3,
    W2 = {
        type: "spring",
        stiffness: 500,
        damping: 25,
        restSpeed: 10
    },
    K2 = e => ({
        type: "spring",
        stiffness: 550,
        damping: e === 0 ? 2 * Math.sqrt(550) : 30,
        restSpeed: 10
    }),
    G2 = {
        type: "keyframes",
        duration: .8
    },
    Y2 = {
        type: "keyframes",
        ease: [.25, .1, .35, 1],
        duration: .3
    },
    Q2 = (e, {
        keyframes: t
    }) => t.length > 2 ? G2 : Xn.has(e) ? e.startsWith("scale") ? K2(t[1]) : W2 : Y2;

function nd(e, t) {
    return e[t] || e.default || e
}
const X2 = {
        skipAnimations: !1,
        useManualTiming: !1
    },
    Z2 = e => e !== null;

function Va(e, {
    repeat: t,
    repeatType: n = "loop"
}, r) {
    const i = e.filter(Z2),
        o = t && n !== "loop" && t % 2 === 1 ? 0 : i.length - 1;
    return !o || r === void 0 ? i[o] : r
}
const Ke = e => e;

function J2(e) {
    let t = new Set,
        n = new Set,
        r = !1,
        i = !1;
    const o = new WeakSet;
    let s = {
        delta: 0,
        timestamp: 0,
        isProcessing: !1
    };

    function a(u) {
        o.has(u) && (l.schedule(u), e()), u(s)
    }
    const l = {
        schedule: (u, c = !1, d = !1) => {
            const m = d && r ? t : n;
            return c && o.add(u), m.has(u) || m.add(u), u
        },
        cancel: u => {
            n.delete(u), o.delete(u)
        },
        process: u => {
            if (s = u, r) {
                i = !0;
                return
            }
            r = !0, [t, n] = [n, t], n.clear(), t.forEach(a), r = !1, i && (i = !1, l.process(u))
        }
    };
    return l
}
const fs = ["read", "resolveKeyframes", "update", "preRender", "render", "postRender"],
    q2 = 40;

function m0(e, t) {
    let n = !1,
        r = !0;
    const i = {
            delta: 0,
            timestamp: 0,
            isProcessing: !1
        },
        o = () => n = !0,
        s = fs.reduce((p, h) => (p[h] = J2(o), p), {}),
        {
            read: a,
            resolveKeyframes: l,
            update: u,
            preRender: c,
            render: d,
            postRender: f
        } = s,
        m = () => {
            const p = performance.now();
            n = !1, i.delta = r ? 1e3 / 60 : Math.max(Math.min(p - i.timestamp, q2), 1), i.timestamp = p, i.isProcessing = !0, a.process(i), l.process(i), u.process(i), c.process(i), d.process(i), f.process(i), i.isProcessing = !1, n && t && (r = !1, e(m))
        },
        x = () => {
            n = !0, r = !0, i.isProcessing || e(m)
        };
    return {
        schedule: fs.reduce((p, h) => {
            const g = s[h];
            return p[h] = (P, R = !1, A = !1) => (n || x(), g.schedule(P, R, A)), p
        }, {}),
        cancel: p => {
            for (let h = 0; h < fs.length; h++) s[fs[h]].cancel(p)
        },
        state: i,
        steps: s
    }
}
const {
    schedule: oe,
    cancel: Bn,
    state: Ie,
    steps: wl
} = m0(typeof requestAnimationFrame < "u" ? requestAnimationFrame : Ke, !0), g0 = (e, t, n) => (((1 - 3 * n + 3 * t) * e + (3 * n - 6 * t)) * e + 3 * t) * e, eS = 1e-7, tS = 12;

function nS(e, t, n, r, i) {
    let o, s, a = 0;
    do s = t + (n - t) / 2, o = g0(s, r, i) - e, o > 0 ? n = s : t = s; while (Math.abs(o) > eS && ++a < tS);
    return s
}

function Oo(e, t, n, r) {
    if (e === t && n === r) return Ke;
    const i = o => nS(o, 0, 1, e, n);
    return o => o === 0 || o === 1 ? o : g0(i(o), t, r)
}
const v0 = e => t => t <= .5 ? e(2 * t) / 2 : (2 - e(2 * (1 - t))) / 2,
    y0 = e => t => 1 - e(1 - t),
    x0 = Oo(.33, 1.53, .69, .99),
    rd = y0(x0),
    w0 = v0(rd),
    S0 = e => (e *= 2) < 1 ? .5 * rd(e) : .5 * (2 - Math.pow(2, -10 * (e - 1))),
    id = e => 1 - Math.sin(Math.acos(e)),
    T0 = y0(id),
    P0 = v0(id),
    E0 = e => /^0[^.\s]+$/u.test(e);

function rS(e) {
    return typeof e == "number" ? e === 0 : e !== null ? e === "none" || e === "0" || E0(e) : !0
}
let Nu = Ke;
const C0 = e => /^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),
    k0 = e => t => typeof t == "string" && t.startsWith(e),
    R0 = k0("--"),
    iS = k0("var(--"),
    od = e => iS(e) ? oS.test(e.split("/*")[0].trim()) : !1,
    oS = /var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu,
    sS = /^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;

function aS(e) {
    const t = sS.exec(e);
    if (!t) return [, ];
    const [, n, r, i] = t;
    return [`--${n??r}`, i]
}

function j0(e, t, n = 1) {
    const [r, i] = aS(e);
    if (!r) return;
    const o = window.getComputedStyle(t).getPropertyValue(r);
    if (o) {
        const s = o.trim();
        return C0(s) ? parseFloat(s) : s
    }
    return od(i) ? j0(i, t, n + 1) : i
}
const Un = (e, t, n) => n > t ? t : n < e ? e : n,
    xi = {
        test: e => typeof e == "number",
        parse: parseFloat,
        transform: e => e
    },
    Po = { ...xi,
        transform: e => Un(0, 1, e)
    },
    hs = { ...xi,
        default: 1
    },
    Vo = e => ({
        test: t => typeof t == "string" && t.endsWith(e) && t.split(" ").length === 1,
        parse: parseFloat,
        transform: t => `${t}${e}`
    }),
    Pn = Vo("deg"),
    Wt = Vo("%"),
    $ = Vo("px"),
    lS = Vo("vh"),
    uS = Vo("vw"),
    yh = { ...Wt,
        parse: e => Wt.parse(e) / 100,
        transform: e => Wt.transform(e * 100)
    },
    cS = new Set(["width", "height", "top", "left", "right", "bottom", "x", "y", "translateX", "translateY"]),
    xh = e => e === xi || e === $,
    wh = (e, t) => parseFloat(e.split(", ")[t]),
    Sh = (e, t) => (n, {
        transform: r
    }) => {
        if (r === "none" || !r) return 0;
        const i = r.match(/^matrix3d\((.+)\)$/u);
        if (i) return wh(i[1], t); {
            const o = r.match(/^matrix\((.+)\)$/u);
            return o ? wh(o[1], e) : 0
        }
    },
    dS = new Set(["x", "y", "z"]),
    fS = _o.filter(e => !dS.has(e));

function hS(e) {
    const t = [];
    return fS.forEach(n => {
        const r = e.getValue(n);
        r !== void 0 && (t.push([n, r.get()]), r.set(n.startsWith("scale") ? 1 : 0))
    }), t
}
const di = {
    width: ({
        x: e
    }, {
        paddingLeft: t = "0",
        paddingRight: n = "0"
    }) => e.max - e.min - parseFloat(t) - parseFloat(n),
    height: ({
        y: e
    }, {
        paddingTop: t = "0",
        paddingBottom: n = "0"
    }) => e.max - e.min - parseFloat(t) - parseFloat(n),
    top: (e, {
        top: t
    }) => parseFloat(t),
    left: (e, {
        left: t
    }) => parseFloat(t),
    bottom: ({
        y: e
    }, {
        top: t
    }) => parseFloat(t) + (e.max - e.min),
    right: ({
        x: e
    }, {
        left: t
    }) => parseFloat(t) + (e.max - e.min),
    x: Sh(4, 13),
    y: Sh(5, 14)
};
di.translateX = di.x;
di.translateY = di.y;
const A0 = e => t => t.test(e),
    pS = {
        test: e => e === "auto",
        parse: e => e
    },
    L0 = [xi, $, Wt, Pn, uS, lS, pS],
    Th = e => L0.find(A0(e)),
    mr = new Set;
let Du = !1,
    _u = !1;

function M0() {
    if (_u) {
        const e = Array.from(mr).filter(r => r.needsMeasurement),
            t = new Set(e.map(r => r.element)),
            n = new Map;
        t.forEach(r => {
            const i = hS(r);
            i.length && (n.set(r, i), r.render())
        }), e.forEach(r => r.measureInitialState()), t.forEach(r => {
            r.render();
            const i = n.get(r);
            i && i.forEach(([o, s]) => {
                var a;
                (a = r.getValue(o)) === null || a === void 0 || a.set(s)
            })
        }), e.forEach(r => r.measureEndState()), e.forEach(r => {
            r.suspendedScrollY !== void 0 && window.scrollTo(0, r.suspendedScrollY)
        })
    }
    _u = !1, Du = !1, mr.forEach(e => e.complete()), mr.clear()
}

function N0() {
    mr.forEach(e => {
        e.readKeyframes(), e.needsMeasurement && (_u = !0)
    })
}

function mS() {
    N0(), M0()
}
class sd {
    constructor(t, n, r, i, o, s = !1) {
        this.isComplete = !1, this.isAsync = !1, this.needsMeasurement = !1, this.isScheduled = !1, this.unresolvedKeyframes = [...t], this.onComplete = n, this.name = r, this.motionValue = i, this.element = o, this.isAsync = s
    }
    scheduleResolve() {
        this.isScheduled = !0, this.isAsync ? (mr.add(this), Du || (Du = !0, oe.read(N0), oe.resolveKeyframes(M0))) : (this.readKeyframes(), this.complete())
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: t,
            name: n,
            element: r,
            motionValue: i
        } = this;
        for (let o = 0; o < t.length; o++)
            if (t[o] === null)
                if (o === 0) {
                    const s = i == null ? void 0 : i.get(),
                        a = t[t.length - 1];
                    if (s !== void 0) t[0] = s;
                    else if (r && n) {
                        const l = r.readValue(n, a);
                        l != null && (t[0] = l)
                    }
                    t[0] === void 0 && (t[0] = a), i && s === void 0 && i.set(t[0])
                } else t[o] = t[o - 1]
    }
    setFinalKeyframe() {}
    measureInitialState() {}
    renderEndStyles() {}
    measureEndState() {}
    complete() {
        this.isComplete = !0, this.onComplete(this.unresolvedKeyframes, this.finalKeyframe), mr.delete(this)
    }
    cancel() {
        this.isComplete || (this.isScheduled = !1, mr.delete(this))
    }
    resume() {
        this.isComplete || this.scheduleResolve()
    }
}
const Ji = e => Math.round(e * 1e5) / 1e5,
    ad = /-?(?:\d+(?:\.\d+)?|\.\d+)/gu;

function gS(e) {
    return e == null
}
const vS = /^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,
    ld = (e, t) => n => !!(typeof n == "string" && vS.test(n) && n.startsWith(e) || t && !gS(n) && Object.prototype.hasOwnProperty.call(n, t)),
    D0 = (e, t, n) => r => {
        if (typeof r != "string") return r;
        const [i, o, s, a] = r.match(ad);
        return {
            [e]: parseFloat(i),
            [t]: parseFloat(o),
            [n]: parseFloat(s),
            alpha: a !== void 0 ? parseFloat(a) : 1
        }
    },
    yS = e => Un(0, 255, e),
    Sl = { ...xi,
        transform: e => Math.round(yS(e))
    },
    fr = {
        test: ld("rgb", "red"),
        parse: D0("red", "green", "blue"),
        transform: ({
            red: e,
            green: t,
            blue: n,
            alpha: r = 1
        }) => "rgba(" + Sl.transform(e) + ", " + Sl.transform(t) + ", " + Sl.transform(n) + ", " + Ji(Po.transform(r)) + ")"
    };

function xS(e) {
    let t = "",
        n = "",
        r = "",
        i = "";
    return e.length > 5 ? (t = e.substring(1, 3), n = e.substring(3, 5), r = e.substring(5, 7), i = e.substring(7, 9)) : (t = e.substring(1, 2), n = e.substring(2, 3), r = e.substring(3, 4), i = e.substring(4, 5), t += t, n += n, r += r, i += i), {
        red: parseInt(t, 16),
        green: parseInt(n, 16),
        blue: parseInt(r, 16),
        alpha: i ? parseInt(i, 16) / 255 : 1
    }
}
const Ou = {
        test: ld("#"),
        parse: xS,
        transform: fr.transform
    },
    Hr = {
        test: ld("hsl", "hue"),
        parse: D0("hue", "saturation", "lightness"),
        transform: ({
            hue: e,
            saturation: t,
            lightness: n,
            alpha: r = 1
        }) => "hsla(" + Math.round(e) + ", " + Wt.transform(Ji(t)) + ", " + Wt.transform(Ji(n)) + ", " + Ji(Po.transform(r)) + ")"
    },
    He = {
        test: e => fr.test(e) || Ou.test(e) || Hr.test(e),
        parse: e => fr.test(e) ? fr.parse(e) : Hr.test(e) ? Hr.parse(e) : Ou.parse(e),
        transform: e => typeof e == "string" ? e : e.hasOwnProperty("red") ? fr.transform(e) : Hr.transform(e)
    },
    wS = /(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;

function SS(e) {
    var t, n;
    return isNaN(e) && typeof e == "string" && (((t = e.match(ad)) === null || t === void 0 ? void 0 : t.length) || 0) + (((n = e.match(wS)) === null || n === void 0 ? void 0 : n.length) || 0) > 0
}
const _0 = "number",
    O0 = "color",
    TS = "var",
    PS = "var(",
    Ph = "${}",
    ES = /var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;

function Eo(e) {
    const t = e.toString(),
        n = [],
        r = {
            color: [],
            number: [],
            var: []
        },
        i = [];
    let o = 0;
    const a = t.replace(ES, l => (He.test(l) ? (r.color.push(o), i.push(O0), n.push(He.parse(l))) : l.startsWith(PS) ? (r.var.push(o), i.push(TS), n.push(l)) : (r.number.push(o), i.push(_0), n.push(parseFloat(l))), ++o, Ph)).split(Ph);
    return {
        values: n,
        split: a,
        indexes: r,
        types: i
    }
}

function V0(e) {
    return Eo(e).values
}

function F0(e) {
    const {
        split: t,
        types: n
    } = Eo(e), r = t.length;
    return i => {
        let o = "";
        for (let s = 0; s < r; s++)
            if (o += t[s], i[s] !== void 0) {
                const a = n[s];
                a === _0 ? o += Ji(i[s]) : a === O0 ? o += He.transform(i[s]) : o += i[s]
            }
        return o
    }
}
const CS = e => typeof e == "number" ? 0 : e;

function kS(e) {
    const t = V0(e);
    return F0(e)(t.map(CS))
}
const Hn = {
        test: SS,
        parse: V0,
        createTransformer: F0,
        getAnimatableNone: kS
    },
    RS = new Set(["brightness", "contrast", "saturate", "opacity"]);

function jS(e) {
    const [t, n] = e.slice(0, -1).split("(");
    if (t === "drop-shadow") return e;
    const [r] = n.match(ad) || [];
    if (!r) return e;
    const i = n.replace(r, "");
    let o = RS.has(t) ? 1 : 0;
    return r !== n && (o *= 100), t + "(" + o + i + ")"
}
const AS = /\b([a-z-]*)\(.*?\)/gu,
    Vu = { ...Hn,
        getAnimatableNone: e => {
            const t = e.match(AS);
            return t ? t.map(jS).join(" ") : e
        }
    },
    LS = {
        borderWidth: $,
        borderTopWidth: $,
        borderRightWidth: $,
        borderBottomWidth: $,
        borderLeftWidth: $,
        borderRadius: $,
        radius: $,
        borderTopLeftRadius: $,
        borderTopRightRadius: $,
        borderBottomRightRadius: $,
        borderBottomLeftRadius: $,
        width: $,
        maxWidth: $,
        height: $,
        maxHeight: $,
        top: $,
        right: $,
        bottom: $,
        left: $,
        padding: $,
        paddingTop: $,
        paddingRight: $,
        paddingBottom: $,
        paddingLeft: $,
        margin: $,
        marginTop: $,
        marginRight: $,
        marginBottom: $,
        marginLeft: $,
        backgroundPositionX: $,
        backgroundPositionY: $
    },
    MS = {
        rotate: Pn,
        rotateX: Pn,
        rotateY: Pn,
        rotateZ: Pn,
        scale: hs,
        scaleX: hs,
        scaleY: hs,
        scaleZ: hs,
        skew: Pn,
        skewX: Pn,
        skewY: Pn,
        distance: $,
        translateX: $,
        translateY: $,
        translateZ: $,
        x: $,
        y: $,
        z: $,
        perspective: $,
        transformPerspective: $,
        opacity: Po,
        originX: yh,
        originY: yh,
        originZ: $
    },
    Eh = { ...xi,
        transform: Math.round
    },
    ud = { ...LS,
        ...MS,
        zIndex: Eh,
        size: $,
        fillOpacity: Po,
        strokeOpacity: Po,
        numOctaves: Eh
    },
    NS = { ...ud,
        color: He,
        backgroundColor: He,
        outlineColor: He,
        fill: He,
        stroke: He,
        borderColor: He,
        borderTopColor: He,
        borderRightColor: He,
        borderBottomColor: He,
        borderLeftColor: He,
        filter: Vu,
        WebkitFilter: Vu
    },
    cd = e => NS[e];

function I0(e, t) {
    let n = cd(e);
    return n !== Vu && (n = Hn), n.getAnimatableNone ? n.getAnimatableNone(t) : void 0
}
const DS = new Set(["auto", "none", "0"]);

function _S(e, t, n) {
    let r = 0,
        i;
    for (; r < e.length && !i;) {
        const o = e[r];
        typeof o == "string" && !DS.has(o) && Eo(o).values.length && (i = e[r]), r++
    }
    if (i && n)
        for (const o of t) e[o] = I0(n, i)
}
class z0 extends sd {
    constructor(t, n, r, i, o) {
        super(t, n, r, i, o, !0)
    }
    readKeyframes() {
        const {
            unresolvedKeyframes: t,
            element: n,
            name: r
        } = this;
        if (!n || !n.current) return;
        super.readKeyframes();
        for (let l = 0; l < t.length; l++) {
            let u = t[l];
            if (typeof u == "string" && (u = u.trim(), od(u))) {
                const c = j0(u, n.current);
                c !== void 0 && (t[l] = c), l === t.length - 1 && (this.finalKeyframe = u)
            }
        }
        if (this.resolveNoneKeyframes(), !cS.has(r) || t.length !== 2) return;
        const [i, o] = t, s = Th(i), a = Th(o);
        if (s !== a)
            if (xh(s) && xh(a))
                for (let l = 0; l < t.length; l++) {
                    const u = t[l];
                    typeof u == "string" && (t[l] = parseFloat(u))
                } else this.needsMeasurement = !0
    }
    resolveNoneKeyframes() {
        const {
            unresolvedKeyframes: t,
            name: n
        } = this, r = [];
        for (let i = 0; i < t.length; i++) rS(t[i]) && r.push(i);
        r.length && _S(t, r, n)
    }
    measureInitialState() {
        const {
            element: t,
            unresolvedKeyframes: n,
            name: r
        } = this;
        if (!t || !t.current) return;
        r === "height" && (this.suspendedScrollY = window.pageYOffset), this.measuredOrigin = di[r](t.measureViewportBox(), window.getComputedStyle(t.current)), n[0] = this.measuredOrigin;
        const i = n[n.length - 1];
        i !== void 0 && t.getValue(r, i).jump(i, !1)
    }
    measureEndState() {
        var t;
        const {
            element: n,
            name: r,
            unresolvedKeyframes: i
        } = this;
        if (!n || !n.current) return;
        const o = n.getValue(r);
        o && o.jump(this.measuredOrigin, !1);
        const s = i.length - 1,
            a = i[s];
        i[s] = di[r](n.measureViewportBox(), window.getComputedStyle(n.current)), a !== null && this.finalKeyframe === void 0 && (this.finalKeyframe = a), !((t = this.removedTransforms) === null || t === void 0) && t.length && this.removedTransforms.forEach(([l, u]) => {
            n.getValue(l).set(u)
        }), this.resolveNoneKeyframes()
    }
}

function dd(e) {
    return typeof e == "function"
}
let js;

function OS() {
    js = void 0
}
const Kt = {
        now: () => (js === void 0 && Kt.set(Ie.isProcessing || X2.useManualTiming ? Ie.timestamp : performance.now()), js),
        set: e => {
            js = e, queueMicrotask(OS)
        }
    },
    Ch = (e, t) => t === "zIndex" ? !1 : !!(typeof e == "number" || Array.isArray(e) || typeof e == "string" && (Hn.test(e) || e === "0") && !e.startsWith("url("));

function VS(e) {
    const t = e[0];
    if (e.length === 1) return !0;
    for (let n = 0; n < e.length; n++)
        if (e[n] !== t) return !0
}

function FS(e, t, n, r) {
    const i = e[0];
    if (i === null) return !1;
    if (t === "display" || t === "visibility") return !0;
    const o = e[e.length - 1],
        s = Ch(i, t),
        a = Ch(o, t);
    return !s || !a ? !1 : VS(e) || (n === "spring" || dd(n)) && r
}
const IS = 40;
class b0 {
    constructor({
        autoplay: t = !0,
        delay: n = 0,
        type: r = "keyframes",
        repeat: i = 0,
        repeatDelay: o = 0,
        repeatType: s = "loop",
        ...a
    }) {
        this.isStopped = !1, this.hasAttemptedResolve = !1, this.createdAt = Kt.now(), this.options = {
            autoplay: t,
            delay: n,
            type: r,
            repeat: i,
            repeatDelay: o,
            repeatType: s,
            ...a
        }, this.updateFinishedPromise()
    }
    calcStartTime() {
        return this.resolvedAt ? this.resolvedAt - this.createdAt > IS ? this.resolvedAt : this.createdAt : this.createdAt
    }
    get resolved() {
        return !this._resolved && !this.hasAttemptedResolve && mS(), this._resolved
    }
    onKeyframesResolved(t, n) {
        this.resolvedAt = Kt.now(), this.hasAttemptedResolve = !0;
        const {
            name: r,
            type: i,
            velocity: o,
            delay: s,
            onComplete: a,
            onUpdate: l,
            isGenerator: u
        } = this.options;
        if (!u && !FS(t, r, i, o))
            if (s) this.options.duration = 0;
            else {
                l == null || l(Va(t, this.options, n)), a == null || a(), this.resolveFinishedPromise();
                return
            }
        const c = this.initPlayback(t, n);
        c !== !1 && (this._resolved = {
            keyframes: t,
            finalKeyframe: n,
            ...c
        }, this.onPostResolved())
    }
    onPostResolved() {}
    then(t, n) {
        return this.currentFinishedPromise.then(t, n)
    }
    updateFinishedPromise() {
        this.currentFinishedPromise = new Promise(t => {
            this.resolveFinishedPromise = t
        })
    }
}

function B0(e, t) {
    return t ? e * (1e3 / t) : 0
}
const zS = 5;

function U0(e, t, n) {
    const r = Math.max(t - zS, 0);
    return B0(n - e(r), t - r)
}
const Tl = .001,
    bS = .01,
    BS = 10,
    US = .05,
    HS = 1;

function $S({
    duration: e = 800,
    bounce: t = .25,
    velocity: n = 0,
    mass: r = 1
}) {
    let i, o, s = 1 - t;
    s = Un(US, HS, s), e = Un(bS, BS, un(e)), s < 1 ? (i = u => {
        const c = u * s,
            d = c * e,
            f = c - n,
            m = Fu(u, s),
            x = Math.exp(-d);
        return Tl - f / m * x
    }, o = u => {
        const d = u * s * e,
            f = d * n + n,
            m = Math.pow(s, 2) * Math.pow(u, 2) * e,
            x = Math.exp(-d),
            w = Fu(Math.pow(u, 2), s);
        return (-i(u) + Tl > 0 ? -1 : 1) * ((f - m) * x) / w
    }) : (i = u => {
        const c = Math.exp(-u * e),
            d = (u - n) * e + 1;
        return -Tl + c * d
    }, o = u => {
        const c = Math.exp(-u * e),
            d = (n - u) * (e * e);
        return c * d
    });
    const a = 5 / e,
        l = KS(i, o, a);
    if (e = ln(e), isNaN(l)) return {
        stiffness: 100,
        damping: 10,
        duration: e
    }; {
        const u = Math.pow(l, 2) * r;
        return {
            stiffness: u,
            damping: s * 2 * Math.sqrt(r * u),
            duration: e
        }
    }
}
const WS = 12;

function KS(e, t, n) {
    let r = n;
    for (let i = 1; i < WS; i++) r = r - e(r) / t(r);
    return r
}

function Fu(e, t) {
    return e * Math.sqrt(1 - t * t)
}
const GS = ["duration", "bounce"],
    YS = ["stiffness", "damping", "mass"];

function kh(e, t) {
    return t.some(n => e[n] !== void 0)
}

function QS(e) {
    let t = {
        velocity: 0,
        stiffness: 100,
        damping: 10,
        mass: 1,
        isResolvedFromDuration: !1,
        ...e
    };
    if (!kh(e, YS) && kh(e, GS)) {
        const n = $S(e);
        t = { ...t,
            ...n,
            mass: 1
        }, t.isResolvedFromDuration = !0
    }
    return t
}

function H0({
    keyframes: e,
    restDelta: t,
    restSpeed: n,
    ...r
}) {
    const i = e[0],
        o = e[e.length - 1],
        s = {
            done: !1,
            value: i
        },
        {
            stiffness: a,
            damping: l,
            mass: u,
            duration: c,
            velocity: d,
            isResolvedFromDuration: f
        } = QS({ ...r,
            velocity: -un(r.velocity || 0)
        }),
        m = d || 0,
        x = l / (2 * Math.sqrt(a * u)),
        w = o - i,
        E = un(Math.sqrt(a / u)),
        p = Math.abs(w) < 5;
    n || (n = p ? .01 : 2), t || (t = p ? .005 : .5);
    let h;
    if (x < 1) {
        const g = Fu(E, x);
        h = P => {
            const R = Math.exp(-x * E * P);
            return o - R * ((m + x * E * w) / g * Math.sin(g * P) + w * Math.cos(g * P))
        }
    } else if (x === 1) h = g => o - Math.exp(-E * g) * (w + (m + E * w) * g);
    else {
        const g = E * Math.sqrt(x * x - 1);
        h = P => {
            const R = Math.exp(-x * E * P),
                A = Math.min(g * P, 300);
            return o - R * ((m + x * E * w) * Math.sinh(A) + g * w * Math.cosh(A)) / g
        }
    }
    return {
        calculatedDuration: f && c || null,
        next: g => {
            const P = h(g);
            if (f) s.done = g >= c;
            else {
                let R = 0;
                x < 1 && (R = g === 0 ? ln(m) : U0(h, g, P));
                const A = Math.abs(R) <= n,
                    N = Math.abs(o - P) <= t;
                s.done = A && N
            }
            return s.value = s.done ? o : P, s
        }
    }
}

function Rh({
    keyframes: e,
    velocity: t = 0,
    power: n = .8,
    timeConstant: r = 325,
    bounceDamping: i = 10,
    bounceStiffness: o = 500,
    modifyTarget: s,
    min: a,
    max: l,
    restDelta: u = .5,
    restSpeed: c
}) {
    const d = e[0],
        f = {
            done: !1,
            value: d
        },
        m = y => a !== void 0 && y < a || l !== void 0 && y > l,
        x = y => a === void 0 ? l : l === void 0 || Math.abs(a - y) < Math.abs(l - y) ? a : l;
    let w = n * t;
    const E = d + w,
        p = s === void 0 ? E : s(E);
    p !== E && (w = p - d);
    const h = y => -w * Math.exp(-y / r),
        g = y => p + h(y),
        P = y => {
            const O = h(y),
                M = g(y);
            f.done = Math.abs(O) <= u, f.value = f.done ? p : M
        };
    let R, A;
    const N = y => {
        m(f.value) && (R = y, A = H0({
            keyframes: [f.value, x(f.value)],
            velocity: U0(g, y, f.value),
            damping: i,
            stiffness: o,
            restDelta: u,
            restSpeed: c
        }))
    };
    return N(0), {
        calculatedDuration: null,
        next: y => {
            let O = !1;
            return !A && R === void 0 && (O = !0, P(y), N(y)), R !== void 0 && y >= R ? A.next(y - R) : (!O && P(y), f)
        }
    }
}
const XS = Oo(.42, 0, 1, 1),
    ZS = Oo(0, 0, .58, 1),
    $0 = Oo(.42, 0, .58, 1),
    JS = e => Array.isArray(e) && typeof e[0] != "number",
    fd = e => Array.isArray(e) && typeof e[0] == "number",
    jh = {
        linear: Ke,
        easeIn: XS,
        easeInOut: $0,
        easeOut: ZS,
        circIn: id,
        circInOut: P0,
        circOut: T0,
        backIn: rd,
        backInOut: w0,
        backOut: x0,
        anticipate: S0
    },
    Ah = e => {
        if (fd(e)) {
            Nu(e.length === 4);
            const [t, n, r, i] = e;
            return Oo(t, n, r, i)
        } else if (typeof e == "string") return Nu(jh[e] !== void 0), jh[e];
        return e
    },
    qS = (e, t) => n => t(e(n)),
    cn = (...e) => e.reduce(qS),
    fi = (e, t, n) => {
        const r = t - e;
        return r === 0 ? 1 : (n - e) / r
    },
    xe = (e, t, n) => e + (t - e) * n;

function Pl(e, t, n) {
    return n < 0 && (n += 1), n > 1 && (n -= 1), n < 1 / 6 ? e + (t - e) * 6 * n : n < 1 / 2 ? t : n < 2 / 3 ? e + (t - e) * (2 / 3 - n) * 6 : e
}

function e3({
    hue: e,
    saturation: t,
    lightness: n,
    alpha: r
}) {
    e /= 360, t /= 100, n /= 100;
    let i = 0,
        o = 0,
        s = 0;
    if (!t) i = o = s = n;
    else {
        const a = n < .5 ? n * (1 + t) : n + t - n * t,
            l = 2 * n - a;
        i = Pl(l, a, e + 1 / 3), o = Pl(l, a, e), s = Pl(l, a, e - 1 / 3)
    }
    return {
        red: Math.round(i * 255),
        green: Math.round(o * 255),
        blue: Math.round(s * 255),
        alpha: r
    }
}

function ua(e, t) {
    return n => n > 0 ? t : e
}
const El = (e, t, n) => {
        const r = e * e,
            i = n * (t * t - r) + r;
        return i < 0 ? 0 : Math.sqrt(i)
    },
    t3 = [Ou, fr, Hr],
    n3 = e => t3.find(t => t.test(e));

function Lh(e) {
    const t = n3(e);
    if (!t) return !1;
    let n = t.parse(e);
    return t === Hr && (n = e3(n)), n
}
const Mh = (e, t) => {
        const n = Lh(e),
            r = Lh(t);
        if (!n || !r) return ua(e, t);
        const i = { ...n
        };
        return o => (i.red = El(n.red, r.red, o), i.green = El(n.green, r.green, o), i.blue = El(n.blue, r.blue, o), i.alpha = xe(n.alpha, r.alpha, o), fr.transform(i))
    },
    Iu = new Set(["none", "hidden"]);

function r3(e, t) {
    return Iu.has(e) ? n => n <= 0 ? e : t : n => n >= 1 ? t : e
}

function i3(e, t) {
    return n => xe(e, t, n)
}

function hd(e) {
    return typeof e == "number" ? i3 : typeof e == "string" ? od(e) ? ua : He.test(e) ? Mh : a3 : Array.isArray(e) ? W0 : typeof e == "object" ? He.test(e) ? Mh : o3 : ua
}

function W0(e, t) {
    const n = [...e],
        r = n.length,
        i = e.map((o, s) => hd(o)(o, t[s]));
    return o => {
        for (let s = 0; s < r; s++) n[s] = i[s](o);
        return n
    }
}

function o3(e, t) {
    const n = { ...e,
            ...t
        },
        r = {};
    for (const i in n) e[i] !== void 0 && t[i] !== void 0 && (r[i] = hd(e[i])(e[i], t[i]));
    return i => {
        for (const o in r) n[o] = r[o](i);
        return n
    }
}

function s3(e, t) {
    var n;
    const r = [],
        i = {
            color: 0,
            var: 0,
            number: 0
        };
    for (let o = 0; o < t.values.length; o++) {
        const s = t.types[o],
            a = e.indexes[s][i[s]],
            l = (n = e.values[a]) !== null && n !== void 0 ? n : 0;
        r[o] = l, i[s]++
    }
    return r
}
const a3 = (e, t) => {
    const n = Hn.createTransformer(t),
        r = Eo(e),
        i = Eo(t);
    return r.indexes.var.length === i.indexes.var.length && r.indexes.color.length === i.indexes.color.length && r.indexes.number.length >= i.indexes.number.length ? Iu.has(e) && !i.values.length || Iu.has(t) && !r.values.length ? r3(e, t) : cn(W0(s3(r, i), i.values), n) : ua(e, t)
};

function K0(e, t, n) {
    return typeof e == "number" && typeof t == "number" && typeof n == "number" ? xe(e, t, n) : hd(e)(e, t)
}

function l3(e, t, n) {
    const r = [],
        i = n || K0,
        o = e.length - 1;
    for (let s = 0; s < o; s++) {
        let a = i(e[s], e[s + 1]);
        if (t) {
            const l = Array.isArray(t) ? t[s] || Ke : t;
            a = cn(l, a)
        }
        r.push(a)
    }
    return r
}

function u3(e, t, {
    clamp: n = !0,
    ease: r,
    mixer: i
} = {}) {
    const o = e.length;
    if (Nu(o === t.length), o === 1) return () => t[0];
    if (o === 2 && e[0] === e[1]) return () => t[1];
    e[0] > e[o - 1] && (e = [...e].reverse(), t = [...t].reverse());
    const s = l3(t, r, i),
        a = s.length,
        l = u => {
            let c = 0;
            if (a > 1)
                for (; c < e.length - 2 && !(u < e[c + 1]); c++);
            const d = fi(e[c], e[c + 1], u);
            return s[c](d)
        };
    return n ? u => l(Un(e[0], e[o - 1], u)) : l
}

function c3(e, t) {
    const n = e[e.length - 1];
    for (let r = 1; r <= t; r++) {
        const i = fi(0, t, r);
        e.push(xe(n, 1, i))
    }
}

function d3(e) {
    const t = [0];
    return c3(t, e.length - 1), t
}

function f3(e, t) {
    return e.map(n => n * t)
}

function h3(e, t) {
    return e.map(() => t || $0).splice(0, e.length - 1)
}

function ca({
    duration: e = 300,
    keyframes: t,
    times: n,
    ease: r = "easeInOut"
}) {
    const i = JS(r) ? r.map(Ah) : Ah(r),
        o = {
            done: !1,
            value: t[0]
        },
        s = f3(n && n.length === t.length ? n : d3(t), e),
        a = u3(s, t, {
            ease: Array.isArray(i) ? i : h3(t, i)
        });
    return {
        calculatedDuration: e,
        next: l => (o.value = a(l), o.done = l >= e, o)
    }
}
const Nh = 2e4;

function p3(e) {
    let t = 0;
    const n = 50;
    let r = e.next(t);
    for (; !r.done && t < Nh;) t += n, r = e.next(t);
    return t >= Nh ? 1 / 0 : t
}
const m3 = e => {
        const t = ({
            timestamp: n
        }) => e(n);
        return {
            start: () => oe.update(t, !0),
            stop: () => Bn(t),
            now: () => Ie.isProcessing ? Ie.timestamp : Kt.now()
        }
    },
    g3 = {
        decay: Rh,
        inertia: Rh,
        tween: ca,
        keyframes: ca,
        spring: H0
    },
    v3 = e => e / 100;
class pd extends b0 {
    constructor(t) {
        super(t), this.holdTime = null, this.cancelTime = null, this.currentTime = 0, this.playbackSpeed = 1, this.pendingPlayState = "running", this.startTime = null, this.state = "idle", this.stop = () => {
            if (this.resolver.cancel(), this.isStopped = !0, this.state === "idle") return;
            this.teardown();
            const {
                onStop: l
            } = this.options;
            l && l()
        };
        const {
            name: n,
            motionValue: r,
            element: i,
            keyframes: o
        } = this.options, s = (i == null ? void 0 : i.KeyframeResolver) || sd, a = (l, u) => this.onKeyframesResolved(l, u);
        this.resolver = new s(o, a, n, r, i), this.resolver.scheduleResolve()
    }
    initPlayback(t) {
        const {
            type: n = "keyframes",
            repeat: r = 0,
            repeatDelay: i = 0,
            repeatType: o,
            velocity: s = 0
        } = this.options, a = dd(n) ? n : g3[n] || ca;
        let l, u;
        a !== ca && typeof t[0] != "number" && (l = cn(v3, K0(t[0], t[1])), t = [0, 100]);
        const c = a({ ...this.options,
            keyframes: t
        });
        o === "mirror" && (u = a({ ...this.options,
            keyframes: [...t].reverse(),
            velocity: -s
        })), c.calculatedDuration === null && (c.calculatedDuration = p3(c));
        const {
            calculatedDuration: d
        } = c, f = d + i, m = f * (r + 1) - i;
        return {
            generator: c,
            mirroredGenerator: u,
            mapPercentToKeyframes: l,
            calculatedDuration: d,
            resolvedDuration: f,
            totalDuration: m
        }
    }
    onPostResolved() {
        const {
            autoplay: t = !0
        } = this.options;
        this.play(), this.pendingPlayState === "paused" || !t ? this.pause() : this.state = this.pendingPlayState
    }
    tick(t, n = !1) {
        const {
            resolved: r
        } = this;
        if (!r) {
            const {
                keyframes: y
            } = this.options;
            return {
                done: !0,
                value: y[y.length - 1]
            }
        }
        const {
            finalKeyframe: i,
            generator: o,
            mirroredGenerator: s,
            mapPercentToKeyframes: a,
            keyframes: l,
            calculatedDuration: u,
            totalDuration: c,
            resolvedDuration: d
        } = r;
        if (this.startTime === null) return o.next(0);
        const {
            delay: f,
            repeat: m,
            repeatType: x,
            repeatDelay: w,
            onUpdate: E
        } = this.options;
        this.speed > 0 ? this.startTime = Math.min(this.startTime, t) : this.speed < 0 && (this.startTime = Math.min(t - c / this.speed, this.startTime)), n ? this.currentTime = t : this.holdTime !== null ? this.currentTime = this.holdTime : this.currentTime = Math.round(t - this.startTime) * this.speed;
        const p = this.currentTime - f * (this.speed >= 0 ? 1 : -1),
            h = this.speed >= 0 ? p < 0 : p > c;
        this.currentTime = Math.max(p, 0), this.state === "finished" && this.holdTime === null && (this.currentTime = c);
        let g = this.currentTime,
            P = o;
        if (m) {
            const y = Math.min(this.currentTime, c) / d;
            let O = Math.floor(y),
                M = y % 1;
            !M && y >= 1 && (M = 1), M === 1 && O--, O = Math.min(O, m + 1), !!(O % 2) && (x === "reverse" ? (M = 1 - M, w && (M -= w / d)) : x === "mirror" && (P = s)), g = Un(0, 1, M) * d
        }
        const R = h ? {
            done: !1,
            value: l[0]
        } : P.next(g);
        a && (R.value = a(R.value));
        let {
            done: A
        } = R;
        !h && u !== null && (A = this.speed >= 0 ? this.currentTime >= c : this.currentTime <= 0);
        const N = this.holdTime === null && (this.state === "finished" || this.state === "running" && A);
        return N && i !== void 0 && (R.value = Va(l, this.options, i)), E && E(R.value), N && this.finish(), R
    }
    get duration() {
        const {
            resolved: t
        } = this;
        return t ? un(t.calculatedDuration) : 0
    }
    get time() {
        return un(this.currentTime)
    }
    set time(t) {
        t = ln(t), this.currentTime = t, this.holdTime !== null || this.speed === 0 ? this.holdTime = t : this.driver && (this.startTime = this.driver.now() - t / this.speed)
    }
    get speed() {
        return this.playbackSpeed
    }
    set speed(t) {
        const n = this.playbackSpeed !== t;
        this.playbackSpeed = t, n && (this.time = un(this.currentTime))
    }
    play() {
        if (this.resolver.isScheduled || this.resolver.resume(), !this._resolved) {
            this.pendingPlayState = "running";
            return
        }
        if (this.isStopped) return;
        const {
            driver: t = m3,
            onPlay: n,
            startTime: r
        } = this.options;
        this.driver || (this.driver = t(o => this.tick(o))), n && n();
        const i = this.driver.now();
        this.holdTime !== null ? this.startTime = i - this.holdTime : this.startTime ? this.state === "finished" && (this.startTime = i) : this.startTime = r ? ? this.calcStartTime(), this.state === "finished" && this.updateFinishedPromise(), this.cancelTime = this.startTime, this.holdTime = null, this.state = "running", this.driver.start()
    }
    pause() {
        var t;
        if (!this._resolved) {
            this.pendingPlayState = "paused";
            return
        }
        this.state = "paused", this.holdTime = (t = this.currentTime) !== null && t !== void 0 ? t : 0
    }
    complete() {
        this.state !== "running" && this.play(), this.pendingPlayState = this.state = "finished", this.holdTime = null
    }
    finish() {
        this.teardown(), this.state = "finished";
        const {
            onComplete: t
        } = this.options;
        t && t()
    }
    cancel() {
        this.cancelTime !== null && this.tick(this.cancelTime), this.teardown(), this.updateFinishedPromise()
    }
    teardown() {
        this.state = "idle", this.stopDriver(), this.resolveFinishedPromise(), this.updateFinishedPromise(), this.startTime = this.cancelTime = null, this.resolver.cancel()
    }
    stopDriver() {
        this.driver && (this.driver.stop(), this.driver = void 0)
    }
    sample(t) {
        return this.startTime = 0, this.tick(t, !0)
    }
}
const G0 = new Set(["opacity", "clipPath", "filter", "transform"]),
    y3 = 10,
    x3 = (e, t) => {
        let n = "";
        const r = Math.max(Math.round(t / y3), 2);
        for (let i = 0; i < r; i++) n += e(fi(0, r - 1, i)) + ", ";
        return `linear(${n.substring(0,n.length-2)})`
    };

function md(e) {
    let t;
    return () => (t === void 0 && (t = e()), t)
}
const w3 = {
    linearEasing: void 0
};

function S3(e, t) {
    const n = md(e);
    return () => {
        var r;
        return (r = w3[t]) !== null && r !== void 0 ? r : n()
    }
}
const da = S3(() => {
    try {
        document.createElement("div").animate({
            opacity: 0
        }, {
            easing: "linear(0, 1)"
        })
    } catch {
        return !1
    }
    return !0
}, "linearEasing");

function Y0(e) {
    return !!(typeof e == "function" && da() || !e || typeof e == "string" && (e in zu || da()) || fd(e) || Array.isArray(e) && e.every(Y0))
}
const Bi = ([e, t, n, r]) => `cubic-bezier(${e}, ${t}, ${n}, ${r})`,
    zu = {
        linear: "linear",
        ease: "ease",
        easeIn: "ease-in",
        easeOut: "ease-out",
        easeInOut: "ease-in-out",
        circIn: Bi([0, .65, .55, 1]),
        circOut: Bi([.55, 0, 1, .45]),
        backIn: Bi([.31, .01, .66, -.59]),
        backOut: Bi([.33, 1.53, .69, .99])
    };

function Q0(e, t) {
    if (e) return typeof e == "function" && da() ? x3(e, t) : fd(e) ? Bi(e) : Array.isArray(e) ? e.map(n => Q0(n, t) || zu.easeOut) : zu[e]
}

function T3(e, t, n, {
    delay: r = 0,
    duration: i = 300,
    repeat: o = 0,
    repeatType: s = "loop",
    ease: a,
    times: l
} = {}) {
    const u = {
        [t]: n
    };
    l && (u.offset = l);
    const c = Q0(a, i);
    return Array.isArray(c) && (u.easing = c), e.animate(u, {
        delay: r,
        duration: i,
        easing: Array.isArray(c) ? "linear" : c,
        fill: "both",
        iterations: o + 1,
        direction: s === "reverse" ? "alternate" : "normal"
    })
}

function Dh(e, t) {
    e.timeline = t, e.onfinish = null
}
const P3 = md(() => Object.hasOwnProperty.call(Element.prototype, "animate")),
    fa = 10,
    E3 = 2e4;

function C3(e) {
    return dd(e.type) || e.type === "spring" || !Y0(e.ease)
}

function k3(e, t) {
    const n = new pd({ ...t,
        keyframes: e,
        repeat: 0,
        delay: 0,
        isGenerator: !0
    });
    let r = {
        done: !1,
        value: e[0]
    };
    const i = [];
    let o = 0;
    for (; !r.done && o < E3;) r = n.sample(o), i.push(r.value), o += fa;
    return {
        times: void 0,
        keyframes: i,
        duration: o - fa,
        ease: "linear"
    }
}
const X0 = {
    anticipate: S0,
    backInOut: w0,
    circInOut: P0
};

function R3(e) {
    return e in X0
}
class _h extends b0 {
    constructor(t) {
        super(t);
        const {
            name: n,
            motionValue: r,
            element: i,
            keyframes: o
        } = this.options;
        this.resolver = new z0(o, (s, a) => this.onKeyframesResolved(s, a), n, r, i), this.resolver.scheduleResolve()
    }
    initPlayback(t, n) {
        var r;
        let {
            duration: i = 300,
            times: o,
            ease: s,
            type: a,
            motionValue: l,
            name: u,
            startTime: c
        } = this.options;
        if (!(!((r = l.owner) === null || r === void 0) && r.current)) return !1;
        if (typeof s == "string" && da() && R3(s) && (s = X0[s]), C3(this.options)) {
            const {
                onComplete: f,
                onUpdate: m,
                motionValue: x,
                element: w,
                ...E
            } = this.options, p = k3(t, E);
            t = p.keyframes, t.length === 1 && (t[1] = t[0]), i = p.duration, o = p.times, s = p.ease, a = "keyframes"
        }
        const d = T3(l.owner.current, u, t, { ...this.options,
            duration: i,
            times: o,
            ease: s
        });
        return d.startTime = c ? ? this.calcStartTime(), this.pendingTimeline ? (Dh(d, this.pendingTimeline), this.pendingTimeline = void 0) : d.onfinish = () => {
            const {
                onComplete: f
            } = this.options;
            l.set(Va(t, this.options, n)), f && f(), this.cancel(), this.resolveFinishedPromise()
        }, {
            animation: d,
            duration: i,
            times: o,
            type: a,
            ease: s,
            keyframes: t
        }
    }
    get duration() {
        const {
            resolved: t
        } = this;
        if (!t) return 0;
        const {
            duration: n
        } = t;
        return un(n)
    }
    get time() {
        const {
            resolved: t
        } = this;
        if (!t) return 0;
        const {
            animation: n
        } = t;
        return un(n.currentTime || 0)
    }
    set time(t) {
        const {
            resolved: n
        } = this;
        if (!n) return;
        const {
            animation: r
        } = n;
        r.currentTime = ln(t)
    }
    get speed() {
        const {
            resolved: t
        } = this;
        if (!t) return 1;
        const {
            animation: n
        } = t;
        return n.playbackRate
    }
    set speed(t) {
        const {
            resolved: n
        } = this;
        if (!n) return;
        const {
            animation: r
        } = n;
        r.playbackRate = t
    }
    get state() {
        const {
            resolved: t
        } = this;
        if (!t) return "idle";
        const {
            animation: n
        } = t;
        return n.playState
    }
    get startTime() {
        const {
            resolved: t
        } = this;
        if (!t) return null;
        const {
            animation: n
        } = t;
        return n.startTime
    }
    attachTimeline(t) {
        if (!this._resolved) this.pendingTimeline = t;
        else {
            const {
                resolved: n
            } = this;
            if (!n) return Ke;
            const {
                animation: r
            } = n;
            Dh(r, t)
        }
        return Ke
    }
    play() {
        if (this.isStopped) return;
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: n
        } = t;
        n.playState === "finished" && this.updateFinishedPromise(), n.play()
    }
    pause() {
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: n
        } = t;
        n.pause()
    }
    stop() {
        if (this.resolver.cancel(), this.isStopped = !0, this.state === "idle") return;
        this.resolveFinishedPromise(), this.updateFinishedPromise();
        const {
            resolved: t
        } = this;
        if (!t) return;
        const {
            animation: n,
            keyframes: r,
            duration: i,
            type: o,
            ease: s,
            times: a
        } = t;
        if (n.playState === "idle" || n.playState === "finished") return;
        if (this.time) {
            const {
                motionValue: u,
                onUpdate: c,
                onComplete: d,
                element: f,
                ...m
            } = this.options, x = new pd({ ...m,
                keyframes: r,
                duration: i,
                type: o,
                ease: s,
                times: a,
                isGenerator: !0
            }), w = ln(this.time);
            u.setWithVelocity(x.sample(w - fa).value, x.sample(w).value, fa)
        }
        const {
            onStop: l
        } = this.options;
        l && l(), this.cancel()
    }
    complete() {
        const {
            resolved: t
        } = this;
        t && t.animation.finish()
    }
    cancel() {
        const {
            resolved: t
        } = this;
        t && t.animation.cancel()
    }
    static supports(t) {
        const {
            motionValue: n,
            name: r,
            repeatDelay: i,
            repeatType: o,
            damping: s,
            type: a
        } = t;
        return P3() && r && G0.has(r) && n && n.owner && n.owner.current instanceof HTMLElement && !n.owner.getProps().onUpdate && !i && o !== "mirror" && s !== 0 && a !== "inertia"
    }
}
const j3 = md(() => window.ScrollTimeline !== void 0);
class A3 {
    constructor(t) {
        this.stop = () => this.runAll("stop"), this.animations = t.filter(Boolean)
    }
    then(t, n) {
        return Promise.all(this.animations).then(t).catch(n)
    }
    getAll(t) {
        return this.animations[0][t]
    }
    setAll(t, n) {
        for (let r = 0; r < this.animations.length; r++) this.animations[r][t] = n
    }
    attachTimeline(t, n) {
        const r = this.animations.map(i => j3() && i.attachTimeline ? i.attachTimeline(t) : n(i));
        return () => {
            r.forEach((i, o) => {
                i && i(), this.animations[o].stop()
            })
        }
    }
    get time() {
        return this.getAll("time")
    }
    set time(t) {
        this.setAll("time", t)
    }
    get speed() {
        return this.getAll("speed")
    }
    set speed(t) {
        this.setAll("speed", t)
    }
    get startTime() {
        return this.getAll("startTime")
    }
    get duration() {
        let t = 0;
        for (let n = 0; n < this.animations.length; n++) t = Math.max(t, this.animations[n].duration);
        return t
    }
    runAll(t) {
        this.animations.forEach(n => n[t]())
    }
    play() {
        this.runAll("play")
    }
    pause() {
        this.runAll("pause")
    }
    cancel() {
        this.runAll("cancel")
    }
    complete() {
        this.runAll("complete")
    }
}

function L3({
    when: e,
    delay: t,
    delayChildren: n,
    staggerChildren: r,
    staggerDirection: i,
    repeat: o,
    repeatType: s,
    repeatDelay: a,
    from: l,
    elapsed: u,
    ...c
}) {
    return !!Object.keys(c).length
}
const gd = (e, t, n, r = {}, i, o) => s => {
        const a = nd(r, e) || {},
            l = a.delay || r.delay || 0;
        let {
            elapsed: u = 0
        } = r;
        u = u - ln(l);
        let c = {
            keyframes: Array.isArray(n) ? n : [null, n],
            ease: "easeOut",
            velocity: t.getVelocity(),
            ...a,
            delay: -u,
            onUpdate: f => {
                t.set(f), a.onUpdate && a.onUpdate(f)
            },
            onComplete: () => {
                s(), a.onComplete && a.onComplete()
            },
            name: e,
            motionValue: t,
            element: o ? void 0 : i
        };
        L3(a) || (c = { ...c,
            ...Q2(e, c)
        }), c.duration && (c.duration = ln(c.duration)), c.repeatDelay && (c.repeatDelay = ln(c.repeatDelay)), c.from !== void 0 && (c.keyframes[0] = c.from);
        let d = !1;
        if ((c.type === !1 || c.duration === 0 && !c.repeatDelay) && (c.duration = 0, c.delay === 0 && (d = !0)), d && !o && t.get() !== void 0) {
            const f = Va(c.keyframes, a);
            if (f !== void 0) return oe.update(() => {
                c.onUpdate(f), c.onComplete()
            }), new A3([])
        }
        return !o && _h.supports(c) ? new _h(c) : new pd(c)
    },
    M3 = e => !!(e && typeof e == "object" && e.mix && e.toValue),
    N3 = e => Mu(e) ? e[e.length - 1] || 0 : e;

function vd(e, t) {
    e.indexOf(t) === -1 && e.push(t)
}

function yd(e, t) {
    const n = e.indexOf(t);
    n > -1 && e.splice(n, 1)
}
class xd {
    constructor() {
        this.subscriptions = []
    }
    add(t) {
        return vd(this.subscriptions, t), () => yd(this.subscriptions, t)
    }
    notify(t, n, r) {
        const i = this.subscriptions.length;
        if (i)
            if (i === 1) this.subscriptions[0](t, n, r);
            else
                for (let o = 0; o < i; o++) {
                    const s = this.subscriptions[o];
                    s && s(t, n, r)
                }
    }
    getSize() {
        return this.subscriptions.length
    }
    clear() {
        this.subscriptions.length = 0
    }
}
const Oh = 30,
    D3 = e => !isNaN(parseFloat(e));
class _3 {
    constructor(t, n = {}) {
        this.version = "11.11.2", this.canTrackVelocity = null, this.events = {}, this.updateAndNotify = (r, i = !0) => {
            const o = Kt.now();
            this.updatedAt !== o && this.setPrevFrameValue(), this.prev = this.current, this.setCurrent(r), this.current !== this.prev && this.events.change && this.events.change.notify(this.current), i && this.events.renderRequest && this.events.renderRequest.notify(this.current)
        }, this.hasAnimated = !1, this.setCurrent(t), this.owner = n.owner
    }
    setCurrent(t) {
        this.current = t, this.updatedAt = Kt.now(), this.canTrackVelocity === null && t !== void 0 && (this.canTrackVelocity = D3(this.current))
    }
    setPrevFrameValue(t = this.current) {
        this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt
    }
    onChange(t) {
        return this.on("change", t)
    }
    on(t, n) {
        this.events[t] || (this.events[t] = new xd);
        const r = this.events[t].add(n);
        return t === "change" ? () => {
            r(), oe.read(() => {
                this.events.change.getSize() || this.stop()
            })
        } : r
    }
    clearListeners() {
        for (const t in this.events) this.events[t].clear()
    }
    attach(t, n) {
        this.passiveEffect = t, this.stopPassiveEffect = n
    }
    set(t, n = !0) {
        !n || !this.passiveEffect ? this.updateAndNotify(t, n) : this.passiveEffect(t, this.updateAndNotify)
    }
    setWithVelocity(t, n, r) {
        this.set(n), this.prev = void 0, this.prevFrameValue = t, this.prevUpdatedAt = this.updatedAt - r
    }
    jump(t, n = !0) {
        this.updateAndNotify(t), this.prev = t, this.prevUpdatedAt = this.prevFrameValue = void 0, n && this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
    get() {
        return this.current
    }
    getPrevious() {
        return this.prev
    }
    getVelocity() {
        const t = Kt.now();
        if (!this.canTrackVelocity || this.prevFrameValue === void 0 || t - this.updatedAt > Oh) return 0;
        const n = Math.min(this.updatedAt - this.prevUpdatedAt, Oh);
        return B0(parseFloat(this.current) - parseFloat(this.prevFrameValue), n)
    }
    start(t) {
        return this.stop(), new Promise(n => {
            this.hasAnimated = !0, this.animation = t(n), this.events.animationStart && this.events.animationStart.notify()
        }).then(() => {
            this.events.animationComplete && this.events.animationComplete.notify(), this.clearAnimation()
        })
    }
    stop() {
        this.animation && (this.animation.stop(), this.events.animationCancel && this.events.animationCancel.notify()), this.clearAnimation()
    }
    isAnimating() {
        return !!this.animation
    }
    clearAnimation() {
        delete this.animation
    }
    destroy() {
        this.clearListeners(), this.stop(), this.stopPassiveEffect && this.stopPassiveEffect()
    }
}

function Co(e, t) {
    return new _3(e, t)
}

function O3(e, t, n) {
    e.hasValue(t) ? e.getValue(t).set(n) : e.addValue(t, Co(n))
}

function V3(e, t) {
    const n = Oa(e, t);
    let {
        transitionEnd: r = {},
        transition: i = {},
        ...o
    } = n || {};
    o = { ...o,
        ...r
    };
    for (const s in o) {
        const a = N3(o[s]);
        O3(e, s, a)
    }
}
const Fa = e => e.replace(/([a-z])([A-Z])/gu, "$1-$2").toLowerCase(),
    F3 = "framerAppearId",
    Z0 = "data-" + Fa(F3);

function J0(e) {
    return e.props[Z0]
}
const We = e => !!(e && e.getVelocity);

function I3(e) {
    return !!(We(e) && e.add)
}

function q0(e) {
    if (Xn.has(e)) return "transform";
    if (G0.has(e)) return Fa(e)
}

function bu(e, t) {
    var n;
    if (!e.applyWillChange) return;
    const r = e.getValue("willChange");
    if (I3(r)) return r.add(t);
    !(!((n = e.props.style) === null || n === void 0) && n.willChange) && q0(t) && e.setStaticValue("willChange", "transform")
}

function z3({
    protectedKeys: e,
    needsAnimating: t
}, n) {
    const r = e.hasOwnProperty(n) && t[n] !== !0;
    return t[n] = !1, r
}

function ev(e, t, {
    delay: n = 0,
    transitionOverride: r,
    type: i
} = {}) {
    var o;
    let {
        transition: s = e.getDefaultTransition(),
        transitionEnd: a,
        ...l
    } = t;
    r && (s = r);
    const u = [],
        c = i && e.animationState && e.animationState.getState()[i];
    for (const d in l) {
        const f = e.getValue(d, (o = e.latestValues[d]) !== null && o !== void 0 ? o : null),
            m = l[d];
        if (m === void 0 || c && z3(c, d)) continue;
        const x = {
            delay: n,
            ...nd(s || {}, d)
        };
        let w = !1;
        if (window.MotionHandoffAnimation) {
            const p = J0(e);
            if (p) {
                const h = window.MotionHandoffAnimation(p, d, oe);
                h !== null && (x.startTime = h, w = !0)
            }
        }
        bu(e, d), f.start(gd(d, f, m, e.shouldReduceMotion && Xn.has(d) ? {
            type: !1
        } : x, e, w));
        const E = f.animation;
        E && u.push(E)
    }
    return a && Promise.all(u).then(() => {
        oe.update(() => {
            a && V3(e, a)
        })
    }), u
}

function Bu(e, t, n = {}) {
    var r;
    const i = Oa(e, t, n.type === "exit" ? (r = e.presenceContext) === null || r === void 0 ? void 0 : r.custom : void 0);
    let {
        transition: o = e.getDefaultTransition() || {}
    } = i || {};
    n.transitionOverride && (o = n.transitionOverride);
    const s = i ? () => Promise.all(ev(e, i, n)) : () => Promise.resolve(),
        a = e.variantChildren && e.variantChildren.size ? (u = 0) => {
            const {
                delayChildren: c = 0,
                staggerChildren: d,
                staggerDirection: f
            } = o;
            return b3(e, t, c + u, d, f, n)
        } : () => Promise.resolve(),
        {
            when: l
        } = o;
    if (l) {
        const [u, c] = l === "beforeChildren" ? [s, a] : [a, s];
        return u().then(() => c())
    } else return Promise.all([s(), a(n.delay)])
}

function b3(e, t, n = 0, r = 0, i = 1, o) {
    const s = [],
        a = (e.variantChildren.size - 1) * r,
        l = i === 1 ? (u = 0) => u * r : (u = 0) => a - u * r;
    return Array.from(e.variantChildren).sort(B3).forEach((u, c) => {
        u.notify("AnimationStart", t), s.push(Bu(u, t, { ...o,
            delay: n + l(c)
        }).then(() => u.notify("AnimationComplete", t)))
    }), Promise.all(s)
}

function B3(e, t) {
    return e.sortNodePosition(t)
}

function U3(e, t, n = {}) {
    e.notify("AnimationStart", t);
    let r;
    if (Array.isArray(t)) {
        const i = t.map(o => Bu(e, o, n));
        r = Promise.all(i)
    } else if (typeof t == "string") r = Bu(e, t, n);
    else {
        const i = typeof t == "function" ? Oa(e, t, n.custom) : t;
        r = Promise.all(ev(e, i, n))
    }
    return r.then(() => {
        e.notify("AnimationComplete", t)
    })
}
const H3 = td.length;

function tv(e) {
    if (!e) return;
    if (!e.isControllingVariants) {
        const n = e.parent ? tv(e.parent) || {} : {};
        return e.props.initial !== void 0 && (n.initial = e.props.initial), n
    }
    const t = {};
    for (let n = 0; n < H3; n++) {
        const r = td[n],
            i = e.props[r];
        (To(i) || i === !1) && (t[r] = i)
    }
    return t
}
const $3 = [...ed].reverse(),
    W3 = ed.length;

function K3(e) {
    return t => Promise.all(t.map(({
        animation: n,
        options: r
    }) => U3(e, n, r)))
}

function G3(e) {
    let t = K3(e),
        n = Vh(),
        r = !0;
    const i = l => (u, c) => {
        var d;
        const f = Oa(e, c, l === "exit" ? (d = e.presenceContext) === null || d === void 0 ? void 0 : d.custom : void 0);
        if (f) {
            const {
                transition: m,
                transitionEnd: x,
                ...w
            } = f;
            u = { ...u,
                ...w,
                ...x
            }
        }
        return u
    };

    function o(l) {
        t = l(e)
    }

    function s(l) {
        const {
            props: u
        } = e, c = tv(e.parent) || {}, d = [], f = new Set;
        let m = {},
            x = 1 / 0;
        for (let E = 0; E < W3; E++) {
            const p = $3[E],
                h = n[p],
                g = u[p] !== void 0 ? u[p] : c[p],
                P = To(g),
                R = p === l ? h.isActive : null;
            R === !1 && (x = E);
            let A = g === c[p] && g !== u[p] && P;
            if (A && r && e.manuallyAnimateOnMount && (A = !1), h.protectedKeys = { ...m
                }, !h.isActive && R === null || !g && !h.prevProp || So(g) || typeof g == "boolean") continue;
            const N = Y3(h.prevProp, g);
            let y = N || p === l && h.isActive && !A && P || E > x && P,
                O = !1;
            const M = Array.isArray(g) ? g : [g];
            let U = M.reduce(i(p), {});
            R === !1 && (U = {});
            const {
                prevResolvedValues: te = {}
            } = h, Te = { ...te,
                ...U
            }, le = he => {
                y = !0, f.has(he) && (O = !0, f.delete(he)), h.needsAnimating[he] = !0;
                const D = e.getValue(he);
                D && (D.liveStyle = !1)
            };
            for (const he in Te) {
                const D = U[he],
                    F = te[he];
                if (m.hasOwnProperty(he)) continue;
                let W = !1;
                Mu(D) && Mu(F) ? W = !p0(D, F) : W = D !== F, W ? D != null ? le(he) : f.add(he) : D !== void 0 && f.has(he) ? le(he) : h.protectedKeys[he] = !0
            }
            h.prevProp = g, h.prevResolvedValues = U, h.isActive && (m = { ...m,
                ...U
            }), r && e.blockInitialAnimation && (y = !1), y && (!(A && N) || O) && d.push(...M.map(he => ({
                animation: he,
                options: {
                    type: p
                }
            })))
        }
        if (f.size) {
            const E = {};
            f.forEach(p => {
                const h = e.getBaseTarget(p),
                    g = e.getValue(p);
                g && (g.liveStyle = !0), E[p] = h ? ? null
            }), d.push({
                animation: E
            })
        }
        let w = !!d.length;
        return r && (u.initial === !1 || u.initial === u.animate) && !e.manuallyAnimateOnMount && (w = !1), r = !1, w ? t(d) : Promise.resolve()
    }

    function a(l, u) {
        var c;
        if (n[l].isActive === u) return Promise.resolve();
        (c = e.variantChildren) === null || c === void 0 || c.forEach(f => {
            var m;
            return (m = f.animationState) === null || m === void 0 ? void 0 : m.setActive(l, u)
        }), n[l].isActive = u;
        const d = s(l);
        for (const f in n) n[f].protectedKeys = {};
        return d
    }
    return {
        animateChanges: s,
        setActive: a,
        setAnimateFunction: o,
        getState: () => n,
        reset: () => {
            n = Vh(), r = !0
        }
    }
}

function Y3(e, t) {
    return typeof t == "string" ? t !== e : Array.isArray(t) ? !p0(t, e) : !1
}

function tr(e = !1) {
    return {
        isActive: e,
        protectedKeys: {},
        needsAnimating: {},
        prevResolvedValues: {}
    }
}

function Vh() {
    return {
        animate: tr(!0),
        whileInView: tr(),
        whileHover: tr(),
        whileTap: tr(),
        whileDrag: tr(),
        whileFocus: tr(),
        exit: tr()
    }
}
class Zn {
    constructor(t) {
        this.isMounted = !1, this.node = t
    }
    update() {}
}
class Q3 extends Zn {
    constructor(t) {
        super(t), t.animationState || (t.animationState = G3(t))
    }
    updateAnimationControlsSubscription() {
        const {
            animate: t
        } = this.node.getProps();
        So(t) && (this.unmountControls = t.subscribe(this.node))
    }
    mount() {
        this.updateAnimationControlsSubscription()
    }
    update() {
        const {
            animate: t
        } = this.node.getProps(), {
            animate: n
        } = this.node.prevProps || {};
        t !== n && this.updateAnimationControlsSubscription()
    }
    unmount() {
        var t;
        this.node.animationState.reset(), (t = this.unmountControls) === null || t === void 0 || t.call(this)
    }
}
let X3 = 0;
class Z3 extends Zn {
    constructor() {
        super(...arguments), this.id = X3++
    }
    update() {
        if (!this.node.presenceContext) return;
        const {
            isPresent: t,
            onExitComplete: n
        } = this.node.presenceContext, {
            isPresent: r
        } = this.node.prevPresenceContext || {};
        if (!this.node.animationState || t === r) return;
        const i = this.node.animationState.setActive("exit", !t);
        n && !t && i.then(() => n(this.id))
    }
    mount() {
        const {
            register: t
        } = this.node.presenceContext || {};
        t && (this.unmount = t(this.id))
    }
    unmount() {}
}
const J3 = {
        animation: {
            Feature: Q3
        },
        exit: {
            Feature: Z3
        }
    },
    nv = e => e.pointerType === "mouse" ? typeof e.button != "number" || e.button <= 0 : e.isPrimary !== !1;

function Ia(e, t = "page") {
    return {
        point: {
            x: e[`${t}X`],
            y: e[`${t}Y`]
        }
    }
}
const q3 = e => t => nv(t) && e(t, Ia(t));

function on(e, t, n, r = {
    passive: !0
}) {
    return e.addEventListener(t, n, r), () => e.removeEventListener(t, n)
}

function dn(e, t, n, r) {
    return on(e, t, q3(n), r)
}
const Fh = (e, t) => Math.abs(e - t);

function e4(e, t) {
    const n = Fh(e.x, t.x),
        r = Fh(e.y, t.y);
    return Math.sqrt(n ** 2 + r ** 2)
}
class rv {
    constructor(t, n, {
        transformPagePoint: r,
        contextWindow: i,
        dragSnapToOrigin: o = !1
    } = {}) {
        if (this.startEvent = null, this.lastMoveEvent = null, this.lastMoveEventInfo = null, this.handlers = {}, this.contextWindow = window, this.updatePoint = () => {
                if (!(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                const d = kl(this.lastMoveEventInfo, this.history),
                    f = this.startEvent !== null,
                    m = e4(d.offset, {
                        x: 0,
                        y: 0
                    }) >= 3;
                if (!f && !m) return;
                const {
                    point: x
                } = d, {
                    timestamp: w
                } = Ie;
                this.history.push({ ...x,
                    timestamp: w
                });
                const {
                    onStart: E,
                    onMove: p
                } = this.handlers;
                f || (E && E(this.lastMoveEvent, d), this.startEvent = this.lastMoveEvent), p && p(this.lastMoveEvent, d)
            }, this.handlePointerMove = (d, f) => {
                this.lastMoveEvent = d, this.lastMoveEventInfo = Cl(f, this.transformPagePoint), oe.update(this.updatePoint, !0)
            }, this.handlePointerUp = (d, f) => {
                this.end();
                const {
                    onEnd: m,
                    onSessionEnd: x,
                    resumeAnimation: w
                } = this.handlers;
                if (this.dragSnapToOrigin && w && w(), !(this.lastMoveEvent && this.lastMoveEventInfo)) return;
                const E = kl(d.type === "pointercancel" ? this.lastMoveEventInfo : Cl(f, this.transformPagePoint), this.history);
                this.startEvent && m && m(d, E), x && x(d, E)
            }, !nv(t)) return;
        this.dragSnapToOrigin = o, this.handlers = n, this.transformPagePoint = r, this.contextWindow = i || window;
        const s = Ia(t),
            a = Cl(s, this.transformPagePoint),
            {
                point: l
            } = a,
            {
                timestamp: u
            } = Ie;
        this.history = [{ ...l,
            timestamp: u
        }];
        const {
            onSessionStart: c
        } = n;
        c && c(t, kl(a, this.history)), this.removeListeners = cn(dn(this.contextWindow, "pointermove", this.handlePointerMove), dn(this.contextWindow, "pointerup", this.handlePointerUp), dn(this.contextWindow, "pointercancel", this.handlePointerUp))
    }
    updateHandlers(t) {
        this.handlers = t
    }
    end() {
        this.removeListeners && this.removeListeners(), Bn(this.updatePoint)
    }
}

function Cl(e, t) {
    return t ? {
        point: t(e.point)
    } : e
}

function Ih(e, t) {
    return {
        x: e.x - t.x,
        y: e.y - t.y
    }
}

function kl({
    point: e
}, t) {
    return {
        point: e,
        delta: Ih(e, iv(t)),
        offset: Ih(e, t4(t)),
        velocity: n4(t, .1)
    }
}

function t4(e) {
    return e[0]
}

function iv(e) {
    return e[e.length - 1]
}

function n4(e, t) {
    if (e.length < 2) return {
        x: 0,
        y: 0
    };
    let n = e.length - 1,
        r = null;
    const i = iv(e);
    for (; n >= 0 && (r = e[n], !(i.timestamp - r.timestamp > ln(t)));) n--;
    if (!r) return {
        x: 0,
        y: 0
    };
    const o = un(i.timestamp - r.timestamp);
    if (o === 0) return {
        x: 0,
        y: 0
    };
    const s = {
        x: (i.x - r.x) / o,
        y: (i.y - r.y) / o
    };
    return s.x === 1 / 0 && (s.x = 0), s.y === 1 / 0 && (s.y = 0), s
}

function ov(e) {
    let t = null;
    return () => {
        const n = () => {
            t = null
        };
        return t === null ? (t = e, n) : !1
    }
}
const zh = ov("dragHorizontal"),
    bh = ov("dragVertical");

function sv(e) {
    let t = !1;
    if (e === "y") t = bh();
    else if (e === "x") t = zh();
    else {
        const n = zh(),
            r = bh();
        n && r ? t = () => {
            n(), r()
        } : (n && n(), r && r())
    }
    return t
}

function av() {
    const e = sv(!0);
    return e ? (e(), !1) : !0
}

function $r(e) {
    return e && typeof e == "object" && Object.prototype.hasOwnProperty.call(e, "current")
}
const lv = 1e-4,
    r4 = 1 - lv,
    i4 = 1 + lv,
    uv = .01,
    o4 = 0 - uv,
    s4 = 0 + uv;

function gt(e) {
    return e.max - e.min
}

function a4(e, t, n) {
    return Math.abs(e - t) <= n
}

function Bh(e, t, n, r = .5) {
    e.origin = r, e.originPoint = xe(t.min, t.max, e.origin), e.scale = gt(n) / gt(t), e.translate = xe(n.min, n.max, e.origin) - e.originPoint, (e.scale >= r4 && e.scale <= i4 || isNaN(e.scale)) && (e.scale = 1), (e.translate >= o4 && e.translate <= s4 || isNaN(e.translate)) && (e.translate = 0)
}

function qi(e, t, n, r) {
    Bh(e.x, t.x, n.x, r ? r.originX : void 0), Bh(e.y, t.y, n.y, r ? r.originY : void 0)
}

function Uh(e, t, n) {
    e.min = n.min + t.min, e.max = e.min + gt(t)
}

function l4(e, t, n) {
    Uh(e.x, t.x, n.x), Uh(e.y, t.y, n.y)
}

function Hh(e, t, n) {
    e.min = t.min - n.min, e.max = e.min + gt(t)
}

function eo(e, t, n) {
    Hh(e.x, t.x, n.x), Hh(e.y, t.y, n.y)
}

function u4(e, {
    min: t,
    max: n
}, r) {
    return t !== void 0 && e < t ? e = r ? xe(t, e, r.min) : Math.max(e, t) : n !== void 0 && e > n && (e = r ? xe(n, e, r.max) : Math.min(e, n)), e
}

function $h(e, t, n) {
    return {
        min: t !== void 0 ? e.min + t : void 0,
        max: n !== void 0 ? e.max + n - (e.max - e.min) : void 0
    }
}

function c4(e, {
    top: t,
    left: n,
    bottom: r,
    right: i
}) {
    return {
        x: $h(e.x, n, i),
        y: $h(e.y, t, r)
    }
}

function Wh(e, t) {
    let n = t.min - e.min,
        r = t.max - e.max;
    return t.max - t.min < e.max - e.min && ([n, r] = [r, n]), {
        min: n,
        max: r
    }
}

function d4(e, t) {
    return {
        x: Wh(e.x, t.x),
        y: Wh(e.y, t.y)
    }
}

function f4(e, t) {
    let n = .5;
    const r = gt(e),
        i = gt(t);
    return i > r ? n = fi(t.min, t.max - r, e.min) : r > i && (n = fi(e.min, e.max - i, t.min)), Un(0, 1, n)
}

function h4(e, t) {
    const n = {};
    return t.min !== void 0 && (n.min = t.min - e.min), t.max !== void 0 && (n.max = t.max - e.min), n
}
const Uu = .35;

function p4(e = Uu) {
    return e === !1 ? e = 0 : e === !0 && (e = Uu), {
        x: Kh(e, "left", "right"),
        y: Kh(e, "top", "bottom")
    }
}

function Kh(e, t, n) {
    return {
        min: Gh(e, t),
        max: Gh(e, n)
    }
}

function Gh(e, t) {
    return typeof e == "number" ? e : e[t] || 0
}
const Yh = () => ({
        translate: 0,
        scale: 1,
        origin: 0,
        originPoint: 0
    }),
    Wr = () => ({
        x: Yh(),
        y: Yh()
    }),
    Qh = () => ({
        min: 0,
        max: 0
    }),
    ke = () => ({
        x: Qh(),
        y: Qh()
    });

function Tt(e) {
    return [e("x"), e("y")]
}

function cv({
    top: e,
    left: t,
    right: n,
    bottom: r
}) {
    return {
        x: {
            min: t,
            max: n
        },
        y: {
            min: e,
            max: r
        }
    }
}

function m4({
    x: e,
    y: t
}) {
    return {
        top: t.min,
        right: e.max,
        bottom: t.max,
        left: e.min
    }
}

function g4(e, t) {
    if (!t) return e;
    const n = t({
            x: e.left,
            y: e.top
        }),
        r = t({
            x: e.right,
            y: e.bottom
        });
    return {
        top: n.y,
        left: n.x,
        bottom: r.y,
        right: r.x
    }
}

function Rl(e) {
    return e === void 0 || e === 1
}

function Hu({
    scale: e,
    scaleX: t,
    scaleY: n
}) {
    return !Rl(e) || !Rl(t) || !Rl(n)
}

function or(e) {
    return Hu(e) || dv(e) || e.z || e.rotate || e.rotateX || e.rotateY || e.skewX || e.skewY
}

function dv(e) {
    return Xh(e.x) || Xh(e.y)
}

function Xh(e) {
    return e && e !== "0%"
}

function ha(e, t, n) {
    const r = e - n,
        i = t * r;
    return n + i
}

function Zh(e, t, n, r, i) {
    return i !== void 0 && (e = ha(e, i, r)), ha(e, n, r) + t
}

function $u(e, t = 0, n = 1, r, i) {
    e.min = Zh(e.min, t, n, r, i), e.max = Zh(e.max, t, n, r, i)
}

function fv(e, {
    x: t,
    y: n
}) {
    $u(e.x, t.translate, t.scale, t.originPoint), $u(e.y, n.translate, n.scale, n.originPoint)
}
const Jh = .999999999999,
    qh = 1.0000000000001;

function v4(e, t, n, r = !1) {
    const i = n.length;
    if (!i) return;
    t.x = t.y = 1;
    let o, s;
    for (let a = 0; a < i; a++) {
        o = n[a], s = o.projectionDelta;
        const {
            visualElement: l
        } = o.options;
        l && l.props.style && l.props.style.display === "contents" || (r && o.options.layoutScroll && o.scroll && o !== o.root && Gr(e, {
            x: -o.scroll.offset.x,
            y: -o.scroll.offset.y
        }), s && (t.x *= s.x.scale, t.y *= s.y.scale, fv(e, s)), r && or(o.latestValues) && Gr(e, o.latestValues))
    }
    t.x < qh && t.x > Jh && (t.x = 1), t.y < qh && t.y > Jh && (t.y = 1)
}

function Kr(e, t) {
    e.min = e.min + t, e.max = e.max + t
}

function ep(e, t, n, r, i = .5) {
    const o = xe(e.min, e.max, i);
    $u(e, t, n, o, r)
}

function Gr(e, t) {
    ep(e.x, t.x, t.scaleX, t.scale, t.originX), ep(e.y, t.y, t.scaleY, t.scale, t.originY)
}

function hv(e, t) {
    return cv(g4(e.getBoundingClientRect(), t))
}

function y4(e, t, n) {
    const r = hv(e, n),
        {
            scroll: i
        } = t;
    return i && (Kr(r.x, i.offset.x), Kr(r.y, i.offset.y)), r
}
const pv = ({
        current: e
    }) => e ? e.ownerDocument.defaultView : null,
    x4 = new WeakMap;
class w4 {
    constructor(t) {
        this.openGlobalLock = null, this.isDragging = !1, this.currentDirection = null, this.originPoint = {
            x: 0,
            y: 0
        }, this.constraints = !1, this.hasMutatedConstraints = !1, this.elastic = ke(), this.visualElement = t
    }
    start(t, {
        snapToCursor: n = !1
    } = {}) {
        const {
            presenceContext: r
        } = this.visualElement;
        if (r && r.isPresent === !1) return;
        const i = c => {
                const {
                    dragSnapToOrigin: d
                } = this.getProps();
                d ? this.pauseAnimation() : this.stopAnimation(), n && this.snapToCursor(Ia(c, "page").point)
            },
            o = (c, d) => {
                const {
                    drag: f,
                    dragPropagation: m,
                    onDragStart: x
                } = this.getProps();
                if (f && !m && (this.openGlobalLock && this.openGlobalLock(), this.openGlobalLock = sv(f), !this.openGlobalLock)) return;
                this.isDragging = !0, this.currentDirection = null, this.resolveConstraints(), this.visualElement.projection && (this.visualElement.projection.isAnimationBlocked = !0, this.visualElement.projection.target = void 0), Tt(E => {
                    let p = this.getAxisMotionValue(E).get() || 0;
                    if (Wt.test(p)) {
                        const {
                            projection: h
                        } = this.visualElement;
                        if (h && h.layout) {
                            const g = h.layout.layoutBox[E];
                            g && (p = gt(g) * (parseFloat(p) / 100))
                        }
                    }
                    this.originPoint[E] = p
                }), x && oe.postRender(() => x(c, d)), bu(this.visualElement, "transform");
                const {
                    animationState: w
                } = this.visualElement;
                w && w.setActive("whileDrag", !0)
            },
            s = (c, d) => {
                const {
                    dragPropagation: f,
                    dragDirectionLock: m,
                    onDirectionLock: x,
                    onDrag: w
                } = this.getProps();
                if (!f && !this.openGlobalLock) return;
                const {
                    offset: E
                } = d;
                if (m && this.currentDirection === null) {
                    this.currentDirection = S4(E), this.currentDirection !== null && x && x(this.currentDirection);
                    return
                }
                this.updateAxis("x", d.point, E), this.updateAxis("y", d.point, E), this.visualElement.render(), w && w(c, d)
            },
            a = (c, d) => this.stop(c, d),
            l = () => Tt(c => {
                var d;
                return this.getAnimationState(c) === "paused" && ((d = this.getAxisMotionValue(c).animation) === null || d === void 0 ? void 0 : d.play())
            }),
            {
                dragSnapToOrigin: u
            } = this.getProps();
        this.panSession = new rv(t, {
            onSessionStart: i,
            onStart: o,
            onMove: s,
            onSessionEnd: a,
            resumeAnimation: l
        }, {
            transformPagePoint: this.visualElement.getTransformPagePoint(),
            dragSnapToOrigin: u,
            contextWindow: pv(this.visualElement)
        })
    }
    stop(t, n) {
        const r = this.isDragging;
        if (this.cancel(), !r) return;
        const {
            velocity: i
        } = n;
        this.startAnimation(i);
        const {
            onDragEnd: o
        } = this.getProps();
        o && oe.postRender(() => o(t, n))
    }
    cancel() {
        this.isDragging = !1;
        const {
            projection: t,
            animationState: n
        } = this.visualElement;
        t && (t.isAnimationBlocked = !1), this.panSession && this.panSession.end(), this.panSession = void 0;
        const {
            dragPropagation: r
        } = this.getProps();
        !r && this.openGlobalLock && (this.openGlobalLock(), this.openGlobalLock = null), n && n.setActive("whileDrag", !1)
    }
    updateAxis(t, n, r) {
        const {
            drag: i
        } = this.getProps();
        if (!r || !ps(t, i, this.currentDirection)) return;
        const o = this.getAxisMotionValue(t);
        let s = this.originPoint[t] + r[t];
        this.constraints && this.constraints[t] && (s = u4(s, this.constraints[t], this.elastic[t])), o.set(s)
    }
    resolveConstraints() {
        var t;
        const {
            dragConstraints: n,
            dragElastic: r
        } = this.getProps(), i = this.visualElement.projection && !this.visualElement.projection.layout ? this.visualElement.projection.measure(!1) : (t = this.visualElement.projection) === null || t === void 0 ? void 0 : t.layout, o = this.constraints;
        n && $r(n) ? this.constraints || (this.constraints = this.resolveRefConstraints()) : n && i ? this.constraints = c4(i.layoutBox, n) : this.constraints = !1, this.elastic = p4(r), o !== this.constraints && i && this.constraints && !this.hasMutatedConstraints && Tt(s => {
            this.constraints !== !1 && this.getAxisMotionValue(s) && (this.constraints[s] = h4(i.layoutBox[s], this.constraints[s]))
        })
    }
    resolveRefConstraints() {
        const {
            dragConstraints: t,
            onMeasureDragConstraints: n
        } = this.getProps();
        if (!t || !$r(t)) return !1;
        const r = t.current,
            {
                projection: i
            } = this.visualElement;
        if (!i || !i.layout) return !1;
        const o = y4(r, i.root, this.visualElement.getTransformPagePoint());
        let s = d4(i.layout.layoutBox, o);
        if (n) {
            const a = n(m4(s));
            this.hasMutatedConstraints = !!a, a && (s = cv(a))
        }
        return s
    }
    startAnimation(t) {
        const {
            drag: n,
            dragMomentum: r,
            dragElastic: i,
            dragTransition: o,
            dragSnapToOrigin: s,
            onDragTransitionEnd: a
        } = this.getProps(), l = this.constraints || {}, u = Tt(c => {
            if (!ps(c, n, this.currentDirection)) return;
            let d = l && l[c] || {};
            s && (d = {
                min: 0,
                max: 0
            });
            const f = i ? 200 : 1e6,
                m = i ? 40 : 1e7,
                x = {
                    type: "inertia",
                    velocity: r ? t[c] : 0,
                    bounceStiffness: f,
                    bounceDamping: m,
                    timeConstant: 750,
                    restDelta: 1,
                    restSpeed: 10,
                    ...o,
                    ...d
                };
            return this.startAxisValueAnimation(c, x)
        });
        return Promise.all(u).then(a)
    }
    startAxisValueAnimation(t, n) {
        const r = this.getAxisMotionValue(t);
        return bu(this.visualElement, t), r.start(gd(t, r, 0, n, this.visualElement, !1))
    }
    stopAnimation() {
        Tt(t => this.getAxisMotionValue(t).stop())
    }
    pauseAnimation() {
        Tt(t => {
            var n;
            return (n = this.getAxisMotionValue(t).animation) === null || n === void 0 ? void 0 : n.pause()
        })
    }
    getAnimationState(t) {
        var n;
        return (n = this.getAxisMotionValue(t).animation) === null || n === void 0 ? void 0 : n.state
    }
    getAxisMotionValue(t) {
        const n = `_drag${t.toUpperCase()}`,
            r = this.visualElement.getProps(),
            i = r[n];
        return i || this.visualElement.getValue(t, (r.initial ? r.initial[t] : void 0) || 0)
    }
    snapToCursor(t) {
        Tt(n => {
            const {
                drag: r
            } = this.getProps();
            if (!ps(n, r, this.currentDirection)) return;
            const {
                projection: i
            } = this.visualElement, o = this.getAxisMotionValue(n);
            if (i && i.layout) {
                const {
                    min: s,
                    max: a
                } = i.layout.layoutBox[n];
                o.set(t[n] - xe(s, a, .5))
            }
        })
    }
    scalePositionWithinConstraints() {
        if (!this.visualElement.current) return;
        const {
            drag: t,
            dragConstraints: n
        } = this.getProps(), {
            projection: r
        } = this.visualElement;
        if (!$r(n) || !r || !this.constraints) return;
        this.stopAnimation();
        const i = {
            x: 0,
            y: 0
        };
        Tt(s => {
            const a = this.getAxisMotionValue(s);
            if (a && this.constraints !== !1) {
                const l = a.get();
                i[s] = f4({
                    min: l,
                    max: l
                }, this.constraints[s])
            }
        });
        const {
            transformTemplate: o
        } = this.visualElement.getProps();
        this.visualElement.current.style.transform = o ? o({}, "") : "none", r.root && r.root.updateScroll(), r.updateLayout(), this.resolveConstraints(), Tt(s => {
            if (!ps(s, t, null)) return;
            const a = this.getAxisMotionValue(s),
                {
                    min: l,
                    max: u
                } = this.constraints[s];
            a.set(xe(l, u, i[s]))
        })
    }
    addListeners() {
        if (!this.visualElement.current) return;
        x4.set(this.visualElement, this);
        const t = this.visualElement.current,
            n = dn(t, "pointerdown", l => {
                const {
                    drag: u,
                    dragListener: c = !0
                } = this.getProps();
                u && c && this.start(l)
            }),
            r = () => {
                const {
                    dragConstraints: l
                } = this.getProps();
                $r(l) && l.current && (this.constraints = this.resolveRefConstraints())
            },
            {
                projection: i
            } = this.visualElement,
            o = i.addEventListener("measure", r);
        i && !i.layout && (i.root && i.root.updateScroll(), i.updateLayout()), oe.read(r);
        const s = on(window, "resize", () => this.scalePositionWithinConstraints()),
            a = i.addEventListener("didUpdate", ({
                delta: l,
                hasLayoutChanged: u
            }) => {
                this.isDragging && u && (Tt(c => {
                    const d = this.getAxisMotionValue(c);
                    d && (this.originPoint[c] += l[c].translate, d.set(d.get() + l[c].translate))
                }), this.visualElement.render())
            });
        return () => {
            s(), n(), o(), a && a()
        }
    }
    getProps() {
        const t = this.visualElement.getProps(),
            {
                drag: n = !1,
                dragDirectionLock: r = !1,
                dragPropagation: i = !1,
                dragConstraints: o = !1,
                dragElastic: s = Uu,
                dragMomentum: a = !0
            } = t;
        return { ...t,
            drag: n,
            dragDirectionLock: r,
            dragPropagation: i,
            dragConstraints: o,
            dragElastic: s,
            dragMomentum: a
        }
    }
}

function ps(e, t, n) {
    return (t === !0 || t === e) && (n === null || n === e)
}

function S4(e, t = 10) {
    let n = null;
    return Math.abs(e.y) > t ? n = "y" : Math.abs(e.x) > t && (n = "x"), n
}
class T4 extends Zn {
    constructor(t) {
        super(t), this.removeGroupControls = Ke, this.removeListeners = Ke, this.controls = new w4(t)
    }
    mount() {
        const {
            dragControls: t
        } = this.node.getProps();
        t && (this.removeGroupControls = t.subscribe(this.controls)), this.removeListeners = this.controls.addListeners() || Ke
    }
    unmount() {
        this.removeGroupControls(), this.removeListeners()
    }
}
const tp = e => (t, n) => {
    e && oe.postRender(() => e(t, n))
};
class P4 extends Zn {
    constructor() {
        super(...arguments), this.removePointerDownListener = Ke
    }
    onPointerDown(t) {
        this.session = new rv(t, this.createPanHandlers(), {
            transformPagePoint: this.node.getTransformPagePoint(),
            contextWindow: pv(this.node)
        })
    }
    createPanHandlers() {
        const {
            onPanSessionStart: t,
            onPanStart: n,
            onPan: r,
            onPanEnd: i
        } = this.node.getProps();
        return {
            onSessionStart: tp(t),
            onStart: tp(n),
            onMove: r,
            onEnd: (o, s) => {
                delete this.session, i && oe.postRender(() => i(o, s))
            }
        }
    }
    mount() {
        this.removePointerDownListener = dn(this.node.current, "pointerdown", t => this.onPointerDown(t))
    }
    update() {
        this.session && this.session.updateHandlers(this.createPanHandlers())
    }
    unmount() {
        this.removePointerDownListener(), this.session && this.session.end()
    }
}
const wd = C.createContext(null);

function E4() {
    const e = C.useContext(wd);
    if (e === null) return [!0, null];
    const {
        isPresent: t,
        onExitComplete: n,
        register: r
    } = e, i = C.useId();
    C.useEffect(() => r(i), []);
    const o = C.useCallback(() => n && n(i), [i, n]);
    return !t && n ? [!1, o] : [!0]
}
const mv = C.createContext({}),
    gv = C.createContext({}),
    As = {
        hasAnimatedSinceResize: !0,
        hasEverUpdated: !1
    };

function np(e, t) {
    return t.max === t.min ? 0 : e / (t.max - t.min) * 100
}
const Di = {
        correct: (e, t) => {
            if (!t.target) return e;
            if (typeof e == "string")
                if ($.test(e)) e = parseFloat(e);
                else return e;
            const n = np(e, t.target.x),
                r = np(e, t.target.y);
            return `${n}% ${r}%`
        }
    },
    C4 = {
        correct: (e, {
            treeScale: t,
            projectionDelta: n
        }) => {
            const r = e,
                i = Hn.parse(e);
            if (i.length > 5) return r;
            const o = Hn.createTransformer(e),
                s = typeof i[0] != "number" ? 1 : 0,
                a = n.x.scale * t.x,
                l = n.y.scale * t.y;
            i[0 + s] /= a, i[1 + s] /= l;
            const u = xe(a, l, .5);
            return typeof i[2 + s] == "number" && (i[2 + s] /= u), typeof i[3 + s] == "number" && (i[3 + s] /= u), o(i)
        }
    },
    pa = {};

function k4(e) {
    Object.assign(pa, e)
}
const {
    schedule: Sd,
    cancel: FE
} = m0(queueMicrotask, !1);
class R4 extends C.Component {
    componentDidMount() {
        const {
            visualElement: t,
            layoutGroup: n,
            switchLayoutGroup: r,
            layoutId: i
        } = this.props, {
            projection: o
        } = t;
        k4(j4), o && (n.group && n.group.add(o), r && r.register && i && r.register(o), o.root.didUpdate(), o.addEventListener("animationComplete", () => {
            this.safeToRemove()
        }), o.setOptions({ ...o.options,
            onExitComplete: () => this.safeToRemove()
        })), As.hasEverUpdated = !0
    }
    getSnapshotBeforeUpdate(t) {
        const {
            layoutDependency: n,
            visualElement: r,
            drag: i,
            isPresent: o
        } = this.props, s = r.projection;
        return s && (s.isPresent = o, i || t.layoutDependency !== n || n === void 0 ? s.willUpdate() : this.safeToRemove(), t.isPresent !== o && (o ? s.promote() : s.relegate() || oe.postRender(() => {
            const a = s.getStack();
            (!a || !a.members.length) && this.safeToRemove()
        }))), null
    }
    componentDidUpdate() {
        const {
            projection: t
        } = this.props.visualElement;
        t && (t.root.didUpdate(), Sd.postRender(() => {
            !t.currentAnimation && t.isLead() && this.safeToRemove()
        }))
    }
    componentWillUnmount() {
        const {
            visualElement: t,
            layoutGroup: n,
            switchLayoutGroup: r
        } = this.props, {
            projection: i
        } = t;
        i && (i.scheduleCheckAfterUnmount(), n && n.group && n.group.remove(i), r && r.deregister && r.deregister(i))
    }
    safeToRemove() {
        const {
            safeToRemove: t
        } = this.props;
        t && t()
    }
    render() {
        return null
    }
}

function vv(e) {
    const [t, n] = E4(), r = C.useContext(mv);
    return v.jsx(R4, { ...e,
        layoutGroup: r,
        switchLayoutGroup: C.useContext(gv),
        isPresent: t,
        safeToRemove: n
    })
}
const j4 = {
        borderRadius: { ...Di,
            applyTo: ["borderTopLeftRadius", "borderTopRightRadius", "borderBottomLeftRadius", "borderBottomRightRadius"]
        },
        borderTopLeftRadius: Di,
        borderTopRightRadius: Di,
        borderBottomLeftRadius: Di,
        borderBottomRightRadius: Di,
        boxShadow: C4
    },
    yv = ["TopLeft", "TopRight", "BottomLeft", "BottomRight"],
    A4 = yv.length,
    rp = e => typeof e == "string" ? parseFloat(e) : e,
    ip = e => typeof e == "number" || $.test(e);

function L4(e, t, n, r, i, o) {
    i ? (e.opacity = xe(0, n.opacity !== void 0 ? n.opacity : 1, M4(r)), e.opacityExit = xe(t.opacity !== void 0 ? t.opacity : 1, 0, N4(r))) : o && (e.opacity = xe(t.opacity !== void 0 ? t.opacity : 1, n.opacity !== void 0 ? n.opacity : 1, r));
    for (let s = 0; s < A4; s++) {
        const a = `border${yv[s]}Radius`;
        let l = op(t, a),
            u = op(n, a);
        if (l === void 0 && u === void 0) continue;
        l || (l = 0), u || (u = 0), l === 0 || u === 0 || ip(l) === ip(u) ? (e[a] = Math.max(xe(rp(l), rp(u), r), 0), (Wt.test(u) || Wt.test(l)) && (e[a] += "%")) : e[a] = u
    }(t.rotate || n.rotate) && (e.rotate = xe(t.rotate || 0, n.rotate || 0, r))
}

function op(e, t) {
    return e[t] !== void 0 ? e[t] : e.borderRadius
}
const M4 = xv(0, .5, T0),
    N4 = xv(.5, .95, Ke);

function xv(e, t, n) {
    return r => r < e ? 0 : r > t ? 1 : n(fi(e, t, r))
}

function sp(e, t) {
    e.min = t.min, e.max = t.max
}

function St(e, t) {
    sp(e.x, t.x), sp(e.y, t.y)
}

function ap(e, t) {
    e.translate = t.translate, e.scale = t.scale, e.originPoint = t.originPoint, e.origin = t.origin
}

function lp(e, t, n, r, i) {
    return e -= t, e = ha(e, 1 / n, r), i !== void 0 && (e = ha(e, 1 / i, r)), e
}

function D4(e, t = 0, n = 1, r = .5, i, o = e, s = e) {
    if (Wt.test(t) && (t = parseFloat(t), t = xe(s.min, s.max, t / 100) - s.min), typeof t != "number") return;
    let a = xe(o.min, o.max, r);
    e === o && (a -= t), e.min = lp(e.min, t, n, a, i), e.max = lp(e.max, t, n, a, i)
}

function up(e, t, [n, r, i], o, s) {
    D4(e, t[n], t[r], t[i], t.scale, o, s)
}
const _4 = ["x", "scaleX", "originX"],
    O4 = ["y", "scaleY", "originY"];

function cp(e, t, n, r) {
    up(e.x, t, _4, n ? n.x : void 0, r ? r.x : void 0), up(e.y, t, O4, n ? n.y : void 0, r ? r.y : void 0)
}

function dp(e) {
    return e.translate === 0 && e.scale === 1
}

function wv(e) {
    return dp(e.x) && dp(e.y)
}

function fp(e, t) {
    return e.min === t.min && e.max === t.max
}

function V4(e, t) {
    return fp(e.x, t.x) && fp(e.y, t.y)
}

function hp(e, t) {
    return Math.round(e.min) === Math.round(t.min) && Math.round(e.max) === Math.round(t.max)
}

function Sv(e, t) {
    return hp(e.x, t.x) && hp(e.y, t.y)
}

function pp(e) {
    return gt(e.x) / gt(e.y)
}

function mp(e, t) {
    return e.translate === t.translate && e.scale === t.scale && e.originPoint === t.originPoint
}
class F4 {
    constructor() {
        this.members = []
    }
    add(t) {
        vd(this.members, t), t.scheduleRender()
    }
    remove(t) {
        if (yd(this.members, t), t === this.prevLead && (this.prevLead = void 0), t === this.lead) {
            const n = this.members[this.members.length - 1];
            n && this.promote(n)
        }
    }
    relegate(t) {
        const n = this.members.findIndex(i => t === i);
        if (n === 0) return !1;
        let r;
        for (let i = n; i >= 0; i--) {
            const o = this.members[i];
            if (o.isPresent !== !1) {
                r = o;
                break
            }
        }
        return r ? (this.promote(r), !0) : !1
    }
    promote(t, n) {
        const r = this.lead;
        if (t !== r && (this.prevLead = r, this.lead = t, t.show(), r)) {
            r.instance && r.scheduleRender(), t.scheduleRender(), t.resumeFrom = r, n && (t.resumeFrom.preserveOpacity = !0), r.snapshot && (t.snapshot = r.snapshot, t.snapshot.latestValues = r.animationValues || r.latestValues), t.root && t.root.isUpdating && (t.isLayoutDirty = !0);
            const {
                crossfade: i
            } = t.options;
            i === !1 && r.hide()
        }
    }
    exitAnimationComplete() {
        this.members.forEach(t => {
            const {
                options: n,
                resumingFrom: r
            } = t;
            n.onExitComplete && n.onExitComplete(), r && r.options.onExitComplete && r.options.onExitComplete()
        })
    }
    scheduleRender() {
        this.members.forEach(t => {
            t.instance && t.scheduleRender(!1)
        })
    }
    removeLeadSnapshot() {
        this.lead && this.lead.snapshot && (this.lead.snapshot = void 0)
    }
}

function I4(e, t, n) {
    let r = "";
    const i = e.x.translate / t.x,
        o = e.y.translate / t.y,
        s = (n == null ? void 0 : n.z) || 0;
    if ((i || o || s) && (r = `translate3d(${i}px, ${o}px, ${s}px) `), (t.x !== 1 || t.y !== 1) && (r += `scale(${1/t.x}, ${1/t.y}) `), n) {
        const {
            transformPerspective: u,
            rotate: c,
            rotateX: d,
            rotateY: f,
            skewX: m,
            skewY: x
        } = n;
        u && (r = `perspective(${u}px) ${r}`), c && (r += `rotate(${c}deg) `), d && (r += `rotateX(${d}deg) `), f && (r += `rotateY(${f}deg) `), m && (r += `skewX(${m}deg) `), x && (r += `skewY(${x}deg) `)
    }
    const a = e.x.scale * t.x,
        l = e.y.scale * t.y;
    return (a !== 1 || l !== 1) && (r += `scale(${a}, ${l})`), r || "none"
}
const z4 = (e, t) => e.depth - t.depth;
class b4 {
    constructor() {
        this.children = [], this.isDirty = !1
    }
    add(t) {
        vd(this.children, t), this.isDirty = !0
    }
    remove(t) {
        yd(this.children, t), this.isDirty = !0
    }
    forEach(t) {
        this.isDirty && this.children.sort(z4), this.isDirty = !1, this.children.forEach(t)
    }
}

function Ls(e) {
    const t = We(e) ? e.get() : e;
    return M3(t) ? t.toValue() : t
}

function B4(e, t) {
    const n = Kt.now(),
        r = ({
            timestamp: i
        }) => {
            const o = i - n;
            o >= t && (Bn(r), e(o - t))
        };
    return oe.read(r, !0), () => Bn(r)
}

function U4(e) {
    return e instanceof SVGElement && e.tagName !== "svg"
}

function H4(e, t, n) {
    const r = We(e) ? e : Co(e);
    return r.start(gd("", r, t, n)), r.animation
}
const sr = {
        type: "projectionFrame",
        totalNodes: 0,
        resolvedTargetDeltas: 0,
        recalculatedProjection: 0
    },
    Ui = typeof window < "u" && window.MotionDebug !== void 0,
    jl = ["", "X", "Y", "Z"],
    $4 = {
        visibility: "hidden"
    },
    gp = 1e3;
let W4 = 0;

function Al(e, t, n, r) {
    const {
        latestValues: i
    } = t;
    i[e] && (n[e] = i[e], t.setStaticValue(e, 0), r && (r[e] = 0))
}

function Tv(e) {
    if (e.hasCheckedOptimisedAppear = !0, e.root === e) return;
    const {
        visualElement: t
    } = e.options;
    if (!t) return;
    const n = J0(t);
    if (window.MotionHasOptimisedAnimation(n, "transform")) {
        const {
            layout: i,
            layoutId: o
        } = e.options;
        window.MotionCancelOptimisedAnimation(n, "transform", oe, !(i || o))
    }
    const {
        parent: r
    } = e;
    r && !r.hasCheckedOptimisedAppear && Tv(r)
}

function Pv({
    attachResizeListener: e,
    defaultParent: t,
    measureScroll: n,
    checkIsScrollRoot: r,
    resetTransform: i
}) {
    return class {
        constructor(s = {}, a = t == null ? void 0 : t()) {
            this.id = W4++, this.animationId = 0, this.children = new Set, this.options = {}, this.isTreeAnimating = !1, this.isAnimationBlocked = !1, this.isLayoutDirty = !1, this.isProjectionDirty = !1, this.isSharedProjectionDirty = !1, this.isTransformDirty = !1, this.updateManuallyBlocked = !1, this.updateBlockedByResize = !1, this.isUpdating = !1, this.isSVG = !1, this.needsReset = !1, this.shouldResetTransform = !1, this.hasCheckedOptimisedAppear = !1, this.treeScale = {
                x: 1,
                y: 1
            }, this.eventHandlers = new Map, this.hasTreeAnimated = !1, this.updateScheduled = !1, this.scheduleUpdate = () => this.update(), this.projectionUpdateScheduled = !1, this.checkUpdateFailed = () => {
                this.isUpdating && (this.isUpdating = !1, this.clearAllSnapshots())
            }, this.updateProjection = () => {
                this.projectionUpdateScheduled = !1, Ui && (sr.totalNodes = sr.resolvedTargetDeltas = sr.recalculatedProjection = 0), this.nodes.forEach(Y4), this.nodes.forEach(q4), this.nodes.forEach(eT), this.nodes.forEach(Q4), Ui && window.MotionDebug.record(sr)
            }, this.resolvedRelativeTargetAt = 0, this.hasProjected = !1, this.isVisible = !0, this.animationProgress = 0, this.sharedNodes = new Map, this.latestValues = s, this.root = a ? a.root || a : this, this.path = a ? [...a.path, a] : [], this.parent = a, this.depth = a ? a.depth + 1 : 0;
            for (let l = 0; l < this.path.length; l++) this.path[l].shouldResetTransform = !0;
            this.root === this && (this.nodes = new b4)
        }
        addEventListener(s, a) {
            return this.eventHandlers.has(s) || this.eventHandlers.set(s, new xd), this.eventHandlers.get(s).add(a)
        }
        notifyListeners(s, ...a) {
            const l = this.eventHandlers.get(s);
            l && l.notify(...a)
        }
        hasListeners(s) {
            return this.eventHandlers.has(s)
        }
        mount(s, a = this.root.hasTreeAnimated) {
            if (this.instance) return;
            this.isSVG = U4(s), this.instance = s;
            const {
                layoutId: l,
                layout: u,
                visualElement: c
            } = this.options;
            if (c && !c.current && c.mount(s), this.root.nodes.add(this), this.parent && this.parent.children.add(this), a && (u || l) && (this.isLayoutDirty = !0), e) {
                let d;
                const f = () => this.root.updateBlockedByResize = !1;
                e(s, () => {
                    this.root.updateBlockedByResize = !0, d && d(), d = B4(f, 250), As.hasAnimatedSinceResize && (As.hasAnimatedSinceResize = !1, this.nodes.forEach(yp))
                })
            }
            l && this.root.registerSharedNode(l, this), this.options.animate !== !1 && c && (l || u) && this.addEventListener("didUpdate", ({
                delta: d,
                hasLayoutChanged: f,
                hasRelativeTargetChanged: m,
                layout: x
            }) => {
                if (this.isTreeAnimationBlocked()) {
                    this.target = void 0, this.relativeTarget = void 0;
                    return
                }
                const w = this.options.transition || c.getDefaultTransition() || oT,
                    {
                        onLayoutAnimationStart: E,
                        onLayoutAnimationComplete: p
                    } = c.getProps(),
                    h = !this.targetLayout || !Sv(this.targetLayout, x) || m,
                    g = !f && m;
                if (this.options.layoutRoot || this.resumeFrom && this.resumeFrom.instance || g || f && (h || !this.currentAnimation)) {
                    this.resumeFrom && (this.resumingFrom = this.resumeFrom, this.resumingFrom.resumingFrom = void 0), this.setAnimationOrigin(d, g);
                    const P = { ...nd(w, "layout"),
                        onPlay: E,
                        onComplete: p
                    };
                    (c.shouldReduceMotion || this.options.layoutRoot) && (P.delay = 0, P.type = !1), this.startAnimation(P)
                } else f || yp(this), this.isLead() && this.options.onExitComplete && this.options.onExitComplete();
                this.targetLayout = x
            })
        }
        unmount() {
            this.options.layoutId && this.willUpdate(), this.root.nodes.remove(this);
            const s = this.getStack();
            s && s.remove(this), this.parent && this.parent.children.delete(this), this.instance = void 0, Bn(this.updateProjection)
        }
        blockUpdate() {
            this.updateManuallyBlocked = !0
        }
        unblockUpdate() {
            this.updateManuallyBlocked = !1
        }
        isUpdateBlocked() {
            return this.updateManuallyBlocked || this.updateBlockedByResize
        }
        isTreeAnimationBlocked() {
            return this.isAnimationBlocked || this.parent && this.parent.isTreeAnimationBlocked() || !1
        }
        startUpdate() {
            this.isUpdateBlocked() || (this.isUpdating = !0, this.nodes && this.nodes.forEach(tT), this.animationId++)
        }
        getTransformTemplate() {
            const {
                visualElement: s
            } = this.options;
            return s && s.getProps().transformTemplate
        }
        willUpdate(s = !0) {
            if (this.root.hasTreeAnimated = !0, this.root.isUpdateBlocked()) {
                this.options.onExitComplete && this.options.onExitComplete();
                return
            }
            if (window.MotionCancelOptimisedAnimation && !this.hasCheckedOptimisedAppear && Tv(this), !this.root.isUpdating && this.root.startUpdate(), this.isLayoutDirty) return;
            this.isLayoutDirty = !0;
            for (let c = 0; c < this.path.length; c++) {
                const d = this.path[c];
                d.shouldResetTransform = !0, d.updateScroll("snapshot"), d.options.layoutRoot && d.willUpdate(!1)
            }
            const {
                layoutId: a,
                layout: l
            } = this.options;
            if (a === void 0 && !l) return;
            const u = this.getTransformTemplate();
            this.prevTransformTemplateValue = u ? u(this.latestValues, "") : void 0, this.updateSnapshot(), s && this.notifyListeners("willUpdate")
        }
        update() {
            if (this.updateScheduled = !1, this.isUpdateBlocked()) {
                this.unblockUpdate(), this.clearAllSnapshots(), this.nodes.forEach(vp);
                return
            }
            this.isUpdating || this.nodes.forEach(Z4), this.isUpdating = !1, this.nodes.forEach(J4), this.nodes.forEach(K4), this.nodes.forEach(G4), this.clearAllSnapshots();
            const a = Kt.now();
            Ie.delta = Un(0, 1e3 / 60, a - Ie.timestamp), Ie.timestamp = a, Ie.isProcessing = !0, wl.update.process(Ie), wl.preRender.process(Ie), wl.render.process(Ie), Ie.isProcessing = !1
        }
        didUpdate() {
            this.updateScheduled || (this.updateScheduled = !0, Sd.read(this.scheduleUpdate))
        }
        clearAllSnapshots() {
            this.nodes.forEach(X4), this.sharedNodes.forEach(nT)
        }
        scheduleUpdateProjection() {
            this.projectionUpdateScheduled || (this.projectionUpdateScheduled = !0, oe.preRender(this.updateProjection, !1, !0))
        }
        scheduleCheckAfterUnmount() {
            oe.postRender(() => {
                this.isLayoutDirty ? this.root.didUpdate() : this.root.checkUpdateFailed()
            })
        }
        updateSnapshot() {
            this.snapshot || !this.instance || (this.snapshot = this.measure())
        }
        updateLayout() {
            if (!this.instance || (this.updateScroll(), !(this.options.alwaysMeasureLayout && this.isLead()) && !this.isLayoutDirty)) return;
            if (this.resumeFrom && !this.resumeFrom.instance)
                for (let l = 0; l < this.path.length; l++) this.path[l].updateScroll();
            const s = this.layout;
            this.layout = this.measure(!1), this.layoutCorrected = ke(), this.isLayoutDirty = !1, this.projectionDelta = void 0, this.notifyListeners("measure", this.layout.layoutBox);
            const {
                visualElement: a
            } = this.options;
            a && a.notify("LayoutMeasure", this.layout.layoutBox, s ? s.layoutBox : void 0)
        }
        updateScroll(s = "measure") {
            let a = !!(this.options.layoutScroll && this.instance);
            if (this.scroll && this.scroll.animationId === this.root.animationId && this.scroll.phase === s && (a = !1), a) {
                const l = r(this.instance);
                this.scroll = {
                    animationId: this.root.animationId,
                    phase: s,
                    isRoot: l,
                    offset: n(this.instance),
                    wasRoot: this.scroll ? this.scroll.isRoot : l
                }
            }
        }
        resetTransform() {
            if (!i) return;
            const s = this.isLayoutDirty || this.shouldResetTransform || this.options.alwaysMeasureLayout,
                a = this.projectionDelta && !wv(this.projectionDelta),
                l = this.getTransformTemplate(),
                u = l ? l(this.latestValues, "") : void 0,
                c = u !== this.prevTransformTemplateValue;
            s && (a || or(this.latestValues) || c) && (i(this.instance, u), this.shouldResetTransform = !1, this.scheduleRender())
        }
        measure(s = !0) {
            const a = this.measurePageBox();
            let l = this.removeElementScroll(a);
            return s && (l = this.removeTransform(l)), sT(l), {
                animationId: this.root.animationId,
                measuredBox: a,
                layoutBox: l,
                latestValues: {},
                source: this.id
            }
        }
        measurePageBox() {
            var s;
            const {
                visualElement: a
            } = this.options;
            if (!a) return ke();
            const l = a.measureViewportBox();
            if (!(((s = this.scroll) === null || s === void 0 ? void 0 : s.wasRoot) || this.path.some(aT))) {
                const {
                    scroll: c
                } = this.root;
                c && (Kr(l.x, c.offset.x), Kr(l.y, c.offset.y))
            }
            return l
        }
        removeElementScroll(s) {
            var a;
            const l = ke();
            if (St(l, s), !((a = this.scroll) === null || a === void 0) && a.wasRoot) return l;
            for (let u = 0; u < this.path.length; u++) {
                const c = this.path[u],
                    {
                        scroll: d,
                        options: f
                    } = c;
                c !== this.root && d && f.layoutScroll && (d.wasRoot && St(l, s), Kr(l.x, d.offset.x), Kr(l.y, d.offset.y))
            }
            return l
        }
        applyTransform(s, a = !1) {
            const l = ke();
            St(l, s);
            for (let u = 0; u < this.path.length; u++) {
                const c = this.path[u];
                !a && c.options.layoutScroll && c.scroll && c !== c.root && Gr(l, {
                    x: -c.scroll.offset.x,
                    y: -c.scroll.offset.y
                }), or(c.latestValues) && Gr(l, c.latestValues)
            }
            return or(this.latestValues) && Gr(l, this.latestValues), l
        }
        removeTransform(s) {
            const a = ke();
            St(a, s);
            for (let l = 0; l < this.path.length; l++) {
                const u = this.path[l];
                if (!u.instance || !or(u.latestValues)) continue;
                Hu(u.latestValues) && u.updateSnapshot();
                const c = ke(),
                    d = u.measurePageBox();
                St(c, d), cp(a, u.latestValues, u.snapshot ? u.snapshot.layoutBox : void 0, c)
            }
            return or(this.latestValues) && cp(a, this.latestValues), a
        }
        setTargetDelta(s) {
            this.targetDelta = s, this.root.scheduleUpdateProjection(), this.isProjectionDirty = !0
        }
        setOptions(s) {
            this.options = { ...this.options,
                ...s,
                crossfade: s.crossfade !== void 0 ? s.crossfade : !0
            }
        }
        clearMeasurements() {
            this.scroll = void 0, this.layout = void 0, this.snapshot = void 0, this.prevTransformTemplateValue = void 0, this.targetDelta = void 0, this.target = void 0, this.isLayoutDirty = !1
        }
        forceRelativeParentToResolveTarget() {
            this.relativeParent && this.relativeParent.resolvedRelativeTargetAt !== Ie.timestamp && this.relativeParent.resolveTargetDelta(!0)
        }
        resolveTargetDelta(s = !1) {
            var a;
            const l = this.getLead();
            this.isProjectionDirty || (this.isProjectionDirty = l.isProjectionDirty), this.isTransformDirty || (this.isTransformDirty = l.isTransformDirty), this.isSharedProjectionDirty || (this.isSharedProjectionDirty = l.isSharedProjectionDirty);
            const u = !!this.resumingFrom || this !== l;
            if (!(s || u && this.isSharedProjectionDirty || this.isProjectionDirty || !((a = this.parent) === null || a === void 0) && a.isProjectionDirty || this.attemptToResolveRelativeTarget || this.root.updateBlockedByResize)) return;
            const {
                layout: d,
                layoutId: f
            } = this.options;
            if (!(!this.layout || !(d || f))) {
                if (this.resolvedRelativeTargetAt = Ie.timestamp, !this.targetDelta && !this.relativeTarget) {
                    const m = this.getClosestProjectingParent();
                    m && m.layout && this.animationProgress !== 1 ? (this.relativeParent = m, this.forceRelativeParentToResolveTarget(), this.relativeTarget = ke(), this.relativeTargetOrigin = ke(), eo(this.relativeTargetOrigin, this.layout.layoutBox, m.layout.layoutBox), St(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                }
                if (!(!this.relativeTarget && !this.targetDelta)) {
                    if (this.target || (this.target = ke(), this.targetWithTransforms = ke()), this.relativeTarget && this.relativeTargetOrigin && this.relativeParent && this.relativeParent.target ? (this.forceRelativeParentToResolveTarget(), l4(this.target, this.relativeTarget, this.relativeParent.target)) : this.targetDelta ? (this.resumingFrom ? this.target = this.applyTransform(this.layout.layoutBox) : St(this.target, this.layout.layoutBox), fv(this.target, this.targetDelta)) : St(this.target, this.layout.layoutBox), this.attemptToResolveRelativeTarget) {
                        this.attemptToResolveRelativeTarget = !1;
                        const m = this.getClosestProjectingParent();
                        m && !!m.resumingFrom == !!this.resumingFrom && !m.options.layoutScroll && m.target && this.animationProgress !== 1 ? (this.relativeParent = m, this.forceRelativeParentToResolveTarget(), this.relativeTarget = ke(), this.relativeTargetOrigin = ke(), eo(this.relativeTargetOrigin, this.target, m.target), St(this.relativeTarget, this.relativeTargetOrigin)) : this.relativeParent = this.relativeTarget = void 0
                    }
                    Ui && sr.resolvedTargetDeltas++
                }
            }
        }
        getClosestProjectingParent() {
            if (!(!this.parent || Hu(this.parent.latestValues) || dv(this.parent.latestValues))) return this.parent.isProjecting() ? this.parent : this.parent.getClosestProjectingParent()
        }
        isProjecting() {
            return !!((this.relativeTarget || this.targetDelta || this.options.layoutRoot) && this.layout)
        }
        calcProjection() {
            var s;
            const a = this.getLead(),
                l = !!this.resumingFrom || this !== a;
            let u = !0;
            if ((this.isProjectionDirty || !((s = this.parent) === null || s === void 0) && s.isProjectionDirty) && (u = !1), l && (this.isSharedProjectionDirty || this.isTransformDirty) && (u = !1), this.resolvedRelativeTargetAt === Ie.timestamp && (u = !1), u) return;
            const {
                layout: c,
                layoutId: d
            } = this.options;
            if (this.isTreeAnimating = !!(this.parent && this.parent.isTreeAnimating || this.currentAnimation || this.pendingAnimation), this.isTreeAnimating || (this.targetDelta = this.relativeTarget = void 0), !this.layout || !(c || d)) return;
            St(this.layoutCorrected, this.layout.layoutBox);
            const f = this.treeScale.x,
                m = this.treeScale.y;
            v4(this.layoutCorrected, this.treeScale, this.path, l), a.layout && !a.target && (this.treeScale.x !== 1 || this.treeScale.y !== 1) && (a.target = a.layout.layoutBox, a.targetWithTransforms = ke());
            const {
                target: x
            } = a;
            if (!x) {
                this.prevProjectionDelta && (this.createProjectionDeltas(), this.scheduleRender());
                return
            }!this.projectionDelta || !this.prevProjectionDelta ? this.createProjectionDeltas() : (ap(this.prevProjectionDelta.x, this.projectionDelta.x), ap(this.prevProjectionDelta.y, this.projectionDelta.y)), qi(this.projectionDelta, this.layoutCorrected, x, this.latestValues), (this.treeScale.x !== f || this.treeScale.y !== m || !mp(this.projectionDelta.x, this.prevProjectionDelta.x) || !mp(this.projectionDelta.y, this.prevProjectionDelta.y)) && (this.hasProjected = !0, this.scheduleRender(), this.notifyListeners("projectionUpdate", x)), Ui && sr.recalculatedProjection++
        }
        hide() {
            this.isVisible = !1
        }
        show() {
            this.isVisible = !0
        }
        scheduleRender(s = !0) {
            var a;
            if ((a = this.options.visualElement) === null || a === void 0 || a.scheduleRender(), s) {
                const l = this.getStack();
                l && l.scheduleRender()
            }
            this.resumingFrom && !this.resumingFrom.instance && (this.resumingFrom = void 0)
        }
        createProjectionDeltas() {
            this.prevProjectionDelta = Wr(), this.projectionDelta = Wr(), this.projectionDeltaWithTransform = Wr()
        }
        setAnimationOrigin(s, a = !1) {
            const l = this.snapshot,
                u = l ? l.latestValues : {},
                c = { ...this.latestValues
                },
                d = Wr();
            (!this.relativeParent || !this.relativeParent.options.layoutRoot) && (this.relativeTarget = this.relativeTargetOrigin = void 0), this.attemptToResolveRelativeTarget = !a;
            const f = ke(),
                m = l ? l.source : void 0,
                x = this.layout ? this.layout.source : void 0,
                w = m !== x,
                E = this.getStack(),
                p = !E || E.members.length <= 1,
                h = !!(w && !p && this.options.crossfade === !0 && !this.path.some(iT));
            this.animationProgress = 0;
            let g;
            this.mixTargetDelta = P => {
                const R = P / 1e3;
                xp(d.x, s.x, R), xp(d.y, s.y, R), this.setTargetDelta(d), this.relativeTarget && this.relativeTargetOrigin && this.layout && this.relativeParent && this.relativeParent.layout && (eo(f, this.layout.layoutBox, this.relativeParent.layout.layoutBox), rT(this.relativeTarget, this.relativeTargetOrigin, f, R), g && V4(this.relativeTarget, g) && (this.isProjectionDirty = !1), g || (g = ke()), St(g, this.relativeTarget)), w && (this.animationValues = c, L4(c, u, this.latestValues, R, h, p)), this.root.scheduleUpdateProjection(), this.scheduleRender(), this.animationProgress = R
            }, this.mixTargetDelta(this.options.layoutRoot ? 1e3 : 0)
        }
        startAnimation(s) {
            this.notifyListeners("animationStart"), this.currentAnimation && this.currentAnimation.stop(), this.resumingFrom && this.resumingFrom.currentAnimation && this.resumingFrom.currentAnimation.stop(), this.pendingAnimation && (Bn(this.pendingAnimation), this.pendingAnimation = void 0), this.pendingAnimation = oe.update(() => {
                As.hasAnimatedSinceResize = !0, this.currentAnimation = H4(0, gp, { ...s,
                    onUpdate: a => {
                        this.mixTargetDelta(a), s.onUpdate && s.onUpdate(a)
                    },
                    onComplete: () => {
                        s.onComplete && s.onComplete(), this.completeAnimation()
                    }
                }), this.resumingFrom && (this.resumingFrom.currentAnimation = this.currentAnimation), this.pendingAnimation = void 0
            })
        }
        completeAnimation() {
            this.resumingFrom && (this.resumingFrom.currentAnimation = void 0, this.resumingFrom.preserveOpacity = void 0);
            const s = this.getStack();
            s && s.exitAnimationComplete(), this.resumingFrom = this.currentAnimation = this.animationValues = void 0, this.notifyListeners("animationComplete")
        }
        finishAnimation() {
            this.currentAnimation && (this.mixTargetDelta && this.mixTargetDelta(gp), this.currentAnimation.stop()), this.completeAnimation()
        }
        applyTransformsToTarget() {
            const s = this.getLead();
            let {
                targetWithTransforms: a,
                target: l,
                layout: u,
                latestValues: c
            } = s;
            if (!(!a || !l || !u)) {
                if (this !== s && this.layout && u && Ev(this.options.animationType, this.layout.layoutBox, u.layoutBox)) {
                    l = this.target || ke();
                    const d = gt(this.layout.layoutBox.x);
                    l.x.min = s.target.x.min, l.x.max = l.x.min + d;
                    const f = gt(this.layout.layoutBox.y);
                    l.y.min = s.target.y.min, l.y.max = l.y.min + f
                }
                St(a, l), Gr(a, c), qi(this.projectionDeltaWithTransform, this.layoutCorrected, a, c)
            }
        }
        registerSharedNode(s, a) {
            this.sharedNodes.has(s) || this.sharedNodes.set(s, new F4), this.sharedNodes.get(s).add(a);
            const u = a.options.initialPromotionConfig;
            a.promote({
                transition: u ? u.transition : void 0,
                preserveFollowOpacity: u && u.shouldPreserveFollowOpacity ? u.shouldPreserveFollowOpacity(a) : void 0
            })
        }
        isLead() {
            const s = this.getStack();
            return s ? s.lead === this : !0
        }
        getLead() {
            var s;
            const {
                layoutId: a
            } = this.options;
            return a ? ((s = this.getStack()) === null || s === void 0 ? void 0 : s.lead) || this : this
        }
        getPrevLead() {
            var s;
            const {
                layoutId: a
            } = this.options;
            return a ? (s = this.getStack()) === null || s === void 0 ? void 0 : s.prevLead : void 0
        }
        getStack() {
            const {
                layoutId: s
            } = this.options;
            if (s) return this.root.sharedNodes.get(s)
        }
        promote({
            needsReset: s,
            transition: a,
            preserveFollowOpacity: l
        } = {}) {
            const u = this.getStack();
            u && u.promote(this, l), s && (this.projectionDelta = void 0, this.needsReset = !0), a && this.setOptions({
                transition: a
            })
        }
        relegate() {
            const s = this.getStack();
            return s ? s.relegate(this) : !1
        }
        resetSkewAndRotation() {
            const {
                visualElement: s
            } = this.options;
            if (!s) return;
            let a = !1;
            const {
                latestValues: l
            } = s;
            if ((l.z || l.rotate || l.rotateX || l.rotateY || l.rotateZ || l.skewX || l.skewY) && (a = !0), !a) return;
            const u = {};
            l.z && Al("z", s, u, this.animationValues);
            for (let c = 0; c < jl.length; c++) Al(`rotate${jl[c]}`, s, u, this.animationValues), Al(`skew${jl[c]}`, s, u, this.animationValues);
            s.render();
            for (const c in u) s.setStaticValue(c, u[c]), this.animationValues && (this.animationValues[c] = u[c]);
            s.scheduleRender()
        }
        getProjectionStyles(s) {
            var a, l;
            if (!this.instance || this.isSVG) return;
            if (!this.isVisible) return $4;
            const u = {
                    visibility: ""
                },
                c = this.getTransformTemplate();
            if (this.needsReset) return this.needsReset = !1, u.opacity = "", u.pointerEvents = Ls(s == null ? void 0 : s.pointerEvents) || "", u.transform = c ? c(this.latestValues, "") : "none", u;
            const d = this.getLead();
            if (!this.projectionDelta || !this.layout || !d.target) {
                const w = {};
                return this.options.layoutId && (w.opacity = this.latestValues.opacity !== void 0 ? this.latestValues.opacity : 1, w.pointerEvents = Ls(s == null ? void 0 : s.pointerEvents) || ""), this.hasProjected && !or(this.latestValues) && (w.transform = c ? c({}, "") : "none", this.hasProjected = !1), w
            }
            const f = d.animationValues || d.latestValues;
            this.applyTransformsToTarget(), u.transform = I4(this.projectionDeltaWithTransform, this.treeScale, f), c && (u.transform = c(f, u.transform));
            const {
                x: m,
                y: x
            } = this.projectionDelta;
            u.transformOrigin = `${m.origin*100}% ${x.origin*100}% 0`, d.animationValues ? u.opacity = d === this ? (l = (a = f.opacity) !== null && a !== void 0 ? a : this.latestValues.opacity) !== null && l !== void 0 ? l : 1 : this.preserveOpacity ? this.latestValues.opacity : f.opacityExit : u.opacity = d === this ? f.opacity !== void 0 ? f.opacity : "" : f.opacityExit !== void 0 ? f.opacityExit : 0;
            for (const w in pa) {
                if (f[w] === void 0) continue;
                const {
                    correct: E,
                    applyTo: p
                } = pa[w], h = u.transform === "none" ? f[w] : E(f[w], d);
                if (p) {
                    const g = p.length;
                    for (let P = 0; P < g; P++) u[p[P]] = h
                } else u[w] = h
            }
            return this.options.layoutId && (u.pointerEvents = d === this ? Ls(s == null ? void 0 : s.pointerEvents) || "" : "none"), u
        }
        clearSnapshot() {
            this.resumeFrom = this.snapshot = void 0
        }
        resetTree() {
            this.root.nodes.forEach(s => {
                var a;
                return (a = s.currentAnimation) === null || a === void 0 ? void 0 : a.stop()
            }), this.root.nodes.forEach(vp), this.root.sharedNodes.clear()
        }
    }
}

function K4(e) {
    e.updateLayout()
}

function G4(e) {
    var t;
    const n = ((t = e.resumeFrom) === null || t === void 0 ? void 0 : t.snapshot) || e.snapshot;
    if (e.isLead() && e.layout && n && e.hasListeners("didUpdate")) {
        const {
            layoutBox: r,
            measuredBox: i
        } = e.layout, {
            animationType: o
        } = e.options, s = n.source !== e.layout.source;
        o === "size" ? Tt(d => {
            const f = s ? n.measuredBox[d] : n.layoutBox[d],
                m = gt(f);
            f.min = r[d].min, f.max = f.min + m
        }) : Ev(o, n.layoutBox, r) && Tt(d => {
            const f = s ? n.measuredBox[d] : n.layoutBox[d],
                m = gt(r[d]);
            f.max = f.min + m, e.relativeTarget && !e.currentAnimation && (e.isProjectionDirty = !0, e.relativeTarget[d].max = e.relativeTarget[d].min + m)
        });
        const a = Wr();
        qi(a, r, n.layoutBox);
        const l = Wr();
        s ? qi(l, e.applyTransform(i, !0), n.measuredBox) : qi(l, r, n.layoutBox);
        const u = !wv(a);
        let c = !1;
        if (!e.resumeFrom) {
            const d = e.getClosestProjectingParent();
            if (d && !d.resumeFrom) {
                const {
                    snapshot: f,
                    layout: m
                } = d;
                if (f && m) {
                    const x = ke();
                    eo(x, n.layoutBox, f.layoutBox);
                    const w = ke();
                    eo(w, r, m.layoutBox), Sv(x, w) || (c = !0), d.options.layoutRoot && (e.relativeTarget = w, e.relativeTargetOrigin = x, e.relativeParent = d)
                }
            }
        }
        e.notifyListeners("didUpdate", {
            layout: r,
            snapshot: n,
            delta: l,
            layoutDelta: a,
            hasLayoutChanged: u,
            hasRelativeTargetChanged: c
        })
    } else if (e.isLead()) {
        const {
            onExitComplete: r
        } = e.options;
        r && r()
    }
    e.options.transition = void 0
}

function Y4(e) {
    Ui && sr.totalNodes++, e.parent && (e.isProjecting() || (e.isProjectionDirty = e.parent.isProjectionDirty), e.isSharedProjectionDirty || (e.isSharedProjectionDirty = !!(e.isProjectionDirty || e.parent.isProjectionDirty || e.parent.isSharedProjectionDirty)), e.isTransformDirty || (e.isTransformDirty = e.parent.isTransformDirty))
}

function Q4(e) {
    e.isProjectionDirty = e.isSharedProjectionDirty = e.isTransformDirty = !1
}

function X4(e) {
    e.clearSnapshot()
}

function vp(e) {
    e.clearMeasurements()
}

function Z4(e) {
    e.isLayoutDirty = !1
}

function J4(e) {
    const {
        visualElement: t
    } = e.options;
    t && t.getProps().onBeforeLayoutMeasure && t.notify("BeforeLayoutMeasure"), e.resetTransform()
}

function yp(e) {
    e.finishAnimation(), e.targetDelta = e.relativeTarget = e.target = void 0, e.isProjectionDirty = !0
}

function q4(e) {
    e.resolveTargetDelta()
}

function eT(e) {
    e.calcProjection()
}

function tT(e) {
    e.resetSkewAndRotation()
}

function nT(e) {
    e.removeLeadSnapshot()
}

function xp(e, t, n) {
    e.translate = xe(t.translate, 0, n), e.scale = xe(t.scale, 1, n), e.origin = t.origin, e.originPoint = t.originPoint
}

function wp(e, t, n, r) {
    e.min = xe(t.min, n.min, r), e.max = xe(t.max, n.max, r)
}

function rT(e, t, n, r) {
    wp(e.x, t.x, n.x, r), wp(e.y, t.y, n.y, r)
}

function iT(e) {
    return e.animationValues && e.animationValues.opacityExit !== void 0
}
const oT = {
        duration: .45,
        ease: [.4, 0, .1, 1]
    },
    Sp = e => typeof navigator < "u" && navigator.userAgent && navigator.userAgent.toLowerCase().includes(e),
    Tp = Sp("applewebkit/") && !Sp("chrome/") ? Math.round : Ke;

function Pp(e) {
    e.min = Tp(e.min), e.max = Tp(e.max)
}

function sT(e) {
    Pp(e.x), Pp(e.y)
}

function Ev(e, t, n) {
    return e === "position" || e === "preserve-aspect" && !a4(pp(t), pp(n), .2)
}

function aT(e) {
    var t;
    return e !== e.root && ((t = e.scroll) === null || t === void 0 ? void 0 : t.wasRoot)
}
const lT = Pv({
        attachResizeListener: (e, t) => on(e, "resize", t),
        measureScroll: () => ({
            x: document.documentElement.scrollLeft || document.body.scrollLeft,
            y: document.documentElement.scrollTop || document.body.scrollTop
        }),
        checkIsScrollRoot: () => !0
    }),
    Ll = {
        current: void 0
    },
    Cv = Pv({
        measureScroll: e => ({
            x: e.scrollLeft,
            y: e.scrollTop
        }),
        defaultParent: () => {
            if (!Ll.current) {
                const e = new lT({});
                e.mount(window), e.setOptions({
                    layoutScroll: !0
                }), Ll.current = e
            }
            return Ll.current
        },
        resetTransform: (e, t) => {
            e.style.transform = t !== void 0 ? t : "none"
        },
        checkIsScrollRoot: e => window.getComputedStyle(e).position === "fixed"
    }),
    uT = {
        pan: {
            Feature: P4
        },
        drag: {
            Feature: T4,
            ProjectionNode: Cv,
            MeasureLayout: vv
        }
    };

function Ep(e, t) {
    const n = t ? "pointerenter" : "pointerleave",
        r = t ? "onHoverStart" : "onHoverEnd",
        i = (o, s) => {
            if (o.pointerType === "touch" || av()) return;
            const a = e.getProps();
            e.animationState && a.whileHover && e.animationState.setActive("whileHover", t);
            const l = a[r];
            l && oe.postRender(() => l(o, s))
        };
    return dn(e.current, n, i, {
        passive: !e.getProps()[r]
    })
}
class cT extends Zn {
    mount() {
        this.unmount = cn(Ep(this.node, !0), Ep(this.node, !1))
    }
    unmount() {}
}
class dT extends Zn {
    constructor() {
        super(...arguments), this.isActive = !1
    }
    onFocus() {
        let t = !1;
        try {
            t = this.node.current.matches(":focus-visible")
        } catch {
            t = !0
        }!t || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !0), this.isActive = !0)
    }
    onBlur() {
        !this.isActive || !this.node.animationState || (this.node.animationState.setActive("whileFocus", !1), this.isActive = !1)
    }
    mount() {
        this.unmount = cn(on(this.node.current, "focus", () => this.onFocus()), on(this.node.current, "blur", () => this.onBlur()))
    }
    unmount() {}
}
const kv = (e, t) => t ? e === t ? !0 : kv(e, t.parentElement) : !1;

function Ml(e, t) {
    if (!t) return;
    const n = new PointerEvent("pointer" + e);
    t(n, Ia(n))
}
class fT extends Zn {
    constructor() {
        super(...arguments), this.removeStartListeners = Ke, this.removeEndListeners = Ke, this.removeAccessibleListeners = Ke, this.startPointerPress = (t, n) => {
            if (this.isPressing) return;
            this.removeEndListeners();
            const r = this.node.getProps(),
                o = dn(window, "pointerup", (a, l) => {
                    if (!this.checkPressEnd()) return;
                    const {
                        onTap: u,
                        onTapCancel: c,
                        globalTapTarget: d
                    } = this.node.getProps(), f = !d && !kv(this.node.current, a.target) ? c : u;
                    f && oe.update(() => f(a, l))
                }, {
                    passive: !(r.onTap || r.onPointerUp)
                }),
                s = dn(window, "pointercancel", (a, l) => this.cancelPress(a, l), {
                    passive: !(r.onTapCancel || r.onPointerCancel)
                });
            this.removeEndListeners = cn(o, s), this.startPress(t, n)
        }, this.startAccessiblePress = () => {
            const t = o => {
                    if (o.key !== "Enter" || this.isPressing) return;
                    const s = a => {
                        a.key !== "Enter" || !this.checkPressEnd() || Ml("up", (l, u) => {
                            const {
                                onTap: c
                            } = this.node.getProps();
                            c && oe.postRender(() => c(l, u))
                        })
                    };
                    this.removeEndListeners(), this.removeEndListeners = on(this.node.current, "keyup", s), Ml("down", (a, l) => {
                        this.startPress(a, l)
                    })
                },
                n = on(this.node.current, "keydown", t),
                r = () => {
                    this.isPressing && Ml("cancel", (o, s) => this.cancelPress(o, s))
                },
                i = on(this.node.current, "blur", r);
            this.removeAccessibleListeners = cn(n, i)
        }
    }
    startPress(t, n) {
        this.isPressing = !0;
        const {
            onTapStart: r,
            whileTap: i
        } = this.node.getProps();
        i && this.node.animationState && this.node.animationState.setActive("whileTap", !0), r && oe.postRender(() => r(t, n))
    }
    checkPressEnd() {
        return this.removeEndListeners(), this.isPressing = !1, this.node.getProps().whileTap && this.node.animationState && this.node.animationState.setActive("whileTap", !1), !av()
    }
    cancelPress(t, n) {
        if (!this.checkPressEnd()) return;
        const {
            onTapCancel: r
        } = this.node.getProps();
        r && oe.postRender(() => r(t, n))
    }
    mount() {
        const t = this.node.getProps(),
            n = dn(t.globalTapTarget ? window : this.node.current, "pointerdown", this.startPointerPress, {
                passive: !(t.onTapStart || t.onPointerStart)
            }),
            r = on(this.node.current, "focus", this.startAccessiblePress);
        this.removeStartListeners = cn(n, r)
    }
    unmount() {
        this.removeStartListeners(), this.removeEndListeners(), this.removeAccessibleListeners()
    }
}
const Wu = new WeakMap,
    Nl = new WeakMap,
    hT = e => {
        const t = Wu.get(e.target);
        t && t(e)
    },
    pT = e => {
        e.forEach(hT)
    };

function mT({
    root: e,
    ...t
}) {
    const n = e || document;
    Nl.has(n) || Nl.set(n, {});
    const r = Nl.get(n),
        i = JSON.stringify(t);
    return r[i] || (r[i] = new IntersectionObserver(pT, {
        root: e,
        ...t
    })), r[i]
}

function gT(e, t, n) {
    const r = mT(t);
    return Wu.set(e, n), r.observe(e), () => {
        Wu.delete(e), r.unobserve(e)
    }
}
const vT = {
    some: 0,
    all: 1
};
class yT extends Zn {
    constructor() {
        super(...arguments), this.hasEnteredView = !1, this.isInView = !1
    }
    startObserver() {
        this.unmount();
        const {
            viewport: t = {}
        } = this.node.getProps(), {
            root: n,
            margin: r,
            amount: i = "some",
            once: o
        } = t, s = {
            root: n ? n.current : void 0,
            rootMargin: r,
            threshold: typeof i == "number" ? i : vT[i]
        }, a = l => {
            const {
                isIntersecting: u
            } = l;
            if (this.isInView === u || (this.isInView = u, o && !u && this.hasEnteredView)) return;
            u && (this.hasEnteredView = !0), this.node.animationState && this.node.animationState.setActive("whileInView", u);
            const {
                onViewportEnter: c,
                onViewportLeave: d
            } = this.node.getProps(), f = u ? c : d;
            f && f(l)
        };
        return gT(this.node.current, s, a)
    }
    mount() {
        this.startObserver()
    }
    update() {
        if (typeof IntersectionObserver > "u") return;
        const {
            props: t,
            prevProps: n
        } = this.node;
        ["amount", "margin", "root"].some(xT(t, n)) && this.startObserver()
    }
    unmount() {}
}

function xT({
    viewport: e = {}
}, {
    viewport: t = {}
} = {}) {
    return n => e[n] !== t[n]
}
const wT = {
        inView: {
            Feature: yT
        },
        tap: {
            Feature: fT
        },
        focus: {
            Feature: dT
        },
        hover: {
            Feature: cT
        }
    },
    ST = {
        layout: {
            ProjectionNode: Cv,
            MeasureLayout: vv
        }
    },
    Rv = C.createContext({
        transformPagePoint: e => e,
        isStatic: !1,
        reducedMotion: "never"
    }),
    za = C.createContext({}),
    Td = typeof window < "u",
    TT = Td ? C.useLayoutEffect : C.useEffect,
    jv = C.createContext({
        strict: !1
    });

function PT(e, t, n, r, i) {
    var o, s;
    const {
        visualElement: a
    } = C.useContext(za), l = C.useContext(jv), u = C.useContext(wd), c = C.useContext(Rv).reducedMotion, d = C.useRef();
    r = r || l.renderer, !d.current && r && (d.current = r(e, {
        visualState: t,
        parent: a,
        props: n,
        presenceContext: u,
        blockInitialAnimation: u ? u.initial === !1 : !1,
        reducedMotionConfig: c
    }));
    const f = d.current,
        m = C.useContext(gv);
    f && !f.projection && i && (f.type === "html" || f.type === "svg") && ET(d.current, n, i, m), C.useInsertionEffect(() => {
        f && f.update(n, u)
    });
    const x = n[Z0],
        w = C.useRef(!!x && !(!((o = window.MotionHandoffIsComplete) === null || o === void 0) && o.call(window, x)) && ((s = window.MotionHasOptimisedAnimation) === null || s === void 0 ? void 0 : s.call(window, x)));
    return TT(() => {
        f && (window.MotionIsMounted = !0, f.updateFeatures(), Sd.render(f.render), w.current && f.animationState && f.animationState.animateChanges())
    }), C.useEffect(() => {
        f && (!w.current && f.animationState && f.animationState.animateChanges(), w.current && (queueMicrotask(() => {
            var E;
            (E = window.MotionHandoffMarkAsComplete) === null || E === void 0 || E.call(window, x)
        }), w.current = !1))
    }), f
}

function ET(e, t, n, r) {
    const {
        layoutId: i,
        layout: o,
        drag: s,
        dragConstraints: a,
        layoutScroll: l,
        layoutRoot: u
    } = t;
    e.projection = new n(e.latestValues, t["data-framer-portal-id"] ? void 0 : Av(e.parent)), e.projection.setOptions({
        layoutId: i,
        layout: o,
        alwaysMeasureLayout: !!s || a && $r(a),
        visualElement: e,
        animationType: typeof o == "string" ? o : "both",
        initialPromotionConfig: r,
        layoutScroll: l,
        layoutRoot: u
    })
}

function Av(e) {
    if (e) return e.options.allowProjection !== !1 ? e.projection : Av(e.parent)
}

function CT(e, t, n) {
    return C.useCallback(r => {
        r && e.mount && e.mount(r), t && (r ? t.mount(r) : t.unmount()), n && (typeof n == "function" ? n(r) : $r(n) && (n.current = r))
    }, [t])
}

function ba(e) {
    return So(e.animate) || td.some(t => To(e[t]))
}

function Lv(e) {
    return !!(ba(e) || e.variants)
}

function kT(e, t) {
    if (ba(e)) {
        const {
            initial: n,
            animate: r
        } = e;
        return {
            initial: n === !1 || To(n) ? n : void 0,
            animate: To(r) ? r : void 0
        }
    }
    return e.inherit !== !1 ? t : {}
}

function RT(e) {
    const {
        initial: t,
        animate: n
    } = kT(e, C.useContext(za));
    return C.useMemo(() => ({
        initial: t,
        animate: n
    }), [Cp(t), Cp(n)])
}

function Cp(e) {
    return Array.isArray(e) ? e.join(" ") : e
}
const kp = {
        animation: ["animate", "variants", "whileHover", "whileTap", "exit", "whileInView", "whileFocus", "whileDrag"],
        exit: ["exit"],
        drag: ["drag", "dragControls"],
        focus: ["whileFocus"],
        hover: ["whileHover", "onHoverStart", "onHoverEnd"],
        tap: ["whileTap", "onTap", "onTapStart", "onTapCancel"],
        pan: ["onPan", "onPanStart", "onPanSessionStart", "onPanEnd"],
        inView: ["whileInView", "onViewportEnter", "onViewportLeave"],
        layout: ["layout", "layoutId"]
    },
    hi = {};
for (const e in kp) hi[e] = {
    isEnabled: t => kp[e].some(n => !!t[n])
};

function jT(e) {
    for (const t in e) hi[t] = { ...hi[t],
        ...e[t]
    }
}
const AT = Symbol.for("motionComponentSymbol");

function LT({
    preloadedFeatures: e,
    createVisualElement: t,
    useRender: n,
    useVisualState: r,
    Component: i
}) {
    e && jT(e);

    function o(a, l) {
        let u;
        const c = { ...C.useContext(Rv),
                ...a,
                layoutId: MT(a)
            },
            {
                isStatic: d
            } = c,
            f = RT(a),
            m = r(a, d);
        if (!d && Td) {
            NT();
            const x = DT(c);
            u = x.MeasureLayout, f.visualElement = PT(i, m, c, t, x.ProjectionNode)
        }
        return v.jsxs(za.Provider, {
            value: f,
            children: [u && f.visualElement ? v.jsx(u, {
                visualElement: f.visualElement,
                ...c
            }) : null, n(i, a, CT(m, f.visualElement, l), m, d, f.visualElement)]
        })
    }
    const s = C.forwardRef(o);
    return s[AT] = i, s
}

function MT({
    layoutId: e
}) {
    const t = C.useContext(mv).id;
    return t && e !== void 0 ? t + "-" + e : e
}

function NT(e, t) {
    C.useContext(jv).strict
}

function DT(e) {
    const {
        drag: t,
        layout: n
    } = hi;
    if (!t && !n) return {};
    const r = { ...t,
        ...n
    };
    return {
        MeasureLayout: t != null && t.isEnabled(e) || n != null && n.isEnabled(e) ? r.MeasureLayout : void 0,
        ProjectionNode: r.ProjectionNode
    }
}
const _T = ["animate", "circle", "defs", "desc", "ellipse", "g", "image", "line", "filter", "marker", "mask", "metadata", "path", "pattern", "polygon", "polyline", "rect", "stop", "switch", "symbol", "svg", "text", "tspan", "use", "view"];

function Pd(e) {
    return typeof e != "string" || e.includes("-") ? !1 : !!(_T.indexOf(e) > -1 || /[A-Z]/u.test(e))
}

function Mv(e, {
    style: t,
    vars: n
}, r, i) {
    Object.assign(e.style, t, i && i.getProjectionStyles(r));
    for (const o in n) e.style.setProperty(o, n[o])
}
const Nv = new Set(["baseFrequency", "diffuseConstant", "kernelMatrix", "kernelUnitLength", "keySplines", "keyTimes", "limitingConeAngle", "markerHeight", "markerWidth", "numOctaves", "targetX", "targetY", "surfaceScale", "specularConstant", "specularExponent", "stdDeviation", "tableValues", "viewBox", "gradientTransform", "pathLength", "startOffset", "textLength", "lengthAdjust"]);

function Dv(e, t, n, r) {
    Mv(e, t, void 0, r);
    for (const i in t.attrs) e.setAttribute(Nv.has(i) ? i : Fa(i), t.attrs[i])
}

function _v(e, {
    layout: t,
    layoutId: n
}) {
    return Xn.has(e) || e.startsWith("origin") || (t || n !== void 0) && (!!pa[e] || e === "opacity")
}

function Ed(e, t, n) {
    var r;
    const {
        style: i
    } = e, o = {};
    for (const s in i)(We(i[s]) || t.style && We(t.style[s]) || _v(s, e) || ((r = n == null ? void 0 : n.getValue(s)) === null || r === void 0 ? void 0 : r.liveStyle) !== void 0) && (o[s] = i[s]);
    return n && i && typeof i.willChange == "string" && (n.applyWillChange = !1), o
}

function Ov(e, t, n) {
    const r = Ed(e, t, n);
    for (const i in e)
        if (We(e[i]) || We(t[i])) {
            const o = _o.indexOf(i) !== -1 ? "attr" + i.charAt(0).toUpperCase() + i.substring(1) : i;
            r[o] = e[i]
        }
    return r
}

function OT(e) {
    const t = C.useRef(null);
    return t.current === null && (t.current = e()), t.current
}

function VT({
    applyWillChange: e = !1,
    scrapeMotionValuesFromProps: t,
    createRenderState: n,
    onMount: r
}, i, o, s, a) {
    const l = {
        latestValues: FT(i, o, s, a ? !1 : e, t),
        renderState: n()
    };
    return r && (l.mount = u => r(i, u, l)), l
}
const Vv = e => (t, n) => {
    const r = C.useContext(za),
        i = C.useContext(wd),
        o = () => VT(e, t, r, i, n);
    return n ? o() : OT(o)
};

function Rp(e, t, n) {
    const r = Array.isArray(t) ? t : [t];
    for (let i = 0; i < r.length; i++) {
        const o = qc(e, r[i]);
        if (o) {
            const {
                transitionEnd: s,
                transition: a,
                ...l
            } = o;
            n(l, s)
        }
    }
}

function FT(e, t, n, r, i) {
    var o;
    const s = {};
    let a = r && ((o = e.style) === null || o === void 0 ? void 0 : o.willChange) === void 0;
    const l = i(e, {});
    for (const w in l) s[w] = Ls(l[w]);
    let {
        initial: u,
        animate: c
    } = e;
    const d = ba(e),
        f = Lv(e);
    t && f && !d && e.inherit !== !1 && (u === void 0 && (u = t.initial), c === void 0 && (c = t.animate));
    let m = n ? n.initial === !1 : !1;
    m = m || u === !1;
    const x = m ? c : u;
    return x && typeof x != "boolean" && !So(x) && Rp(e, x, (w, E) => {
        for (const p in w) {
            let h = w[p];
            if (Array.isArray(h)) {
                const g = m ? h.length - 1 : 0;
                h = h[g]
            }
            h !== null && (s[p] = h)
        }
        for (const p in E) s[p] = E[p]
    }), a && c && u !== !1 && !So(c) && Rp(e, c, w => {
        for (const E in w)
            if (q0(E)) {
                s.willChange = "transform";
                return
            }
    }), s
}
const Cd = () => ({
        style: {},
        transform: {},
        transformOrigin: {},
        vars: {}
    }),
    Fv = () => ({ ...Cd(),
        attrs: {}
    }),
    Iv = (e, t) => t && typeof e == "number" ? t.transform(e) : e,
    IT = {
        x: "translateX",
        y: "translateY",
        z: "translateZ",
        transformPerspective: "perspective"
    },
    zT = _o.length;

function bT(e, t, n) {
    let r = "",
        i = !0;
    for (let o = 0; o < zT; o++) {
        const s = _o[o],
            a = e[s];
        if (a === void 0) continue;
        let l = !0;
        if (typeof a == "number" ? l = a === (s.startsWith("scale") ? 1 : 0) : l = parseFloat(a) === 0, !l || n) {
            const u = Iv(a, ud[s]);
            if (!l) {
                i = !1;
                const c = IT[s] || s;
                r += `${c}(${u}) `
            }
            n && (t[s] = u)
        }
    }
    return r = r.trim(), n ? r = n(t, i ? "" : r) : i && (r = "none"), r
}

function kd(e, t, n) {
    const {
        style: r,
        vars: i,
        transformOrigin: o
    } = e;
    let s = !1,
        a = !1;
    for (const l in t) {
        const u = t[l];
        if (Xn.has(l)) {
            s = !0;
            continue
        } else if (R0(l)) {
            i[l] = u;
            continue
        } else {
            const c = Iv(u, ud[l]);
            l.startsWith("origin") ? (a = !0, o[l] = c) : r[l] = c
        }
    }
    if (t.transform || (s || n ? r.transform = bT(t, e.transform, n) : r.transform && (r.transform = "none")), a) {
        const {
            originX: l = "50%",
            originY: u = "50%",
            originZ: c = 0
        } = o;
        r.transformOrigin = `${l} ${u} ${c}`
    }
}

function jp(e, t, n) {
    return typeof e == "string" ? e : $.transform(t + n * e)
}

function BT(e, t, n) {
    const r = jp(t, e.x, e.width),
        i = jp(n, e.y, e.height);
    return `${r} ${i}`
}
const UT = {
        offset: "stroke-dashoffset",
        array: "stroke-dasharray"
    },
    HT = {
        offset: "strokeDashoffset",
        array: "strokeDasharray"
    };

function $T(e, t, n = 1, r = 0, i = !0) {
    e.pathLength = 1;
    const o = i ? UT : HT;
    e[o.offset] = $.transform(-r);
    const s = $.transform(t),
        a = $.transform(n);
    e[o.array] = `${s} ${a}`
}

function Rd(e, {
    attrX: t,
    attrY: n,
    attrScale: r,
    originX: i,
    originY: o,
    pathLength: s,
    pathSpacing: a = 1,
    pathOffset: l = 0,
    ...u
}, c, d) {
    if (kd(e, u, d), c) {
        e.style.viewBox && (e.attrs.viewBox = e.style.viewBox);
        return
    }
    e.attrs = e.style, e.style = {};
    const {
        attrs: f,
        style: m,
        dimensions: x
    } = e;
    f.transform && (x && (m.transform = f.transform), delete f.transform), x && (i !== void 0 || o !== void 0 || m.transform) && (m.transformOrigin = BT(x, i !== void 0 ? i : .5, o !== void 0 ? o : .5)), t !== void 0 && (f.x = t), n !== void 0 && (f.y = n), r !== void 0 && (f.scale = r), s !== void 0 && $T(f, s, a, l, !1)
}
const jd = e => typeof e == "string" && e.toLowerCase() === "svg",
    WT = {
        useVisualState: Vv({
            scrapeMotionValuesFromProps: Ov,
            createRenderState: Fv,
            onMount: (e, t, {
                renderState: n,
                latestValues: r
            }) => {
                oe.read(() => {
                    try {
                        n.dimensions = typeof t.getBBox == "function" ? t.getBBox() : t.getBoundingClientRect()
                    } catch {
                        n.dimensions = {
                            x: 0,
                            y: 0,
                            width: 0,
                            height: 0
                        }
                    }
                }), oe.render(() => {
                    Rd(n, r, jd(t.tagName), e.transformTemplate), Dv(t, n)
                })
            }
        })
    },
    KT = {
        useVisualState: Vv({
            applyWillChange: !0,
            scrapeMotionValuesFromProps: Ed,
            createRenderState: Cd
        })
    };

function zv(e, t, n) {
    for (const r in t) !We(t[r]) && !_v(r, n) && (e[r] = t[r])
}

function GT({
    transformTemplate: e
}, t) {
    return C.useMemo(() => {
        const n = Cd();
        return kd(n, t, e), Object.assign({}, n.vars, n.style)
    }, [t])
}

function YT(e, t) {
    const n = e.style || {},
        r = {};
    return zv(r, n, e), Object.assign(r, GT(e, t)), r
}

function QT(e, t) {
    const n = {},
        r = YT(e, t);
    return e.drag && e.dragListener !== !1 && (n.draggable = !1, r.userSelect = r.WebkitUserSelect = r.WebkitTouchCallout = "none", r.touchAction = e.drag === !0 ? "none" : `pan-${e.drag==="x"?"y":"x"}`), e.tabIndex === void 0 && (e.onTap || e.onTapStart || e.whileTap) && (n.tabIndex = 0), n.style = r, n
}
const XT = new Set(["animate", "exit", "variants", "initial", "style", "values", "variants", "transition", "transformTemplate", "custom", "inherit", "onBeforeLayoutMeasure", "onAnimationStart", "onAnimationComplete", "onUpdate", "onDragStart", "onDrag", "onDragEnd", "onMeasureDragConstraints", "onDirectionLock", "onDragTransitionEnd", "_dragX", "_dragY", "onHoverStart", "onHoverEnd", "onViewportEnter", "onViewportLeave", "globalTapTarget", "ignoreStrict", "viewport"]);

function ma(e) {
    return e.startsWith("while") || e.startsWith("drag") && e !== "draggable" || e.startsWith("layout") || e.startsWith("onTap") || e.startsWith("onPan") || e.startsWith("onLayout") || XT.has(e)
}
let bv = e => !ma(e);

function ZT(e) {
    e && (bv = t => t.startsWith("on") ? !ma(t) : e(t))
}
try {
    ZT(require("@emotion/is-prop-valid").default)
} catch {}

function JT(e, t, n) {
    const r = {};
    for (const i in e) i === "values" && typeof e.values == "object" || (bv(i) || n === !0 && ma(i) || !t && !ma(i) || e.draggable && i.startsWith("onDrag")) && (r[i] = e[i]);
    return r
}

function qT(e, t, n, r) {
    const i = C.useMemo(() => {
        const o = Fv();
        return Rd(o, t, jd(r), e.transformTemplate), { ...o.attrs,
            style: { ...o.style
            }
        }
    }, [t]);
    if (e.style) {
        const o = {};
        zv(o, e.style, e), i.style = { ...o,
            ...i.style
        }
    }
    return i
}

function eP(e = !1) {
    return (n, r, i, {
        latestValues: o
    }, s) => {
        const l = (Pd(n) ? qT : QT)(r, o, s, n),
            u = JT(r, typeof n == "string", e),
            c = n !== C.Fragment ? { ...u,
                ...l,
                ref: i
            } : {},
            {
                children: d
            } = r,
            f = C.useMemo(() => We(d) ? d.get() : d, [d]);
        return C.createElement(n, { ...c,
            children: f
        })
    }
}

function tP(e, t) {
    return function(r, {
        forwardMotionProps: i
    } = {
        forwardMotionProps: !1
    }) {
        const s = { ...Pd(r) ? WT : KT,
            preloadedFeatures: e,
            useRender: eP(i),
            createVisualElement: t,
            Component: r
        };
        return LT(s)
    }
}
const Ku = {
        current: null
    },
    Bv = {
        current: !1
    };

function nP() {
    if (Bv.current = !0, !!Td)
        if (window.matchMedia) {
            const e = window.matchMedia("(prefers-reduced-motion)"),
                t = () => Ku.current = e.matches;
            e.addListener(t), t()
        } else Ku.current = !1
}

function rP(e, t, n) {
    for (const r in t) {
        const i = t[r],
            o = n[r];
        if (We(i)) e.addValue(r, i);
        else if (We(o)) e.addValue(r, Co(i, {
            owner: e
        }));
        else if (o !== i)
            if (e.hasValue(r)) {
                const s = e.getValue(r);
                s.liveStyle === !0 ? s.jump(i) : s.hasAnimated || s.set(i)
            } else {
                const s = e.getStaticValue(r);
                e.addValue(r, Co(s !== void 0 ? s : i, {
                    owner: e
                }))
            }
    }
    for (const r in n) t[r] === void 0 && e.removeValue(r);
    return t
}
const Ap = new WeakMap,
    iP = [...L0, He, Hn],
    oP = e => iP.find(A0(e)),
    Lp = ["AnimationStart", "AnimationComplete", "Update", "BeforeLayoutMeasure", "LayoutMeasure", "LayoutAnimationStart", "LayoutAnimationComplete"];
class sP {
    scrapeMotionValuesFromProps(t, n, r) {
        return {}
    }
    constructor({
        parent: t,
        props: n,
        presenceContext: r,
        reducedMotionConfig: i,
        blockInitialAnimation: o,
        visualState: s
    }, a = {}) {
        this.applyWillChange = !1, this.current = null, this.children = new Set, this.isVariantNode = !1, this.isControllingVariants = !1, this.shouldReduceMotion = null, this.values = new Map, this.KeyframeResolver = sd, this.features = {}, this.valueSubscriptions = new Map, this.prevMotionValues = {}, this.events = {}, this.propEventSubscriptions = {}, this.notifyUpdate = () => this.notify("Update", this.latestValues), this.render = () => {
            this.current && (this.triggerBuild(), this.renderInstance(this.current, this.renderState, this.props.style, this.projection))
        }, this.renderScheduledAt = 0, this.scheduleRender = () => {
            const f = Kt.now();
            this.renderScheduledAt < f && (this.renderScheduledAt = f, oe.render(this.render, !1, !0))
        };
        const {
            latestValues: l,
            renderState: u
        } = s;
        this.latestValues = l, this.baseTarget = { ...l
        }, this.initialValues = n.initial ? { ...l
        } : {}, this.renderState = u, this.parent = t, this.props = n, this.presenceContext = r, this.depth = t ? t.depth + 1 : 0, this.reducedMotionConfig = i, this.options = a, this.blockInitialAnimation = !!o, this.isControllingVariants = ba(n), this.isVariantNode = Lv(n), this.isVariantNode && (this.variantChildren = new Set), this.manuallyAnimateOnMount = !!(t && t.current);
        const {
            willChange: c,
            ...d
        } = this.scrapeMotionValuesFromProps(n, {}, this);
        for (const f in d) {
            const m = d[f];
            l[f] !== void 0 && We(m) && m.set(l[f], !1)
        }
    }
    mount(t) {
        this.current = t, Ap.set(t, this), this.projection && !this.projection.instance && this.projection.mount(t), this.parent && this.isVariantNode && !this.isControllingVariants && (this.removeFromVariantTree = this.parent.addVariantChild(this)), this.values.forEach((n, r) => this.bindToMotionValue(r, n)), Bv.current || nP(), this.shouldReduceMotion = this.reducedMotionConfig === "never" ? !1 : this.reducedMotionConfig === "always" ? !0 : Ku.current, this.parent && this.parent.children.add(this), this.update(this.props, this.presenceContext)
    }
    unmount() {
        Ap.delete(this.current), this.projection && this.projection.unmount(), Bn(this.notifyUpdate), Bn(this.render), this.valueSubscriptions.forEach(t => t()), this.valueSubscriptions.clear(), this.removeFromVariantTree && this.removeFromVariantTree(), this.parent && this.parent.children.delete(this);
        for (const t in this.events) this.events[t].clear();
        for (const t in this.features) {
            const n = this.features[t];
            n && (n.unmount(), n.isMounted = !1)
        }
        this.current = null
    }
    bindToMotionValue(t, n) {
        this.valueSubscriptions.has(t) && this.valueSubscriptions.get(t)();
        const r = Xn.has(t),
            i = n.on("change", a => {
                this.latestValues[t] = a, this.props.onUpdate && oe.preRender(this.notifyUpdate), r && this.projection && (this.projection.isTransformDirty = !0)
            }),
            o = n.on("renderRequest", this.scheduleRender);
        let s;
        window.MotionCheckAppearSync && (s = window.MotionCheckAppearSync(this, t, n)), this.valueSubscriptions.set(t, () => {
            i(), o(), s && s(), n.owner && n.stop()
        })
    }
    sortNodePosition(t) {
        return !this.current || !this.sortInstanceNodePosition || this.type !== t.type ? 0 : this.sortInstanceNodePosition(this.current, t.current)
    }
    updateFeatures() {
        let t = "animation";
        for (t in hi) {
            const n = hi[t];
            if (!n) continue;
            const {
                isEnabled: r,
                Feature: i
            } = n;
            if (!this.features[t] && i && r(this.props) && (this.features[t] = new i(this)), this.features[t]) {
                const o = this.features[t];
                o.isMounted ? o.update() : (o.mount(), o.isMounted = !0)
            }
        }
    }
    triggerBuild() {
        this.build(this.renderState, this.latestValues, this.props)
    }
    measureViewportBox() {
        return this.current ? this.measureInstanceViewportBox(this.current, this.props) : ke()
    }
    getStaticValue(t) {
        return this.latestValues[t]
    }
    setStaticValue(t, n) {
        this.latestValues[t] = n
    }
    update(t, n) {
        (t.transformTemplate || this.props.transformTemplate) && this.scheduleRender(), this.prevProps = this.props, this.props = t, this.prevPresenceContext = this.presenceContext, this.presenceContext = n;
        for (let r = 0; r < Lp.length; r++) {
            const i = Lp[r];
            this.propEventSubscriptions[i] && (this.propEventSubscriptions[i](), delete this.propEventSubscriptions[i]);
            const o = "on" + i,
                s = t[o];
            s && (this.propEventSubscriptions[i] = this.on(i, s))
        }
        this.prevMotionValues = rP(this, this.scrapeMotionValuesFromProps(t, this.prevProps, this), this.prevMotionValues), this.handleChildMotionValue && this.handleChildMotionValue()
    }
    getProps() {
        return this.props
    }
    getVariant(t) {
        return this.props.variants ? this.props.variants[t] : void 0
    }
    getDefaultTransition() {
        return this.props.transition
    }
    getTransformPagePoint() {
        return this.props.transformPagePoint
    }
    getClosestVariantNode() {
        return this.isVariantNode ? this : this.parent ? this.parent.getClosestVariantNode() : void 0
    }
    addVariantChild(t) {
        const n = this.getClosestVariantNode();
        if (n) return n.variantChildren && n.variantChildren.add(t), () => n.variantChildren.delete(t)
    }
    addValue(t, n) {
        const r = this.values.get(t);
        n !== r && (r && this.removeValue(t), this.bindToMotionValue(t, n), this.values.set(t, n), this.latestValues[t] = n.get())
    }
    removeValue(t) {
        this.values.delete(t);
        const n = this.valueSubscriptions.get(t);
        n && (n(), this.valueSubscriptions.delete(t)), delete this.latestValues[t], this.removeValueFromRenderState(t, this.renderState)
    }
    hasValue(t) {
        return this.values.has(t)
    }
    getValue(t, n) {
        if (this.props.values && this.props.values[t]) return this.props.values[t];
        let r = this.values.get(t);
        return r === void 0 && n !== void 0 && (r = Co(n === null ? void 0 : n, {
            owner: this
        }), this.addValue(t, r)), r
    }
    readValue(t, n) {
        var r;
        let i = this.latestValues[t] !== void 0 || !this.current ? this.latestValues[t] : (r = this.getBaseTargetFromProps(this.props, t)) !== null && r !== void 0 ? r : this.readValueFromInstance(this.current, t, this.options);
        return i != null && (typeof i == "string" && (C0(i) || E0(i)) ? i = parseFloat(i) : !oP(i) && Hn.test(n) && (i = I0(t, n)), this.setBaseTarget(t, We(i) ? i.get() : i)), We(i) ? i.get() : i
    }
    setBaseTarget(t, n) {
        this.baseTarget[t] = n
    }
    getBaseTarget(t) {
        var n;
        const {
            initial: r
        } = this.props;
        let i;
        if (typeof r == "string" || typeof r == "object") {
            const s = qc(this.props, r, (n = this.presenceContext) === null || n === void 0 ? void 0 : n.custom);
            s && (i = s[t])
        }
        if (r && i !== void 0) return i;
        const o = this.getBaseTargetFromProps(this.props, t);
        return o !== void 0 && !We(o) ? o : this.initialValues[t] !== void 0 && i === void 0 ? void 0 : this.baseTarget[t]
    }
    on(t, n) {
        return this.events[t] || (this.events[t] = new xd), this.events[t].add(n)
    }
    notify(t, ...n) {
        this.events[t] && this.events[t].notify(...n)
    }
}
class Uv extends sP {
    constructor() {
        super(...arguments), this.KeyframeResolver = z0
    }
    sortInstanceNodePosition(t, n) {
        return t.compareDocumentPosition(n) & 2 ? 1 : -1
    }
    getBaseTargetFromProps(t, n) {
        return t.style ? t.style[n] : void 0
    }
    removeValueFromRenderState(t, {
        vars: n,
        style: r
    }) {
        delete n[t], delete r[t]
    }
}

function aP(e) {
    return window.getComputedStyle(e)
}
class lP extends Uv {
    constructor() {
        super(...arguments), this.type = "html", this.applyWillChange = !0, this.renderInstance = Mv
    }
    readValueFromInstance(t, n) {
        if (Xn.has(n)) {
            const r = cd(n);
            return r && r.default || 0
        } else {
            const r = aP(t),
                i = (R0(n) ? r.getPropertyValue(n) : r[n]) || 0;
            return typeof i == "string" ? i.trim() : i
        }
    }
    measureInstanceViewportBox(t, {
        transformPagePoint: n
    }) {
        return hv(t, n)
    }
    build(t, n, r) {
        kd(t, n, r.transformTemplate)
    }
    scrapeMotionValuesFromProps(t, n, r) {
        return Ed(t, n, r)
    }
    handleChildMotionValue() {
        this.childSubscription && (this.childSubscription(), delete this.childSubscription);
        const {
            children: t
        } = this.props;
        We(t) && (this.childSubscription = t.on("change", n => {
            this.current && (this.current.textContent = `${n}`)
        }))
    }
}
class uP extends Uv {
    constructor() {
        super(...arguments), this.type = "svg", this.isSVGTag = !1, this.measureInstanceViewportBox = ke
    }
    getBaseTargetFromProps(t, n) {
        return t[n]
    }
    readValueFromInstance(t, n) {
        if (Xn.has(n)) {
            const r = cd(n);
            return r && r.default || 0
        }
        return n = Nv.has(n) ? n : Fa(n), t.getAttribute(n)
    }
    scrapeMotionValuesFromProps(t, n, r) {
        return Ov(t, n, r)
    }
    build(t, n, r) {
        Rd(t, n, this.isSVGTag, r.transformTemplate)
    }
    renderInstance(t, n, r, i) {
        Dv(t, n, r, i)
    }
    mount(t) {
        this.isSVGTag = jd(t.tagName), super.mount(t)
    }
}
const cP = (e, t) => Pd(e) ? new uP(t) : new lP(t, {
        allowProjection: e !== C.Fragment
    }),
    dP = tP({ ...J3,
        ...wT,
        ...uT,
        ...ST
    }, cP),
    J = $2(dP),
    fP = () => {
        const e = [{
            id: 1,
            href: "https://github.com/NoorNazar123",
            icon: B2
        }, {
            id: 2,
            href: "https://www.linkedin.com/in/noor-nazar-dev/",
            icon: U2
        }];
        return v.jsx("div", {
            className: "flex gap-[1rem] md:gap-[2rem]",
            children: e.map(t => v.jsx(J.div, {
                initial: {
                    opacity: 0,
                    scale: 0,
                    y: 60
                },
                whileInView: {
                    opacity: 1,
                    scale: 1,
                    y: 0
                },
                whileHover: {
                    scale: 1.5
                },
                transition: {
                    duration: .5
                },
                children: v.jsx(H2, {
                    href: t.href,
                    icon: t.icon
                }, t.id)
            }, t.id))
        })
    },
    ei = ({
        children: e,
        delay: t = .5,
        y: n = 0
    }) => v.jsx(J.div, {
        initial: {
            y: 30,
            opacity: 0
        },
        animate: {
            y: n,
            opacity: 1
        },
        transition: {
            delay: t,
            duration: 1,
            type: "spring",
            stiffness: 150
        },
        children: e
    }),
    hP = () => {
        const [e, t] = C.useState(!1), n = () => {
            t(!e), console.log("click", e)
        };
        return v.jsxs("header", {
            className: "bg-white flex justify-between shadow-md px-[20px] py-4 md:px-[100px] items-center sticky top-0 z-[1] ",
            children: [v.jsx(rn, {
                to: "/",
                children: v.jsx(ei, {
                    delay: "0.3",
                    children: v.jsx("h2", {
                        className: "text-[30px] hover:scale-105 duration-300 leading-[27px] font-[600] md:text-[45px] md:leading-[75px] md:font-[900]",
                        children: "Noor eNazar"
                    })
                })
            }), v.jsx(D2, {
                isOpen: e,
                setIsOpen: t
            }), v.jsx(ei, {
                delay: "0.5",
                children: v.jsxs("div", {
                    className: "block opacity-[80%] scale-50 md:scale-100 cursor-pointer",
                    onClick: n,
                    children: [v.jsx("div", {
                        className: `${e?" translate-y-[.50rem] rotate-45 opacity-[50%] ":"block"} w-[45px] h-[4px] rounded-sm bg-black my-2 duration-[.3s]`
                    }), v.jsx("div", {
                        className: `${e?"hidden":"block"} w-[45px] h-[4px] rounded-sm bg-black my-2`
                    }), v.jsx("div", {
                        className: `${e?" translate-y-[-.20rem] rotate-[-45deg] opacity-[50%] ":"block"} w-[45px] h-[4px] rounded-sm bg-black my-2 duration-[.3s]`
                    })]
                })
            }), v.jsx("div", {
                children: v.jsx(ei, {
                    delay: "0.8",
                    children: v.jsx(fP, {})
                })
            })]
        })
    };

function zE(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 384 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M0 32l34.9 395.8L192 480l157.1-52.2L384 32H0zm313.1 80l-4.8 47.3L193 208.6l-.3.1h111.5l-12.8 146.6-98.2 28.7-98.8-29.2-6.4-73.9h48.9l3.2 38.3 52.6 13.3 54.7-15.4 3.7-61.6-166.3-.5v-.1l-.2.1-3.6-46.3L193.1 162l6.5-2.7H76.7L70.9 112h242.2z"
            },
            child: []
        }]
    })(e)
}

function pP(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 320 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M279.14 288l14.22-92.66h-88.91v-60.13c0-25.35 12.42-50.06 52.24-50.06h40.42V6.26S260.43 0 225.36 0c-73.22 0-121.08 44.38-121.08 124.72v70.62H22.89V288h81.39v224h100.17V288z"
            },
            child: []
        }]
    })(e)
}

function bE(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 384 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M0 32l34.9 395.8L191.5 480l157.6-52.2L384 32H0zm308.2 127.9H124.4l4.1 49.4h175.6l-13.6 148.4-97.9 27v.3h-1.1l-98.7-27.3-6-75.8h47.7L138 320l53.5 14.5 53.7-14.5 6-62.2H84.3L71.5 112.2h241.1l-4.4 47.7z"
            },
            child: []
        }]
    })(e)
}

function mP(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M224.1 141c-63.6 0-114.9 51.3-114.9 114.9s51.3 114.9 114.9 114.9S339 319.5 339 255.9 287.7 141 224.1 141zm0 189.6c-41.1 0-74.7-33.5-74.7-74.7s33.5-74.7 74.7-74.7 74.7 33.5 74.7 74.7-33.6 74.7-74.7 74.7zm146.4-194.3c0 14.9-12 26.8-26.8 26.8-14.9 0-26.8-12-26.8-26.8s12-26.8 26.8-26.8 26.8 12 26.8 26.8zm76.1 27.2c-1.7-35.9-9.9-67.7-36.2-93.9-26.2-26.2-58-34.4-93.9-36.2-37-2.1-147.9-2.1-184.9 0-35.8 1.7-67.6 9.9-93.9 36.1s-34.4 58-36.2 93.9c-2.1 37-2.1 147.9 0 184.9 1.7 35.9 9.9 67.7 36.2 93.9s58 34.4 93.9 36.2c37 2.1 147.9 2.1 184.9 0 35.9-1.7 67.7-9.9 93.9-36.2 26.2-26.2 34.4-58 36.2-93.9 2.1-37 2.1-147.8 0-184.8zM398.8 388c-7.8 19.6-22.9 34.7-42.6 42.6-29.5 11.7-99.5 9-132.1 9s-102.7 2.6-132.1-9c-19.6-7.8-34.7-22.9-42.6-42.6-11.7-29.5-9-99.5-9-132.1s-2.6-102.7 9-132.1c7.8-19.6 22.9-34.7 42.6-42.6 29.5-11.7 99.5-9 132.1-9s102.7-2.6 132.1 9c19.6 7.8 34.7 22.9 42.6 42.6 11.7 29.5 9 99.5 9 132.1s2.7 102.7-9 132.1z"
            },
            child: []
        }]
    })(e)
}

function BE(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M0 32v448h448V32H0zm243.8 349.4c0 43.6-25.6 63.5-62.9 63.5-33.7 0-53.2-17.4-63.2-38.5l34.3-20.7c6.6 11.7 12.6 21.6 27.1 21.6 13.8 0 22.6-5.4 22.6-26.5V237.7h42.1v143.7zm99.6 63.5c-39.1 0-64.4-18.6-76.7-43l34.3-19.8c9 14.7 20.8 25.6 41.5 25.6 17.4 0 28.6-8.7 28.6-20.8 0-14.4-11.4-19.5-30.7-28l-10.5-4.5c-30.4-12.9-50.5-29.2-50.5-63.5 0-31.6 24.1-55.6 61.6-55.6 26.8 0 46 9.3 59.8 33.7L368 290c-7.2-12.9-15-18-27.1-18-12.3 0-20.1 7.8-20.1 18 0 12.6 7.8 17.7 25.9 25.6l10.5 4.5c35.8 15.3 55.9 31 55.9 66.2 0 37.8-29.8 58.6-69.7 58.6z"
            },
            child: []
        }]
    })(e)
}

function gP(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M100.28 448H7.4V148.9h92.88zM53.79 108.1C24.09 108.1 0 83.5 0 53.8a53.79 53.79 0 0 1 107.58 0c0 29.7-24.1 54.3-53.79 54.3zM447.9 448h-92.68V302.4c0-34.7-.7-79.2-48.29-79.2-48.29 0-55.69 37.7-55.69 76.7V448h-92.78V148.9h89.08v40.8h1.3c12.4-23.5 42.69-48.3 87.88-48.3 94 0 111.28 61.9 111.28 142.3V448z"
            },
            child: []
        }]
    })(e)
}

function UE(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 512 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M418.2 177.2c-5.4-1.8-10.8-3.5-16.2-5.1.9-3.7 1.7-7.4 2.5-11.1 12.3-59.6 4.2-107.5-23.1-123.3-26.3-15.1-69.2.6-112.6 38.4-4.3 3.7-8.5 7.6-12.5 11.5-2.7-2.6-5.5-5.2-8.3-7.7-45.5-40.4-91.1-57.4-118.4-41.5-26.2 15.2-34 60.3-23 116.7 1.1 5.6 2.3 11.1 3.7 16.7-6.4 1.8-12.7 3.8-18.6 5.9C38.3 196.2 0 225.4 0 255.6c0 31.2 40.8 62.5 96.3 81.5 4.5 1.5 9 3 13.6 4.3-1.5 6-2.8 11.9-4 18-10.5 55.5-2.3 99.5 23.9 114.6 27 15.6 72.4-.4 116.6-39.1 3.5-3.1 7-6.3 10.5-9.7 4.4 4.3 9 8.4 13.6 12.4 42.8 36.8 85.1 51.7 111.2 36.6 27-15.6 35.8-62.9 24.4-120.5-.9-4.4-1.9-8.9-3-13.5 3.2-.9 6.3-1.9 9.4-2.9 57.7-19.1 99.5-50 99.5-81.7 0-30.3-39.4-59.7-93.8-78.4zM282.9 92.3c37.2-32.4 71.9-45.1 87.7-36 16.9 9.7 23.4 48.9 12.8 100.4-.7 3.4-1.4 6.7-2.3 10-22.2-5-44.7-8.6-67.3-10.6-13-18.6-27.2-36.4-42.6-53.1 3.9-3.7 7.7-7.2 11.7-10.7zM167.2 307.5c5.1 8.7 10.3 17.4 15.8 25.9-15.6-1.7-31.1-4.2-46.4-7.5 4.4-14.4 9.9-29.3 16.3-44.5 4.6 8.8 9.3 17.5 14.3 26.1zm-30.3-120.3c14.4-3.2 29.7-5.8 45.6-7.8-5.3 8.3-10.5 16.8-15.4 25.4-4.9 8.5-9.7 17.2-14.2 26-6.3-14.9-11.6-29.5-16-43.6zm27.4 68.9c6.6-13.8 13.8-27.3 21.4-40.6s15.8-26.2 24.4-38.9c15-1.1 30.3-1.7 45.9-1.7s31 .6 45.9 1.7c8.5 12.6 16.6 25.5 24.3 38.7s14.9 26.7 21.7 40.4c-6.7 13.8-13.9 27.4-21.6 40.8-7.6 13.3-15.7 26.2-24.2 39-14.9 1.1-30.4 1.6-46.1 1.6s-30.9-.5-45.6-1.4c-8.7-12.7-16.9-25.7-24.6-39s-14.8-26.8-21.5-40.6zm180.6 51.2c5.1-8.8 9.9-17.7 14.6-26.7 6.4 14.5 12 29.2 16.9 44.3-15.5 3.5-31.2 6.2-47 8 5.4-8.4 10.5-17 15.5-25.6zm14.4-76.5c-4.7-8.8-9.5-17.6-14.5-26.2-4.9-8.5-10-16.9-15.3-25.2 16.1 2 31.5 4.7 45.9 8-4.6 14.8-10 29.2-16.1 43.4zM256.2 118.3c10.5 11.4 20.4 23.4 29.6 35.8-19.8-.9-39.7-.9-59.5 0 9.8-12.9 19.9-24.9 29.9-35.8zM140.2 57c16.8-9.8 54.1 4.2 93.4 39 2.5 2.2 5 4.6 7.6 7-15.5 16.7-29.8 34.5-42.9 53.1-22.6 2-45 5.5-67.2 10.4-1.3-5.1-2.4-10.3-3.5-15.5-9.4-48.4-3.2-84.9 12.6-94zm-24.5 263.6c-4.2-1.2-8.3-2.5-12.4-3.9-21.3-6.7-45.5-17.3-63-31.2-10.1-7-16.9-17.8-18.8-29.9 0-18.3 31.6-41.7 77.2-57.6 5.7-2 11.5-3.8 17.3-5.5 6.8 21.7 15 43 24.5 63.6-9.6 20.9-17.9 42.5-24.8 64.5zm116.6 98c-16.5 15.1-35.6 27.1-56.4 35.3-11.1 5.3-23.9 5.8-35.3 1.3-15.9-9.2-22.5-44.5-13.5-92 1.1-5.6 2.3-11.2 3.7-16.7 22.4 4.8 45 8.1 67.9 9.8 13.2 18.7 27.7 36.6 43.2 53.4-3.2 3.1-6.4 6.1-9.6 8.9zm24.5-24.3c-10.2-11-20.4-23.2-30.3-36.3 9.6.4 19.5.6 29.5.6 10.3 0 20.4-.2 30.4-.7-9.2 12.7-19.1 24.8-29.6 36.4zm130.7 30c-.9 12.2-6.9 23.6-16.5 31.3-15.9 9.2-49.8-2.8-86.4-34.2-4.2-3.6-8.4-7.5-12.7-11.5 15.3-16.9 29.4-34.8 42.2-53.6 22.9-1.9 45.7-5.4 68.2-10.5 1 4.1 1.9 8.2 2.7 12.2 4.9 21.6 5.7 44.1 2.5 66.3zm18.2-107.5c-2.8.9-5.6 1.8-8.5 2.6-7-21.8-15.6-43.1-25.5-63.8 9.6-20.4 17.7-41.4 24.5-62.9 5.2 1.5 10.2 3.1 15 4.7 46.6 16 79.3 39.8 79.3 58 0 19.6-34.9 44.9-84.8 61.4zm-149.7-15c25.3 0 45.8-20.5 45.8-45.8s-20.5-45.8-45.8-45.8c-25.3 0-45.8 20.5-45.8 45.8s20.5 45.8 45.8 45.8z"
            },
            child: []
        }]
    })(e)
}

function HE(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M257.5 445.1l-22.2 22.2c-9.4 9.4-24.6 9.4-33.9 0L7 273c-9.4-9.4-9.4-24.6 0-33.9L201.4 44.7c9.4-9.4 24.6-9.4 33.9 0l22.2 22.2c9.5 9.5 9.3 25-.4 34.3L136.6 216H424c13.3 0 24 10.7 24 24v32c0 13.3-10.7 24-24 24H136.6l120.5 114.8c9.8 9.3 10 24.8.4 34.3z"
            },
            child: []
        }]
    })(e)
}

function $E(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 448 512"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M190.5 66.9l22.2-22.2c9.4-9.4 24.6-9.4 33.9 0L441 239c9.4 9.4 9.4 24.6 0 33.9L246.6 467.3c-9.4 9.4-24.6 9.4-33.9 0l-22.2-22.2c-9.5-9.5-9.3-25 .4-34.3L311.4 296H24c-13.3 0-24-10.7-24-24v-32c0-13.3 10.7-24 24-24h287.4L190.9 101.2c-9.8-9.3-10-24.8-.4-34.3z"
            },
            child: []
        }]
    })(e)
}
const Ms = ({
        className: e,
        labelText: t
    }) => v.jsx("h2", {
        className: `${e} leading-[27px] font-[600] md:font-[900] md:leading-[45px] s`,
        children: t
    }),
    vP = () => v.jsxs(J.footer, {
        className: "pt-[90px] bg-gray-50",
        initial: {
            opacity: 0
        },
        whileInView: {
            opacity: 1
        },
        transition: {
            duration: .3,
            ease: "easeInOut"
        },
        children: [v.jsx("div", {
            className: "layout",
            children: v.jsxs("div", {
                className: "container mx-auto py-10 flex flex-col md:flex-row justify-between items-center",
                children: [v.jsx(J.div, {
                    initial: {
                        opacity: 0,
                        scale: 0,
                        y: 60
                    },
                    whileInView: {
                        opacity: 1,
                        scale: 1,
                        y: 0
                    },
                    whileHover: {
                        scale: 1.5
                    },
                    transition: {
                        duration: .5
                    },
                    children: v.jsx(rn, {
                        to: "/",
                        children: v.jsx(Ms, {
                            className: "text-[35px]",
                            labelText: "Noor e Nazar"
                        })
                    })
                }), v.jsx("div", {
                    className: "md:mb-4",
                    children: v.jsxs("ul", {
                        className: "flex space-x-4 my-8 md:my-0",
                        children: [v.jsx("li", {
                            className: "nav-link",
                            children: v.jsx(rn, {
                                to: "/api/v1/noor-e-nazar/about",
                                className: "text-black hover:text-gray-700 duration-300",
                                children: "About"
                            })
                        }), v.jsx("li", {
                            className: "nav-link",
                            children: v.jsx(rn, {
                                to: "/api/v1/noor-e-nazar/project",
                                className: "text-black hover:text-gray-700 duration-300",
                                children: "Projects"
                            })
                        }), v.jsx("li", {
                            className: "nav-link",
                            children: v.jsx(rn, {
                                to: "/api/v1/noor-e-nazar/contact",
                                className: "text-black hover:text-gray-700 duration-300",
                                children: "Contact"
                            })
                        })]
                    })
                }), v.jsx("div", {
                    className: "mb-4 md:mb-0",
                    children: v.jsxs("ul", {
                        className: "flex space-x-10",
                        children: [v.jsx(J.li, {
                            initial: {
                                opacity: 0,
                                scale: 0,
                                y: 60
                            },
                            whileInView: {
                                opacity: 1,
                                scale: 1,
                                y: 0
                            },
                            whileHover: {
                                scale: 1.5
                            },
                            transition: {
                                duration: .5
                            },
                            children: v.jsx("a", {
                                href: "https://www.facebook.com/profile.php?id=61553746727080",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-[24px]",
                                children: v.jsx(pP, {
                                    className: "hover:text-blue-600 duration-300"
                                })
                            })
                        }), v.jsx(J.li, {
                            initial: {
                                opacity: 0,
                                scale: 0,
                                y: 60
                            },
                            whileInView: {
                                opacity: 1,
                                scale: 1,
                                y: 0
                            },
                            whileHover: {
                                scale: 1.5
                            },
                            transition: {
                                duration: .5
                            },
                            children: v.jsx("a", {
                                href: "https://www.instagram.com/uszai_093/",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-[24px]",
                                children: v.jsx(mP, {
                                    className: "hover:text-pink-600 duration-300"
                                })
                            })
                        }), v.jsx(J.li, {
                            initial: {
                                opacity: 0,
                                scale: 0,
                                y: 60
                            },
                            whileInView: {
                                opacity: 1,
                                scale: 1,
                                y: 0
                            },
                            whileHover: {
                                scale: 1.5
                            },
                            transition: {
                                duration: .5
                            },
                            children: v.jsx("a", {
                                href: "https://www.linkedin.com/in/noor-nazar-dev",
                                target: "_blank",
                                rel: "noreferrer",
                                className: "text-[24px]",
                                children: v.jsx(gP, {
                                    className: "hover:text-blue-700 duration-300"
                                })
                            })
                        })]
                    })
                })]
            })
        }), v.jsxs(J.div, {
            className: "text-center my-4 pt-4",
            initial: {
                opacity: 0,
                scale: .5,
                y: -60
            },
            whileInView: {
                opacity: 1,
                scale: 1,
                y: 0
            },
            transition: {
                duration: .5
            },
            children: [v.jsx("p", {
                children: "© 2024 Noor e Nazar. All rights reserved."
            }), v.jsxs("p", {
                children: ["Email:", v.jsx("a", {
                    href: "mailto:noorenazar.prog@gmail.com",
                    className: "text-blue-600 px-1",
                    children: "noorenazar.prog@gmail.com"
                })]
            })]
        })]
    }),
    yP = () => {
        const {
            pathname: e
        } = yi();
        return C.useEffect(() => {
            window.scrollTo(0, 0)
        }, [e]), null
    },
    xP = () => v.jsxs("div", {
        children: [v.jsx(yP, {}), v.jsx(hP, {}), v.jsx(a2, {}), v.jsx(vP, {})]
    }),
    wP = "modulepreload",
    SP = function(e) {
        return "/" + e
    },
    Mp = {},
    Ba = function(t, n, r) {
        let i = Promise.resolve();
        if (n && n.length > 0) {
            document.getElementsByTagName("link");
            const s = document.querySelector("meta[property=csp-nonce]"),
                a = (s == null ? void 0 : s.nonce) || (s == null ? void 0 : s.getAttribute("nonce"));
            i = Promise.allSettled(n.map(l => {
                if (l = SP(l), l in Mp) return;
                Mp[l] = !0;
                const u = l.endsWith(".css"),
                    c = u ? '[rel="stylesheet"]' : "";
                if (document.querySelector(`link[href="${l}"]${c}`)) return;
                const d = document.createElement("link");
                if (d.rel = u ? "stylesheet" : wP, u || (d.as = "script"), d.crossOrigin = "", d.href = l, a && d.setAttribute("nonce", a), document.head.appendChild(d), u) return new Promise((f, m) => {
                    d.addEventListener("load", f), d.addEventListener("error", () => m(new Error(`Unable to preload CSS for ${l}`)))
                })
            }))
        }

        function o(s) {
            const a = new Event("vite:preloadError", {
                cancelable: !0
            });
            if (a.payload = s, window.dispatchEvent(a), !a.defaultPrevented) throw s
        }
        return i.then(s => {
            for (const a of s || []) a.status === "rejected" && o(a.reason);
            return t().catch(o)
        })
    },
    TP = "/assets/v1-CRIR4Y9l.mp4",
    Ot = ({
        className: e,
        label: t,
        onClick: n,
        ...r
    }) => v.jsx("button", {
        className: e,
        onClick: n,
        ...r,
        children: t
    });
var Hv = {
        exports: {}
    },
    PP = "SECRET_DO_NOT_PASS_THIS_OR_YOU_WILL_BE_FIRED",
    EP = PP,
    CP = EP;

function $v() {}

function Wv() {}
Wv.resetWarningCache = $v;
var kP = function() {
    function e(r, i, o, s, a, l) {
        if (l !== CP) {
            var u = new Error("Calling PropTypes validators directly is not supported by the `prop-types` package. Use PropTypes.checkPropTypes() to call them. Read more at http://fb.me/use-check-prop-types");
            throw u.name = "Invariant Violation", u
        }
    }
    e.isRequired = e;

    function t() {
        return e
    }
    var n = {
        array: e,
        bigint: e,
        bool: e,
        func: e,
        number: e,
        object: e,
        string: e,
        symbol: e,
        any: e,
        arrayOf: t,
        element: e,
        elementType: e,
        instanceOf: t,
        node: e,
        objectOf: t,
        oneOf: t,
        oneOfType: t,
        shape: t,
        exact: t,
        checkPropTypes: Wv,
        resetWarningCache: $v
    };
    return n.PropTypes = n, n
};
Hv.exports = kP();
var RP = Hv.exports;
const pe = pi(RP);

function jP(e) {
    return e && typeof e == "object" && "default" in e ? e.default : e
}
var Kv = C,
    AP = jP(Kv);

function Np(e, t, n) {
    return t in e ? Object.defineProperty(e, t, {
        value: n,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = n, e
}

function LP(e, t) {
    e.prototype = Object.create(t.prototype), e.prototype.constructor = e, e.__proto__ = t
}
var MP = !!(typeof window < "u" && window.document && window.document.createElement);

function NP(e, t, n) {
    if (typeof e != "function") throw new Error("Expected reducePropsToState to be a function.");
    if (typeof t != "function") throw new Error("Expected handleStateChangeOnClient to be a function.");
    if (typeof n < "u" && typeof n != "function") throw new Error("Expected mapStateOnServer to either be undefined or a function.");

    function r(i) {
        return i.displayName || i.name || "Component"
    }
    return function(o) {
        if (typeof o != "function") throw new Error("Expected WrappedComponent to be a React component.");
        var s = [],
            a;

        function l() {
            a = e(s.map(function(c) {
                return c.props
            })), u.canUseDOM ? t(a) : n && (a = n(a))
        }
        var u = function(c) {
            LP(d, c);

            function d() {
                return c.apply(this, arguments) || this
            }
            d.peek = function() {
                return a
            }, d.rewind = function() {
                if (d.canUseDOM) throw new Error("You may only call rewind() on the server. Call peek() to read the current state.");
                var x = a;
                return a = void 0, s = [], x
            };
            var f = d.prototype;
            return f.UNSAFE_componentWillMount = function() {
                s.push(this), l()
            }, f.componentDidUpdate = function() {
                l()
            }, f.componentWillUnmount = function() {
                var x = s.indexOf(this);
                s.splice(x, 1), l()
            }, f.render = function() {
                return AP.createElement(o, this.props)
            }, d
        }(Kv.PureComponent);
        return Np(u, "displayName", "SideEffect(" + r(o) + ")"), Np(u, "canUseDOM", MP), u
    }
}
var DP = NP;
const _P = pi(DP);
var OP = typeof Element < "u",
    VP = typeof Map == "function",
    FP = typeof Set == "function",
    IP = typeof ArrayBuffer == "function" && !!ArrayBuffer.isView;

function Ns(e, t) {
    if (e === t) return !0;
    if (e && t && typeof e == "object" && typeof t == "object") {
        if (e.constructor !== t.constructor) return !1;
        var n, r, i;
        if (Array.isArray(e)) {
            if (n = e.length, n != t.length) return !1;
            for (r = n; r-- !== 0;)
                if (!Ns(e[r], t[r])) return !1;
            return !0
        }
        var o;
        if (VP && e instanceof Map && t instanceof Map) {
            if (e.size !== t.size) return !1;
            for (o = e.entries(); !(r = o.next()).done;)
                if (!t.has(r.value[0])) return !1;
            for (o = e.entries(); !(r = o.next()).done;)
                if (!Ns(r.value[1], t.get(r.value[0]))) return !1;
            return !0
        }
        if (FP && e instanceof Set && t instanceof Set) {
            if (e.size !== t.size) return !1;
            for (o = e.entries(); !(r = o.next()).done;)
                if (!t.has(r.value[0])) return !1;
            return !0
        }
        if (IP && ArrayBuffer.isView(e) && ArrayBuffer.isView(t)) {
            if (n = e.length, n != t.length) return !1;
            for (r = n; r-- !== 0;)
                if (e[r] !== t[r]) return !1;
            return !0
        }
        if (e.constructor === RegExp) return e.source === t.source && e.flags === t.flags;
        if (e.valueOf !== Object.prototype.valueOf && typeof e.valueOf == "function" && typeof t.valueOf == "function") return e.valueOf() === t.valueOf();
        if (e.toString !== Object.prototype.toString && typeof e.toString == "function" && typeof t.toString == "function") return e.toString() === t.toString();
        if (i = Object.keys(e), n = i.length, n !== Object.keys(t).length) return !1;
        for (r = n; r-- !== 0;)
            if (!Object.prototype.hasOwnProperty.call(t, i[r])) return !1;
        if (OP && e instanceof Element) return !1;
        for (r = n; r-- !== 0;)
            if (!((i[r] === "_owner" || i[r] === "__v" || i[r] === "__o") && e.$$typeof) && !Ns(e[i[r]], t[i[r]])) return !1;
        return !0
    }
    return e !== e && t !== t
}
var zP = function(t, n) {
    try {
        return Ns(t, n)
    } catch (r) {
        if ((r.message || "").match(/stack|recursion/i)) return console.warn("react-fast-compare cannot handle circular refs"), !1;
        throw r
    }
};
const bP = pi(zP);
/*
object-assign
(c) Sindre Sorhus
@license MIT
*/
var Dp = Object.getOwnPropertySymbols,
    BP = Object.prototype.hasOwnProperty,
    UP = Object.prototype.propertyIsEnumerable;

function HP(e) {
    if (e == null) throw new TypeError("Object.assign cannot be called with null or undefined");
    return Object(e)
}

function $P() {
    try {
        if (!Object.assign) return !1;
        var e = new String("abc");
        if (e[5] = "de", Object.getOwnPropertyNames(e)[0] === "5") return !1;
        for (var t = {}, n = 0; n < 10; n++) t["_" + String.fromCharCode(n)] = n;
        var r = Object.getOwnPropertyNames(t).map(function(o) {
            return t[o]
        });
        if (r.join("") !== "0123456789") return !1;
        var i = {};
        return "abcdefghijklmnopqrst".split("").forEach(function(o) {
            i[o] = o
        }), Object.keys(Object.assign({}, i)).join("") === "abcdefghijklmnopqrst"
    } catch {
        return !1
    }
}
var WP = $P() ? Object.assign : function(e, t) {
    for (var n, r = HP(e), i, o = 1; o < arguments.length; o++) {
        n = Object(arguments[o]);
        for (var s in n) BP.call(n, s) && (r[s] = n[s]);
        if (Dp) {
            i = Dp(n);
            for (var a = 0; a < i.length; a++) UP.call(n, i[a]) && (r[i[a]] = n[i[a]])
        }
    }
    return r
};
const KP = pi(WP);
var gr = {
        BODY: "bodyAttributes",
        HTML: "htmlAttributes",
        TITLE: "titleAttributes"
    },
    G = {
        BASE: "base",
        BODY: "body",
        HEAD: "head",
        HTML: "html",
        LINK: "link",
        META: "meta",
        NOSCRIPT: "noscript",
        SCRIPT: "script",
        STYLE: "style",
        TITLE: "title"
    };
Object.keys(G).map(function(e) {
    return G[e]
});
var me = {
        CHARSET: "charset",
        CSS_TEXT: "cssText",
        HREF: "href",
        HTTPEQUIV: "http-equiv",
        INNER_HTML: "innerHTML",
        ITEM_PROP: "itemprop",
        NAME: "name",
        PROPERTY: "property",
        REL: "rel",
        SRC: "src",
        TARGET: "target"
    },
    ga = {
        accesskey: "accessKey",
        charset: "charSet",
        class: "className",
        contenteditable: "contentEditable",
        contextmenu: "contextMenu",
        "http-equiv": "httpEquiv",
        itemprop: "itemProp",
        tabindex: "tabIndex"
    },
    ko = {
        DEFAULT_TITLE: "defaultTitle",
        DEFER: "defer",
        ENCODE_SPECIAL_CHARACTERS: "encodeSpecialCharacters",
        ON_CHANGE_CLIENT_STATE: "onChangeClientState",
        TITLE_TEMPLATE: "titleTemplate"
    },
    GP = Object.keys(ga).reduce(function(e, t) {
        return e[ga[t]] = t, e
    }, {}),
    YP = [G.NOSCRIPT, G.SCRIPT, G.STYLE],
    Vt = "data-react-helmet",
    QP = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function(e) {
        return typeof e
    } : function(e) {
        return e && typeof Symbol == "function" && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    },
    XP = function(e, t) {
        if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
    },
    ZP = function() {
        function e(t, n) {
            for (var r = 0; r < n.length; r++) {
                var i = n[r];
                i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(t, i.key, i)
            }
        }
        return function(t, n, r) {
            return n && e(t.prototype, n), r && e(t, r), t
        }
    }(),
    rt = Object.assign || function(e) {
        for (var t = 1; t < arguments.length; t++) {
            var n = arguments[t];
            for (var r in n) Object.prototype.hasOwnProperty.call(n, r) && (e[r] = n[r])
        }
        return e
    },
    JP = function(e, t) {
        if (typeof t != "function" && t !== null) throw new TypeError("Super expression must either be null or a function, not " + typeof t);
        e.prototype = Object.create(t && t.prototype, {
            constructor: {
                value: e,
                enumerable: !1,
                writable: !0,
                configurable: !0
            }
        }), t && (Object.setPrototypeOf ? Object.setPrototypeOf(e, t) : e.__proto__ = t)
    },
    _p = function(e, t) {
        var n = {};
        for (var r in e) t.indexOf(r) >= 0 || Object.prototype.hasOwnProperty.call(e, r) && (n[r] = e[r]);
        return n
    },
    qP = function(e, t) {
        if (!e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
        return t && (typeof t == "object" || typeof t == "function") ? t : e
    },
    Gu = function(t) {
        var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !0;
        return n === !1 ? String(t) : String(t).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;")
    },
    eE = function(t) {
        var n = ti(t, G.TITLE),
            r = ti(t, ko.TITLE_TEMPLATE);
        if (r && n) return r.replace(/%s/g, function() {
            return Array.isArray(n) ? n.join("") : n
        });
        var i = ti(t, ko.DEFAULT_TITLE);
        return n || i || void 0
    },
    tE = function(t) {
        return ti(t, ko.ON_CHANGE_CLIENT_STATE) || function() {}
    },
    Dl = function(t, n) {
        return n.filter(function(r) {
            return typeof r[t] < "u"
        }).map(function(r) {
            return r[t]
        }).reduce(function(r, i) {
            return rt({}, r, i)
        }, {})
    },
    nE = function(t, n) {
        return n.filter(function(r) {
            return typeof r[G.BASE] < "u"
        }).map(function(r) {
            return r[G.BASE]
        }).reverse().reduce(function(r, i) {
            if (!r.length)
                for (var o = Object.keys(i), s = 0; s < o.length; s++) {
                    var a = o[s],
                        l = a.toLowerCase();
                    if (t.indexOf(l) !== -1 && i[l]) return r.concat(i)
                }
            return r
        }, [])
    },
    _i = function(t, n, r) {
        var i = {};
        return r.filter(function(o) {
            return Array.isArray(o[t]) ? !0 : (typeof o[t] < "u" && sE("Helmet: " + t + ' should be of type "Array". Instead found type "' + QP(o[t]) + '"'), !1)
        }).map(function(o) {
            return o[t]
        }).reverse().reduce(function(o, s) {
            var a = {};
            s.filter(function(f) {
                for (var m = void 0, x = Object.keys(f), w = 0; w < x.length; w++) {
                    var E = x[w],
                        p = E.toLowerCase();
                    n.indexOf(p) !== -1 && !(m === me.REL && f[m].toLowerCase() === "canonical") && !(p === me.REL && f[p].toLowerCase() === "stylesheet") && (m = p), n.indexOf(E) !== -1 && (E === me.INNER_HTML || E === me.CSS_TEXT || E === me.ITEM_PROP) && (m = E)
                }
                if (!m || !f[m]) return !1;
                var h = f[m].toLowerCase();
                return i[m] || (i[m] = {}), a[m] || (a[m] = {}), i[m][h] ? !1 : (a[m][h] = !0, !0)
            }).reverse().forEach(function(f) {
                return o.push(f)
            });
            for (var l = Object.keys(a), u = 0; u < l.length; u++) {
                var c = l[u],
                    d = KP({}, i[c], a[c]);
                i[c] = d
            }
            return o
        }, []).reverse()
    },
    ti = function(t, n) {
        for (var r = t.length - 1; r >= 0; r--) {
            var i = t[r];
            if (i.hasOwnProperty(n)) return i[n]
        }
        return null
    },
    rE = function(t) {
        return {
            baseTag: nE([me.HREF, me.TARGET], t),
            bodyAttributes: Dl(gr.BODY, t),
            defer: ti(t, ko.DEFER),
            encode: ti(t, ko.ENCODE_SPECIAL_CHARACTERS),
            htmlAttributes: Dl(gr.HTML, t),
            linkTags: _i(G.LINK, [me.REL, me.HREF], t),
            metaTags: _i(G.META, [me.NAME, me.CHARSET, me.HTTPEQUIV, me.PROPERTY, me.ITEM_PROP], t),
            noscriptTags: _i(G.NOSCRIPT, [me.INNER_HTML], t),
            onChangeClientState: tE(t),
            scriptTags: _i(G.SCRIPT, [me.SRC, me.INNER_HTML], t),
            styleTags: _i(G.STYLE, [me.CSS_TEXT], t),
            title: eE(t),
            titleAttributes: Dl(gr.TITLE, t)
        }
    },
    Yu = function() {
        var e = Date.now();
        return function(t) {
            var n = Date.now();
            n - e > 16 ? (e = n, t(n)) : setTimeout(function() {
                Yu(t)
            }, 0)
        }
    }(),
    Op = function(t) {
        return clearTimeout(t)
    },
    iE = typeof window < "u" ? window.requestAnimationFrame && window.requestAnimationFrame.bind(window) || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || Yu : global.requestAnimationFrame || Yu,
    oE = typeof window < "u" ? window.cancelAnimationFrame || window.webkitCancelAnimationFrame || window.mozCancelAnimationFrame || Op : global.cancelAnimationFrame || Op,
    sE = function(t) {
        return console && typeof console.warn == "function" && console.warn(t)
    },
    Oi = null,
    aE = function(t) {
        Oi && oE(Oi), t.defer ? Oi = iE(function() {
            Vp(t, function() {
                Oi = null
            })
        }) : (Vp(t), Oi = null)
    },
    Vp = function(t, n) {
        var r = t.baseTag,
            i = t.bodyAttributes,
            o = t.htmlAttributes,
            s = t.linkTags,
            a = t.metaTags,
            l = t.noscriptTags,
            u = t.onChangeClientState,
            c = t.scriptTags,
            d = t.styleTags,
            f = t.title,
            m = t.titleAttributes;
        Qu(G.BODY, i), Qu(G.HTML, o), lE(f, m);
        var x = {
                baseTag: Ar(G.BASE, r),
                linkTags: Ar(G.LINK, s),
                metaTags: Ar(G.META, a),
                noscriptTags: Ar(G.NOSCRIPT, l),
                scriptTags: Ar(G.SCRIPT, c),
                styleTags: Ar(G.STYLE, d)
            },
            w = {},
            E = {};
        Object.keys(x).forEach(function(p) {
            var h = x[p],
                g = h.newTags,
                P = h.oldTags;
            g.length && (w[p] = g), P.length && (E[p] = x[p].oldTags)
        }), n && n(), u(t, w, E)
    },
    Gv = function(t) {
        return Array.isArray(t) ? t.join("") : t
    },
    lE = function(t, n) {
        typeof t < "u" && document.title !== t && (document.title = Gv(t)), Qu(G.TITLE, n)
    },
    Qu = function(t, n) {
        var r = document.getElementsByTagName(t)[0];
        if (r) {
            for (var i = r.getAttribute(Vt), o = i ? i.split(",") : [], s = [].concat(o), a = Object.keys(n), l = 0; l < a.length; l++) {
                var u = a[l],
                    c = n[u] || "";
                r.getAttribute(u) !== c && r.setAttribute(u, c), o.indexOf(u) === -1 && o.push(u);
                var d = s.indexOf(u);
                d !== -1 && s.splice(d, 1)
            }
            for (var f = s.length - 1; f >= 0; f--) r.removeAttribute(s[f]);
            o.length === s.length ? r.removeAttribute(Vt) : r.getAttribute(Vt) !== a.join(",") && r.setAttribute(Vt, a.join(","))
        }
    },
    Ar = function(t, n) {
        var r = document.head || document.querySelector(G.HEAD),
            i = r.querySelectorAll(t + "[" + Vt + "]"),
            o = Array.prototype.slice.call(i),
            s = [],
            a = void 0;
        return n && n.length && n.forEach(function(l) {
            var u = document.createElement(t);
            for (var c in l)
                if (l.hasOwnProperty(c))
                    if (c === me.INNER_HTML) u.innerHTML = l.innerHTML;
                    else if (c === me.CSS_TEXT) u.styleSheet ? u.styleSheet.cssText = l.cssText : u.appendChild(document.createTextNode(l.cssText));
            else {
                var d = typeof l[c] > "u" ? "" : l[c];
                u.setAttribute(c, d)
            }
            u.setAttribute(Vt, "true"), o.some(function(f, m) {
                return a = m, u.isEqualNode(f)
            }) ? o.splice(a, 1) : s.push(u)
        }), o.forEach(function(l) {
            return l.parentNode.removeChild(l)
        }), s.forEach(function(l) {
            return r.appendChild(l)
        }), {
            oldTags: o,
            newTags: s
        }
    },
    Yv = function(t) {
        return Object.keys(t).reduce(function(n, r) {
            var i = typeof t[r] < "u" ? r + '="' + t[r] + '"' : "" + r;
            return n ? n + " " + i : i
        }, "")
    },
    uE = function(t, n, r, i) {
        var o = Yv(r),
            s = Gv(n);
        return o ? "<" + t + " " + Vt + '="true" ' + o + ">" + Gu(s, i) + "</" + t + ">" : "<" + t + " " + Vt + '="true">' + Gu(s, i) + "</" + t + ">"
    },
    cE = function(t, n, r) {
        return n.reduce(function(i, o) {
            var s = Object.keys(o).filter(function(u) {
                    return !(u === me.INNER_HTML || u === me.CSS_TEXT)
                }).reduce(function(u, c) {
                    var d = typeof o[c] > "u" ? c : c + '="' + Gu(o[c], r) + '"';
                    return u ? u + " " + d : d
                }, ""),
                a = o.innerHTML || o.cssText || "",
                l = YP.indexOf(t) === -1;
            return i + "<" + t + " " + Vt + '="true" ' + s + (l ? "/>" : ">" + a + "</" + t + ">")
        }, "")
    },
    Qv = function(t) {
        var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        return Object.keys(t).reduce(function(r, i) {
            return r[ga[i] || i] = t[i], r
        }, n)
    },
    dE = function(t) {
        var n = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
        return Object.keys(t).reduce(function(r, i) {
            return r[GP[i] || i] = t[i], r
        }, n)
    },
    fE = function(t, n, r) {
        var i, o = (i = {
                key: n
            }, i[Vt] = !0, i),
            s = Qv(r, o);
        return [ht.createElement(G.TITLE, s, n)]
    },
    hE = function(t, n) {
        return n.map(function(r, i) {
            var o, s = (o = {
                key: i
            }, o[Vt] = !0, o);
            return Object.keys(r).forEach(function(a) {
                var l = ga[a] || a;
                if (l === me.INNER_HTML || l === me.CSS_TEXT) {
                    var u = r.innerHTML || r.cssText;
                    s.dangerouslySetInnerHTML = {
                        __html: u
                    }
                } else s[l] = r[a]
            }), ht.createElement(t, s)
        })
    },
    Jt = function(t, n, r) {
        switch (t) {
            case G.TITLE:
                return {
                    toComponent: function() {
                        return fE(t, n.title, n.titleAttributes)
                    },
                    toString: function() {
                        return uE(t, n.title, n.titleAttributes, r)
                    }
                };
            case gr.BODY:
            case gr.HTML:
                return {
                    toComponent: function() {
                        return Qv(n)
                    },
                    toString: function() {
                        return Yv(n)
                    }
                };
            default:
                return {
                    toComponent: function() {
                        return hE(t, n)
                    },
                    toString: function() {
                        return cE(t, n, r)
                    }
                }
        }
    },
    Xv = function(t) {
        var n = t.baseTag,
            r = t.bodyAttributes,
            i = t.encode,
            o = t.htmlAttributes,
            s = t.linkTags,
            a = t.metaTags,
            l = t.noscriptTags,
            u = t.scriptTags,
            c = t.styleTags,
            d = t.title,
            f = d === void 0 ? "" : d,
            m = t.titleAttributes;
        return {
            base: Jt(G.BASE, n, i),
            bodyAttributes: Jt(gr.BODY, r, i),
            htmlAttributes: Jt(gr.HTML, o, i),
            link: Jt(G.LINK, s, i),
            meta: Jt(G.META, a, i),
            noscript: Jt(G.NOSCRIPT, l, i),
            script: Jt(G.SCRIPT, u, i),
            style: Jt(G.STYLE, c, i),
            title: Jt(G.TITLE, {
                title: f,
                titleAttributes: m
            }, i)
        }
    },
    pE = function(t) {
        var n, r;
        return r = n = function(i) {
            JP(o, i);

            function o() {
                return XP(this, o), qP(this, i.apply(this, arguments))
            }
            return o.prototype.shouldComponentUpdate = function(a) {
                return !bP(this.props, a)
            }, o.prototype.mapNestedChildrenToProps = function(a, l) {
                if (!l) return null;
                switch (a.type) {
                    case G.SCRIPT:
                    case G.NOSCRIPT:
                        return {
                            innerHTML: l
                        };
                    case G.STYLE:
                        return {
                            cssText: l
                        }
                }
                throw new Error("<" + a.type + " /> elements are self-closing and can not contain children. Refer to our API for more information.")
            }, o.prototype.flattenArrayTypeChildren = function(a) {
                var l, u = a.child,
                    c = a.arrayTypeChildren,
                    d = a.newChildProps,
                    f = a.nestedChildren;
                return rt({}, c, (l = {}, l[u.type] = [].concat(c[u.type] || [], [rt({}, d, this.mapNestedChildrenToProps(u, f))]), l))
            }, o.prototype.mapObjectTypeChildren = function(a) {
                var l, u, c = a.child,
                    d = a.newProps,
                    f = a.newChildProps,
                    m = a.nestedChildren;
                switch (c.type) {
                    case G.TITLE:
                        return rt({}, d, (l = {}, l[c.type] = m, l.titleAttributes = rt({}, f), l));
                    case G.BODY:
                        return rt({}, d, {
                            bodyAttributes: rt({}, f)
                        });
                    case G.HTML:
                        return rt({}, d, {
                            htmlAttributes: rt({}, f)
                        })
                }
                return rt({}, d, (u = {}, u[c.type] = rt({}, f), u))
            }, o.prototype.mapArrayTypeChildrenToProps = function(a, l) {
                var u = rt({}, l);
                return Object.keys(a).forEach(function(c) {
                    var d;
                    u = rt({}, u, (d = {}, d[c] = a[c], d))
                }), u
            }, o.prototype.warnOnInvalidChildren = function(a, l) {
                return !0
            }, o.prototype.mapChildrenToProps = function(a, l) {
                var u = this,
                    c = {};
                return ht.Children.forEach(a, function(d) {
                    if (!(!d || !d.props)) {
                        var f = d.props,
                            m = f.children,
                            x = _p(f, ["children"]),
                            w = dE(x);
                        switch (u.warnOnInvalidChildren(d, m), d.type) {
                            case G.LINK:
                            case G.META:
                            case G.NOSCRIPT:
                            case G.SCRIPT:
                            case G.STYLE:
                                c = u.flattenArrayTypeChildren({
                                    child: d,
                                    arrayTypeChildren: c,
                                    newChildProps: w,
                                    nestedChildren: m
                                });
                                break;
                            default:
                                l = u.mapObjectTypeChildren({
                                    child: d,
                                    newProps: l,
                                    newChildProps: w,
                                    nestedChildren: m
                                });
                                break
                        }
                    }
                }), l = this.mapArrayTypeChildrenToProps(c, l), l
            }, o.prototype.render = function() {
                var a = this.props,
                    l = a.children,
                    u = _p(a, ["children"]),
                    c = rt({}, u);
                return l && (c = this.mapChildrenToProps(l, c)), ht.createElement(t, c)
            }, ZP(o, null, [{
                key: "canUseDOM",
                set: function(a) {
                    t.canUseDOM = a
                }
            }]), o
        }(ht.Component), n.propTypes = {
            base: pe.object,
            bodyAttributes: pe.object,
            children: pe.oneOfType([pe.arrayOf(pe.node), pe.node]),
            defaultTitle: pe.string,
            defer: pe.bool,
            encodeSpecialCharacters: pe.bool,
            htmlAttributes: pe.object,
            link: pe.arrayOf(pe.object),
            meta: pe.arrayOf(pe.object),
            noscript: pe.arrayOf(pe.object),
            onChangeClientState: pe.func,
            script: pe.arrayOf(pe.object),
            style: pe.arrayOf(pe.object),
            title: pe.string,
            titleAttributes: pe.object,
            titleTemplate: pe.string
        }, n.defaultProps = {
            defer: !0,
            encodeSpecialCharacters: !0
        }, n.peek = t.peek, n.rewind = function() {
            var i = t.rewind();
            return i || (i = Xv({
                baseTag: [],
                bodyAttributes: {},
                encodeSpecialCharacters: !0,
                htmlAttributes: {},
                linkTags: [],
                metaTags: [],
                noscriptTags: [],
                scriptTags: [],
                styleTags: [],
                title: "",
                titleAttributes: {}
            })), i
        }, r
    },
    mE = function() {
        return null
    },
    gE = _P(rE, aE, Xv)(mE),
    Xu = pE(gE);
Xu.renderStatic = Xu.rewind;
const Fo = ({
        title: e
    }) => v.jsx("div", {
        children: v.jsxs(Xu, {
            children: [v.jsx("meta", {
                charSet: "utf-8"
            }), v.jsxs("title", {
                children: ["Noor's Dev Excellence (", e, ") "]
            }), v.jsx("link", {
                rel: "canonical",
                href: "http://mysite.com/example"
            })]
        })
    }),
    vE = ({
        children: e,
        delay: t = .5,
        x: n = 0
    }) => v.jsx(J.div, {
        initial: {
            x: -90,
            opacity: 0
        },
        animate: {
            x: n,
            opacity: 1
        },
        transition: {
            delay: t,
            type: "spring",
            stiffness: 150
        },
        children: e
    }),
    yE = C.lazy(() => Ba(() =>
        import ("./OfferSection-BCcAEGhj.js"), __vite__mapDeps([0, 1]))),
    xE = C.lazy(() => Ba(() =>
        import ("./Freelance-jazf_0ED.js"), [])),
    wE = C.lazy(() => Ba(() =>
        import ("./ProjectCards-D4fuLip7.js"), [])),
    SE = C.lazy(() => Ba(() =>
        import ("./GoogleMap-CvgdlVpD.js"), [])),
    TE = () => v.jsxs(J.div, {
        initial: {
            opacity: 0
        },
        whileInView: {
            opacity: 1
        },
        transition: {
            duration: .3,
            ease: "easeInOut"
        },
        children: [v.jsx(Fo, {
            title: "Home"
        }), v.jsxs("div", {
            className: " home-container text-white relative z-0",
            children: [v.jsxs("video", {
                className: "w-full h-[90vh] object-cover",
                autoPlay: !0,
                loop: !0,
                muted: !0,
                children: [v.jsx("source", {
                    src: TP,
                    type: "video/mp4"
                }), "Your browser does not support the video tag."]
            }), v.jsxs(J.div, {
                className: " md:w-[100%] absolute top-0 z-[1] text-center pt-[80px] md:pt-[160px]",
                initial: {
                    opacity: 0,
                    y: 50
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: 2,
                    ease: "easeInOut"
                },
                children: [v.jsxs(ei, {
                    delay: "0.5",
                    children: [v.jsx("h1", {
                        className: " relative text-[40px] leading-[35px] font-[700] md:text-[60px] md:leading-[45px] md:font-[800] md:mt-4 mt-1",
                        children: "Showcasing"
                    }), v.jsx("h1", {
                        className: " relative text-[40px] leading-[35px] font-[700] md:text-[70px] md:leading-[45px] md:font-[800] md:mt-4 mt-1",
                        children: "Dev Excellence"
                    })]
                }), v.jsx(ei, {
                    delay: "0.8",
                    children: v.jsxs("p", {
                        className: "text-[20px] leading-[35px] font-[300] pt-8 px-3",
                        children: ["I am a Frontend Developer specializing in JavaScript and React.js.", v.jsx("br", {}), "Explore my portfolio to see my skills and projects."]
                    })
                }), v.jsxs("div", {
                    className: "mt-10 md:flex gap-4 justify-center items-center ",
                    children: [v.jsx(rn, {
                        to: "/api/v1/noor-e-nazar/about",
                        children: v.jsx(vE, {
                            delay: "1",
                            children: v.jsx(Ot, {
                                className: "bg-white w-[15rem] md:w-[10rem] rounded-md block text-[20px] mx-auto font-[500] hover:bg-opacity-50 text-black px-6 py-4  my-3 md:my-1",
                                label: "About Me"
                            })
                        })
                    }), v.jsx(rn, {
                        to: "/api/v1/noor-e-nazar/project",
                        children: v.jsx(ei, {
                            delay: "1",
                            children: v.jsx(Ot, {
                                className: "hover:bg-white w-[15rem] md:w-[10rem] rounded-md text-[18px] block mx-auto bg-opacity-90 hover:text-black px-4 py-4 my-3 border ",
                                label: "View Projects"
                            })
                        })
                    })]
                })]
            })]
        }), v.jsxs(C.Suspense, {
            fallback: v.jsx("div", {
                children: "Loading..."
            }),
            children: [v.jsx(yE, {}), v.jsx(wE, {}), v.jsx(xE, {}), v.jsx(SE, {})]
        })]
    }),
    Fp = ({
        className: e,
        labelText: t
    }) => v.jsx("p", {
        className: `${e}  leading-[27px] font-[400] md:leading-[27px]`,
        children: t
    }),
    PE = "/assets/auth-DKqaqtHk.png";

function EE(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 1024 1024"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M854.6 289.1a362.49 362.49 0 0 0-79.9-115.7 370.83 370.83 0 0 0-118.2-77.8C610.7 76.6 562.1 67 512 67c-50.1 0-98.7 9.6-144.5 28.5-44.3 18.3-84 44.5-118.2 77.8A363.6 363.6 0 0 0 169.4 289c-19.5 45-29.4 92.8-29.4 142 0 70.6 16.9 140.9 50.1 208.7 26.7 54.5 64 107.6 111 158.1 80.3 86.2 164.5 138.9 188.4 153a43.9 43.9 0 0 0 22.4 6.1c7.8 0 15.5-2 22.4-6.1 23.9-14.1 108.1-66.8 188.4-153 47-50.4 84.3-103.6 111-158.1C867.1 572 884 501.8 884 431.1c0-49.2-9.9-97-29.4-142zM512 880.2c-65.9-41.9-300-207.8-300-449.1 0-77.9 31.1-151.1 87.6-206.3C356.3 169.5 431.7 139 512 139s155.7 30.5 212.4 85.9C780.9 280 812 353.2 812 431.1c0 241.3-234.1 407.2-300 449.1zm0-617.2c-97.2 0-176 78.8-176 176s78.8 176 176 176 176-78.8 176-176-78.8-176-176-176zm79.2 255.2A111.6 111.6 0 0 1 512 551c-29.9 0-58-11.7-79.2-32.8A111.6 111.6 0 0 1 400 439c0-29.9 11.7-58 32.8-79.2C454 338.6 482.1 327 512 327c29.9 0 58 11.6 79.2 32.8C612.4 381 624 409.1 624 439c0 29.9-11.6 58-32.8 79.2z"
            },
            child: []
        }]
    })(e)
}

function Zv(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 1024 1024"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M928 160H96c-17.7 0-32 14.3-32 32v640c0 17.7 14.3 32 32 32h832c17.7 0 32-14.3 32-32V192c0-17.7-14.3-32-32-32zm-40 110.8V792H136V270.8l-27.6-21.5 39.3-50.5 42.8 33.3h643.1l42.8-33.3 39.3 50.5-27.7 21.5zM833.6 232L512 482 190.4 232l-42.8-33.3-39.3 50.5 27.6 21.5 341.6 265.6a55.99 55.99 0 0 0 68.7 0L888 270.8l27.6-21.5-39.3-50.5-42.7 33.2z"
            },
            child: []
        }]
    })(e)
}

function Jv(e) {
    return et({
        tag: "svg",
        attr: {
            viewBox: "0 0 1024 1024"
        },
        child: [{
            tag: "path",
            attr: {
                d: "M877.1 238.7L770.6 132.3c-13-13-30.4-20.3-48.8-20.3s-35.8 7.2-48.8 20.3L558.3 246.8c-13 13-20.3 30.5-20.3 48.9 0 18.5 7.2 35.8 20.3 48.9l89.6 89.7a405.46 405.46 0 0 1-86.4 127.3c-36.7 36.9-79.6 66-127.2 86.6l-89.6-89.7c-13-13-30.4-20.3-48.8-20.3a68.2 68.2 0 0 0-48.8 20.3L132.3 673c-13 13-20.3 30.5-20.3 48.9 0 18.5 7.2 35.8 20.3 48.9l106.4 106.4c22.2 22.2 52.8 34.9 84.2 34.9 6.5 0 12.8-.5 19.2-1.6 132.4-21.8 263.8-92.3 369.9-198.3C818 606 888.4 474.6 910.4 342.1c6.3-37.6-6.3-76.3-33.3-103.4zm-37.6 91.5c-19.5 117.9-82.9 235.5-178.4 331s-213 158.9-330.9 178.4c-14.8 2.5-30-2.5-40.8-13.2L184.9 721.9 295.7 611l119.8 120 .9.9 21.6-8a481.29 481.29 0 0 0 285.7-285.8l8-21.6-120.8-120.7 110.8-110.9 104.5 104.5c10.8 10.8 15.8 26 13.3 40.8z"
            },
            child: []
        }]
    })(e)
}

function qv(e) {
    return et({
        tag: "svg",
        attr: {
            t: "1569683925316",
            viewBox: "0 0 1024 1024",
            version: "1.1"
        },
        child: [{
            tag: "defs",
            attr: {},
            child: []
        }, {
            tag: "path",
            attr: {
                d: "M713.5 599.9c-10.9-5.6-65.2-32.2-75.3-35.8-10.1-3.8-17.5-5.6-24.8 5.6-7.4 11.1-28.4 35.8-35 43.3-6.4 7.4-12.9 8.3-23.8 2.8-64.8-32.4-107.3-57.8-150-131.1-11.3-19.5 11.3-18.1 32.4-60.2 3.6-7.4 1.8-13.7-1-19.3-2.8-5.6-24.8-59.8-34-81.9-8.9-21.5-18.1-18.5-24.8-18.9-6.4-0.4-13.7-0.4-21.1-0.4-7.4 0-19.3 2.8-29.4 13.7-10.1 11.1-38.6 37.8-38.6 92s39.5 106.7 44.9 114.1c5.6 7.4 77.7 118.6 188.4 166.5 70 30.2 97.4 32.8 132.4 27.6 21.3-3.2 65.2-26.6 74.3-52.5 9.1-25.8 9.1-47.9 6.4-52.5-2.7-4.9-10.1-7.7-21-13z"
            },
            child: []
        }, {
            tag: "path",
            attr: {
                d: "M925.2 338.4c-22.6-53.7-55-101.9-96.3-143.3-41.3-41.3-89.5-73.8-143.3-96.3C630.6 75.7 572.2 64 512 64h-2c-60.6 0.3-119.3 12.3-174.5 35.9-53.3 22.8-101.1 55.2-142 96.5-40.9 41.3-73 89.3-95.2 142.8-23 55.4-34.6 114.3-34.3 174.9 0.3 69.4 16.9 138.3 48 199.9v152c0 25.4 20.6 46 46 46h152.1c61.6 31.1 130.5 47.7 199.9 48h2.1c59.9 0 118-11.6 172.7-34.3 53.5-22.3 101.6-54.3 142.8-95.2 41.3-40.9 73.8-88.7 96.5-142 23.6-55.2 35.6-113.9 35.9-174.5 0.3-60.9-11.5-120-34.8-175.6z m-151.1 438C704 845.8 611 884 512 884h-1.7c-60.3-0.3-120.2-15.3-173.1-43.5l-8.4-4.5H188V695.2l-4.5-8.4C155.3 633.9 140.3 574 140 513.7c-0.4-99.7 37.7-193.3 107.6-263.8 69.8-70.5 163.1-109.5 262.8-109.9h1.7c50 0 98.5 9.7 144.2 28.9 44.6 18.7 84.6 45.6 119 80 34.3 34.3 61.3 74.4 80 119 19.4 46.2 29.1 95.2 28.9 145.8-0.6 99.6-39.7 192.9-110.1 262.7z"
            },
            child: []
        }]
    })(e)
}
const CE = () => {
        const [e, t] = C.useState(!0), [n, r] = C.useState(!1), [i, o] = C.useState(!1), s = () => {
            t(!0), r(!1), o(!1)
        }, a = () => {
            t(!1), r(!0), o(!1)
        }, l = () => {
            t(!1), r(!1), o(!0)
        };
        return v.jsxs(J.div, {
            className: "px-4 md:px-8 lg:px-16 ",
            initial: {
                opacity: 0
            },
            whileInView: {
                opacity: 1
            },
            transition: {
                duration: .5
            },
            children: [v.jsx(Fo, {
                title: "About Me"
            }), v.jsxs("div", {
                className: "layout md:text-center",
                children: [v.jsxs(J.div, {
                    className: "pt-[20px] md:pt-[90px]",
                    initial: {
                        opacity: 0,
                        y: 50
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: .5
                    },
                    children: [v.jsx(Ms, {
                        className: "text-[45px] md:text-[45px] md:font-[900] my-6 my:4",
                        labelText: "About Me"
                    }), v.jsx(Fp, {
                        className: "mx-1 md:mx-auto w-full md:w-[60%] ",
                        labelText: `I am Muhammad Noor Nazar, a frontend developer
            specializing in React.js and also exploring MERN stack. Explore my journey and
            projects.`
                    })]
                }), v.jsxs("div", {
                    className: "flex flex-col gap-4 md:flex-row justify-between py-[40px] mt-1 md:mt-[60px]",
                    children: [v.jsxs("div", {
                        className: "left w-full md:w-[60%] mx-auto mb-6 pt-[20px] text-left",
                        children: [v.jsxs(J.div, {
                            initial: {
                                opacity: 0,
                                x: -50
                            },
                            whileInView: {
                                opacity: 1,
                                x: 0
                            },
                            transition: {
                                duration: .5
                            },
                            children: [v.jsx(Ms, {
                                className: "text-[40px] md:text-[50px]",
                                labelText: "Noor Nazar's"
                            }), v.jsx(Ms, {
                                className: "text-[40px] md:text-[50px] mt-6",
                                labelText: "Development Journey"
                            }), v.jsx(Fp, {
                                className: "mt-8",
                                labelText: `Hi, I'm Muhammad Noor, a passionate frontend developer with
              expertise in React.js and the MERN stack. I specialize in creating
              dynamic, responsive web applications with a focus on clean design
              and seamless performance. Currently, I'm diving deeper into
              full-stack development to expand my skills in backend technologies.
              Let's connect and collaborate on something amazing!`
                            })]
                        }), v.jsxs(J.div, {
                            className: "flex flex-wrap mt-6",
                            initial: {
                                opacity: 0,
                                y: 50
                            },
                            whileInView: {
                                opacity: 1,
                                y: 0
                            },
                            transition: {
                                duration: .5
                            },
                            children: [v.jsx(Ot, {
                                className: "my-2 md:my-4 ml-0 mr-4 bg-white py-3 px-4 rounded-md shadow-md hover:text-gray-700 hover:bg-[rgba(247,247,247,0.54)]",
                                label: "Skills",
                                onClick: s
                            }), v.jsx(Ot, {
                                className: "my-2 md:my-4 ml-0 mr-4 bg-white py-3 px-4 rounded-md shadow-md hover:text-gray-700 hover:bg-[rgba(247,247,247,0.54)]",
                                label: "Education",
                                onClick: a
                            }), v.jsx(Ot, {
                                className: "my-2 md:my-4 ml-0 mr-4 bg-white py-3 px-4 rounded-md shadow-md hover:text-gray-700 hover:bg-[rgba(247,247,247,0.54)]",
                                label: "Contact Me",
                                onClick: l
                            })]
                        }), v.jsxs(J.div, {
                            className: "mt-4",
                            initial: {
                                opacity: 0,
                                x: -50
                            },
                            whileInView: {
                                opacity: 1,
                                x: 0
                            },
                            transition: {
                                duration: .5
                            },
                            children: [e && v.jsxs("div", {
                                className: "p-4 bg-white rounded-lg shadow-md max-w-lg",
                                children: [v.jsx("h2", {
                                    className: "text-xl md:text-2xl font-bold  mb-4",
                                    children: "Web Development Skills"
                                }), v.jsxs("ul", {
                                    className: "grid grid-cols-2 gap-4 text-gray-700 font-semibold mr-2",
                                    children: [v.jsx("li", {
                                        children: "HTML & CSS"
                                    }), v.jsx("li", {
                                        children: "JavaScript"
                                    }), v.jsx("li", {
                                        children: "React.js"
                                    }), v.jsx("li", {
                                        children: " Git & GitHub"
                                    }), v.jsx("li", {
                                        children: "Tailwind CSS"
                                    }), v.jsx("li", {
                                        children: " API Integration"
                                    }), v.jsx("li", {
                                        children: " Responsive Design"
                                    }), v.jsx("li", {
                                        children: "Strapi"
                                    })]
                                })]
                            }), n && v.jsxs("div", {
                                className: "p-4 bg-white rounded-lg shadow-md max-w-lg mt-6",
                                children: [v.jsx("h2", {
                                    className: "text-xl md:text-2xl font-bold text-gray-800 mb-4",
                                    children: "Education"
                                }), v.jsxs("ul", {
                                    className: "space-y-2",
                                    children: [v.jsxs("li", {
                                        className: "flex items-center",
                                        children: [v.jsx("span", {
                                            className: "text-gray-800 font-semibold mr-2",
                                            children: "University:"
                                        }), "BSCS from Federal Urdu University, Karachi"]
                                    }), v.jsxs("li", {
                                        className: "flex items-center",
                                        children: [v.jsx("span", {
                                            className: "text-gray-800 font-semibold mr-2",
                                            children: "College:"
                                        }), "Govt. College For Men, Nazimabad"]
                                    })]
                                })]
                            }), i && v.jsxs("div", {
                                className: "p-4 bg-white rounded-lg shadow-md max-w-lg mt-6",
                                children: [v.jsx("h2", {
                                    className: "text-xl md:text-2xl font-bold text-gray-800 mb-4",
                                    children: "Get in Touch"
                                }), v.jsxs("ul", {
                                    className: "space-y-2",
                                    children: [v.jsxs("li", {
                                        className: "flex items-center",
                                        children: [v.jsx(Jv, {
                                            className: " mr-2 scale-125 duration-300 hover:scale-150"
                                        }), v.jsx("a", {
                                            href: "tel:03178813001",
                                            className: " hover:text-blue-800",
                                            children: "0317 8813001"
                                        })]
                                    }), v.jsxs("li", {
                                        className: "flex items-center",
                                        children: [v.jsx(qv, {
                                            className: " mr-2 scale-125 duration-300 hover:scale-150"
                                        }), v.jsx("a", {
                                            href: "https://wa.me/923178813001",
                                            target: "_blank",
                                            rel: "noopener noreferrer",
                                            className: "text-gray-800 hover:text-blue-500",
                                            children: "+92 317 8813001"
                                        })]
                                    }), v.jsxs("li", {
                                        className: "flex items-center",
                                        children: [v.jsx(Zv, {
                                            className: " mr-2 scale-125 duration-300 hover:scale-150"
                                        }), v.jsx("a", {
                                            href: "mailto:noorenazar.prog@gmail.com",
                                            className: "text-gray-800 hover:text-blue-500",
                                            children: "noorenazar.prog@gmail.com"
                                        })]
                                    })]
                                })]
                            })]
                        })]
                    }), v.jsx(J.div, {
                        className: "right w-full md:w-[40%] mx-auto mt-8 md:mt-0 overflow-hidden h-auto md:h-[600px] md:translate-y-[1rem] rounded-[20px] hover:shadow-multi-color duration-200",
                        initial: {
                            opacity: 0,
                            y: -50
                        },
                        whileInView: {
                            opacity: 1,
                            y: 0
                        },
                        transition: {
                            duration: .5
                        },
                        children: v.jsx("img", {
                            className: "object-cover shadow-lg w-full h-full hover:scale-110 duration-500",
                            src: PE,
                            alt: "My Picture"
                        })
                    })]
                })]
            })]
        })
    },
    kE = "/assets/youtube1-G-W2BbTz.jpg",
    RE = "/assets/renies-DNvAfVAT.jpg",
    jE = "/assets/graphicdev-CON0mdS2.jpg",
    AE = "/assets/nextjsweb-DkNDaXij.jpg",
    LE = "/assets/portfolio-CJPuu56W.webp",
    ME = () => {
        const [e, t] = C.useState("All"), n = [{
            id: 1,
            title: "YouTube Clone",
            description: "Developed a YouTube clone in React.js with RapidAPI integration, showcasing frontend development and API integration skills.",
            image: kE,
            link: "https://zingy-brigadeiros-cf2f51.netlify.app/",
            technology: "React.js"
        }, {
            id: 2,
            title: "Renie",
            description: "Specialized in converting complex Figma designs into React components, ensuring precise attention to design and development principles.",
            image: RE,
            link: "https://www.renie.io/",
            technology: "MERN"
        }, {
            id: 3,
            title: "Graphic Web",
            description: "Developed a static website for a client using HTML, CSS, and JavaScript, with GSAP for engaging animations.",
            image: jE,
            link: "https://symphonious-marzipan-f6b121.netlify.app/",
            technology: "Vanilla JS"
        }, {
            id: 4,
            title: "Next.js Web App",
            description: "Created a static web application with Next.js using basic knowledge and the Aceternity UI framework.",
            image: AE,
            link: "https://nextjs-with-aceternity-ui-git-main-noor-nazars-projects.vercel.app/",
            technology: "Next.js"
        }, {
            id: 5,
            title: "Portfolio",
            description: "Developed A personal portfolio  static website using HTML, CSS, and JavaScript.",
            image: LE,
            link: "https://comforting-concha-965fde.netlify.app/",
            technology: "MERN"
        }], r = e === "All" ? n : n.filter(i => i.technology === e);
        return v.jsxs(J.div, {
            className: "layout min-h-screen p-8",
            initial: {
                opacity: 0
            },
            whileInView: {
                opacity: 1
            },
            transition: {
                duration: .5
            },
            children: [v.jsx(Fo, {
                title: "Projects"
            }), v.jsxs(J.section, {
                className: "text-center my-16",
                initial: {
                    opacity: 0,
                    y: 50
                },
                whileInView: {
                    opacity: 1,
                    y: 0
                },
                transition: {
                    duration: .5
                },
                children: [v.jsxs("h2", {
                    className: "text-[45px] font-bold mb-4 text-gray-800",
                    children: ["Highlighted Projects (", r.length, ")"]
                }), v.jsxs("p", {
                    className: "text-lg text-gray-800",
                    children: ["Explore my key projects that showcase my skills in web development, including ", v.jsx("br", {}), " YouTube clone and more."]
                })]
            }), v.jsxs(J.div, {
                className: "flex flex-wrap space-x-4 my-8",
                initial: {
                    opacity: 0,
                    x: -50
                },
                whileInView: {
                    opacity: 1,
                    x: 0
                },
                transition: {
                    duration: .5
                },
                children: [v.jsx(Ot, {
                    className: "px-4 py-2 duration-500 shadow-md rounded-md hover:rounded-xl hover:text-gray-500",
                    onClick: () => t("All"),
                    label: "All"
                }), v.jsx(Ot, {
                    className: "px-4 py-2 duration-500 shadow-md rounded-md hover:rounded-xl hover:text-gray-500 my-2",
                    onClick: () => t("React.js"),
                    label: "React.js"
                }), v.jsx(Ot, {
                    className: "px-4 py-2 duration-500 shadow-md rounded-md hover:rounded-xl hover:text-gray-500 my-2",
                    onClick: () => t("Next.js"),
                    label: "Next.js"
                }), v.jsx(Ot, {
                    className: "px-4 py-2 duration-500 shadow-md rounded-md hover:rounded-xl hover:text-gray-500 my-2",
                    onClick: () => t("MERN"),
                    label: "MERN"
                }), v.jsx(Ot, {
                    className: "px-4 py-2 duration-500 shadow-md rounded-md hover:rounded-xl hover:text-gray-500 my-2",
                    onClick: () => t("Vanilla JS"),
                    label: "Vanilla JS"
                })]
            }), v.jsx(J.div, {
                className: "grid sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16",
                initial: {
                    opacity: 0,
                    y: 50,
                    scale: .8
                },
                whileInView: {
                    opacity: 1,
                    scale: 1,
                    y: 0
                },
                transition: {
                    duration: 1
                },
                children: r.map(i => v.jsx("div", {
                    className: " shadow-md hover:shadow-multi-color hover:scale-110 duration-300 rounded-md overflow-hidden",
                    children: v.jsxs("a", {
                        href: i.link,
                        target: "_blank",
                        rel: "noopener noreferrer",
                        children: [v.jsx("div", {
                            className: " overflow-hidden",
                            children: v.jsx("img", {
                                className: "w-full h-[250px] scale-100 hover:scale-125 duration-500 object-cover",
                                src: i.image,
                                alt: i.title
                            })
                        }), v.jsxs("div", {
                            className: "p-4 ",
                            children: [v.jsx("h3", {
                                className: "text-xl font-semibold",
                                children: i.title
                            }), v.jsx("p", {
                                className: "text-sm text-gray-700",
                                children: i.description
                            })]
                        })]
                    })
                }, i.id))
            })]
        })
    },
    NE = () => v.jsxs(J.div, {
        className: "py-12 px-6 md:px-12",
        initial: {
            opacity: 0
        },
        whileInView: {
            opacity: 1
        },
        transition: {
            duration: .5
        },
        children: [v.jsx(Fo, {
            title: "Contact"
        }), v.jsxs("div", {
            className: "layout max-w-7xl mx-auto",
            children: [v.jsxs("div", {
                className: "text-center",
                children: [v.jsx(J.h2, {
                    className: "text-4xl font-bold text-gray-800",
                    initial: {
                        opacity: 0,
                        y: -50
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: .5
                    },
                    children: "Get in Touch"
                }), v.jsx(J.p, {
                    className: "text-gray-600 mt-4",
                    initial: {
                        opacity: 0,
                        y: -50
                    },
                    whileInView: {
                        opacity: 1,
                        y: 0
                    },
                    transition: {
                        duration: .5
                    },
                    children: "Feel free to contact me via the form below or reach out via the provided contact details."
                })]
            }), v.jsxs(J.div, {
                className: "mt-12 flex flex-col md:flex-row justify-between items-center",
                initial: {
                    opacity: 0,
                    x: -50
                },
                whileInView: {
                    opacity: 1,
                    x: 0
                },
                transition: {
                    duration: .5
                },
                children: [v.jsxs(J.div, {
                    className: "bg-white shadow-lg rounded-lg p-6 w-full md:w-[60%] mb-8 md:mb-0",
                    initial: {
                        opacity: 0
                    },
                    whileInView: {
                        opacity: 1
                    },
                    transition: {
                        duration: .5
                    },
                    children: [v.jsx(J.h3, {
                        className: "text-2xl font-semibold mb-6",
                        initial: {
                            opacity: 0,
                            x: -50
                        },
                        whileInView: {
                            opacity: 1,
                            x: 0
                        },
                        transition: {
                            duration: .5
                        },
                        children: "Contact Form"
                    }), v.jsxs(J.form, {
                        className: "space-y-4",
                        action: "https://formsubmit.co/noor.nazar.programmer.prog@gmail.com",
                        method: "POST",
                        initial: {
                            opacity: 0,
                            x: -50
                        },
                        whileInView: {
                            opacity: 1,
                            x: 0
                        },
                        transition: {
                            duration: .5
                        },
                        children: [v.jsx("input", {
                            type: "hidden",
                            name: "_next",
                            value: "https://your-redirect-url.com"
                        }), v.jsxs("div", {
                            className: "flex flex-col",
                            children: [v.jsx("label", {
                                className: "mb-2",
                                htmlFor: "name",
                                children: "Full Name"
                            }), v.jsx("input", {
                                type: "text",
                                id: "name",
                                name: "name",
                                required: !0,
                                className: "border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:shadow-md focus:border-transparent",
                                placeholder: "Your Name"
                            })]
                        }), v.jsxs("div", {
                            className: "flex flex-col",
                            children: [v.jsx("label", {
                                className: "mb-2",
                                htmlFor: "email",
                                children: "Email Address"
                            }), v.jsx("input", {
                                type: "email",
                                id: "email",
                                name: "email",
                                required: !0,
                                className: "border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:shadow-md focus:border-transparent",
                                placeholder: "you@example.com"
                            })]
                        }), v.jsxs("div", {
                            className: "flex flex-col",
                            children: [v.jsx("label", {
                                className: "mb-2",
                                htmlFor: "message",
                                children: "Message"
                            }), v.jsx("textarea", {
                                id: "message",
                                rows: "5",
                                name: "message",
                                required: !0,
                                className: "border border-gray-300 p-3 rounded-lg shadow-sm focus:outline-none focus:shadow-md focus:border-transparent",
                                placeholder: "Your Message"
                            })]
                        }), v.jsx("button", {
                            type: "submit",
                            className: "bg-white shadow-md py-3 px-6 rounded-lg hover:bg-[#f7f7f7] transition duration-300",
                            children: "Send Message"
                        })]
                    })]
                }), v.jsxs(J.div, {
                    className: "w-full md:w-[35%] text-center md:text-left space-y-6",
                    initial: {
                        opacity: 0
                    },
                    whileInView: {
                        opacity: 1
                    },
                    transition: {
                        duration: .5
                    },
                    children: [v.jsxs(J.div, {
                        className: "flex flex-col items-center md:items-start space-y-4",
                        whileHover: {
                            scale: 1.1
                        },
                        transition: {
                            duration: .3
                        },
                        children: [v.jsx(Jv, {
                            className: "scale-125 hover:scale-150 text-3xl"
                        }), v.jsxs("p", {
                            className: "text-lg text-gray-700",
                            children: ["Call:", " ", v.jsx("a", {
                                href: "tel:+923178813001",
                                className: "text-blue-500 hover:underline",
                                children: "+92 317 8813001"
                            })]
                        })]
                    }), v.jsxs(J.div, {
                        className: "flex flex-col items-center md:items-start space-y-4",
                        whileHover: {
                            scale: 1.1
                        },
                        transition: {
                            duration: .3
                        },
                        children: [v.jsx(Zv, {
                            className: "scale-125 hover:scale-150 text-3xl"
                        }), v.jsxs("p", {
                            className: "text-lg text-gray-700",
                            children: ["Email:", " ", v.jsx("a", {
                                href: "mailto:noorenazar.prog@gmail.com",
                                className: "text-blue-500 hover:underline",
                                children: "noorenazar.prog@gmail.com"
                            })]
                        })]
                    }), v.jsxs(J.div, {
                        className: "flex flex-col items-center md:items-start space-y-4",
                        whileHover: {
                            scale: 1.1
                        },
                        transition: {
                            duration: .3
                        },
                        children: [v.jsx(qv, {
                            className: "scale-125 hover:scale-150 text-3xl"
                        }), v.jsxs("p", {
                            className: "text-lg text-gray-700",
                            children: ["WhatsApp:", " ", v.jsx("a", {
                                href: "https://wa.me/923178813001",
                                target: "_blank",
                                rel: "noopener noreferrer",
                                className: "text-blue-500 hover:underline",
                                children: "+92 317 8813001"
                            })]
                        })]
                    }), v.jsxs(J.div, {
                        className: "flex flex-col items-center md:items-start space-y-4",
                        whileHover: {
                            scale: 1.1
                        },
                        transition: {
                            duration: .3
                        },
                        children: [v.jsx(EE, {
                            className: "scale-125 hover:scale-150 text-3xl"
                        }), v.jsx("p", {
                            className: "text-lg text-gray-700",
                            children: "Karachi, Pakistan"
                        })]
                    })]
                })]
            })]
        })]
    }),
    DE = () => v.jsxs("div", {
        className: "min-h-screen bg-gradient-to-br from-pink-500 to-yellow-500 flex flex-col justify-center items-center py-10",
        children: [v.jsx(Fo, {
            title: "404 page not font"
        }), v.jsx("h1", {
            className: "text-8xl font-bold text-white animate-bounce",
            children: "404"
        }), v.jsx("p", {
            className: "text-2xl text-white mt-4 animate-pulse",
            children: "Oops! Page Not Found"
        }), v.jsx("p", {
            className: "text-lg text-white mt-2",
            children: "It looks like you're lost, but don't worry, everything is still fun here!"
        }), v.jsx(rn, {
            to: "/",
            children: v.jsx(Ot, {
                className: "mt-6 px-6 py-4 bg-white font-semibold rounded-lg shadow-lg  hover:scale-110 transition-transform duration-300",
                label: "Take me Home"
            })
        }), v.jsx("div", {
            className: "mt-10",
            children: v.jsx("img", {
                src: "https://media.giphy.com/media/l378khQxt68syiWJy/giphy.gif",
                alt: "fun gif",
                className: "rounded-full border-4 border-white shadow-md"
            })
        })]
    }),
    _E = m2(Au(v.jsxs(ir, {
        path: "/",
        element: v.jsx(xP, {}),
        children: [v.jsx(ir, {
            path: "/",
            element: v.jsx(TE, {})
        }), v.jsx(ir, {
            path: "/api/v1/noor-e-nazar/about",
            element: v.jsx(CE, {})
        }), v.jsx(ir, {
            path: "/api/v1/noor-e-nazar/Project",
            element: v.jsx(ME, {})
        }), v.jsx(ir, {
            path: "/api/v1/noor-e-nazar/contact",
            element: v.jsx(NE, {})
        }), v.jsx(ir, {
            path: "*",
            element: v.jsx(DE, {})
        })]
    })));
_l.createRoot(document.getElementById("root")).render(v.jsx(v.Fragment, {
    children: v.jsx(P2, {
        router: _E
    })
}));
export {
    Ot as B, bE as F, et as G, Ms as H, rn as L, AE as N, Fp as P, pi as a, BE as b, OE as c, UE as d, zE as e, $E as f, VE as g, HE as h, RE as i, v as j, jE as k, J as m, LE as p, C as r, kE as y
};
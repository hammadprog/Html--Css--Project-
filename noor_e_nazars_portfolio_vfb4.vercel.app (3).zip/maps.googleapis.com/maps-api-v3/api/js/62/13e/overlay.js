google.maps.__gjsload__('overlay', function(_) {
    var Gza = function() {},
        oI = function(a) {
            a.bC = a.bC || new Gza;
            return a.bC
        },
        Hza = function(a) {
            this.Dg = new _.Lq(() => {
                const b = a.bC;
                if (a.getPanes()) {
                    if (a.getProjection()) {
                        if (!b.Fg && a.onAdd) a.onAdd();
                        b.Fg = !0;
                        a.draw()
                    }
                } else {
                    if (b.Fg)
                        if (a.onRemove) a.onRemove();
                        else a.remove();
                    b.Fg = !1
                }
            }, 0)
        },
        Jza = function(a, b) {
            const c = oI(a);
            let d = c.Eg;
            d || (d = c.Eg = new Hza(a));
            _.Mb(c.Dg || [], _.Bn);
            var e = c.Gg = c.Gg || new _.Roa;
            const f = b.__gm;
            e.bindTo("zoom", f);
            e.bindTo("offset", f);
            e.bindTo("center", f, "projectionCenterQ");
            e.bindTo("projection",
                b);
            e.bindTo("projectionTopLeft", f);
            e = c.Ig = c.Ig || new Iza(e);
            e.bindTo("zoom", f);
            e.bindTo("offset", f);
            e.bindTo("projection", b);
            e.bindTo("projectionTopLeft", f);
            a.bindTo("projection", e, "outProjection");
            a.bindTo("panes", f);
            e = () => _.Mq(d.Dg);
            c.Dg = [_.yn(a, "panes_changed", e), _.yn(f, "zoom_changed", e), _.yn(f, "offset_changed", e), _.yn(b, "projection_changed", e), _.yn(f, "projectioncenterq_changed", e)];
            _.Mq(d.Dg);
            b instanceof _.ho ? (_.zo(b, "Ox"), _.M(b, 148440)) : b instanceof _.bp && (_.zo(b, "Oxs"), _.M(b, 181451))
        },
        Kza = function(a) {
            const b =
                oI(a);
            var c = b.Gg;
            c && c.unbindAll();
            (c = b.Ig) && c.unbindAll();
            a.unbindAll();
            a.set("panes", null);
            a.set("projection", null);
            b.Dg && b.Dg.forEach(d => {
                _.Bn(d)
            });
            b.Dg = null;
            b.Eg && (_.Nq(b.Eg.Dg), b.Eg = null)
        },
        Pza = function(a) {
            if (a) {
                var b = a.getMap();
                if (Lza(a) !== b && b && b instanceof _.ho) {
                    const c = b.__gm;
                    c.overlayLayer ? a.__gmop = new Mza(b, a, c.overlayLayer) : c.Eg.then(({
                        ah: d
                    }) => {
                        const e = new Nza(b, d);
                        d.Pi(e);
                        c.overlayLayer = e;
                        Oza(a);
                        Pza(a)
                    })
                }
            }
        },
        Oza = function(a) {
            if (a) {
                var b = a.__gmop;
                b && (a.__gmop = null, b.overlay.unbindAll(), b.overlay.set("panes",
                    null), b.overlay.set("projection", null), b.overlayLayer.vo(b), b.Dg && (b.Dg = !1, b.overlay.onRemove ? b.overlay.onRemove() : b.overlay.remove()))
            }
        },
        Lza = function(a) {
            return (a = a.__gmop) ? a.map : null
        },
        Qza = function(a, b) {
            a.overlay.get("projection") !== b && (a.overlay.bindTo("panes", a.map.__gm), a.overlay.set("projection", b))
        },
        Iza = class extends _.Sn {
            constructor(a) {
                super();
                this.projection = a
            }
            changed(a) {
                a !== "outProjection" && (a = !!(this.get("offset") && this.get("projectionTopLeft") && this.get("projection") && _.pm(this.get("zoom"))),
                    a === !this.get("outProjection") && this.set("outProjection", a ? this.projection : null))
            }
        };
    _.Ja(Hza, _.Sn);
    var Mza = class {
            constructor(a, b, c) {
                this.map = a;
                this.overlay = b;
                this.overlayLayer = c;
                this.Dg = !1;
                _.zo(this.map, "Ox");
                _.M(this.map, 148440);
                c.On(this)
            }
            draw() {
                this.Dg || (this.Dg = !0, this.overlay.onAdd && this.overlay.onAdd());
                this.overlay.draw && this.overlay.draw()
            }
        },
        Nza = class {
            constructor(a, b) {
                this.map = a;
                this.ah = b;
                this.Dg = null;
                this.Eg = []
            }
            dispose() {}
            Ch(a, b, c, d, e, f, g, h) {
                const k = this.Dg = this.Dg || new _.RB(this.map, this.ah, () => {});
                k.Ch(a, b, c, d, e, f, g, h);
                for (const m of this.Eg) Qza(m, k), m.draw()
            }
            On(a) {
                this.Eg.push(a);
                this.Dg &&
                    Qza(a, this.Dg);
                this.ah.refresh()
            }
            vo(a) {
                _.Rb(this.Eg, a)
            }
        };
    _.Ll("overlay", {
        jE: function(a) {
            if (a) {
                Kza(a);
                delete oI(a).Hg;
                Oza(a);
                var b = a.getMap();
                b && (b instanceof _.ho ? Pza(a) : a && (b = a.getMap(), (oI(a).Hg || null) !== b && (b && Jza(a, b), oI(a).Hg = b)))
            }
        },
        preventMapHitsFrom: a => {
            _.ty(a, {
                Hk: ({
                    event: b
                }) => {
                    _.ix(b.Dg)
                },
                Ik: b => {
                    _.ey(b)
                },
                Zq: b => {
                    _.fy(b)
                },
                Kl: b => {
                    _.fy(b)
                },
                Zk: b => {
                    _.gy(b)
                }
            }).sr(!0)
        },
        preventMapHitsAndGesturesFrom: a => {
            a.addEventListener("click", _.wn);
            a.addEventListener("contextmenu", _.wn);
            a.addEventListener("dblclick", _.wn);
            a.addEventListener("mousedown", _.wn);
            a.addEventListener("mousemove",
                _.wn);
            a.addEventListener("MSPointerDown", _.wn);
            a.addEventListener("pointerdown", _.wn);
            a.addEventListener("touchstart", _.wn);
            a.addEventListener("wheel", _.wn)
        }
    });
});
google.maps.__gjsload__('geometry', function(_) {
    var Toa = function(a, b) {
            return Math.abs(_.nm(b - a, -180, 180))
        },
        Uoa = function(a, b, c, d, e) {
            if (!d) {
                c = Toa(a.lng(), c) / Toa(a.lng(), b.lng());
                if (!e) return e = Math.sin(_.ol(a.lat())), e = Math.log((1 + e) / (1 - e)) / 2, b = Math.sin(_.ol(b.lat())), _.pl(2 * Math.atan(Math.exp(e + c * (Math.log((1 + b) / (1 - b)) / 2 - e))) - Math.PI / 2);
                a = e.fromLatLngToPoint(a);
                b = e.fromLatLngToPoint(b);
                return e.fromPointToLatLng(new _.Fo(a.x + c * (b.x - a.x), a.y + c * (b.y - a.y))).lat()
            }
            e = _.ol(a.lat());
            a = _.ol(a.lng());
            d = _.ol(b.lat());
            b = _.ol(b.lng());
            c = _.ol(c);
            return _.nm(_.pl(Math.atan2(Math.sin(e) *
                Math.cos(d) * Math.sin(c - b) - Math.sin(d) * Math.cos(e) * Math.sin(c - a), Math.cos(e) * Math.cos(d) * Math.sin(a - b))), -90, 90)
        },
        Voa = function(a, b) {
            a = new _.hn(a, !1);
            b = new _.hn(b, !1);
            return a.equals(b)
        },
        Woa = function(a, b, c) {
            a = _.on(a);
            c = c || 1E-9;
            const d = _.nm(a.lng(), -180, 180),
                e = b instanceof _.Eu,
                f = !!b.get("geodesic"),
                g = b.get("latLngs");
            b = b.get("map");
            b = !f && b ? b.getProjection() : null;
            for (let r = 0, t = g.getLength(); r < t; ++r) {
                const v = g.getAt(r),
                    w = v.getLength(),
                    y = e ? w : w - 1;
                for (let C = 0; C < y; ++C) {
                    var h = v.getAt(C);
                    const F = v.getAt((C +
                        1) % w);
                    if (Voa(h, a) || Voa(F, a)) return !0;
                    var k = _.nm(h.lng(), -180, 180),
                        m = _.nm(F.lng(), -180, 180);
                    const K = Math.max(k, m),
                        H = Math.min(k, m);
                    if (k = Math.abs(_.nm(k - m, -180, 180)) <= 1E-9 && (Math.abs(_.nm(k - d, -180, 180)) <= c || Math.abs(_.nm(m - d, -180, 180)) <= c)) {
                        k = a.lat();
                        m = Math.min(h.lat(), F.lat()) - c;
                        var p = Math.max(h.lat(), F.lat()) + c;
                        k = k >= m && k <= p
                    }
                    if (k) return !0;
                    if (K - H > 180 ? d + c >= K || d - c <= H : d + c >= H && d - c <= K)
                        if (h = Uoa(h, F, d, f, b), Math.abs(h - a.lat()) < c) return !0
                }
            }
            return !1
        },
        Xoa = function(a, b) {
            const c = _.kn(a);
            a = _.ln(a);
            const d = _.kn(b);
            b = _.ln(b);
            return 2 * Math.asin(Math.sqrt(Math.pow(Math.sin((c - d) / 2), 2) + Math.cos(c) * Math.cos(d) * Math.pow(Math.sin((a - b) / 2), 2)))
        },
        Yoa = function(a, b, c) {
            a = _.on(a);
            b = _.on(b);
            c = c || 6378137;
            return Xoa(a, b) * c
        },
        apa = function(a, b) {
            b = b || 6378137;
            a instanceof _.xp && (a = a.getArray());
            a = (0, _.pt)(a);
            if (a.length === 0) return 0;
            const c = Array(4),
                d = Array(3),
                e = [1, 0, 0, 0],
                f = Array(3);
            Zoa(a[a.length - 1], f);
            for (let v = 0; v < a.length; ++v) Zoa(a[v], d), cD(f, d, c), $oa(c, e, e), [f[0], f[1], f[2]] = d;
            const [g, h, k] = f, [m, p, r, t] = e;
            return 2 * Math.atan2(g *
                p + h * r + k * t, m) * (b * b)
        },
        bpa = function(a, b) {
            if (isFinite(a)) {
                var c = a % 360;
                a = Math.round(c / 90);
                c -= a * 90;
                if (c === 30 || c === -30) {
                    c = Math.sign(c) * .5;
                    var d = Math.sqrt(.75)
                } else c === 45 || c === -45 ? (c = Math.sign(c) * Math.SQRT1_2, d = Math.SQRT1_2) : (d = c / 180 * Math.PI, c = Math.sin(d), d = Math.cos(d));
                switch (a & 3) {
                    case 0:
                        b[0] = c;
                        b[1] = d;
                        break;
                    case 1:
                        b[0] = d;
                        b[1] = -c;
                        break;
                    case 2:
                        b[0] = -c;
                        b[1] = -d;
                        break;
                    default:
                        b[0] = -d, b[1] = c
                }
            } else b[0] = NaN, b[1] = NaN
        },
        Zoa = function(a, b) {
            const c = Array(2);
            bpa(a.lat(), c);
            const [d, e] = c;
            bpa(a.lng(), c);
            const [f, g] = c;
            b[0] = e * g;
            b[1] = e * f;
            b[2] = d
        },
        $oa = function(a, b, c) {
            const d = a[0] * b[1] + a[1] * b[0] + a[2] * b[3] - a[3] * b[2],
                e = a[0] * b[2] - a[1] * b[3] + a[2] * b[0] + a[3] * b[1],
                f = a[0] * b[3] + a[1] * b[2] - a[2] * b[1] + a[3] * b[0];
            c[0] = a[0] * b[0] - a[1] * b[1] - a[2] * b[2] - a[3] * b[3];
            c[1] = d;
            c[2] = e;
            c[3] = f
        },
        cD = function(a, b, c) {
            var d = a[0] - b[0],
                e = a[1] - b[1],
                f = a[2] - b[2];
            const g = a[0] + b[0],
                h = a[1] + b[1],
                k = a[2] + b[2];
            var m = g * g + h * h + k * k,
                p = e * k - f * h;
            f = f * g - d * k;
            d = d * h - e * g;
            e = m * m + p * p + f * f + d * d;
            if (e !== 0) b = Math.sqrt(e), c[0] = m / b, c[1] = p / b, c[2] = f / b, c[3] = d / b;
            else {
                a: for (m = [a[0] - b[0], a[1] -
                        b[1], a[2] - b[2]
                    ], p = 0; p < 3; ++p)
                    if (m[p] !== 0) {
                        if (m[p] < 0) {
                            m = [-m[0], -m[1], -m[2]];
                            break a
                        }
                        break
                    }p = 0;
                for (f = 1; f < m.length; ++f) Math.abs(m[f]) < Math.abs(m[p]) && (p = f);f = [0, 0, 0];f[p] = 1;m = [m[1] * f[2] - m[2] * f[1], m[2] * f[0] - m[0] * f[2], m[0] * f[1] - m[1] * f[0]];p = Math.hypot(...m);m = [m[0] / p, m[1] / p, m[2] / p];p = Array(4);cD(a, m, p);a = Array(4);cD(m, b, a);$oa(a, p, c)
            }
        },
        dD = class {};
    dD.isLocationOnEdge = Woa;
    dD.containsLocation = function(a, b) {
        a = _.on(a);
        const c = _.nm(a.lng(), -180, 180),
            d = !!b.get("geodesic"),
            e = b.get("latLngs");
        var f = b.get("map");
        f = !d && f ? f.getProjection() : null;
        let g = !1;
        for (let k = 0, m = e.getLength(); k < m; ++k) {
            const p = e.getAt(k);
            for (let r = 0, t = p.getLength(); r < t; ++r) {
                const v = p.getAt(r),
                    w = p.getAt((r + 1) % t);
                var h = _.nm(v.lng(), -180, 180);
                const y = _.nm(w.lng(), -180, 180),
                    C = Math.max(h, y);
                h = Math.min(h, y);
                (C - h > 180 ? c >= C || c < h : c < C && c >= h) && Uoa(v, w, c, d, f) < a.lat() && (g = !g)
            }
        }
        return g || Woa(a, b)
    };
    var eD = class {};
    eD.computeSignedArea = apa;
    eD.computeArea = function(a, b) {
        if (!(a instanceof _.xp || Array.isArray(a) || a instanceof _.oo || a instanceof _.Ep)) try {
            a = _.no(a)
        } catch (c) {
            try {
                a = new _.Ep((0, _.fea)(a))
            } catch (d) {
                throw _.Lm("Invalid path passed to computeArea(): " + JSON.stringify(a));
            }
        }
        b = b || 6378137;
        if (a instanceof _.Ep) {
            if (a.getRadius() === void 0) throw _.Lm("Invalid path passed to computeArea(): Circle is missing radius.");
            if (a.getRadius() < 0) throw _.Lm("Invalid path passed to computeArea(): Circle must have non-negative radius.");
            if (b < 0) throw _.Lm("Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative.");
            if (a.getRadius() > Math.PI * b) throw _.Lm("Invalid path passed to computeArea(): Circle must not cover more than 100% of the sphere.");
            return 2 * Math.PI * b ** 2 * (1 - Math.cos(a.getRadius() / b))
        }
        if (a instanceof _.oo) {
            if (b < 0) throw _.Lm("Invalid radiusOfSphere passed to computeArea(): radiusOfSphere must be non-negative.");
            if (a.si.lo > a.si.hi) throw _.Lm("Invalid path passed to computeArea(): the southern LatLng of a LatLngBounds cannot be more north than the northern LatLng.");
            let c = 2 * Math.PI * b ** 2 * (1 - Math.cos((a.si.lo -
                90) * Math.PI / 180));
            c -= 2 * Math.PI * b ** 2 * (1 - Math.cos((a.si.hi - 90) * Math.PI / 180));
            return c * Math.abs(a.Mh.hi - a.Mh.lo) / 360
        }
        return Math.abs(apa(a, b))
    };
    eD.computeLength = function(a, b) {
        b = b || 6378137;
        let c = 0;
        a instanceof _.xp && (a = a.getArray());
        for (let d = 0, e = a.length - 1; d < e; ++d) c += Yoa(a[d], a[d + 1], b);
        return c
    };
    eD.computeDistanceBetween = Yoa;
    eD.interpolate = function(a, b, c) {
        a = _.on(a);
        b = _.on(b);
        const d = _.kn(a);
        var e = _.ln(a);
        const f = _.kn(b),
            g = _.ln(b),
            h = Math.cos(d),
            k = Math.cos(f);
        b = Xoa(a, b);
        const m = Math.sin(b);
        if (m < 1E-6) return new _.hn(a.lat(), a.lng());
        a = Math.sin((1 - c) * b) / m;
        c = Math.sin(c * b) / m;
        b = a * h * Math.cos(e) + c * k * Math.cos(g);
        e = a * h * Math.sin(e) + c * k * Math.sin(g);
        return new _.hn(_.pl(Math.atan2(a * Math.sin(d) + c * Math.sin(f), Math.sqrt(b * b + e * e))), _.pl(Math.atan2(e, b)))
    };
    eD.computeOffsetOrigin = function(a, b, c, d) {
        a = _.on(a);
        c = _.ol(c);
        b /= d || 6378137;
        d = Math.cos(b);
        const e = Math.sin(b) * Math.cos(c);
        b = Math.sin(b) * Math.sin(c);
        c = Math.sin(_.kn(a));
        const f = e * e * d * d + d * d * d * d - d * d * c * c;
        if (f < 0) return null;
        var g = e * c + Math.sqrt(f);
        g /= d * d + e * e;
        const h = (c - e * g) / d;
        g = Math.atan2(h, g);
        if (g < -Math.PI / 2 || g > Math.PI / 2) g = e * c - Math.sqrt(f), g = Math.atan2(h, g / (d * d + e * e));
        if (g < -Math.PI / 2 || g > Math.PI / 2) return null;
        a = _.ln(a) - Math.atan2(b, d * Math.cos(g) - e * Math.sin(g));
        return new _.hn(_.pl(g), _.pl(a))
    };
    eD.computeOffset = function(a, b, c, d) {
        a = _.on(a);
        b /= d || 6378137;
        c = _.ol(c);
        var e = _.kn(a);
        a = _.ln(a);
        d = Math.cos(b);
        b = Math.sin(b);
        const f = Math.sin(e);
        e = Math.cos(e);
        const g = d * f + b * e * Math.cos(c);
        return new _.hn(_.pl(Math.asin(g)), _.pl(a + Math.atan2(b * e * Math.sin(c), d - f * g)))
    };
    eD.computeHeading = function(a, b) {
        a = _.on(a);
        b = _.on(b);
        const c = _.kn(a),
            d = _.ln(a);
        a = _.kn(b);
        b = _.ln(b) - d;
        return _.nm(_.pl(Math.atan2(Math.sin(b) * Math.cos(a), Math.cos(c) * Math.sin(a) - Math.sin(c) * Math.cos(a) * Math.cos(b))), -180, 180)
    };
    var cpa = {
        encoding: _.Vu,
        spherical: eD,
        poly: dD
    };
    _.pa.google.maps.geometry = cpa;
    _.Ll("geometry", cpa);
});